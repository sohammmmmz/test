"""Sync orchestration.

One entry point shared by all three triggers — the nightly schedule, the manual
button, and webhook deliveries. They differ only in the ``trigger`` recorded and
the size of the window re-fetched.

Stages are deliberately independent: one failing marks the run PARTIAL and the
rest continue. A single repo with a revoked token should not stop the other
nineteen from syncing, and a run that dies silently at 2am is indistinguishable
from a quiet night.
"""

from __future__ import annotations

import logging

from django.db import transaction
from django.utils import timezone

from common import cache
from projects.models import Project
from sync.models import RunStatus, SyncRun, SyncScope, TriggerSource
from team.identity import AuthorResolver

from .syncers import (
    commit_window,
    refresh_repo_metadata,
    sync_branches,
    sync_commits,
    sync_issues,
    sync_members,
    sync_merge_requests,
    sync_milestones,
)

logger = logging.getLogger(__name__)


def sync_project(
    project: Project,
    *,
    trigger: str = TriggerSource.MANUAL,
    triggered_by=None,
    parent: SyncRun | None = None,
    full: bool = False,
    window_days: int | None = None,
    client=None,
    run_scoring: bool = True,
) -> SyncRun:
    """Run every sync stage for one project and return the recorded run.

    ``window_days`` narrows only the commit window; every other stage —
    branches, members, merge requests, the vault, compliance — runs exactly as
    it always does. A quick sync is meant to be a cheaper version of the same
    operation, not a different one that leaves half the record stale.
    """
    from gitlab_integration.client import GitLabClient

    run = SyncRun.objects.create(
        project=project,
        parent=parent,
        scope=SyncScope.PROJECT,
        employee=getattr(parent, "employee", None),
        trigger=trigger,
        triggered_by=triggered_by,
        status=RunStatus.RUNNING,
        started_at=timezone.now(),
    )

    repo = getattr(project, "repo", None)
    if repo is None:
        # Should be unreachable: a repository is mandatory at registration.
        run.record_error("setup", "Project has no GitLab repository.")
        _finish(run, RunStatus.FAILED)
        return run

    client = client or GitLabClient.for_service()
    resolver = AuthorResolver()
    since, until = commit_window(repo, full=full, days=window_days)
    run.window_start, run.window_end = since, until

    stages = [
        ("repo", lambda: refresh_repo_metadata(repo, client)),
        ("milestones", lambda: sync_milestones(repo, client)),
        ("commits", lambda: sync_commits(repo, client, resolver, since=since, until=until)),
        ("branches", lambda: sync_branches(repo, client, resolver)),
        ("issues", lambda: sync_issues(repo, client, resolver, updated_after=since)),
        (
            "merge_requests",
            lambda: sync_merge_requests(repo, client, resolver, updated_after=since),
        ),
        ("members", lambda: sync_members(repo, client, resolver)),
    ]

    failed_stages = 0
    for name, runner in stages:
        try:
            outcome = runner()
        except Exception as exc:  # noqa: BLE001 - stage isolation is the point
            failed_stages += 1
            logger.exception("Sync stage %s failed for %s", name, project.name)
            run.record_error(name, str(exc))
        else:
            if outcome is not None and hasattr(outcome, "as_dict"):
                run.record_stage(name, **outcome.as_dict())

    unmapped = resolver.flush_unmapped()
    if unmapped:
        run.record_stage("identity", unmapped_authors=unmapped)

    # Downstream stages read what the ones above just wrote.
    for name, runner in (
        ("vault", lambda: _regenerate_vault(project, run)),
        ("compliance", lambda: _evaluate_compliance(project, run)),
    ):
        try:
            outcome = runner()
        except Exception as exc:  # noqa: BLE001
            failed_stages += 1
            logger.exception("Sync stage %s failed for %s", name, project.name)
            run.record_error(name, str(exc))
        else:
            if isinstance(outcome, dict):
                run.record_stage(name, **outcome)

    if run_scoring:
        try:
            queued = _enqueue_scoring(project, run)
            run.record_stage("scoring", queued=queued)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Queueing scoring failed for %s", project.name)
            run.record_error("scoring", str(exc))

    _refresh_project_activity(project)

    status = RunStatus.SUCCESS if failed_stages == 0 else RunStatus.PARTIAL
    _finish(run, status)
    return run


def sync_projects(
    projects,
    *,
    scope: str,
    trigger: str = TriggerSource.SCHEDULE,
    triggered_by=None,
    employee=None,
    full: bool = False,
    window_days: int | None = None,
) -> SyncRun:
    """Sync a set of projects under one parent run, one child run each.

    The shared body of every multi-project sync — the fleet, a person's
    repositories, a hand-picked selection. Kept as one function because the
    interesting part is the failure accounting, and three copies of that would
    eventually disagree about what "partial" means.
    """
    projects = list(projects)
    parent = SyncRun.objects.create(
        scope=scope,
        employee=employee,
        trigger=trigger,
        triggered_by=triggered_by,
        status=RunStatus.RUNNING,
        started_at=timezone.now(),
    )

    succeeded = partial = failed = 0

    for project in projects:
        try:
            child = sync_project(
                project,
                trigger=trigger,
                triggered_by=triggered_by,
                parent=parent,
                full=full,
                window_days=window_days,
            )
        except Exception as exc:  # noqa: BLE001 - one repo must not stop the rest
            failed += 1
            logger.exception("Sync failed outright for %s", project.name)
            parent.record_error("project", str(exc), project=project.name)
            continue

        if child.status == RunStatus.SUCCESS:
            succeeded += 1
        elif child.status == RunStatus.PARTIAL:
            partial += 1
        else:
            failed += 1

    parent.record_stage(
        "projects",
        total=len(projects),
        succeeded=succeeded,
        partial=partial,
        failed=failed,
    )

    if not projects:
        # Nothing to do is not a failure, but it must not read as a green sync
        # either — someone asked for work that had no targets, and that is worth
        # seeing on the history.
        parent.record_error("scope", "No projects matched this request.")
        _finish(parent, RunStatus.PARTIAL)
        return parent

    if failed == 0 and partial == 0:
        status = RunStatus.SUCCESS
    elif succeeded == 0 and partial == 0 and failed:
        status = RunStatus.FAILED
    else:
        status = RunStatus.PARTIAL

    _finish(parent, status)
    return parent


def sync_all_projects(
    *,
    trigger: str = TriggerSource.SCHEDULE,
    triggered_by=None,
    full: bool = False,
    window_days: int | None = None,
) -> SyncRun:
    """Fleet-wide sync. Each project gets its own child run."""
    return sync_projects(
        Project.objects.select_related("repo").exclude(status="archived"),
        scope=SyncScope.ALL_PROJECTS,
        trigger=trigger,
        triggered_by=triggered_by,
        full=full,
        window_days=window_days,
    )


def projects_for_employee(employee) -> list[Project]:
    """Every project a person's work could appear in.

    GitLab has no "fetch this person's commits" endpoint — commits belong to
    repositories, not to people — so syncing a member means syncing the
    repositories they are attached to and then attributing what comes back.

    Attachment is read from both sides deliberately. Repository membership is
    synced from GitLab and is the ground truth for access; assignments are typed
    by hand and are the ground truth for intent. Someone can easily have one
    without the other, and syncing only the intersection would quietly skip the
    repository their commits are actually in.
    """
    from activity.models import ProjectMember
    from team.models import Assignment

    member_project_ids = set(
        ProjectMember.objects.filter(employee=employee)
        .values_list("repo__project_id", flat=True)
    )
    assigned_project_ids = set(
        Assignment.objects.filter(employee=employee).values_list("project_id", flat=True)
    )

    ids = {pid for pid in member_project_ids | assigned_project_ids if pid}
    return list(
        Project.objects.select_related("repo")
        .filter(pk__in=ids)
        .exclude(status="archived")
        .order_by("name")
    )


def sync_employee(
    employee,
    *,
    trigger: str = TriggerSource.MANUAL,
    triggered_by=None,
    full: bool = False,
    window_days: int | None = None,
) -> SyncRun:
    """Bring one person's activity up to date across all their repositories."""
    run = sync_projects(
        projects_for_employee(employee),
        scope=SyncScope.EMPLOYEE,
        employee=employee,
        trigger=trigger,
        triggered_by=triggered_by,
        full=full,
        window_days=window_days,
    )
    _attribute(run)
    return run


def sync_all_employees(
    *,
    trigger: str = TriggerSource.MANUAL,
    triggered_by=None,
    full: bool = False,
    window_days: int | None = None,
) -> SyncRun:
    """Every repository any active person is attached to.

    Not the same as a fleet sync, and the difference is the point: a project
    nobody is on contributes nothing to anyone's utilisation, so it is not worth
    the API calls when the question being asked is about people.
    """
    from team.models import Employee

    projects: dict[int, Project] = {}
    for employee in Employee.objects.filter(is_active=True):
        for project in projects_for_employee(employee):
            projects[project.pk] = project

    run = sync_projects(
        sorted(projects.values(), key=lambda p: p.name),
        scope=SyncScope.ALL_EMPLOYEES,
        trigger=trigger,
        triggered_by=triggered_by,
        full=full,
        window_days=window_days,
    )
    _attribute(run)
    return run


def _attribute(run: SyncRun) -> None:
    """Re-run attribution over anything still credited to nobody.

    Belongs to the person-scoped syncs specifically. A sync only attributes the
    commits it fetched, but the reason someone asked to sync a person is very
    often that this person's commits were *not* showing up — so the useful thing
    to do afterwards is re-decide the unattributed backlog with whatever the
    roster now says. It is a local pass with no GitLab calls.
    """
    from team.identity import reattribute_activity

    try:
        result = reattribute_activity(only_unattributed=True)
    except Exception as exc:  # noqa: BLE001 - the sync itself already succeeded
        logger.exception("Re-attribution after a person sync failed")
        run.record_error("identity", str(exc))
    else:
        run.record_stage("identity", **result)
    run.save(update_fields=["stage_counts", "errors", "updated_at"])


# ---------------------------------------------------------------------------
# Stage helpers — imported lazily so this module stays importable standalone.
# ---------------------------------------------------------------------------


def _regenerate_vault(project: Project, run: SyncRun) -> dict:
    from vault.generator import regenerate_vault

    snapshot = regenerate_vault(project, sync_run=run)
    return {
        "nodes": snapshot.node_count,
        "edges": snapshot.edge_count,
        "dangling": snapshot.dangling_edge_count,
        "committed": bool(snapshot.commit_sha),
    }


def _evaluate_compliance(project: Project, run: SyncRun) -> dict:
    from compliance.engine import evaluate_project

    evaluations = evaluate_project(project, sync_run=run)
    return {
        "rules": len(evaluations),
        "passed": sum(1 for e in evaluations if e.passed),
        "failed": sum(1 for e in evaluations if not e.passed),
    }


def _enqueue_scoring(project: Project, run: SyncRun) -> int:
    from scoring.pipeline import enqueue_unscored_commits

    return enqueue_unscored_commits(project, sync_run=run)


def _refresh_project_activity(project: Project) -> None:
    """Denormalise the latest activity timestamp for cheap list views."""
    from django.db.models import Max

    from activity.models import Commit

    latest = Commit.objects.filter(repo__project=project).aggregate(
        latest=Max("authored_date")
    )["latest"]

    Project.objects.filter(pk=project.pk).update(
        last_activity_at=latest, last_synced_at=timezone.now()
    )


def _finish(run: SyncRun, status: str) -> None:
    run.status = status
    run.finished_at = timezone.now()
    with transaction.atomic():
        run.save()

    # Every cached dashboard is derived from what this run just wrote, so it is
    # all retired here — including after a failed run, which may still have
    # committed several stages before falling over. One bump is cheaper than
    # working out which stages produced which screens, and being wrong about
    # that means serving numbers that are quietly out of date.
    cache.bump(cache.ACTIVITY, cache.PROJECTS, cache.SCORING, cache.TEAM)
