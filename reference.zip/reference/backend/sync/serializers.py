from rest_framework import serializers

from .models import SyncRun, SyncScope, WebhookEvent


class SyncRunSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source="project.name", read_only=True)
    project_slug = serializers.CharField(source="project.slug", read_only=True)
    triggered_by_name = serializers.CharField(
        source="triggered_by.username", read_only=True
    )
    duration_seconds = serializers.FloatField(read_only=True)
    error_count = serializers.SerializerMethodField()

    class Meta:
        model = SyncRun
        fields = [
            "id", "project", "project_name", "project_slug", "parent", "trigger",
            "triggered_by", "triggered_by_name", "status", "window_start", "window_end",
            "started_at", "finished_at", "duration_seconds", "stage_counts", "errors",
            "error_count", "created_at",
        ]

    def get_error_count(self, obj) -> int:
        return len(obj.errors or [])


class SyncRunSummarySerializer(serializers.ModelSerializer):
    """A run as a list row: enough to see what happened, no payload.

    ``stage_counts`` and ``errors`` are unbounded JSON — a fleet run over twenty
    repositories carries a lot of both — and the history table shows neither in
    full. Serializing them for every row made the sync screen the slowest in
    the app for no visible benefit.
    """

    project_name = serializers.CharField(source="project.name", read_only=True)
    project_slug = serializers.CharField(source="project.slug", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    triggered_by_name = serializers.CharField(
        source="triggered_by.username", read_only=True
    )
    duration_seconds = serializers.FloatField(read_only=True)
    error_count = serializers.SerializerMethodField()
    error_stages = serializers.SerializerMethodField()
    changes = serializers.SerializerMethodField()
    scope_label = serializers.SerializerMethodField()

    class Meta:
        model = SyncRun
        fields = [
            "id", "project", "project_name", "project_slug", "employee",
            "employee_name", "scope", "scope_label", "parent", "trigger",
            "triggered_by_name", "status", "started_at", "finished_at",
            "duration_seconds", "error_count", "error_stages", "changes", "created_at",
        ]

    def get_scope_label(self, obj) -> str:
        """What this run covered, in the words the sync page uses.

        Built here rather than in the browser because the answer depends on
        which of ``project``/``employee`` is set as well as on ``scope``, and
        that is backend knowledge.
        """
        if obj.employee_id and obj.scope == SyncScope.EMPLOYEE:
            return getattr(obj.employee, "full_name", "One team member")
        if obj.scope == SyncScope.ALL_EMPLOYEES:
            return "All team members"
        if obj.project_id:
            return getattr(obj.project, "name", "One project")
        return "All projects"

    def get_error_count(self, obj) -> int:
        return len(obj.errors or [])

    def get_error_stages(self, obj) -> list[str]:
        return sorted({e.get("stage", "") for e in (obj.errors or []) if e.get("stage")})

    def get_changes(self, obj) -> dict:
        """{stage: rows written} for stages that actually wrote something.

        Computed here rather than in the browser so the full counts never cross
        the wire.
        """
        return {
            stage: (counts.get("created") or 0) + (counts.get("updated") or 0)
            for stage, counts in (obj.stage_counts or {}).items()
            if isinstance(counts, dict)
            and (counts.get("created") or 0) + (counts.get("updated") or 0) > 0
        }


class WebhookEventSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source="project.name", read_only=True)

    class Meta:
        model = WebhookEvent
        fields = [
            "id", "event_type", "gitlab_event_uuid", "gitlab_project_id", "project",
            "project_name", "signature_verified", "received_at", "processed_at",
            "process_error",
        ]
