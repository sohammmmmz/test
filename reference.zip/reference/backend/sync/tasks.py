"""Celery tasks.

The nightly schedule, the manual sync button and webhook deliveries all funnel
into the same idempotent pipeline; only the recorded trigger and the size of the
re-fetched window differ.
"""

from __future__ import annotations

import logging

from celery import shared_task
from django.utils import timezone

from projects.models import Project
from sync.models import RunStatus, SyncRun, TriggerSource, WebhookEvent

logger = logging.getLogger(__name__)


@shared_task(name="sync.nightly_sync", bind=True)
def nightly_sync(self, full: bool = False) -> dict:
    """The scheduled fleet-wide sync.

    Also the reconciliation pass for webhooks: GitLab drops the push event
    entirely when a single push touches more than three branches, so without
    this sweep those commits would never arrive.
    """
    from sync.pipeline import sync_all_projects

    run = sync_all_projects(trigger=TriggerSource.SCHEDULE, full=full)
    run.celery_task_id = self.request.id or ""
    run.save(update_fields=["celery_task_id", "updated_at"])

    score_pending_commits.delay()
    refresh_utilization.delay()

    return {"sync_run_id": run.id, "status": run.status, "stages": run.stage_counts}


@shared_task(name="sync.sync_one_project", bind=True)
def sync_one_project(
    self, project_id: int, trigger: str = TriggerSource.MANUAL, user_id: int | None = None,
    full: bool = False, window_days: int | None = None,
) -> dict:
    """Sync a single project, used by the manual button and webhooks."""
    from accounts.models import User
    from sync.pipeline import sync_project

    project = Project.objects.select_related("repo").filter(pk=project_id).first()
    if project is None:
        return {"error": f"Project {project_id} no longer exists."}

    user = User.objects.filter(pk=user_id).first() if user_id else None
    run = sync_project(
        project, trigger=trigger, triggered_by=user, full=full, window_days=window_days
    )
    run.celery_task_id = self.request.id or ""
    run.save(update_fields=["celery_task_id", "updated_at"])

    score_pending_commits.delay(project_id=project_id)

    return {"sync_run_id": run.id, "status": run.status, "stages": run.stage_counts}


@shared_task(name="sync.sync_all_projects", bind=True)
def sync_all_projects_task(
    self, user_id: int | None = None, full: bool = False, window_days: int | None = None
) -> dict:
    """Every registered project, on demand rather than on the schedule.

    Distinct from ``nightly_sync`` so a button press is not recorded as a
    scheduled run — the history is the place people go to work out why a number
    changed, and mislabelling who asked for it defeats that.
    """
    from accounts.models import User
    from sync.pipeline import sync_all_projects

    user = User.objects.filter(pk=user_id).first() if user_id else None
    run = sync_all_projects(
        trigger=TriggerSource.MANUAL, triggered_by=user, full=full, window_days=window_days
    )
    run.celery_task_id = self.request.id or ""
    run.save(update_fields=["celery_task_id", "updated_at"])

    score_pending_commits.delay()
    refresh_utilization.delay()
    return {"sync_run_id": run.id, "status": run.status, "stages": run.stage_counts}


@shared_task(name="sync.sync_one_employee", bind=True)
def sync_one_employee(
    self, employee_id: int, user_id: int | None = None, full: bool = False,
    window_days: int | None = None,
) -> dict:
    """Bring one person's activity up to date across their repositories."""
    from accounts.models import User
    from sync.pipeline import sync_employee
    from team.models import Employee

    employee = Employee.objects.filter(pk=employee_id).first()
    if employee is None:
        return {"error": f"Employee {employee_id} no longer exists."}

    user = User.objects.filter(pk=user_id).first() if user_id else None
    run = sync_employee(
        employee, trigger=TriggerSource.MANUAL, triggered_by=user,
        full=full, window_days=window_days,
    )
    run.celery_task_id = self.request.id or ""
    run.save(update_fields=["celery_task_id", "updated_at"])

    score_pending_commits.delay()
    return {"sync_run_id": run.id, "status": run.status, "stages": run.stage_counts}


@shared_task(name="sync.sync_all_employees", bind=True)
def sync_all_employees_task(
    self, user_id: int | None = None, full: bool = False, window_days: int | None = None
) -> dict:
    """Every repository any active person is attached to."""
    from accounts.models import User
    from sync.pipeline import sync_all_employees

    user = User.objects.filter(pk=user_id).first() if user_id else None
    run = sync_all_employees(
        trigger=TriggerSource.MANUAL, triggered_by=user, full=full, window_days=window_days
    )
    run.celery_task_id = self.request.id or ""
    run.save(update_fields=["celery_task_id", "updated_at"])

    score_pending_commits.delay()
    refresh_utilization.delay()
    return {"sync_run_id": run.id, "status": run.status, "stages": run.stage_counts}


@shared_task(name="sync.process_webhook_event")
def process_webhook_event(event_id: int) -> dict:
    """Turn a stored webhook delivery into a targeted sync."""
    event = WebhookEvent.objects.filter(pk=event_id).first()
    if event is None:
        return {"error": f"Webhook event {event_id} not found."}
    if event.processed_at:
        return {"skipped": "already processed"}

    try:
        project = event.project
        if project is None:
            from gitlab_integration.webhooks import extract_project_id

            gitlab_project_id = extract_project_id(event.payload)
            project = Project.objects.filter(
                repo__gitlab_project_id=gitlab_project_id
            ).first()

        if project is None:
            # A hook fires for every project in the group, including ones this
            # tool does not track. Not an error.
            event.processed_at = timezone.now()
            event.process_error = "No registered project matches this repository."
            event.save(update_fields=["processed_at", "process_error", "updated_at"])
            return {"skipped": "untracked project"}

        event.project = project
        sync_one_project(project.pk, trigger=TriggerSource.WEBHOOK)

        event.processed_at = timezone.now()
        event.save(update_fields=["project", "processed_at", "updated_at"])
        return {"project": project.slug}

    except Exception as exc:  # noqa: BLE001 - recorded, not swallowed
        logger.exception("Webhook processing failed for event %s", event_id)
        event.process_error = str(exc)
        event.processed_at = timezone.now()
        event.save(update_fields=["process_error", "processed_at", "updated_at"])
        return {"error": str(exc)}


@shared_task(name="scoring.score_pending_commits")
def score_pending_commits(project_id: int | None = None, limit: int | None = None) -> dict:
    """Score queued commits and refresh the daily rollups."""
    from scoring.pipeline import rollup_daily_scores, score_pending

    project = Project.objects.filter(pk=project_id).first() if project_id else None
    counts = score_pending(project=project, limit=limit)

    projects = [project] if project else Project.objects.select_related("repo").all()
    for item in projects:
        if item is not None:
            rollup_daily_scores(item)

    return counts


@shared_task(name="scoring.refresh_utilization")
def refresh_utilization(period_days: int = 14) -> dict:
    from scoring.pipeline import compute_utilization

    return {"snapshots": compute_utilization(period_days=period_days)}


@shared_task(name="scoring.summarize_documents")
def summarize_documents(limit: int = 20) -> dict:
    """Extract BRD/technical summaries so scoring has business context.

    Gemini reads PDFs natively, so this turns an uploaded requirements document
    into something a relevance judgment can actually be made against.
    """
    from gitlab_integration.client import GitLabClient
    from projects.models import Document
    from scoring.gemini import get_scorer

    pending = Document.objects.filter(summary="").select_related("project__repo")[:limit]
    scorer = get_scorer()
    client = GitLabClient.for_service()
    done = failed = 0

    for document in pending:
        repo = getattr(document.project, "repo", None)
        if repo is None:
            continue
        try:
            import base64

            from django.conf import settings as dj_settings

            payload = client.get_file(
                repo.gitlab_project_id, document.repo_path, dj_settings.DOCUMENTATION_BRANCH
            )
            raw = base64.b64decode(payload.get("content", ""))
            summary = scorer.summarize_document(
                raw, document.content_type or "application/pdf", document.filename
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Summarising %s failed: %s", document.repo_path, exc)
            failed += 1
            continue

        if summary:
            document.summary = summary
            document.summary_model_version = getattr(scorer, "model", "")
            document.summary_generated_at = timezone.now()
            document.save(
                update_fields=[
                    "summary", "summary_model_version", "summary_generated_at", "updated_at",
                ]
            )
            done += 1

    return {"summarized": done, "failed": failed}


@shared_task(name="sync.register_group_webhook")
def register_group_webhook() -> dict:
    from gitlab_integration.webhooks import ensure_group_webhook

    record = ensure_group_webhook()
    if record is None:
        return {"registered": False, "reason": "not configured"}
    return {
        "registered": bool(record.gitlab_hook_id),
        "hook_id": record.gitlab_hook_id,
        "error": record.last_error,
    }


@shared_task(name="sync.prune_sync_history")
def prune_sync_history(keep_days: int = 90) -> dict:
    """Trim old runs and processed webhook deliveries."""
    from datetime import timedelta

    cutoff = timezone.now() - timedelta(days=keep_days)
    runs, _ = SyncRun.objects.filter(
        created_at__lt=cutoff, status__in=[RunStatus.SUCCESS, RunStatus.PARTIAL]
    ).delete()
    events, _ = WebhookEvent.objects.filter(
        received_at__lt=cutoff, processed_at__isnull=False
    ).delete()
    return {"sync_runs_deleted": runs, "webhook_events_deleted": events}


@shared_task(name="vault.index_project_code")
def index_project_code_task(project_id: int, force: bool = False) -> dict:
    """Index a project's codebase into structured records.

    Queued at registration so the code map exists before the first commits are
    scored — without it, relevance can only be judged from the commit message.
    """
    from vault.indexer import index_project_code

    project = Project.objects.select_related("repo").filter(pk=project_id).first()
    if project is None:
        return {"error": f"Project {project_id} no longer exists."}

    run = index_project_code(project, force=force)
    return {
        "run_id": run.id,
        "status": run.status,
        "files_indexed": run.files_indexed,
        "files_unchanged": run.files_unchanged,
        "symbols": run.symbols_extracted,
    }
