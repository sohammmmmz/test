"""What the sync screen is allowed to hide, and how much it may cost.

Two complaints are pinned here. Runs "sometimes not showing up" was a filter:
per-project runs inside a fleet sync were excluded from the list entirely, so a
repository that failed inside an otherwise-green nightly run was unfindable.
And the endpoint is polled while a sync is in flight, so it must not open a
Redis connection or serialise unbounded JSON on every request.
"""

import pytest
from django.core.cache import cache
from django.utils import timezone

from sync.models import RunStatus, SyncRun, TriggerSource

pytestmark = pytest.mark.django_db


@pytest.fixture(autouse=True)
def _clear_probe_cache():
    cache.clear()
    yield
    cache.clear()


def _run(project=None, parent=None, status=RunStatus.SUCCESS, **extra):
    return SyncRun.objects.create(
        project=project,
        parent=parent,
        trigger=TriggerSource.SCHEDULE,
        status=status,
        started_at=timezone.now(),
        finished_at=timezone.now(),
        **extra,
    )


class TestChildRunsAreVisible:
    """A fleet sync showed one row and hid every run that did the actual work.

    Children are reachable rather than inlined: the list says how many there
    are, and they are fetched when a row is expanded. Sending twenty rows of
    unbounded stage JSON on every three-second poll, for rows nobody had opened,
    was the single largest cost on this page.
    """

    def test_the_parent_says_how_many_children_it_has(self, api_client, project):
        fleet = _run()
        _run(project=project, parent=fleet, status=RunStatus.FAILED)

        response = api_client.get("/api/sync/status")

        assert len(response.data["recent"]) == 1, "children do not get their own row"
        assert response.data["recent"][0]["child_count"] == 1

    def test_the_children_are_reachable(self, api_client, project):
        fleet = _run()
        _run(project=project, parent=fleet, status=RunStatus.FAILED)

        children = api_client.get(f"/api/sync/runs/{fleet.id}/children").data

        assert len(children) == 1
        assert children[0]["status"] == "failed"
        assert children[0]["project_name"] == project.name

    def test_children_are_not_inlined_into_the_polled_response(
        self, api_client, project
    ):
        fleet = _run()
        _run(project=project, parent=fleet)

        row = api_client.get("/api/sync/status").data["recent"][0]

        assert "children" not in row, "the poll must stay cheap"

    def test_a_standalone_run_still_appears(self, api_client, project):
        _run(project=project)

        response = api_client.get("/api/sync/status")

        assert len(response.data["recent"]) == 1
        assert response.data["recent"][0]["child_count"] == 0

    def test_a_failing_repo_inside_a_green_fleet_run_is_findable(
        self, api_client, project
    ):
        fleet = _run(status=RunStatus.PARTIAL)
        _run(
            project=project,
            parent=fleet,
            status=RunStatus.FAILED,
            errors=[{"stage": "commits", "message": "401 Unauthorized"}],
        )

        child = api_client.get(f"/api/sync/runs/{fleet.id}/children").data[0]

        assert child["error_count"] == 1
        assert child["error_stages"] == ["commits"]


class TestPayloadIsBounded:
    def test_the_full_stage_counts_never_cross_the_wire(self, api_client, project):
        _run(
            project=project,
            stage_counts={
                "commits": {"created": 3, "updated": 1, "skipped": 0},
                "branches": {"created": 0, "updated": 0},
            },
        )

        row = api_client.get("/api/sync/status").data["recent"][0]

        assert "stage_counts" not in row
        # Only stages that wrote something, reduced to one number each.
        assert row["changes"] == {"commits": 4}

    def test_error_bodies_are_reduced_to_stages(self, api_client, project):
        _run(
            project=project,
            errors=[{"stage": "commits", "message": "x" * 5000}],
        )

        row = api_client.get("/api/sync/status").data["recent"][0]

        assert "errors" not in row
        assert row["error_count"] == 1

    def test_the_list_is_bounded(self, api_client, project):
        for _ in range(25):
            _run(project=project)

        assert len(api_client.get("/api/sync/status?limit=5").data["recent"]) == 5
        assert len(api_client.get("/api/sync/status").data["recent"]) == 20


class TestBrokerProbe:
    def test_it_is_probed_once_and_then_cached(self, api_client, monkeypatch):
        """The probe opens a Redis connection. Polling this endpoint must not
        open one per request — when Redis is down that is the slowest thing on
        the page, in exactly the situation where somebody is reloading it."""
        from sync import dispatch

        calls = []

        class _Connection:
            def ensure_connection(self, **kwargs):
                calls.append(kwargs)

            def release(self):
                pass

        monkeypatch.setattr(
            dispatch, "workers_online", lambda **kwargs: 1
        )
        monkeypatch.setattr(
            "config.celery.app.connection_for_write", lambda: _Connection()
        )

        api_client.get("/api/sync/status")
        api_client.get("/api/sync/status")
        api_client.get("/api/sync/status")

        assert len(calls) == 1
        assert calls[0]["timeout"] == dispatch.BROKER_PROBE_TIMEOUT_SECONDS

    def test_a_queued_sync_with_no_worker_is_reported(self, api_client, monkeypatch):
        """A reachable broker with nothing consuming it is the whole reason a
        queued sync can never appear in the history."""
        from sync import dispatch

        monkeypatch.setattr(dispatch, "broker_is_available", lambda **kw: True)
        monkeypatch.setattr(dispatch, "workers_online", lambda **kw: 0)
        monkeypatch.setattr("sync.views.broker_is_available", lambda **kw: True)

        data = api_client.get("/api/sync/status").data

        assert data["broker_available"] is True
        assert data["workers_online"] == 0
