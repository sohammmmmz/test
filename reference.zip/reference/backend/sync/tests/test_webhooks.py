"""Tests for webhook signature verification, dedupe, and the sync pipeline."""

import json

import pytest
import responses
from django.utils import timezone

from activity.models import Commit
from gitlab_integration.webhooks import compute_signature, dedupe_key, verify_request
from sync.models import RunStatus, SyncRun, TriggerSource, WebhookEvent

API = "https://gitlab.example.com/api/v4"
SIGNING_TOKEN = "test-signing-token"

pytestmark = pytest.mark.django_db


def signed(body: dict, token: str = SIGNING_TOKEN) -> tuple[bytes, dict]:
    raw = json.dumps(body).encode()
    return raw, {"HTTP_WEBHOOK_SIGNATURE": compute_signature(raw, token)}


class TestVerifyRequest:
    def test_accepts_a_correctly_signed_body(self):
        raw, headers = signed({"object_kind": "push"})

        verified, reason = verify_request(raw, headers)

        assert verified is True
        assert reason == "signature"

    def test_rejects_a_tampered_body(self):
        raw, headers = signed({"object_kind": "push"})

        verified, reason = verify_request(raw + b" ", headers)

        assert verified is False
        assert "did not match" in reason

    def test_rejects_a_signature_from_the_wrong_secret(self):
        raw, headers = signed({"object_kind": "push"}, token="attacker-token")

        assert verify_request(raw, headers)[0] is False

    def test_rejects_an_unsigned_delivery(self):
        """Accepting these would make the endpoint an unauthenticated write path."""
        verified, _reason = verify_request(b'{"object_kind":"push"}', {})

        assert verified is False

    def test_accepts_the_prefixed_signature_form(self):
        raw = b'{"a":1}'
        digest = compute_signature(raw, SIGNING_TOKEN)

        assert verify_request(raw, {"HTTP_X_GITLAB_SIGNATURE_256": f"sha256={digest}"})[0]

    def test_falls_back_to_the_plaintext_token(self, settings):
        settings.GITLAB_WEBHOOK_SIGNING_TOKEN = ""
        settings.GITLAB_WEBHOOK_SECRET_TOKEN = "legacy"

        verified, reason = verify_request(b"{}", {"HTTP_X_GITLAB_TOKEN": "legacy"})

        assert verified is True
        assert reason == "secret_token"

    def test_refuses_everything_when_no_token_is_configured(self, settings):
        settings.GITLAB_WEBHOOK_SIGNING_TOKEN = ""
        settings.GITLAB_WEBHOOK_SECRET_TOKEN = ""

        assert verify_request(b"{}", {})[0] is False

    def test_comparison_is_constant_time(self):
        """Guards against timing oracles on the signature."""
        import inspect

        from gitlab_integration import webhooks

        assert "compare_digest" in inspect.getsource(webhooks.verify_request)


class TestDedupeKey:
    def test_prefers_the_event_uuid(self):
        a = dedupe_key(b'{"a":1}', {"HTTP_X_GITLAB_EVENT_UUID": "u1"})
        b = dedupe_key(b'{"a":2}', {"HTTP_X_GITLAB_EVENT_UUID": "u1"})

        assert a == b, "the same delivery retried must produce the same key"

    def test_falls_back_to_hashing_the_body(self):
        assert dedupe_key(b'{"a":1}', {}) != dedupe_key(b'{"a":2}', {})


class TestWebhookEndpoint:
    def test_rejects_an_unsigned_post(self, client):
        response = client.post(
            "/api/gitlab/webhook", data="{}", content_type="application/json"
        )

        assert response.status_code == 401

    def test_accepts_and_stores_a_signed_delivery(self, client, repo, settings):
        settings.CELERY_TASK_ALWAYS_EAGER = True
        body = {"object_kind": "push", "project": {"id": 555}}
        raw, headers = signed(body)

        response = client.post(
            "/api/gitlab/webhook", data=raw, content_type="application/json",
            HTTP_X_GITLAB_EVENT="Push Hook", **headers,
        )

        assert response.status_code == 202
        event = WebhookEvent.objects.get()
        assert event.signature_verified is True
        assert event.project == repo.project

    def test_a_retried_delivery_is_acknowledged_not_reprocessed(self, client, repo):
        raw, headers = signed({"object_kind": "push", "project": {"id": 555}})
        extra = {"HTTP_X_GITLAB_EVENT_UUID": "uuid-1", **headers}

        first = client.post(
            "/api/gitlab/webhook", data=raw, content_type="application/json", **extra
        )
        second = client.post(
            "/api/gitlab/webhook", data=raw, content_type="application/json", **extra
        )

        assert first.status_code == 202
        assert second.status_code == 200
        assert second.json()["duplicate"] is True
        assert WebhookEvent.objects.count() == 1

    def test_a_delivery_for_an_untracked_repo_is_stored_without_a_project(self, client):
        """The group hook fires for every project in the group, tracked or not."""
        raw, headers = signed({"object_kind": "push", "project": {"id": 99999}})

        response = client.post(
            "/api/gitlab/webhook", data=raw, content_type="application/json", **headers
        )

        assert response.status_code == 202
        assert WebhookEvent.objects.get().project is None


class TestProcessWebhookEvent:
    def test_untracked_repository_is_recorded_as_skipped_not_failed(self, db):
        from sync.tasks import process_webhook_event

        event = WebhookEvent.objects.create(
            event_type="push", dedupe_key="k1",
            payload={"project": {"id": 99999}}, signature_verified=True,
        )

        result = process_webhook_event(event.pk)

        assert result == {"skipped": "untracked project"}
        event.refresh_from_db()
        assert event.processed_at is not None

    def test_an_already_processed_event_is_not_redone(self, db):
        from sync.tasks import process_webhook_event

        event = WebhookEvent.objects.create(
            event_type="push", dedupe_key="k2", payload={},
            processed_at=timezone.now(),
        )

        assert process_webhook_event(event.pk) == {"skipped": "already processed"}


class TestSyncPipeline:
    """The nightly schedule, the manual button and webhooks share one path."""

    def _stub_gitlab(self, mocked_responses, commits=None):
        project_payload = {
            "id": 555, "name": "apollo", "path_with_namespace": "acme/apollo",
            "web_url": "https://gitlab.example.com/acme/apollo",
            "default_branch": "main", "visibility": "private",
            "namespace": {"id": 42, "full_path": "acme"},
        }
        mocked_responses.add(responses.GET, f"{API}/projects/555", json=project_payload)
        mocked_responses.add(responses.GET, f"{API}/projects/555/milestones", json=[])
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits", json=commits or []
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches", json=[]
        )
        mocked_responses.add(responses.GET, f"{API}/projects/555/issues", json=[])
        mocked_responses.add(responses.GET, f"{API}/projects/555/merge_requests", json=[])
        mocked_responses.add(responses.GET, f"{API}/projects/555/members/all", json=[])
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches/documentation",
            json={"message": "404"}, status=404,
        )
        mocked_responses.add(
            responses.POST, f"{API}/projects/555/repository/commits",
            json={"id": "vaultsha"}, status=201,
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree", json=[]
        )

    def test_runs_every_stage_and_records_the_result(
        self, project, repo, employee, mocked_responses
    ):
        from compliance.engine import seed_default_rules
        from sync.pipeline import sync_project

        seed_default_rules()
        self._stub_gitlab(
            mocked_responses,
            commits=[
                {
                    "id": "a" * 40, "short_id": "aaaaaaaa", "title": "feat: x",
                    "message": "feat: x", "author_name": "Riya Sharma",
                    "author_email": "riya@company.com",
                    "authored_date": "2026-07-20T10:00:00.000+00:00",
                    "committed_date": "2026-07-20T10:00:00.000+00:00",
                    "parent_ids": ["p"], "stats": {"additions": 1, "deletions": 0, "total": 1},
                }
            ],
        )

        run = sync_project(project, trigger=TriggerSource.MANUAL, run_scoring=False)

        assert run.status == RunStatus.SUCCESS, run.errors
        assert run.stage_counts["commits"]["created"] == 1
        assert "vault" in run.stage_counts
        assert run.stage_counts["compliance"]["rules"] == 3
        assert Commit.objects.count() == 1

    def test_a_failing_stage_marks_the_run_partial_without_aborting_the_rest(
        self, project, repo, mocked_responses
    ):
        """One broken repo must not stop the other nineteen from syncing."""
        from sync.pipeline import sync_project

        self._stub_gitlab(mocked_responses)
        # Override the branches stage with a failure.
        mocked_responses.replace(
            responses.GET, f"{API}/projects/555/repository/branches",
            json={"message": "500"}, status=500,
        )

        run = sync_project(project, run_scoring=False)

        assert run.status == RunStatus.PARTIAL
        assert any(e["stage"] == "branches" for e in run.errors)
        assert "commits" in run.stage_counts, "later stages still ran"

    def test_a_project_without_a_repo_fails_visibly(self, db):
        """Rather than dying silently, which is indistinguishable from a quiet night."""
        from projects.models import Project
        from sync.pipeline import sync_project

        orphan = Project.objects.create(name="Orphan", slug="orphan")

        run = sync_project(orphan, run_scoring=False)

        assert run.status == RunStatus.FAILED
        assert "no GitLab repository" in run.errors[0]["message"]

    def test_repeated_syncs_do_not_duplicate_commits(
        self, project, repo, employee, mocked_responses
    ):
        from sync.pipeline import sync_project

        commit = {
            "id": "a" * 40, "short_id": "aaaaaaaa", "title": "feat: x", "message": "feat: x",
            "author_name": "Riya", "author_email": "riya@company.com",
            "authored_date": "2026-07-20T10:00:00.000+00:00",
            "committed_date": "2026-07-20T10:00:00.000+00:00",
            "parent_ids": ["p"], "stats": {},
        }
        for _ in range(2):
            self._stub_gitlab(mocked_responses, commits=[commit])

        sync_project(project, trigger=TriggerSource.SCHEDULE, run_scoring=False)
        sync_project(project, trigger=TriggerSource.WEBHOOK, run_scoring=False)

        assert Commit.objects.count() == 1
        assert SyncRun.objects.count() == 2

    def test_fleet_sync_creates_a_child_run_per_project(
        self, project, repo, mocked_responses
    ):
        from sync.pipeline import sync_all_projects

        self._stub_gitlab(mocked_responses)

        parent = sync_all_projects(trigger=TriggerSource.SCHEDULE)

        assert parent.project is None
        assert parent.children.count() == 1
        assert parent.stage_counts["projects"]["total"] == 1


class TestTriggerEndpoint:
    def test_manual_trigger_queues_a_project_sync(self, api_client, project, settings):
        settings.CELERY_TASK_ALWAYS_EAGER = True

        response = api_client.post("/api/sync/trigger", {"project": project.pk})

        assert response.status_code == 202
        assert response.json()["scope"] == "project"

    def test_trigger_rejects_an_unknown_project(self, api_client):
        assert api_client.post("/api/sync/trigger", {"project": 99999}).status_code == 404

    def test_status_endpoint_reports_recent_runs(self, api_client, project):
        SyncRun.objects.create(
            project=project, trigger=TriggerSource.MANUAL, status=RunStatus.SUCCESS,
            started_at=timezone.now(), finished_at=timezone.now(),
        )

        data = api_client.get("/api/sync/status").json()

        assert data["is_running"] is False
        assert len(data["recent"]) == 1
