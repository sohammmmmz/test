"""A stopped broker is an operational problem, not an application crash.

Celery raises OperationalError when Redis is unreachable. Left uncaught it
surfaces as a 500 with a stack trace, which tells the reader nothing about the
one thing they need to do.
"""

import pytest
from kombu.exceptions import OperationalError

from sync.dispatch import dispatch_task

pytestmark = pytest.mark.django_db


class FakeTask:
    """Stands in for a Celery task whose broker is down."""

    name = "sync.fake"

    def __init__(self, *, broker_up: bool, inline_raises: bool = False):
        self.broker_up = broker_up
        self.inline_raises = inline_raises
        self.ran_inline = False

    def delay(self, *args, **kwargs):
        if not self.broker_up:
            raise OperationalError("Error 10061 connecting to localhost:6379.")
        return type("R", (), {"id": "task-123"})()

    def __call__(self, *args, **kwargs):
        self.ran_inline = True
        if self.inline_raises:
            raise RuntimeError("sync blew up")
        return {"synced": True}


class TestDispatch:
    def test_queues_normally_when_the_broker_is_up(self):
        outcome = dispatch_task(FakeTask(broker_up=True), 1)

        assert outcome.queued is True
        assert outcome.task_id == "task-123"
        assert outcome.ran_inline is False

    def test_runs_inline_when_the_broker_is_down_and_fallback_is_on(self, settings):
        settings.CELERY_INLINE_FALLBACK = True
        task = FakeTask(broker_up=False)

        outcome = dispatch_task(task, 1)

        assert outcome.ok
        assert outcome.ran_inline is True
        assert task.ran_inline is True
        assert "already finished" in outcome.detail

    def test_reports_the_remedy_when_fallback_is_off(self, settings):
        settings.CELERY_INLINE_FALLBACK = False

        outcome = dispatch_task(FakeTask(broker_up=False), 1)

        assert outcome.ok is False
        assert outcome.broker_available is False
        # Both remedies must be named: start the queue, or opt out of it.
        assert "Redis is expected at" in outcome.detail
        assert "--pool=solo" in outcome.detail, "Windows needs the solo pool"
        assert "CELERY_INLINE_FALLBACK" in outcome.detail

    def test_an_inline_failure_is_reported_rather_than_swallowed(self, settings):
        settings.CELERY_INLINE_FALLBACK = True

        outcome = dispatch_task(FakeTask(broker_up=False, inline_raises=True), 1)

        assert outcome.ok is False
        assert "sync blew up" in outcome.detail


class TestTriggerEndpoint:
    def test_a_stopped_broker_returns_503_not_500(
        self, api_client, project, settings, monkeypatch
    ):
        """This is the exact failure that produced a 500 stack trace."""
        settings.CELERY_INLINE_FALLBACK = False

        def refuse(*_a, **_k):
            raise OperationalError("Error 10061 connecting to localhost:6379.")

        monkeypatch.setattr("sync.views.sync_one_project.delay", refuse)

        response = api_client.post("/api/sync/trigger", {"project": project.pk})

        assert response.status_code == 503
        assert response.json()["code"] == "broker_unavailable"
        assert "Redis is expected at" in response.json()["detail"]

    def test_inline_fallback_reports_that_it_already_ran(
        self, api_client, project, settings, monkeypatch
    ):
        settings.CELERY_INLINE_FALLBACK = True

        def refuse(*_a, **_k):
            raise OperationalError("broker down")

        monkeypatch.setattr("sync.views.sync_one_project.delay", refuse)
        monkeypatch.setattr(
            "sync.views.sync_one_project.__call__", lambda *_a, **_k: {"ok": True}
        )

        response = api_client.post("/api/sync/trigger", {"project": project.pk})

        assert response.status_code == 202
        assert response.json()["ran_inline"] is True

    def test_status_reports_broker_health(self, api_client, monkeypatch):
        """Visible before pressing the button, rather than after it fails."""
        monkeypatch.setattr("sync.views.broker_is_available", lambda: False)

        assert api_client.get("/api/sync/status").json()["broker_available"] is False


class TestWebhookTolerance:
    def test_a_delivery_is_still_accepted_when_the_broker_is_down(
        self, client, repo, settings, monkeypatch
    ):
        """The event is already persisted; rejecting it would make GitLab retry
        something we have safely stored."""
        import hashlib
        import hmac
        import json

        settings.CELERY_INLINE_FALLBACK = False

        def refuse(*_a, **_k):
            raise OperationalError("broker down")

        monkeypatch.setattr("sync.views.process_webhook_event.delay", refuse)

        body = json.dumps({"object_kind": "push", "project": {"id": 555}}).encode()
        signature = hmac.new(
            settings.GITLAB_WEBHOOK_SIGNING_TOKEN.encode(), body, hashlib.sha256
        ).hexdigest()

        response = client.post(
            "/api/gitlab/webhook",
            data=body,
            content_type="application/json",
            HTTP_WEBHOOK_SIGNATURE=signature,
        )

        assert response.status_code == 202
        assert response.json()["processing"] == "deferred"

        from sync.models import WebhookEvent

        assert WebhookEvent.objects.count() == 1, "the delivery must still be recorded"
