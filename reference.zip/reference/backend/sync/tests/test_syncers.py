"""Tests for the sync stages, focused on idempotency and multi-branch coverage."""

from datetime import timedelta

import pytest
import responses
from django.utils import timezone

from activity.models import Branch, Commit, Issue, MergeRequest, Milestone, ProjectMember
from gitlab_integration.client import GitLabClient
from sync.syncers import (
    commit_window,
    extract_issue_refs,
    sync_branches,
    sync_commits,
    sync_issues,
    sync_members,
    sync_merge_requests,
    sync_milestones,
)
from team.identity import AuthorResolver
from team.models import UnmappedAuthor

API = "https://gitlab.example.com/api/v4"

pytestmark = pytest.mark.django_db


@pytest.fixture
def client():
    return GitLabClient(token="t", api_url=API, max_retries=0)


@pytest.fixture
def resolver():
    return AuthorResolver()


def commit_payload(sha, email="riya@company.com", message="feat: thing", **kwargs):
    return {
        "id": sha,
        "short_id": sha[:8],
        "title": message.splitlines()[0],
        "message": message,
        "author_name": kwargs.get("author_name", "Riya Sharma"),
        "author_email": email,
        "committer_name": "Riya Sharma",
        "committer_email": email,
        "authored_date": kwargs.get("authored_date", "2026-07-20T10:00:00.000+00:00"),
        "committed_date": "2026-07-20T10:00:00.000+00:00",
        "web_url": f"https://gitlab.example.com/acme/apollo/-/commit/{sha}",
        "parent_ids": kwargs.get("parent_ids", ["parent1"]),
        "stats": kwargs.get("stats", {"additions": 10, "deletions": 2, "total": 12}),
    }


class TestExtractIssueRefs:
    @pytest.mark.parametrize(
        "message,expected",
        [
            ("feat: add login #123", [123]),
            ("Closes #45 and #46", [45, 46]),
            ("Fixes #7\n\nAlso relates to #7", [7]),
            ("no refs here", []),
            ("colour #ffffff is not an issue", []),
        ],
    )
    def test_finds_issue_numbers(self, message, expected):
        assert extract_issue_refs(message) == expected


class TestCommitWindow:
    def test_first_sync_reaches_back_for_a_backfill(self, repo, settings):
        settings.SYNC_INITIAL_BACKFILL_DAYS = 365
        since, until = commit_window(repo)

        assert (until - since).days == pytest.approx(365, abs=1)

    def test_subsequent_syncs_overlap_the_last_window(self, repo, settings):
        """The overlap is what heals pushes that webhooks dropped."""
        settings.SYNC_LOOKBACK_DAYS = 7
        repo.last_commit_synced_at = timezone.now() - timedelta(days=1)
        repo.save()

        since, _until = commit_window(repo)

        assert since < repo.last_commit_synced_at
        assert (repo.last_commit_synced_at - since).days == 7


class TestSyncCommits:
    def test_requests_all_branches(self, repo, client, resolver, mocked_responses):
        """The default endpoint returns only the default branch, which would
        make a feature-branch team look inactive."""
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits", json=[]
        )

        sync_commits(repo, client, resolver)

        assert mocked_responses.calls[0].request.params["all"] == "True"

    def test_creates_commits_and_attributes_authors(
        self, repo, client, resolver, employee, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40), commit_payload("b" * 40)],
        )

        result = sync_commits(repo, client, resolver)

        assert result.created == 2
        assert Commit.objects.filter(author_employee=employee).count() == 2

    def test_is_idempotent_across_overlapping_runs(
        self, repo, client, resolver, employee, mocked_responses
    ):
        """Webhook, nightly and manual syncs overlap by design."""
        for _ in range(3):
            mocked_responses.add(
                responses.GET, f"{API}/projects/555/repository/commits",
                json=[commit_payload("a" * 40)],
            )

        for _ in range(3):
            sync_commits(repo, client, resolver)

        assert Commit.objects.count() == 1

    def test_reruns_update_rather_than_duplicate(
        self, repo, client, resolver, employee, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40, message="feat: v1")],
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40, message="feat: v2 amended")],
        )

        sync_commits(repo, client, resolver)
        second = sync_commits(repo, client, resolver)

        assert second.updated == 1
        assert Commit.objects.get(sha="a" * 40).message == "feat: v2 amended"

    def test_records_issue_references(self, repo, client, resolver, employee, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40, message="fix: login #42\n\nCloses #43")],
        )

        sync_commits(repo, client, resolver)

        assert Commit.objects.get(sha="a" * 40).referenced_issue_iids == [42, 43]

    def test_flags_merge_commits(self, repo, client, resolver, employee, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40, parent_ids=["p1", "p2"])],
        )

        sync_commits(repo, client, resolver)

        assert Commit.objects.get(sha="a" * 40).is_merge_commit is True

    def test_unknown_author_is_queued_not_dropped(
        self, repo, client, resolver, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40, email="ghost@nowhere.com")],
        )

        sync_commits(repo, client, resolver)
        resolver.flush_unmapped()

        assert Commit.objects.count() == 1, "the commit itself must still be recorded"
        assert Commit.objects.first().author_employee is None
        assert UnmappedAuthor.objects.filter(email="ghost@nowhere.com").exists()

    def test_advances_the_sync_cursor(self, repo, client, resolver, employee, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits",
            json=[commit_payload("a" * 40, authored_date="2026-07-20T10:00:00.000+00:00")],
        )

        sync_commits(repo, client, resolver)

        repo.refresh_from_db()
        assert repo.last_commit_synced_at.isoformat().startswith("2026-07-20T10:00")

    def test_skips_commits_with_no_date(self, repo, client, resolver, mocked_responses):
        payload = commit_payload("a" * 40)
        payload["authored_date"] = None
        payload.pop("created_at", None)
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits", json=[payload]
        )

        result = sync_commits(repo, client, resolver)

        assert result.skipped == 1
        assert Commit.objects.count() == 0


class TestSyncBranches:
    def test_records_branch_ownership(self, repo, client, resolver, employee, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches",
            json=[
                {
                    "name": "feature/login", "default": False, "protected": False,
                    "merged": False,
                    "commit": {
                        "id": "abc", "committed_date": "2026-07-20T10:00:00.000+00:00",
                        "author_email": "riya@company.com", "author_name": "Riya Sharma",
                    },
                }
            ],
        )

        sync_branches(repo, client, resolver)

        branch = Branch.objects.get(name="feature/login")
        assert branch.last_commit_author == employee

    def test_deleted_branches_are_flagged_not_removed(
        self, repo, client, resolver, mocked_responses
    ):
        """Their commits still exist and still count as somebody's work."""
        Branch.objects.create(repo=repo, name="feature/old", is_present=True)
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches", json=[]
        )

        sync_branches(repo, client, resolver)

        assert Branch.objects.get(name="feature/old").is_present is False


class TestSyncMilestonesAndIssues:
    def test_syncs_milestones(self, repo, client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/milestones",
            json=[
                {
                    "id": 1, "iid": 1, "title": "M1 Auth", "description": "",
                    "state": "active", "start_date": "2026-07-01",
                    "due_date": "2026-08-01", "expired": False,
                }
            ],
        )

        sync_milestones(repo, client)

        assert Milestone.objects.get(gitlab_id=1).due_date.isoformat() == "2026-08-01"

    def test_issues_link_to_milestones_and_assignees(
        self, repo, client, resolver, employee, mocked_responses
    ):
        Milestone.objects.create(repo=repo, gitlab_id=1, title="M1", state="active")
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/issues",
            json=[
                {
                    "id": 10, "iid": 1, "title": "Login endpoint", "description": "d",
                    "state": "opened", "labels": ["backend"],
                    "milestone": {"id": 1},
                    "assignees": [{"id": 1001, "name": "Riya Sharma"}],
                    "created_at": "2026-07-01T00:00:00Z",
                    "updated_at": "2026-07-02T00:00:00Z",
                }
            ],
        )

        sync_issues(repo, client, resolver)

        issue = Issue.objects.get(iid=1)
        assert issue.milestone.gitlab_id == 1
        assert list(issue.assignees.all()) == [employee]


class TestSyncMergeRequests:
    def test_syncs_merge_requests_and_review_notes(
        self, repo, client, resolver, employee, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/merge_requests",
            json=[
                {
                    "id": 1, "iid": 3, "title": "Add login", "description": "",
                    "state": "merged", "source_branch": "feature/login",
                    "target_branch": "main",
                    "author": {"id": 1001, "name": "Riya Sharma"},
                    "created_at": "2026-07-01T00:00:00Z",
                    "updated_at": "2026-07-03T00:00:00Z",
                    "merged_at": "2026-07-03T00:00:00Z",
                    "user_notes_count": 2,
                }
            ],
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/merge_requests/3/notes",
            json=[
                {"id": 1, "body": "looks good", "system": False,
                 "author": {"id": 1001}, "created_at": "2026-07-02T00:00:00Z"},
                {"id": 2, "body": "changed title", "system": True,
                 "author": {"id": 1001}, "created_at": "2026-07-02T00:00:00Z"},
            ],
        )

        sync_merge_requests(repo, client, resolver)

        merge_request = MergeRequest.objects.get(iid=3)
        assert merge_request.author_employee == employee
        assert merge_request.notes.count() == 1, "system notes are not contribution"

    def test_a_broken_notes_fetch_does_not_abort_the_stage(
        self, repo, client, resolver, employee, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/merge_requests",
            json=[
                {"id": 1, "iid": 3, "title": "t", "state": "opened",
                 "author": {"id": 1001}, "user_notes_count": 1}
            ],
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/merge_requests/3/notes",
            json={"message": "500"}, status=500,
        )

        result = sync_merge_requests(repo, client, resolver)

        assert result.created == 1
        assert result.errors, "the failure should be recorded, not swallowed"


class TestSyncMembers:
    def test_uses_inherited_membership(self, repo, client, resolver, employee, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/members/all",
            json=[{"id": 1001, "username": "riya", "name": "Riya Sharma", "access_level": 30}],
        )

        sync_members(repo, client, resolver)

        member = ProjectMember.objects.get(gitlab_user_id=1001)
        assert member.employee == employee
        assert member.access_level_display == "Developer"

    def test_removed_members_are_deleted(self, repo, client, resolver, mocked_responses):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=999, username="gone")
        mocked_responses.add(responses.GET, f"{API}/projects/555/members/all", json=[])

        result = sync_members(repo, client, resolver)

        assert result.skipped == 1
        assert not ProjectMember.objects.filter(gitlab_user_id=999).exists()
