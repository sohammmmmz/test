"""Syncing by person and by project, over a one-day window.

The sync screen offers four things: one project, every project, one person,
every person. The first two were already possible; the second two are the new
part, and they need an answer to a question GitLab does not answer directly —
there is no "give me this person's commits" endpoint, because commits belong to
repositories. Syncing a person therefore means syncing the repositories they
are attached to and attributing what comes back.

The other half is the window. An on-demand sync asks "bring me up to date with
today", not "reconcile everything since this repository was last touched", and
those cost very different amounts.
"""

from datetime import timedelta

import pytest
from django.utils import timezone

from activity.models import ProjectMember
from projects.models import GitLabRepo, Project, ProjectStatus
from sync.models import RunStatus, SyncRun, SyncScope
from sync.pipeline import projects_for_employee
from sync.syncers import commit_window
from team.models import Assignment

pytestmark = pytest.mark.django_db


@pytest.fixture
def second_project(db):
    project = Project.objects.create(
        name="Borealis", slug="borealis", status=ProjectStatus.ACTIVE
    )
    GitLabRepo.objects.create(
        project=project,
        gitlab_project_id=77002,
        path_with_namespace="group/borealis",
        web_url="https://gitlab.example.com/group/borealis",
        default_branch="main",
    )
    return project


class TestTheCommitWindow:
    def test_days_pins_the_window_regardless_of_the_last_sync(self, repo):
        repo.last_commit_synced_at = timezone.now() - timedelta(days=90)
        repo.save()

        since, until = commit_window(repo, days=1)

        assert (until - since).days == 1, "one day, not ninety"

    def test_without_days_it_resumes_from_the_last_sync(self, repo, settings):
        settings.SYNC_LOOKBACK_DAYS = 7
        repo.last_commit_synced_at = timezone.now() - timedelta(days=30)
        repo.save()

        since, _until = commit_window(repo)

        assert since < timezone.now() - timedelta(days=30)

    def test_a_never_synced_repo_still_gets_the_full_backfill(self, repo, settings):
        """A one-day window over an empty table would leave a new repository
        looking permanently empty."""
        settings.SYNC_INITIAL_BACKFILL_DAYS = 365
        repo.last_commit_synced_at = None
        repo.save()

        since, until = commit_window(repo, days=1)

        assert (until - since).days == 365

    def test_full_overrides_the_day_window(self, repo, settings):
        settings.SYNC_INITIAL_BACKFILL_DAYS = 365
        repo.last_commit_synced_at = timezone.now()
        repo.save()

        since, until = commit_window(repo, full=True, days=1)

        assert (until - since).days == 365


class TestWhichProjectsAPersonTouches:
    def test_repository_membership_counts(self, employee, project, repo):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )

        assert projects_for_employee(employee) == [project]

    def test_an_assignment_counts_even_without_membership(
        self, employee, project
    ):
        """Assignments are typed by hand and membership is synced from GitLab.
        Someone routinely has one without the other, and syncing only the
        overlap would skip the repository their commits are actually in."""
        Assignment.objects.create(employee=employee, project=project, allocation_percent=50)

        assert projects_for_employee(employee) == [project]

    def test_both_sources_are_unioned_without_duplicates(
        self, employee, project, repo, second_project
    ):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )
        Assignment.objects.create(employee=employee, project=project, allocation_percent=50)
        Assignment.objects.create(
            employee=employee, project=second_project, allocation_percent=50
        )

        found = projects_for_employee(employee)

        assert sorted(p.name for p in found) == ["Apollo", "Borealis"]

    def test_archived_projects_are_left_out(self, employee, project, repo):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )
        project.status = "archived"
        project.save()

        assert projects_for_employee(employee) == []

    def test_someone_on_nothing_has_nothing_to_sync(self, employee):
        assert projects_for_employee(employee) == []


class TestTriggerEndpoint:
    def test_a_project_sync_is_queued(self, api_client, project, monkeypatch):
        seen = _capture(monkeypatch)

        response = api_client.post(
            "/api/sync/trigger", {"scope": "project", "project": project.pk}, format="json"
        )

        assert response.status_code == 202
        assert response.data["scope"] == "project"
        assert seen["task"].name == "sync.sync_one_project"

    def test_a_person_sync_is_queued(self, api_client, employee, monkeypatch):
        seen = _capture(monkeypatch)

        response = api_client.post(
            "/api/sync/trigger", {"scope": "employee", "employee": employee.pk},
            format="json",
        )

        assert response.status_code == 202
        assert response.data["scope"] == "employee"
        assert response.data["target"] == employee.full_name
        assert seen["task"].name == "sync.sync_one_employee"

    def test_all_members_at_once(self, api_client, monkeypatch):
        seen = _capture(monkeypatch)

        response = api_client.post(
            "/api/sync/trigger", {"scope": "all_employees"}, format="json"
        )

        assert response.status_code == 202
        assert seen["task"].name == "sync.sync_all_employees"

    def test_all_projects_is_a_manual_run_not_the_nightly_one(
        self, api_client, monkeypatch
    ):
        """Mislabelling a button press as a scheduled run makes the history
        useless for working out why a number moved."""
        seen = _capture(monkeypatch)

        api_client.post("/api/sync/trigger", {"scope": "all_projects"}, format="json")

        assert seen["task"].name == "sync.sync_all_projects"

    def test_the_default_window_is_one_day(self, api_client, project, monkeypatch, settings):
        settings.SYNC_QUICK_WINDOW_DAYS = 1
        seen = _capture(monkeypatch)

        response = api_client.post(
            "/api/sync/trigger", {"scope": "project", "project": project.pk}, format="json"
        )

        assert response.data["window_days"] == 1
        assert seen["kwargs"]["window_days"] == 1

    def test_a_full_sync_drops_the_window(self, api_client, project, monkeypatch):
        seen = _capture(monkeypatch)

        response = api_client.post(
            "/api/sync/trigger",
            {"scope": "project", "project": project.pk, "full": True},
            format="json",
        )

        assert response.data["window_days"] is None
        assert seen["kwargs"]["full"] is True

    def test_the_window_can_be_widened(self, api_client, project, monkeypatch):
        seen = _capture(monkeypatch)

        api_client.post(
            "/api/sync/trigger",
            {"scope": "project", "project": project.pk, "days": 30},
            format="json",
        )

        assert seen["kwargs"]["window_days"] == 30

    def test_the_old_request_shape_still_works(self, api_client, project, monkeypatch):
        """Callers predating the scope field sent just a project id."""
        seen = _capture(monkeypatch)

        response = api_client.post(
            "/api/sync/trigger", {"project": project.pk}, format="json"
        )

        assert response.status_code == 202
        assert seen["task"].name == "sync.sync_one_project"

    def test_an_unknown_person_is_404_not_a_silent_no_op(self, api_client):
        response = api_client.post(
            "/api/sync/trigger", {"scope": "employee", "employee": 999999}, format="json"
        )

        assert response.status_code == 404


class TestTargets:
    """What the sync screen offers as things to press.

    Worth a test of its own rather than being assumed: this endpoint is the
    only thing standing between the page and an empty screen, and it was
    briefly broken by a query optimisation that no other test touched.
    """

    def test_it_lists_projects_and_people(self, api_client, employee, project, repo):
        data = api_client.get("/api/sync/targets").data

        assert [p["name"] for p in data["projects"]] == [project.name]
        assert [e["full_name"] for e in data["employees"]] == [employee.full_name]

    def test_it_says_how_many_repositories_each_person_has(
        self, api_client, employee, project, repo
    ):
        """Zero means there is nothing to sync, and the button says so rather
        than queueing a run that does nothing."""
        assert api_client.get("/api/sync/targets").data["employees"][0][
            "project_count"
        ] == 0

        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )

        assert api_client.get("/api/sync/targets").data["employees"][0][
            "project_count"
        ] == 1

    def test_it_reports_whether_a_project_can_be_synced(
        self, api_client, project, repo
    ):
        assert api_client.get("/api/sync/targets").data["projects"][0]["has_repo"] is True

    def test_archived_projects_are_not_offered(self, api_client, project):
        project.status = "archived"
        project.save()

        assert api_client.get("/api/sync/targets").data["projects"] == []

    def test_it_states_the_window_the_buttons_will_use(self, api_client, settings):
        settings.SYNC_QUICK_WINDOW_DAYS = 1

        assert api_client.get("/api/sync/targets").data["quick_window_days"] == 1


class TestRunsRecordWhatWasAsked:
    def test_a_person_run_names_the_person(self, employee, project, repo, monkeypatch):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )
        _stub_project_sync(monkeypatch)
        from sync.pipeline import sync_employee

        run = sync_employee(employee, window_days=1)

        assert run.scope == SyncScope.EMPLOYEE
        assert run.employee == employee
        assert run.children.count() == 1

    def test_a_person_on_no_projects_is_partial_not_green(self, employee):
        """Nothing to do is not success — someone asked for work that had no
        targets, and that is exactly what they need to see."""
        from sync.pipeline import sync_employee

        run = sync_employee(employee, window_days=1)

        assert run.status == RunStatus.PARTIAL
        assert run.errors

    def test_the_window_reaches_the_child_runs(
        self, employee, project, repo, monkeypatch
    ):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )
        seen = _stub_project_sync(monkeypatch)
        from sync.pipeline import sync_employee

        sync_employee(employee, window_days=1)

        assert seen[-1]["window_days"] == 1


def _capture(monkeypatch) -> dict:
    """Intercept dispatch so nothing actually runs."""
    seen: dict = {}

    class _Outcome:
        ok = True
        queued = True
        ran_inline = False
        task_id = "test-task"
        detail = ""

    def fake_dispatch(task, *args, **kwargs):
        seen["task"] = task
        seen["args"] = args
        seen["kwargs"] = kwargs
        return _Outcome()

    monkeypatch.setattr("sync.views.dispatch_task", fake_dispatch)
    return seen


def _stub_project_sync(monkeypatch) -> list:
    """Replace the per-project sync so no GitLab call is attempted."""
    calls: list = []

    def fake_sync_project(project, **kwargs):
        calls.append({"project": project, **kwargs})
        return SyncRun.objects.create(
            project=project,
            parent=kwargs.get("parent"),
            trigger=kwargs.get("trigger", "manual"),
            status=RunStatus.SUCCESS,
            started_at=timezone.now(),
            finished_at=timezone.now(),
        )

    monkeypatch.setattr("sync.pipeline.sync_project", fake_sync_project)
    return calls
