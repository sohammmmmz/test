"""Sync API: manual trigger, run history, and the webhook receiver."""

import logging

from django.conf import settings
from django.db.models import Count
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from common import cache as cache_ns
from common.cache import cached
from projects.models import Project
from team.models import Employee

from .dispatch import broker_is_available, dispatch_task
from .models import RunStatus, SyncRun, TriggerSource, WebhookEvent
from .serializers import (
    SyncRunSerializer,
    SyncRunSummarySerializer,
    WebhookEventSerializer,
)
from .tasks import (
    process_webhook_event,
    sync_all_employees_task,
    sync_all_projects_task,
    sync_one_employee,
    sync_one_project,
)

logger = logging.getLogger(__name__)


class SyncRunViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = SyncRunSerializer

    def get_queryset(self):
        qs = SyncRun.objects.select_related("project", "triggered_by")
        project_id = self.request.query_params.get("project")
        if project_id:
            qs = qs.filter(project_id=project_id)
        if self.request.query_params.get("top_level") == "true":
            qs = qs.filter(parent__isnull=True)
        return qs


class WebhookEventViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = WebhookEventSerializer
    queryset = WebhookEvent.objects.select_related("project").all()


class TriggerSyncView(APIView):
    """The sync buttons: one project, all projects, one person, all people.

    Every variant enters the same pipeline the nightly job does, so a manual run
    cannot diverge from a scheduled one. They differ in two things only: which
    repositories are visited, and how far back the commit window reaches.

    The window is the important half. An on-demand sync defaults to the last
    ``SYNC_QUICK_WINDOW_DAYS`` (one day) rather than to "everything since this
    repository was last synced", because the two answer different questions and
    the second one is slow enough that people stop pressing the button.
    ``full`` still forces the complete backfill.
    """

    def post(self, request):
        data = request.data or {}
        full = bool(data.get("full"))
        scope = self._scope(data)
        window_days = self._window_days(data, full=full)

        if scope == "project":
            project = Project.objects.filter(pk=data.get("project")).first()
            if project is None:
                return Response(
                    {"detail": "No such project."}, status=status.HTTP_404_NOT_FOUND
                )
            outcome = dispatch_task(
                sync_one_project,
                project.pk,
                trigger=TriggerSource.MANUAL,
                user_id=request.user.pk,
                full=full,
                window_days=window_days,
            )
            label = project.name

        elif scope == "employee":
            employee = Employee.objects.filter(pk=data.get("employee")).first()
            if employee is None:
                return Response(
                    {"detail": "No such team member."}, status=status.HTTP_404_NOT_FOUND
                )
            outcome = dispatch_task(
                sync_one_employee,
                employee.pk,
                user_id=request.user.pk,
                full=full,
                window_days=window_days,
            )
            label = employee.full_name

        elif scope == "all_employees":
            outcome = dispatch_task(
                sync_all_employees_task,
                user_id=request.user.pk,
                full=full,
                window_days=window_days,
            )
            label = "every team member"

        else:
            scope = "all_projects"
            # The nightly task is reserved for the schedule so the history keeps
            # saying who asked; a button press is a manual run.
            outcome = dispatch_task(
                sync_all_projects_task,
                user_id=request.user.pk,
                full=full,
                window_days=window_days,
            )
            label = "every project"

        if not outcome.ok:
            # A stopped Redis is an operational problem with a clear remedy,
            # not an application crash.
            return Response(
                {
                    "queued": False,
                    "scope": scope,
                    "detail": outcome.detail,
                    "code": "broker_unavailable",
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )

        return Response(
            {
                "queued": outcome.queued,
                "ran_inline": outcome.ran_inline,
                "scope": scope,
                "target": label,
                # Kept under its old name as well: the sync button reads it, and
                # renaming a response field is not worth a broken screen.
                "project": label,
                "window_days": window_days,
                "task_id": outcome.task_id,
                "detail": outcome.detail,
            },
            status=status.HTTP_202_ACCEPTED,
        )

    @staticmethod
    def _scope(data: dict) -> str:
        """What was asked for, tolerating the older request shape.

        Callers before this existed sent ``{"project": id}`` or ``{}``, and both
        still mean what they used to.
        """
        explicit = str(data.get("scope") or "").strip().lower().replace("-", "_")
        if explicit in {"project", "all_projects", "employee", "all_employees"}:
            return explicit
        if data.get("employee"):
            return "employee"
        if data.get("project"):
            return "project"
        return "all_projects"

    @staticmethod
    def _window_days(data: dict, *, full: bool) -> int | None:
        """None means "use the repository's own resume point"."""
        if full:
            return None
        raw = data.get("days", settings.SYNC_QUICK_WINDOW_DAYS)
        if raw in (None, "", "auto"):
            return None
        try:
            return max(1, min(int(raw), 366))
        except (TypeError, ValueError):
            return settings.SYNC_QUICK_WINDOW_DAYS


@api_view(["GET"])
def sync_targets(request):
    """What can be synced: the projects, and the people.

    Served separately from the status feed and cached, because it changes when
    somebody joins or a project is registered — roughly never, relative to how
    often this page is polled. Folding it into the status response would make
    the fast-moving half pay for the slow-moving half three times a minute.
    """
    return Response(
        cached("sync:targets", cache_ns.PROJECTS, {"today": timezone.localdate()})(
            _build_targets
        )
    )


def _build_targets() -> dict:
    from activity.models import ProjectMember
    from team.models import Assignment

    projects = list(
        Project.objects.select_related("repo").exclude(status="archived").order_by("name")
    )

    # Two grouped queries rather than a membership lookup per person. The counts
    # are what make the member list usable — a name with no repositories behind
    # it cannot be synced, and saying so up front is better than a run that
    # completes having done nothing.
    member_counts: dict[int, set] = {}
    for employee_id, project_id in ProjectMember.objects.filter(
        employee__isnull=False, repo__project__isnull=False
    ).values_list("employee_id", "repo__project_id"):
        member_counts.setdefault(employee_id, set()).add(project_id)
    for employee_id, project_id in Assignment.objects.values_list(
        "employee_id", "project_id"
    ):
        member_counts.setdefault(employee_id, set()).add(project_id)

    employees = [
        {
            "id": employee.id,
            "full_name": employee.full_name,
            "department": employee.department,
            "designation": employee.designation,
            "gitlab_username": employee.gitlab_username,
            "project_count": len(member_counts.get(employee.id, ())),
        }
        for employee in Employee.objects.filter(is_active=True).order_by("full_name")
    ]

    return {
        "projects": [
            {
                "id": project.id,
                "name": project.name,
                "slug": project.slug,
                "status": project.status,
                "last_synced_at": project.last_synced_at,
                "last_activity_at": project.last_activity_at,
                "has_repo": getattr(project, "repo", None) is not None,
            }
            for project in projects
        ],
        "employees": employees,
        "quick_window_days": settings.SYNC_QUICK_WINDOW_DAYS,
    }


@api_view(["GET"])
def sync_run_children(request, run_id: int):
    """The per-project runs inside one fleet or person sync.

    Loaded on demand rather than nested into the status feed. A fleet run over
    twenty repositories carries twenty rows of unbounded stage JSON, and sending
    all of that with every poll — for rows nobody has expanded — was the single
    largest thing on this page.
    """
    children = (
        SyncRun.objects.filter(parent_id=run_id)
        .select_related("project", "triggered_by")
        .order_by("project__name", "id")
    )
    return Response(SyncRunSummarySerializer(children, many=True).data)


@api_view(["GET"])
def sync_status(request):
    """Current and recent sync state, for the sync page and the buttons.

    Polled while a sync is in flight, so everything here is chosen for cost.

    Child runs are counted, not serialised — they arrive from
    ``sync_run_children`` when a row is actually expanded. Nesting them here
    meant a fleet sync returned twenty-one rows of unbounded ``stage_counts``
    and ``errors`` JSON on every poll, to render six columns of summary.

    The broker and worker probes are cached (see ``sync.dispatch``) so a stopped
    Redis costs one connection timeout every ten seconds rather than one per
    page load — which is exactly when someone is reloading this page repeatedly
    to find out what is wrong.
    """
    from .dispatch import workers_online

    try:
        limit = max(1, min(int(request.query_params.get("limit", 20)), 100))
    except (TypeError, ValueError):
        limit = 20

    running = SyncRun.objects.filter(status=RunStatus.RUNNING).count()
    recent = list(
        SyncRun.objects.filter(parent__isnull=True)
        .select_related("project", "employee", "triggered_by")
        .annotate(children_total=Count("children"))
        .only(
            "id", "project", "employee", "parent", "scope", "trigger", "triggered_by",
            "status", "started_at", "finished_at", "stage_counts", "errors", "created_at",
        )[:limit]
    )

    rows = []
    for run in recent:
        data = SyncRunSummarySerializer(run).data
        data["child_count"] = run.children_total
        rows.append(data)

    broker = broker_is_available()
    workers = workers_online() if broker else 0

    return Response(
        {
            "running_count": running,
            "is_running": running > 0,
            "latest": rows[0] if rows else None,
            "recent": rows,
            "unprocessed_webhooks": WebhookEvent.objects.filter(
                processed_at__isnull=True
            ).count(),
            # Surfaced so a stopped Redis is visible before someone presses
            # the button and gets a failure.
            "broker_available": broker,
            # A reachable broker with no worker behind it is the reason a
            # queued sync can never appear here: the task is sitting in Redis
            # and nothing is taking it out.
            "workers_online": workers,
        }
    )


class GitLabWebhookView(APIView):
    """Receiver for group-level GitLab webhooks.

    The one endpoint that deliberately bypasses session authentication: GitLab
    authenticates with an HMAC signature over the body instead. Deliveries are
    persisted before processing so a worker crash cannot lose one.
    """

    authentication_classes: list = []
    permission_classes = [AllowAny]

    def post(self, request):
        from gitlab_integration.webhooks import (
            EVENT_HEADER,
            UUID_HEADER,
            dedupe_key,
            extract_project_id,
            parse_payload,
            verify_request,
        )

        body = request.body
        verified, reason = verify_request(body, request.META)
        if not verified:
            logger.warning("Rejected webhook delivery: %s", reason)
            return Response(
                {"detail": "Signature verification failed."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        payload = parse_payload(body)
        event_type = request.META.get(EVENT_HEADER, "") or payload.get("object_kind", "")
        key = dedupe_key(body, request.META)

        gitlab_project_id = extract_project_id(payload)
        project = (
            Project.objects.filter(repo__gitlab_project_id=gitlab_project_id).first()
            if gitlab_project_id
            else None
        )

        event, created = WebhookEvent.objects.get_or_create(
            dedupe_key=key,
            defaults={
                "event_type": event_type,
                "gitlab_event_uuid": request.META.get(UUID_HEADER, "") or "",
                "gitlab_project_id": gitlab_project_id,
                "project": project,
                "payload": payload,
                "signature_verified": True,
                "received_at": timezone.now(),
            },
        )

        if not created:
            # GitLab retries; acknowledging is correct, re-processing is not.
            return Response({"duplicate": True}, status=status.HTTP_200_OK)

        # The delivery is already stored, so a broker outage must not fail the
        # response — GitLab would retry a delivery we have safely recorded, and
        # the nightly reconciliation pass covers anything left unprocessed.
        outcome = dispatch_task(process_webhook_event, event.pk)

        return Response(
            {
                "accepted": True,
                "event_id": event.pk,
                "processing": "queued" if outcome.queued else "deferred",
            },
            status=status.HTTP_202_ACCEPTED,
        )


@api_view(["POST"])
def register_webhook(request):
    """Register or refresh the group webhook from the UI.

    Runs synchronously: it is a single fast API call, and making it depend on
    a running worker would be needless.
    """
    from .tasks import register_group_webhook

    return Response(register_group_webhook())
