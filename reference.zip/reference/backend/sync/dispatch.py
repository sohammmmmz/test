"""Queueing work when the broker may not be there.

Celery raises ``kombu.exceptions.OperationalError`` when it cannot reach the
broker, and left uncaught that surfaces as a 500 with a stack trace — a stopped
Redis should not look like an application crash.

For local development there is also an inline fallback: rather than blocking
every feature behind a running Redis, the job can be executed in-process. That
is genuinely slower and holds the request open, so it is opt-in and never the
default in production.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from django.conf import settings
from kombu.exceptions import OperationalError

logger = logging.getLogger(__name__)


@dataclass
class Dispatch:
    """Outcome of trying to queue a task."""

    queued: bool
    task_id: str = ""
    ran_inline: bool = False
    broker_available: bool = True
    detail: str = ""
    result = None

    @property
    def ok(self) -> bool:
        return self.queued or self.ran_inline


#: How long a broker probe result is reused. The status endpoint is polled
#: while a sync runs, and opening a fresh Redis connection on every poll is
#: both wasteful and — when Redis is down — the slowest thing on the page.
BROKER_PROBE_CACHE_SECONDS = 10

#: Deliberately short. This runs inside a request that renders a page, so the
#: cost of being wrong for ten seconds is far lower than the cost of holding
#: the page open while a dead host times out.
BROKER_PROBE_TIMEOUT_SECONDS = 0.5

_BROKER_PROBE_KEY = "sync:broker-available"
_WORKER_PROBE_KEY = "sync:workers-online"


def workers_online(*, use_cache: bool = True) -> int:
    """How many Celery workers answer a ping.

    A reachable broker is not the same as a running worker, and the difference
    is the whole explanation for "I pressed sync and nothing appeared": the
    task went into Redis and nothing ever took it out. Without this the page
    can only say the queue is fine, which is true and useless.
    """
    from django.core.cache import cache

    if use_cache:
        cached = cache.get(_WORKER_PROBE_KEY)
        if cached is not None:
            return cached

    from config.celery import app

    try:
        replies = app.control.ping(timeout=BROKER_PROBE_TIMEOUT_SECONDS) or []
        count = len(replies)
    except Exception:  # noqa: BLE001 - a broken broker means no workers reachable
        count = 0

    cache.set(_WORKER_PROBE_KEY, count, BROKER_PROBE_CACHE_SECONDS)
    return count


def broker_is_available(*, use_cache: bool = True) -> bool:
    """Cheap liveness probe for the broker, for status displays.

    Cached, because this is called on every render of the sync screen and a
    stopped Redis otherwise costs the full connection timeout *per page load* —
    which is precisely the situation in which someone is reloading that page
    repeatedly to find out what is wrong.
    """
    from django.core.cache import cache

    if use_cache:
        cached = cache.get(_BROKER_PROBE_KEY)
        if cached is not None:
            return cached

    from config.celery import app

    try:
        connection = app.connection_for_write()
        connection.ensure_connection(
            max_retries=0, timeout=BROKER_PROBE_TIMEOUT_SECONDS
        )
        connection.release()
        available = True
    except Exception:  # noqa: BLE001 - any failure means "not usable"
        available = False

    cache.set(_BROKER_PROBE_KEY, available, BROKER_PROBE_CACHE_SECONDS)
    return available


def _inline_allowed() -> bool:
    return getattr(settings, "CELERY_INLINE_FALLBACK", settings.DEBUG)


def dispatch_task(task, *args, **kwargs) -> Dispatch:
    """Queue ``task``, falling back to inline execution when configured.

    Returns a :class:`Dispatch` describing what actually happened so the caller
    can tell the user whether the work is running in the background or already
    finished.
    """
    from django.core.cache import cache

    try:
        async_result = task.delay(*args, **kwargs)
    except OperationalError as exc:
        logger.warning("Celery broker unreachable: %s", exc)
        # A failed dispatch is better evidence than a probe; do not let a stale
        # cached "available" contradict what just happened.
        cache.set(_BROKER_PROBE_KEY, False, BROKER_PROBE_CACHE_SECONDS)

        if not _inline_allowed():
            return Dispatch(
                queued=False,
                broker_available=False,
                detail=(
                    "The background worker queue is unreachable, so this could not be "
                    f"scheduled. Redis is expected at {settings.CELERY_BROKER_URL}. "
                    "Either start it plus a Celery worker "
                    "(`celery -A config worker --pool=solo` on Windows, where the "
                    "default prefork pool does not work), or set "
                    "CELERY_INLINE_FALLBACK=true in your .env to run jobs directly "
                    "in the request without a queue."
                ),
            )

        logger.info("Running %s inline because the broker is unavailable", task.name)
        try:
            result = task(*args, **kwargs)
        except Exception as inline_exc:  # noqa: BLE001 - reported, not swallowed
            logger.exception("Inline execution of %s failed", task.name)
            return Dispatch(
                queued=False,
                broker_available=False,
                detail=f"Ran without a queue and failed: {inline_exc}",
            )

        dispatch = Dispatch(
            queued=False,
            ran_inline=True,
            broker_available=False,
            detail=(
                "Redis is not running, so this ran directly instead of being "
                "queued. It has already finished. Start Redis and the Celery "
                "worker for scheduled and background syncing."
            ),
        )
        dispatch.result = result
        return dispatch

    cache.set(_BROKER_PROBE_KEY, True, BROKER_PROBE_CACHE_SECONDS)
    return Dispatch(queued=True, task_id=async_result.id)
