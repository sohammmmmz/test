"""Sync orchestration records.

The nightly schedule, the manual sync button and the webhook receiver all enter
the same idempotent job. ``SyncRun`` is what makes a failure visible instead of
silent — a sync that dies at 2am with no record is indistinguishable from a
project where nobody committed.
"""

from django.db import models
from django.utils import timezone

from common.models import TimeStampedModel


class TriggerSource(models.TextChoices):
    SCHEDULE = "schedule", "Nightly schedule"
    MANUAL = "manual", "Manual sync"
    WEBHOOK = "webhook", "Webhook"
    REGISTRATION = "registration", "Initial registration"


class RunStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    RUNNING = "running", "Running"
    SUCCESS = "success", "Success"
    PARTIAL = "partial", "Completed with errors"
    FAILED = "failed", "Failed"


class SyncScope(models.TextChoices):
    """What a run was asked to cover.

    Derivable from ``project``/``employee`` being set, but stored explicitly so
    the history can be filtered and labelled without every reader
    re-implementing the same inference — and so "sync this person" stays
    distinguishable from "sync the four repositories they happen to be on",
    which is what it turns into once it starts running.
    """

    PROJECT = "project", "One project"
    ALL_PROJECTS = "all_projects", "All projects"
    EMPLOYEE = "employee", "One team member"
    ALL_EMPLOYEES = "all_employees", "All team members"


class SyncRun(TimeStampedModel):
    """One execution of the sync pipeline, over one project or all of them."""

    project = models.ForeignKey(
        "projects.Project", null=True, blank=True, on_delete=models.CASCADE,
        related_name="sync_runs", help_text="Null for a whole-fleet run.",
    )
    employee = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="sync_runs",
        help_text="Set when this run was requested for one person.",
    )
    scope = models.CharField(
        max_length=16, choices=SyncScope.choices, default=SyncScope.PROJECT, db_index=True
    )
    parent = models.ForeignKey(
        "self", null=True, blank=True, on_delete=models.CASCADE, related_name="children",
        help_text="Set on per-project children of a fleet run.",
    )
    trigger = models.CharField(max_length=32, choices=TriggerSource.choices)
    triggered_by = models.ForeignKey(
        "accounts.User", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="triggered_sync_runs",
    )
    status = models.CharField(
        max_length=16, choices=RunStatus.choices, default=RunStatus.PENDING, db_index=True
    )

    # The commit window this run covered.
    window_start = models.DateTimeField(null=True, blank=True)
    window_end = models.DateTimeField(null=True, blank=True)

    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    # Per-stage counts, e.g. {"commits": {"created": 12, "updated": 3}, ...}
    stage_counts = models.JSONField(default=dict, blank=True)
    # Per-stage failures. A stage failing marks the run PARTIAL, not FAILED —
    # one broken repo should not abort the fleet.
    errors = models.JSONField(default=list, blank=True)
    celery_task_id = models.CharField(max_length=255, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["project", "-created_at"]),
            models.Index(fields=["status", "-created_at"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        scope = self.project.name if self.project else "all projects"
        return f"{self.get_trigger_display()} sync of {scope} [{self.status}]"

    @property
    def duration_seconds(self):
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None

    def record_stage(self, stage: str, **counts):
        self.stage_counts[stage] = {**self.stage_counts.get(stage, {}), **counts}

    def record_error(self, stage: str, message: str, **extra):
        self.errors.append(
            {
                "stage": stage,
                "message": message,
                "at": timezone.now().isoformat(),
                **extra,
            }
        )


class WebhookEvent(TimeStampedModel):
    """A received GitLab webhook delivery.

    Persisted before processing so a delivery is never lost to a worker crash,
    and deduplicated because GitLab retries.
    """

    event_type = models.CharField(max_length=64, db_index=True)
    gitlab_event_uuid = models.CharField(max_length=128, blank=True, db_index=True)
    # Hash over the payload; catches retries that arrive without a UUID.
    dedupe_key = models.CharField(max_length=64, unique=True)

    gitlab_project_id = models.BigIntegerField(null=True, blank=True, db_index=True)
    project = models.ForeignKey(
        "projects.Project", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="webhook_events",
    )

    payload = models.JSONField(default=dict)
    signature_verified = models.BooleanField(default=False)
    received_at = models.DateTimeField(default=timezone.now, db_index=True)
    processed_at = models.DateTimeField(null=True, blank=True)
    process_error = models.TextField(blank=True)

    class Meta:
        ordering = ["-received_at"]

    def __str__(self):
        return f"{self.event_type} @ {self.received_at:%Y-%m-%d %H:%M:%S}"
