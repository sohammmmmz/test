"""Seed the database-backed Celery beat schedule.

Schedules live in the database rather than in code so the nightly sync time can
be changed from Django Admin without a redeploy. This command creates them if
absent and leaves existing entries alone — retuning the schedule must survive
the next deploy.
"""

import json

from django.conf import settings
from django.core.management.base import BaseCommand
from django_celery_beat.models import CrontabSchedule, PeriodicTask

SCHEDULES = [
    {
        "name": "Nightly GitLab sync",
        "task": "sync.nightly_sync",
        "crontab": {"hour": None, "minute": None},  # filled from settings
        "description": (
            "Full fleet sync. Also the reconciliation pass for webhooks, which "
            "GitLab drops entirely when a push touches more than three branches."
        ),
    },
    {
        "name": "Score pending commits",
        "task": "scoring.score_pending_commits",
        "crontab": {"hour": "*/4", "minute": "15"},
        "description": "Work through the scoring queue between nightly runs.",
    },
    {
        "name": "Summarise project documents",
        "task": "scoring.summarize_documents",
        "crontab": {"hour": "3", "minute": "30"},
        "description": "Extract BRD summaries so scoring has business context.",
    },
    {
        "name": "Refresh utilization snapshots",
        "task": "scoring.refresh_utilization",
        "crontab": {"hour": "4", "minute": "0"},
        "description": "Recompute planned allocation against observed engagement.",
    },
    {
        "name": "Prune sync history",
        "task": "sync.prune_sync_history",
        "crontab": {"hour": "5", "minute": "0", "day_of_week": "0"},
        "description": "Weekly trim of old sync runs and processed webhook deliveries.",
    },
]


class Command(BaseCommand):
    help = "Create the default Celery beat schedules if they do not exist."

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Overwrite existing schedules with the defaults.",
        )

    def handle(self, *args, **options):
        created = updated = 0

        for spec in SCHEDULES:
            crontab_spec = dict(spec["crontab"])
            if spec["task"] == "sync.nightly_sync":
                crontab_spec["hour"] = str(settings.NIGHTLY_SYNC_HOUR)
                crontab_spec["minute"] = str(settings.NIGHTLY_SYNC_MINUTE)

            schedule, _ = CrontabSchedule.objects.get_or_create(
                minute=crontab_spec.get("minute", "0"),
                hour=crontab_spec.get("hour", "*"),
                day_of_week=crontab_spec.get("day_of_week", "*"),
                day_of_month=crontab_spec.get("day_of_month", "*"),
                month_of_year=crontab_spec.get("month_of_year", "*"),
                timezone=settings.TIME_ZONE,
            )

            task, was_created = PeriodicTask.objects.get_or_create(
                name=spec["name"],
                defaults={
                    "task": spec["task"],
                    "crontab": schedule,
                    "description": spec["description"],
                    "kwargs": json.dumps({}),
                    "enabled": True,
                },
            )

            if was_created:
                created += 1
            elif options["reset"]:
                task.task = spec["task"]
                task.crontab = schedule
                task.interval = None
                task.description = spec["description"]
                task.save()
                updated += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"Periodic tasks: {created} created, {updated} updated, "
                f"{PeriodicTask.objects.count()} total."
            )
        )
        if not options["reset"] and created == 0:
            self.stdout.write(
                "Existing schedules left unchanged. Use --reset to restore defaults."
            )
