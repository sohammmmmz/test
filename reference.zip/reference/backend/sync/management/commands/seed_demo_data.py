"""Populate the database with realistic data for local development.

Creates no network traffic: every record is written directly, so the UI can be
exercised before any GitLab credentials exist.
"""

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from activity.models import (
    Branch,
    Commit,
    Issue,
    MergeRequest,
    Milestone,
    ProjectMember,
    ReviewNote,
)
from compliance.engine import evaluate_project, seed_default_rules
from projects.models import Document, DocumentKind, GitLabRepo, Project, ProjectStatus
from team.models import Assignment, AuthorAlias, Employee, EmploymentType, ProjectRole

PEOPLE = [
    ("Riya Sharma", "riya.sharma@company.com", EmploymentType.EMPLOYEE, "Senior Engineer", 1001),
    ("Arjun Mehta", "arjun.mehta@company.com", EmploymentType.EMPLOYEE, "Engineer", 1002),
    ("Neha Patel", "neha.patel@company.com", EmploymentType.INTERN, "Intern", 1003),
    ("Vikram Rao", "vikram.rao@company.com", EmploymentType.EMPLOYEE, "Tech Lead", 1004),
]

PROJECTS = [
    ("Apollo Portal", "Customer-facing self-service portal.", ProjectStatus.ACTIVE, True),
    ("Hermes Billing", "Billing and invoicing service.", ProjectStatus.ACTIVE, False),
    ("Atlas Analytics", "Internal analytics dashboards.", ProjectStatus.PLANNING, False),
]


class Command(BaseCommand):
    help = "Seed demo employees, projects and activity for local development."

    def add_arguments(self, parser):
        parser.add_argument("--wipe", action="store_true", help="Delete existing demo data first.")

    @transaction.atomic
    def handle(self, *args, **options):
        if options["wipe"]:
            Project.objects.all().delete()
            Employee.objects.all().delete()
            self.stdout.write("Wiped existing projects and employees.")

        seed_default_rules()

        employees = []
        for name, email, kind, designation, gitlab_id in PEOPLE:
            employee, _ = Employee.objects.get_or_create(
                official_email=email,
                defaults={
                    "full_name": name,
                    "employment_type": kind,
                    "designation": designation,
                    "gitlab_user_id": gitlab_id,
                    "gitlab_username": email.split("@")[0].replace(".", ""),
                    "weekly_capacity_hours": 20 if kind == EmploymentType.INTERN else 40,
                },
            )
            AuthorAlias.objects.get_or_create(
                email=email, defaults={"employee": employee, "source": AuthorAlias.Source.OFFICIAL}
            )
            employees.append(employee)

        now = timezone.now()

        for index, (name, description, status, compliant) in enumerate(PROJECTS):
            project, created = Project.objects.get_or_create(
                slug=name.lower().replace(" ", "-"),
                defaults={
                    "name": name,
                    "description": description,
                    "status": status,
                    "started_on": (now - timedelta(days=90)).date(),
                    "target_end_on": (now + timedelta(days=60)).date(),
                    "owner": employees[3],
                },
            )
            if not created:
                continue

            repo = GitLabRepo.objects.create(
                project=project,
                gitlab_project_id=9000 + index,
                path_with_namespace=f"acme/{project.slug}",
                name=project.slug,
                web_url=f"https://gitlab.com/acme/{project.slug}",
                default_branch="main",
                namespace_id=42,
                namespace_path="acme",
                documentation_branch_ready=compliant,
            )

            if compliant:
                milestone = Milestone.objects.create(
                    repo=repo, gitlab_id=100 + index, iid=1, title="M1 Launch",
                    state="active", start_date=(now - timedelta(days=30)).date(),
                    due_date=(now + timedelta(days=30)).date(),
                )
                for kind in (DocumentKind.BRD, DocumentKind.TECHNICAL):
                    Document.objects.create(
                        project=project, kind=kind,
                        filename=f"{kind.upper()}.pdf", repo_path=f"docs/{kind.upper()}.pdf",
                        content_hash=f"hash-{project.slug}-{kind}",
                        committed_at=now - timedelta(days=20),
                        summary=f"Placeholder summary for the {kind} of {project.name}.",
                    )
            else:
                milestone = None

            member_count = 3 if compliant else 0
            for employee in employees[:member_count]:
                ProjectMember.objects.create(
                    repo=repo, gitlab_user_id=employee.gitlab_user_id,
                    username=employee.gitlab_username, name=employee.full_name,
                    access_level=30, employee=employee,
                )

            for offset, employee in enumerate(employees[: 2 + index]):
                Assignment.objects.create(
                    employee=employee, project=project,
                    role=ProjectRole.TECH_LEAD if offset == 0 else ProjectRole.DEVELOPER,
                    allocation_percent=60 if offset == 0 else 40,
                    started_on=(now - timedelta(days=60)).date(),
                )

            for issue_index in range(1, 4):
                issue = Issue.objects.create(
                    repo=repo, iid=issue_index, gitlab_id=1000 + issue_index,
                    title=f"Task {issue_index} for {project.name}",
                    description="Implement the described behaviour.",
                    state="opened" if issue_index < 3 else "closed",
                    milestone=milestone,
                    gitlab_created_at=now - timedelta(days=30),
                    gitlab_updated_at=now - timedelta(days=2),
                )
                issue.assignees.add(employees[issue_index % len(employees)])

            for branch_index, employee in enumerate(employees[:3]):
                branch_name = f"feature/{employee.gitlab_username}-work"
                last = now - timedelta(days=branch_index * 5)
                Branch.objects.create(
                    repo=repo, name=branch_name, last_commit_sha=f"sha{branch_index}",
                    last_commit_at=last, last_commit_author=employee,
                    last_commit_author_email=employee.official_email,
                )
                for commit_index in range(4):
                    authored = last - timedelta(days=commit_index, hours=commit_index)
                    Commit.objects.create(
                        repo=repo,
                        sha=f"{index}{branch_index}{commit_index}".ljust(40, "f"),
                        short_id=f"{index}{branch_index}{commit_index}abcde"[:8],
                        title=f"feat: work item {commit_index} #{(commit_index % 3) + 1}",
                        message=f"feat: work item {commit_index} #{(commit_index % 3) + 1}",
                        author_name=employee.full_name,
                        author_email=employee.official_email,
                        author_employee=employee,
                        authored_date=authored,
                        committed_date=authored,
                        branch_names=[branch_name],
                        referenced_issue_iids=[(commit_index % 3) + 1],
                        changed_paths=[
                            f"src/{'api' if commit_index % 2 else 'web'}/module.py"
                        ],
                        additions=20 + commit_index,
                        deletions=commit_index,
                    )

                merge_request = MergeRequest.objects.create(
                    repo=repo, iid=branch_index + 1, gitlab_id=2000 + branch_index,
                    title=f"Merge {branch_name}", state="merged" if branch_index == 0 else "opened",
                    source_branch=branch_name, target_branch="main",
                    author_employee=employee, author_gitlab_id=employee.gitlab_user_id,
                    gitlab_created_at=last - timedelta(days=3),
                    gitlab_updated_at=last,
                    merged_at=last if branch_index == 0 else None,
                    user_notes_count=2, has_pipeline_success=True,
                )

                # Review notes by someone other than the author, dated away from
                # their own commits. Without these the demo data has no day of
                # review-without-commits, which is exactly the case the cadence
                # view must not report as an absence.
                reviewer = employees[(branch_index + 1) % len(employees)]
                for note_index in range(2):
                    ReviewNote.objects.create(
                        merge_request=merge_request,
                        gitlab_note_id=int(f"{index}{branch_index}{note_index}9"),
                        author_employee=reviewer,
                        author_gitlab_id=reviewer.gitlab_user_id,
                        body="Looks reasonable — one comment on error handling.",
                        noted_at=last - timedelta(days=7 + note_index),
                    )

            Project.objects.filter(pk=project.pk).update(
                last_activity_at=now - timedelta(days=1), last_synced_at=now
            )

        for project in Project.objects.select_related("repo"):
            evaluate_project(project)

        self.stdout.write(
            self.style.SUCCESS(
                f"Seeded {Employee.objects.count()} employees, "
                f"{Project.objects.count()} projects, {Commit.objects.count()} commits."
            )
        )
        self.stdout.write(
            "Note: HAS_DOCUMENTS reaches out to GitLab, so it may report a scan "
            "failure against these fabricated repositories. That is expected offline."
        )
