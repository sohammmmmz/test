from django.urls import path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("runs", views.SyncRunViewSet, basename="sync-run")
router.register("webhook-events", views.WebhookEventViewSet, basename="webhook-event")

urlpatterns = [
    path("trigger", views.TriggerSyncView.as_view(), name="sync-trigger"),
    path("status", views.sync_status, name="sync-status"),
    path("targets", views.sync_targets, name="sync-targets"),
    path("runs/<int:run_id>/children", views.sync_run_children, name="sync-run-children"),
    path("register-webhook", views.register_webhook, name="sync-register-webhook"),
    *router.urls,
]
