"""Per-entity GitLab synchronisation.

Every syncer upserts on a natural key, so the nightly sweep, the manual sync
button and webhook-driven runs can overlap freely without creating duplicates
or losing writes.
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from datetime import timedelta

from django.conf import settings
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from activity.models import (
    Branch,
    Commit,
    Issue,
    MergeRequest,
    Milestone,
    ProjectMember,
    ReviewNote,
)
from gitlab_integration.client import GitLabClient
from projects.models import GitLabRepo
from team.identity import AuthorResolver

logger = logging.getLogger(__name__)

# "#123", "Closes #45", "Fixes #7" — the cheapest and strongest signal that a
# commit belongs to a piece of assigned work.
ISSUE_REF_RE = re.compile(r"#(\d{1,7})\b")


@dataclass
class StageResult:
    created: int = 0
    updated: int = 0
    skipped: int = 0
    errors: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        data = {"created": self.created, "updated": self.updated, "skipped": self.skipped}
        if self.errors:
            data["errors"] = self.errors
        return data


def _dt(value):
    """Parse a GitLab ISO timestamp into an aware datetime."""
    if not value:
        return None
    parsed = parse_datetime(value) if isinstance(value, str) else value
    if parsed and timezone.is_naive(parsed):
        parsed = timezone.make_aware(parsed, timezone.utc)
    return parsed


def extract_issue_refs(message: str) -> list[int]:
    """Issue iids referenced in a commit message, de-duplicated and ordered."""
    seen, result = set(), []
    for match in ISSUE_REF_RE.finditer(message or ""):
        iid = int(match.group(1))
        if iid not in seen:
            seen.add(iid)
            result.append(iid)
    return result


def commit_window(repo: GitLabRepo, *, full: bool = False, days: int | None = None):
    """The time range this sync should re-fetch.

    Always overlaps previously-synced time rather than resuming exactly where
    it left off: webhooks drop pushes that touch more than three branches, and
    the overlap is what heals those gaps. Upserts make the redundancy free.

    ``days`` pins the window to a fixed span ending now, regardless of when this
    repository was last synced. That is what the quick sync buttons use — "bring
    me up to date with today" is a different question from "reconcile whatever
    has been missed since last time", and answering it takes one page of commits
    from GitLab instead of a week's worth. A repository that has never been
    synced still gets the full backfill, because a one-day window over an empty
    table would leave it looking permanently empty.
    """
    now = timezone.now()
    if full or repo.last_commit_synced_at is None:
        return now - timedelta(days=settings.SYNC_INITIAL_BACKFILL_DAYS), now
    if days is not None:
        return now - timedelta(days=max(1, days)), now
    return (
        repo.last_commit_synced_at - timedelta(days=settings.SYNC_LOOKBACK_DAYS),
        now,
    )


# ---------------------------------------------------------------------------
# Commits
# ---------------------------------------------------------------------------


def sync_commits(
    repo: GitLabRepo,
    client: GitLabClient,
    resolver: AuthorResolver,
    *,
    since=None,
    until=None,
) -> StageResult:
    """Sync commits across every branch.

    ``all_branches=True`` is load-bearing. The endpoint otherwise returns only
    the default branch, so a team that works on feature branches and merges
    rarely would appear to have committed nothing at all.
    """
    result = StageResult()
    newest_seen = repo.last_commit_synced_at

    for payload in client.list_commits(
        repo.gitlab_project_id, since=since, until=until, all_branches=True, with_stats=True
    ):
        authored = _dt(payload.get("authored_date")) or _dt(payload.get("created_at"))
        if authored is None:
            result.skipped += 1
            continue

        stats = payload.get("stats") or {}
        message = payload.get("message", "") or ""
        parents = payload.get("parent_ids") or []
        author_email = (payload.get("author_email") or "").strip().lower()

        # Some responses carry a GitLab-resolved author; prefer it. When they
        # do not — which is most of the time, the commits endpoint returns only
        # the git trailer — the resolver works the account out from the email,
        # its local part and the display name. See ``team.identity``.
        author_account = payload.get("author") or {}
        employee, author_username = resolver.resolve_identity(
            author_email,
            name=payload.get("author_name", ""),
            gitlab_user_id=author_account.get("id"),
            username=author_account.get("username"),
        )

        _obj, created = Commit.objects.update_or_create(
            repo=repo,
            sha=payload["id"],
            defaults={
                "short_id": payload.get("short_id", "") or "",
                "title": payload.get("title", "") or "",
                "message": message,
                "author_name": payload.get("author_name", "") or "",
                "author_email": author_email,
                "author_username": author_username,
                "committer_name": payload.get("committer_name", "") or "",
                "committer_email": (payload.get("committer_email") or "").strip().lower(),
                "authored_date": authored,
                "committed_date": _dt(payload.get("committed_date")),
                "author_employee": employee,
                "web_url": payload.get("web_url", "") or "",
                "parent_ids": parents,
                "is_merge_commit": len(parents) > 1,
                "additions": stats.get("additions"),
                "deletions": stats.get("deletions"),
                "total_changes": stats.get("total"),
                "referenced_issue_iids": extract_issue_refs(message),
            },
        )
        result.created += int(created)
        result.updated += int(not created)

        if newest_seen is None or authored > newest_seen:
            newest_seen = authored

    if newest_seen and newest_seen != repo.last_commit_synced_at:
        repo.last_commit_synced_at = newest_seen
        repo.save(update_fields=["last_commit_synced_at", "updated_at"])

    return result


# ---------------------------------------------------------------------------
# Branches
# ---------------------------------------------------------------------------


def sync_branches(
    repo: GitLabRepo, client: GitLabClient, resolver: AuthorResolver
) -> StageResult:
    """Sync branch metadata.

    Commits are fetched with ``all=true``, which loses branch attribution, so
    this pass is what makes "who owns this feature branch and is it stale?"
    answerable.
    """
    result = StageResult()
    seen: set[str] = set()

    for payload in client.list_branches(repo.gitlab_project_id):
        name = payload["name"]
        seen.add(name)
        last_commit = payload.get("commit") or {}
        author_email = (last_commit.get("author_email") or "").strip().lower()

        _obj, created = Branch.objects.update_or_create(
            repo=repo,
            name=name,
            defaults={
                "is_default": bool(payload.get("default")),
                "is_protected": bool(payload.get("protected")),
                "is_merged": bool(payload.get("merged")),
                "last_commit_sha": last_commit.get("id", "") or "",
                "last_commit_at": _dt(last_commit.get("committed_date")),
                "last_commit_author_email": author_email,
                "last_commit_author": resolver.resolve(
                    author_email, name=last_commit.get("author_name", "")
                ),
                "web_url": payload.get("web_url", "") or "",
                "is_present": True,
            },
        )
        result.created += int(created)
        result.updated += int(not created)

    # Branches deleted upstream are flagged rather than removed: their commits
    # still exist and still count as somebody's work.
    vanished = Branch.objects.filter(repo=repo, is_present=True).exclude(name__in=seen)
    result.skipped = vanished.update(is_present=False)

    return result


# ---------------------------------------------------------------------------
# Milestones, issues, merge requests, members
# ---------------------------------------------------------------------------


def sync_milestones(repo: GitLabRepo, client: GitLabClient) -> StageResult:
    result = StageResult()
    for payload in client.list_milestones(repo.gitlab_project_id):
        _obj, created = Milestone.objects.update_or_create(
            repo=repo,
            gitlab_id=payload["id"],
            defaults={
                "iid": payload.get("iid"),
                "title": payload.get("title", "") or "",
                "description": payload.get("description", "") or "",
                "state": payload.get("state", "") or "",
                "start_date": payload.get("start_date"),
                "due_date": payload.get("due_date"),
                "expired": bool(payload.get("expired")),
                "web_url": payload.get("web_url", "") or "",
            },
        )
        result.created += int(created)
        result.updated += int(not created)
    return result


def sync_issues(
    repo: GitLabRepo, client: GitLabClient, resolver: AuthorResolver, *, updated_after=None
) -> StageResult:
    result = StageResult()
    milestones = {m.gitlab_id: m for m in Milestone.objects.filter(repo=repo)}

    for payload in client.list_issues(repo.gitlab_project_id, updated_after=updated_after):
        milestone_payload = payload.get("milestone") or {}
        assignees = payload.get("assignees") or []
        assignee_ids = [a["id"] for a in assignees if a.get("id")]
        time_stats = payload.get("time_stats") or {}

        issue, created = Issue.objects.update_or_create(
            repo=repo,
            iid=payload["iid"],
            defaults={
                "gitlab_id": payload.get("id"),
                "title": payload.get("title", "") or "",
                "description": payload.get("description", "") or "",
                "state": payload.get("state", "") or "",
                "labels": payload.get("labels") or [],
                "milestone": milestones.get(milestone_payload.get("id")),
                "assignee_gitlab_ids": assignee_ids,
                "due_date": payload.get("due_date"),
                "gitlab_created_at": _dt(payload.get("created_at")),
                "gitlab_updated_at": _dt(payload.get("updated_at")),
                "closed_at": _dt(payload.get("closed_at")),
                "web_url": payload.get("web_url", "") or "",
                "time_estimate_seconds": time_stats.get("time_estimate") or 0,
                "time_spent_seconds": time_stats.get("total_time_spent") or 0,
            },
        )
        result.created += int(created)
        result.updated += int(not created)

        employees = [
            emp
            for emp in (
                resolver.resolve(a.get("email"), gitlab_user_id=a.get("id")) for a in assignees
            )
            if emp is not None
        ]
        issue.assignees.set(employees)

    return result


def sync_merge_requests(
    repo: GitLabRepo,
    client: GitLabClient,
    resolver: AuthorResolver,
    *,
    updated_after=None,
    with_notes: bool = True,
) -> StageResult:
    result = StageResult()
    milestones = {m.gitlab_id: m for m in Milestone.objects.filter(repo=repo)}

    for payload in client.list_merge_requests(
        repo.gitlab_project_id, updated_after=updated_after
    ):
        author = payload.get("author") or {}
        milestone_payload = payload.get("milestone") or {}

        merge_request, created = MergeRequest.objects.update_or_create(
            repo=repo,
            iid=payload["iid"],
            defaults={
                "gitlab_id": payload.get("id"),
                "title": payload.get("title", "") or "",
                "description": payload.get("description", "") or "",
                "state": payload.get("state", "") or "",
                "source_branch": payload.get("source_branch", "") or "",
                "target_branch": payload.get("target_branch", "") or "",
                "author_gitlab_id": author.get("id"),
                "author_employee": resolver.resolve(
                    author.get("email"), name=author.get("name", ""),
                    gitlab_user_id=author.get("id"),
                    username=author.get("username"),
                ),
                "gitlab_created_at": _dt(payload.get("created_at")),
                "gitlab_updated_at": _dt(payload.get("updated_at")),
                "merged_at": _dt(payload.get("merged_at")),
                "closed_at": _dt(payload.get("closed_at")),
                "milestone": milestones.get(milestone_payload.get("id")),
                "labels": payload.get("labels") or [],
                "web_url": payload.get("web_url", "") or "",
                "user_notes_count": payload.get("user_notes_count") or 0,
            },
        )
        result.created += int(created)
        result.updated += int(not created)

        if with_notes and merge_request.user_notes_count:
            try:
                sync_merge_request_notes(repo, merge_request, client, resolver)
            except Exception as exc:  # noqa: BLE001 - one MR must not abort the stage
                result.errors.append(f"notes for !{merge_request.iid}: {exc}")

    return result


def sync_merge_request_notes(
    repo: GitLabRepo, merge_request: MergeRequest, client: GitLabClient, resolver: AuthorResolver
) -> int:
    """Sync review comments.

    Review is real contribution that leaves no commits behind. Without this, a
    person who spends a week unblocking colleagues registers as idle.
    """
    count = 0
    for payload in client.list_merge_request_notes(repo.gitlab_project_id, merge_request.iid):
        if payload.get("system"):
            # Automated "changed the description" entries are not contribution.
            continue
        author = payload.get("author") or {}
        ReviewNote.objects.update_or_create(
            merge_request=merge_request,
            gitlab_note_id=payload["id"],
            defaults={
                "author_gitlab_id": author.get("id"),
                "author_employee": resolver.resolve(
                    author.get("email"), name=author.get("name", ""),
                    gitlab_user_id=author.get("id"),
                    username=author.get("username"),
                ),
                "body": payload.get("body", "") or "",
                "is_system": False,
                "is_resolvable": bool(payload.get("resolvable")),
                "noted_at": _dt(payload.get("created_at")) or timezone.now(),
            },
        )
        count += 1
    return count


def sync_members(
    repo: GitLabRepo, client: GitLabClient, resolver: AuthorResolver
) -> StageResult:
    """Sync project membership, including access inherited from parent groups."""
    result = StageResult()
    seen: set[int] = set()

    for payload in client.list_members(repo.gitlab_project_id, include_inherited=True):
        gitlab_user_id = payload["id"]
        seen.add(gitlab_user_id)

        _obj, created = ProjectMember.objects.update_or_create(
            repo=repo,
            gitlab_user_id=gitlab_user_id,
            defaults={
                "username": payload.get("username", "") or "",
                "name": payload.get("name", "") or "",
                "email": (payload.get("email") or "").strip().lower(),
                "access_level": payload.get("access_level") or 0,
                "employee": resolver.resolve(
                    payload.get("email"), name=payload.get("name", ""),
                    gitlab_user_id=gitlab_user_id,
                    username=payload.get("username"),
                ),
                # Inherited members report the group they came from.
                "is_inherited": bool(payload.get("group_saml_identity"))
                or payload.get("membership_state") == "inherited",
                "expires_at": payload.get("expires_at"),
            },
        )
        result.created += int(created)
        result.updated += int(not created)

    removed, _ = ProjectMember.objects.filter(repo=repo).exclude(
        gitlab_user_id__in=seen
    ).delete()
    result.skipped = removed

    return result


def refresh_repo_metadata(repo: GitLabRepo, client: GitLabClient) -> None:
    """Re-read project metadata so a renamed or re-defaulted repo stays correct."""
    payload = client.get_project(repo.gitlab_project_id)
    namespace = payload.get("namespace") or {}

    repo.path_with_namespace = payload.get("path_with_namespace", repo.path_with_namespace)
    repo.name = payload.get("name", repo.name)
    repo.web_url = payload.get("web_url", repo.web_url)
    repo.default_branch = payload.get("default_branch") or repo.default_branch
    repo.visibility = payload.get("visibility", repo.visibility)
    repo.namespace_id = namespace.get("id", repo.namespace_id)
    repo.namespace_path = namespace.get("full_path", repo.namespace_path)
    repo.last_activity_at = _dt(payload.get("last_activity_at")) or repo.last_activity_at
    repo.save()


def diff_hash(diffs: list[dict]) -> str:
    """Stable hash over a commit's diff, used as the scoring cache key."""
    hasher = hashlib.sha256()
    for entry in sorted(diffs, key=lambda d: d.get("new_path") or d.get("old_path") or ""):
        hasher.update((entry.get("new_path") or "").encode())
        hasher.update((entry.get("diff") or "").encode())
    return hasher.hexdigest()
