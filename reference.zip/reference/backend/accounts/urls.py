from django.urls import path

from . import views

urlpatterns = [
    # Password
    path("login", views.password_login, name="auth-login"),
    path("register", views.register, name="auth-register"),
    path("password", views.change_password, name="auth-password"),
    # Tokens
    path("refresh", views.token_refresh, name="auth-refresh"),
    # GitLab OAuth
    path("gitlab/login", views.gitlab_login, name="gitlab-login"),
    path("gitlab/callback", views.gitlab_callback, name="gitlab-callback"),
    # Shared
    path("me", views.me, name="auth-me"),
    path("logout", views.auth_logout, name="auth-logout"),
    path("config", views.auth_config, name="auth-config"),
]
