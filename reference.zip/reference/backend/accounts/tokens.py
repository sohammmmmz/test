"""JWT issuing, verification and refresh-token rotation.

Why JWTs at all, when Django sessions already work: the session cookie was
capped at twelve hours, so every working day began by being bounced to GitLab
again. A long-lived *session* is the wrong way to fix that — it is a
server-side row that stays valid until it expires, with no way to tell a stolen
cookie from a legitimate one.

The shape here instead:

* a short-lived **access** token (30 minutes) that carries the identity, and
* a long-lived **refresh** token (30 days) whose only power is to mint a new
  pair, and which is *rotated* on every use.

Rotation is what makes the long lifetime defensible. Each refresh token is
issued against a ``RefreshSession`` row that remembers only a hash of the
currently valid token id. Presenting an old one — the signature is still
perfectly valid, it simply is not the current one — means the token was
captured and replayed, so the whole session is revoked and both the attacker
and the real user are logged out. That is deliberately the loud failure: a
silent one would leave the attacker holding a working credential.

Both tokens are signed with HS256 over ``SECRET_KEY``. That is symmetric, which
is fine because only this application both issues and verifies them; there is
no third party to hand a public key to.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass
from datetime import timedelta

import jwt
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils import timezone

from .models import RefreshSession, User

# PyJWT is not the only package on PyPI that installs a top-level module called
# ``jwt``; the unrelated ``jwt`` package does too, and whichever was installed
# last wins. Left unchecked that surfaces as ``AttributeError: module 'jwt' has
# no attribute 'encode'`` from inside a sign-in request, which reads like a bug
# in this file rather than the packaging accident it is. Fail at import instead,
# and say what to run.
if not hasattr(jwt, "encode"):  # pragma: no cover - environment guard
    raise ImportError(
        f"The importable 'jwt' module ({jwt.__file__}) is not PyJWT. The "
        "unrelated PyPI package named 'jwt' installs the same module name and "
        "shadows it. Fix with:\n"
        "    pip uninstall -y jwt PyJWT\n"
        "    pip install PyJWT"
    )

# A malformed "sid" claim reaches the ORM as an invalid UUID rather than as a
# missing row, so both failures have to be caught in the same place.
BAD_SESSION_ID = (ValidationError, ValueError, TypeError)

ALGORITHM = "HS256"
ISSUER = "employee-util-tracker"

ACCESS = "access"
REFRESH = "refresh"


class TokenError(Exception):
    """Any reason a presented token cannot be honoured."""


@dataclass(frozen=True)
class TokenPair:
    access: str
    refresh: str
    access_expires_at: object
    refresh_expires_at: object
    session: RefreshSession


def _signing_key() -> str:
    return getattr(settings, "JWT_SIGNING_KEY", None) or settings.SECRET_KEY


def _access_ttl() -> timedelta:
    return timedelta(seconds=settings.JWT_ACCESS_TTL_SECONDS)


def _refresh_ttl() -> timedelta:
    return timedelta(seconds=settings.JWT_REFRESH_TTL_SECONDS)


def _hash(value: str) -> str:
    """Store only a hash of the live token id.

    A database read — a backup, a log, a stray dump — must not yield anything
    that can be replayed.
    """
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _encode(*, user: User, kind: str, jti: str, session_id: str, expires_at) -> str:
    payload = {
        "sub": str(user.pk),
        "typ": kind,
        "jti": jti,
        "sid": session_id,
        "iss": ISSUER,
        "iat": int(timezone.now().timestamp()),
        "exp": int(expires_at.timestamp()),
    }
    if kind == ACCESS:
        # Denormalised onto the access token so the common path — authenticating
        # a request — needs no database read at all. Staleness is bounded by the
        # access lifetime, which is the trade being made.
        payload["username"] = user.username
        payload["email"] = user.email
        payload["staff"] = bool(user.is_staff)
    return jwt.encode(payload, _signing_key(), algorithm=ALGORITHM)


def decode(token: str, *, expected: str | None = None) -> dict:
    """Verify a token's signature, issuer and expiry, and return its claims."""
    try:
        claims = jwt.decode(
            token,
            _signing_key(),
            algorithms=[ALGORITHM],
            issuer=ISSUER,
            options={"require": ["exp", "sub", "typ", "jti"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise TokenError("Token has expired.") from exc
    except jwt.InvalidTokenError as exc:
        raise TokenError("Token is not valid.") from exc

    if expected is not None and claims.get("typ") != expected:
        # A refresh token must never be usable as an access token: it lives far
        # longer, and the whole point of the short access lifetime is lost if
        # the two are interchangeable.
        raise TokenError(f"Expected a {expected} token.")
    return claims


def issue_pair(user: User, *, session: RefreshSession | None = None, request=None) -> TokenPair:
    """Mint an access/refresh pair, starting a new session unless one is given."""
    now = timezone.now()
    refresh_expires_at = now + _refresh_ttl()
    access_expires_at = now + _access_ttl()
    jti = uuid.uuid4().hex

    if session is None:
        session = RefreshSession.objects.create(
            user=user,
            token_hash=_hash(jti),
            expires_at=refresh_expires_at,
            user_agent=_user_agent(request),
            ip_address=_client_ip(request),
            last_used_at=now,
        )
    else:
        session.previous_token_hash = session.token_hash
        session.rotated_at = now
        session.token_hash = _hash(jti)
        session.last_used_at = now
        session.rotation_count += 1
        # A sliding expiry: someone who uses the tool daily is never logged out,
        # while an abandoned session still dies on schedule.
        session.expires_at = refresh_expires_at
        session.save(
            update_fields=[
                "token_hash", "previous_token_hash", "rotated_at", "last_used_at",
                "rotation_count", "expires_at", "updated_at",
            ]
        )

    session_id = str(session.pk)
    return TokenPair(
        access=_encode(
            user=user, kind=ACCESS, jti=uuid.uuid4().hex,
            session_id=session_id, expires_at=access_expires_at,
        ),
        refresh=_encode(
            user=user, kind=REFRESH, jti=jti,
            session_id=session_id, expires_at=refresh_expires_at,
        ),
        access_expires_at=access_expires_at,
        refresh_expires_at=refresh_expires_at,
        session=session,
    )


def rotate(raw_refresh: str, *, request=None) -> tuple[User, TokenPair]:
    """Exchange a refresh token for a fresh pair, invalidating the one used."""
    claims = decode(raw_refresh, expected=REFRESH)

    try:
        session = RefreshSession.objects.select_related("user").get(pk=claims["sid"])
    except (RefreshSession.DoesNotExist, *BAD_SESSION_ID) as exc:
        raise TokenError("Session is unknown.") from exc

    if session.revoked_at is not None:
        raise TokenError("Session has been signed out.")
    if session.expires_at <= timezone.now():
        raise TokenError("Session has expired.")

    presented = _hash(claims["jti"])
    if session.token_hash != presented:
        if not _within_grace(session, presented):
            # Correctly signed, but superseded and too old to be a race. The
            # only way to hold one of these is to have captured it, so the
            # session dies rather than just the request — leaving it alive would
            # leave whoever replayed the token still holding a working one.
            session.revoke(reason=RefreshSession.RevokeReason.REUSED)
            raise TokenError("Refresh token has already been used.")

    user = session.user
    if not user.is_active:
        session.revoke(reason=RefreshSession.RevokeReason.INACTIVE)
        raise TokenError("Account is disabled.")

    if request is not None:
        session.user_agent = _user_agent(request) or session.user_agent
        session.ip_address = _client_ip(request) or session.ip_address

    return user, issue_pair(user, session=session, request=request)


def _within_grace(session: RefreshSession, presented_hash: str) -> bool:
    """True when this is the token we just replaced, moments ago.

    Two browser tabs waking from sleep, or a page and its data request going out
    together, both present the refresh token they were holding. One wins the
    rotation; the other arrives with a token that is now historic through no
    fault of anyone. Treating that as a replay would sign people out at random,
    which is both wrong and — because it looks like flakiness rather than a
    security event — the kind of wrong that gets the whole mechanism disabled.

    The window is deliberately small. Outside it, a superseded token really is
    evidence of a copy.
    """
    if not session.previous_token_hash or session.rotated_at is None:
        return False
    if session.previous_token_hash != presented_hash:
        return False
    age = (timezone.now() - session.rotated_at).total_seconds()
    return age <= settings.JWT_REFRESH_GRACE_SECONDS


def revoke_session(session_id: str, *, reason: str = "") -> None:
    RefreshSession.objects.filter(pk=session_id, revoked_at__isnull=True).update(
        revoked_at=timezone.now(),
        revoke_reason=reason or RefreshSession.RevokeReason.LOGOUT,
    )


def revoke_all_for_user(user: User, *, reason: str = "") -> int:
    """Sign a person out everywhere. Used when a password changes."""
    return RefreshSession.objects.filter(user=user, revoked_at__isnull=True).update(
        revoked_at=timezone.now(),
        revoke_reason=reason or RefreshSession.RevokeReason.PASSWORD_CHANGE,
    )


def _user_agent(request) -> str:
    if request is None:
        return ""
    return (request.META.get("HTTP_USER_AGENT") or "")[:400]


def _client_ip(request) -> str | None:
    if request is None:
        return None
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
    if forwarded:
        # Left-most entry is the original client; the rest are proxies.
        return forwarded.split(",")[0].strip() or None
    return request.META.get("REMOTE_ADDR") or None
