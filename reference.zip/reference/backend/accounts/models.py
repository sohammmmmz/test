"""Admin users, their sign-in sessions, and their GitLab OAuth credentials.

This is an admin-only tool: every authenticated user is staff. There are two
ways in — a password (restricted to the company email domain) and GitLab OAuth
— and both end at the same place, a JWT access/refresh pair backed by a
``RefreshSession``. The GitLab OAuth tokens are a separate concern: they are
used *only* for acting as that person against GitLab (notably the "is this repo
accessible to me?" check during project registration). All scheduled work uses
the service credential instead.
"""

import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

from common.models import TimeStampedModel


class User(AbstractUser):
    """Application user, identified by GitLab account."""

    email = models.EmailField(unique=True)
    gitlab_user_id = models.BigIntegerField(unique=True, null=True, blank=True)
    gitlab_username = models.CharField(max_length=255, blank=True)
    gitlab_avatar_url = models.URLField(blank=True)
    gitlab_web_url = models.URLField(blank=True)
    last_login_at = models.DateTimeField(null=True, blank=True)

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["email"]

    def __str__(self):
        return self.gitlab_username or self.username or self.email


class RefreshSession(TimeStampedModel):
    """One sign-in, on one device, alive across many refresh rotations.

    Only a hash of the *currently valid* refresh token id is kept, so this table
    holds nothing replayable. Presenting a superseded token means it was
    captured, and the whole row is revoked rather than the single request being
    rejected — see ``accounts.tokens.rotate``.
    """

    class RevokeReason(models.TextChoices):
        LOGOUT = "logout", "Signed out"
        REUSED = "reused", "Superseded token replayed"
        PASSWORD_CHANGE = "password_change", "Password changed"
        INACTIVE = "inactive", "Account disabled"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="refresh_sessions")
    token_hash = models.CharField(max_length=64, db_index=True)
    # The token this one replaced, honoured for a few seconds after rotation.
    # Two tabs waking up together both present the same refresh token, and
    # without this the second one would be read as a replay and sign the person
    # out of a session they are actively using.
    previous_token_hash = models.CharField(max_length=64, blank=True)
    rotated_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField()
    revoked_at = models.DateTimeField(null=True, blank=True)
    revoke_reason = models.CharField(max_length=32, blank=True, choices=RevokeReason.choices)
    last_used_at = models.DateTimeField(null=True, blank=True)
    rotation_count = models.PositiveIntegerField(default=0)
    user_agent = models.CharField(max_length=400, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "revoked_at"])]

    def __str__(self):
        return f"Session {self.pk} for {self.user}"

    @property
    def is_live(self) -> bool:
        return self.revoked_at is None and self.expires_at > timezone.now()

    def revoke(self, *, reason: str = RevokeReason.LOGOUT) -> None:
        if self.revoked_at is not None:
            return
        self.revoked_at = timezone.now()
        self.revoke_reason = reason
        self.save(update_fields=["revoked_at", "revoke_reason", "updated_at"])


class GitLabOAuthToken(TimeStampedModel):
    """A user's GitLab OAuth tokens.

    GitLab access tokens expire after two hours, and refreshing rotates the
    refresh token — the old one is invalidated the moment a new pair is issued.
    Persisting the new pair therefore has to happen before the old one is
    discarded, or the user's connection is orphaned permanently. Refresh is
    wrapped in a transaction with a row lock for exactly this reason (see
    ``gitlab_integration.oauth.refresh_user_token``).
    """

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="gitlab_token")
    access_token = models.TextField()
    refresh_token = models.TextField(blank=True)
    token_type = models.CharField(max_length=32, default="Bearer")
    scope = models.CharField(max_length=255, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    # Set when a refresh fails irrecoverably; the user must re-authorize.
    is_revoked = models.BooleanField(default=False)
    last_refreshed_at = models.DateTimeField(null=True, blank=True)
    refresh_failure_count = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "GitLab OAuth token"

    def __str__(self):
        return f"GitLab token for {self.user}"

    def is_expired(self, leeway_seconds: int = 120) -> bool:
        """True when the access token is expired or about to be.

        The leeway avoids handing out a token that dies mid-request.
        """
        if self.expires_at is None:
            return False
        return timezone.now() >= self.expires_at - timezone.timedelta(seconds=leeway_seconds)


class OAuthState(TimeStampedModel):
    """Short-lived CSRF state for the authorization-code flow."""

    state = models.CharField(max_length=128, unique=True, db_index=True)
    redirect_to = models.CharField(max_length=512, blank=True)
    expires_at = models.DateTimeField()
    consumed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.state

    @property
    def is_usable(self) -> bool:
        return self.consumed_at is None and timezone.now() < self.expires_at
