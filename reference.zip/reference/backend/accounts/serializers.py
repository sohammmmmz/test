"""Registration and password-login payloads.

The company-domain rule lives here rather than in the views because it has to
hold on every route that can create or name an account, and a rule enforced in
two places eventually gets enforced in one.
"""

from django.contrib.auth import authenticate, get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db.models import Q
from rest_framework import serializers

User = get_user_model()


def allowed_domains() -> list[str]:
    from django.conf import settings

    return [d.lower().lstrip("@") for d in settings.ALLOWED_EMAIL_DOMAINS if d.strip()]


def domain_of(email: str) -> str:
    return email.rsplit("@", 1)[-1].lower() if "@" in email else ""


def check_email_domain(email: str) -> str:
    """Reject anything outside the company domain, normalised to lower case.

    Subdomains are not accepted implicitly: ``mail.solargroup.com`` is a
    different mail system from ``solargroup.com`` and may not be under the same
    control, so allowing it has to be an explicit entry in the setting.
    """
    domains = allowed_domains()
    if not domains:
        return email.strip().lower()

    email = email.strip().lower()
    if domain_of(email) not in domains:
        allowed = ", ".join(f"@{d}" for d in domains)
        raise serializers.ValidationError(
            f"Use your company email address. Only {allowed} is accepted here."
        )
    return email


class RegistrationSerializer(serializers.Serializer):
    """A new password account.

    Note what this does *not* accept: ``is_staff``, ``is_superuser`` or any
    other privilege field. Every account in this tool is staff by construction
    (see the view), and letting the request body say so would make the flag
    settable by whoever can reach the endpoint.
    """

    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=8, trim_whitespace=False)
    full_name = serializers.CharField(required=False, allow_blank=True, max_length=300)
    username = serializers.CharField(required=False, allow_blank=True, max_length=150)

    def validate_email(self, value: str) -> str:
        value = check_email_domain(value)
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account already exists for this address.")
        return value

    def validate_username(self, value: str) -> str:
        value = (value or "").strip()
        if value and User.objects.filter(username__iexact=value).exists():
            raise serializers.ValidationError("That user id is taken.")
        return value

    def validate(self, attrs: dict) -> dict:
        # Deferred to here rather than to validate_password so the validators
        # that compare a password against the email and name can actually see
        # them; run field-by-field they would be checking against nothing.
        candidate = User(
            username=attrs.get("username") or attrs["email"].split("@")[0],
            email=attrs["email"],
            first_name=(attrs.get("full_name") or "").split(" ")[0][:150],
        )
        try:
            validate_password(attrs["password"], user=candidate)
        except DjangoValidationError as exc:
            raise serializers.ValidationError({"password": list(exc.messages)}) from exc
        return attrs

    def create(self, validated: dict) -> User:
        email = validated["email"]
        username = validated.get("username") or self._unique_username(email)
        full_name = (validated.get("full_name") or "").strip()
        first, _, last = full_name.partition(" ")

        user = User(
            username=username,
            email=email,
            first_name=first[:150],
            last_name=last[:150],
            # Admin-only tool: there is no non-staff tier to place anyone in.
            is_staff=True,
        )
        user.set_password(validated["password"])
        user.save()
        return user

    @staticmethod
    def _unique_username(email: str) -> str:
        base = email.split("@")[0][:140] or "user"
        candidate = base
        suffix = 2
        while User.objects.filter(username__iexact=candidate).exists():
            candidate = f"{base}{suffix}"
            suffix += 1
        return candidate


class LoginSerializer(serializers.Serializer):
    """Sign in with a user id or a company email address, plus a password."""

    identifier = serializers.CharField()
    password = serializers.CharField(write_only=True, trim_whitespace=False)

    def validate(self, attrs: dict) -> dict:
        identifier = attrs["identifier"].strip()
        if "@" in identifier:
            # Fail on the domain before touching the password, so the message
            # says what is actually wrong rather than "invalid credentials".
            identifier = check_email_domain(identifier)

        user = (
            User.objects.filter(Q(username__iexact=identifier) | Q(email__iexact=identifier))
            .order_by("id")
            .first()
        )

        # Deliberately one message for "no such account" and "wrong password":
        # distinguishing them turns this endpoint into a way to enumerate who
        # works here.
        invalid = serializers.ValidationError(
            {"detail": "That user id or password is not right."}
        )
        if user is None:
            raise invalid

        authenticated = authenticate(
            request=self.context.get("request"),
            username=user.get_username(),
            password=attrs["password"],
        )
        if authenticated is None:
            raise invalid
        if not authenticated.is_active:
            raise serializers.ValidationError({"detail": "This account is disabled."})

        attrs["user"] = authenticated
        return attrs


class PasswordChangeSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True, trim_whitespace=False)
    new_password = serializers.CharField(write_only=True, min_length=8, trim_whitespace=False)

    def validate_current_password(self, value: str) -> str:
        user = self.context["request"].user
        if not user.check_password(value):
            raise serializers.ValidationError("That is not your current password.")
        return value

    def validate_new_password(self, value: str) -> str:
        try:
            validate_password(value, user=self.context["request"].user)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages)) from exc
        return value
