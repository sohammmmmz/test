from rest_framework.permissions import BasePermission


class IsAdminUser(BasePermission):
    """Admin-only tool: authenticated and staff.

    This is the project-wide DRF default (see ``REST_FRAMEWORK`` in settings),
    so endpoints are locked down unless they explicitly opt out — the webhook
    receiver being the one deliberate exception, since GitLab authenticates
    with an HMAC signature rather than a session.
    """

    message = "Administrator access is required."

    def has_permission(self, request, view):
        user = getattr(request, "user", None)
        return bool(user and user.is_authenticated and user.is_staff)
