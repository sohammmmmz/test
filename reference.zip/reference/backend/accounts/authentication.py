"""DRF authentication from a JWT, carried in an httpOnly cookie.

The cookie rather than an ``Authorization`` header is deliberate. This frontend
is a Next.js server that talks to Django on the reader's behalf; if the token
were held in JavaScript it would be reachable by any script on the page, which
is the failure mode httpOnly exists to prevent. The header form is still
accepted so scripts, tests and `curl` have a way in.

A cookie credential is sent by the browser automatically, which is exactly the
condition that makes CSRF possible — so cookie-authenticated *writes* are held
to Django's CSRF check, the same standard ``SessionAuthentication`` applies. A
bearer header is not sent automatically and so is exempt.
"""

from django.contrib.auth import get_user_model
from django.middleware.csrf import CsrfViewMiddleware
from rest_framework import authentication, exceptions

from .tokens import ACCESS, TokenError, decode

User = get_user_model()

ACCESS_COOKIE = "eut_access"
REFRESH_COOKIE = "eut_refresh"


class _CSRFCheck(CsrfViewMiddleware):
    def _reject(self, request, reason):
        return reason


class JWTAuthentication(authentication.BaseAuthentication):
    """Authenticate from the access cookie, or from ``Authorization: Bearer``."""

    keyword = "Bearer"

    def authenticate(self, request):
        raw, from_cookie = self._raw_token(request)
        if not raw:
            return None

        try:
            claims = decode(raw, expected=ACCESS)
        except TokenError as exc:
            # An expired access token is an ordinary event — the frontend is
            # expected to refresh and retry — so it must be reported as 401
            # rather than passed over, or the request would fall through to the
            # permission check and report the misleading "not an administrator".
            raise exceptions.AuthenticationFailed(str(exc)) from exc

        try:
            user = User.objects.get(pk=claims["sub"])
        except (User.DoesNotExist, ValueError, TypeError) as exc:
            raise exceptions.AuthenticationFailed("Account no longer exists.") from exc

        if not user.is_active:
            raise exceptions.AuthenticationFailed("Account is disabled.")

        if from_cookie:
            self._enforce_csrf(request)

        return (user, claims)

    def authenticate_header(self, request):
        # Without this DRF answers 403 instead of 401, and the frontend cannot
        # tell "signed out, go and refresh" from "signed in but not allowed".
        return self.keyword

    def _raw_token(self, request) -> tuple[str, bool]:
        header = authentication.get_authorization_header(request).split()
        if header and header[0].lower() == self.keyword.lower().encode():
            if len(header) != 2:
                raise exceptions.AuthenticationFailed("Malformed Authorization header.")
            return header[1].decode(), False
        return request.COOKIES.get(ACCESS_COOKIE, ""), True

    def _enforce_csrf(self, request) -> None:
        check = _CSRFCheck(lambda r: None)
        check.process_request(request)
        reason = check.process_view(request, None, (), {})
        if reason:
            raise exceptions.PermissionDenied(f"CSRF failed: {reason}")
