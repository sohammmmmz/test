"""Where the tokens live in the browser.

Both cookies are httpOnly, so no script on the page can read them; the Next.js
server is the only thing that ever sees their values, and it attaches them to
its own calls to Django. SameSite=Lax is the second half of that: the browser
will not attach these cookies to a cross-site POST, which removes the class of
CSRF attack that a same-site-agnostic cookie would open up.

The refresh cookie is scoped no more tightly than the access cookie on purpose.
It would be tempting to pin it to the refresh path, but the browser holds these
against the *Next.js* origin and Next forwards whatever it was given, so a path
restriction expressed in Django's terms would simply not apply to the hop that
matters.
"""

from django.conf import settings

from .authentication import ACCESS_COOKIE, REFRESH_COOKIE


def _common() -> dict:
    return {
        "httponly": True,
        "secure": settings.SESSION_COOKIE_SECURE,
        "samesite": settings.SESSION_COOKIE_SAMESITE,
        "path": "/",
    }


def set_auth_cookies(response, pair) -> None:
    response.set_cookie(
        ACCESS_COOKIE,
        pair.access,
        max_age=settings.JWT_ACCESS_TTL_SECONDS,
        **_common(),
    )
    response.set_cookie(
        REFRESH_COOKIE,
        pair.refresh,
        max_age=settings.JWT_REFRESH_TTL_SECONDS,
        **_common(),
    )
    return response


def clear_auth_cookies(response) -> None:
    for name in (ACCESS_COOKIE, REFRESH_COOKIE):
        response.delete_cookie(
            name,
            path="/",
            samesite=settings.SESSION_COOKIE_SAMESITE,
        )
    return response
