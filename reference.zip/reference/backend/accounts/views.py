"""Authentication endpoints: password sign-in, GitLab OAuth, token refresh.

Two ways in, one result. A password login and a completed OAuth round-trip both
end by minting the same JWT pair and dropping it into the same pair of httpOnly
cookies, so everything downstream — DRF, the Next.js proxy, the frontend
middleware — has exactly one notion of "signed in" to reason about.
"""

import logging

from django.conf import settings
from django.contrib.auth import login, logout
from django.shortcuts import redirect
from django.utils import timezone
from django.views.decorators.csrf import ensure_csrf_cookie
from rest_framework import status
from rest_framework.decorators import (
    api_view,
    authentication_classes,
    permission_classes,
    throttle_classes,
)
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle

from gitlab_integration.exceptions import GitLabError
from gitlab_integration.oauth import (
    build_authorize_url,
    consume_state,
    exchange_code_for_token,
    revoke_user_token,
    upsert_user_from_token,
)

from .authentication import REFRESH_COOKIE
from .cookies import clear_auth_cookies, set_auth_cookies
from .models import User
from .serializers import (
    LoginSerializer,
    PasswordChangeSerializer,
    RegistrationSerializer,
    allowed_domains,
)
from .tokens import (
    REFRESH,
    TokenError,
    decode,
    issue_pair,
    revoke_all_for_user,
    revoke_session,
    rotate,
)

logger = logging.getLogger(__name__)

FRONTEND_URL = settings.CORS_ALLOWED_ORIGINS[0] if settings.CORS_ALLOWED_ORIGINS else "/"


class LoginThrottle(AnonRateThrottle):
    """Password endpoints are the one place brute force is worth the attacker's
    time, so they are rate-limited separately from everything else."""

    scope = "login"


def _user_payload(user: User) -> dict:
    token = getattr(user, "gitlab_token", None)
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "full_name": (user.get_full_name() or "").strip() or user.username,
        "gitlab_username": user.gitlab_username,
        "gitlab_user_id": user.gitlab_user_id,
        "avatar_url": user.gitlab_avatar_url,
        "is_staff": user.is_staff,
        "has_password": user.has_usable_password(),
        "gitlab_connected": bool(token and not token.is_revoked),
    }


def _signed_in(user, request, *, http_status=status.HTTP_200_OK):
    pair = issue_pair(user, request=request)
    response = Response(
        {
            "user": _user_payload(user),
            "access_expires_in": settings.JWT_ACCESS_TTL_SECONDS,
            "refresh_expires_in": settings.JWT_REFRESH_TTL_SECONDS,
        },
        status=http_status,
    )
    return set_auth_cookies(response, pair)


# ---------------------------------------------------------------------------
# Password
# ---------------------------------------------------------------------------


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([LoginThrottle])
def password_login(request):
    serializer = LoginSerializer(data=request.data, context={"request": request})
    serializer.is_valid(raise_exception=True)
    user = serializer.validated_data["user"]

    User.objects.filter(pk=user.pk).update(last_login_at=timezone.now())
    return _signed_in(user, request)


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([LoginThrottle])
def register(request):
    """Create a password account.

    Open only while the tool has no users at all — someone has to be able to
    make the first account — and restricted to signed-in staff after that. An
    admin-only dashboard with a permanently open registration endpoint is not
    an admin-only dashboard.
    """
    bootstrap = not User.objects.exists()
    if not bootstrap and not (request.user.is_authenticated and request.user.is_staff):
        return Response(
            {
                "detail": (
                    "Registration is closed. Ask an existing administrator to "
                    "create your account."
                )
            },
            status=status.HTTP_403_FORBIDDEN,
        )

    serializer = RegistrationSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.save()

    if bootstrap:
        # The first account is the one that will have to administer everything
        # else, including Django admin.
        User.objects.filter(pk=user.pk).update(is_superuser=True)
        user.refresh_from_db()
        # Signing them straight in avoids a pointless round-trip to the login
        # form immediately after they proved who they are.
        return _signed_in(user, request, http_status=status.HTTP_201_CREATED)

    return Response({"user": _user_payload(user)}, status=status.HTTP_201_CREATED)


@api_view(["POST"])
def change_password(request):
    serializer = PasswordChangeSerializer(data=request.data, context={"request": request})
    serializer.is_valid(raise_exception=True)

    request.user.set_password(serializer.validated_data["new_password"])
    request.user.save(update_fields=["password"])

    # Every other device holding a refresh token was, as far as this request
    # can tell, the reason for the change. They all go.
    revoke_all_for_user(request.user)
    return _signed_in(request.user, request)


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------


@api_view(["POST"])
@permission_classes([AllowAny])
@authentication_classes([])
def token_refresh(request):
    """Exchange the refresh cookie for a fresh pair.

    Runs without authentication classes on purpose: the caller's access token
    has usually just expired, which is the entire reason they are here.
    """
    raw = request.COOKIES.get(REFRESH_COOKIE) or request.data.get("refresh") or ""
    if not raw:
        return Response(
            {"detail": "No refresh token was presented."},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    try:
        user, pair = rotate(raw, request=request)
    except TokenError as exc:
        response = Response({"detail": str(exc)}, status=status.HTTP_401_UNAUTHORIZED)
        # The cookie is spent either way; leaving it in place would make the
        # browser retry a token that can never work again.
        return clear_auth_cookies(response)

    response = Response({"user": _user_payload(user)})
    return set_auth_cookies(response, pair)


@ensure_csrf_cookie
@api_view(["GET"])
def me(request):
    """The signed-in user. Also mints the CSRF cookie.

    Cookie-authenticated writes are CSRF-checked (see
    ``accounts.authentication``), so the token has to exist before the first
    one — the frontend calls this on load, and this is where it gets set.
    """
    return Response(_user_payload(request.user))


@api_view(["POST"])
@permission_classes([AllowAny])
def auth_logout(request):
    """Sign out of this device.

    Permissive on purpose: signing out must work even when the access token has
    already expired, and refusing would leave the cookies in place.
    """
    raw = request.COOKIES.get(REFRESH_COOKIE, "")
    if raw:
        try:
            claims = decode(raw, expected=REFRESH)
            revoke_session(claims["sid"])
        except (TokenError, KeyError):
            # Already dead, or never valid. Either way there is nothing to end.
            pass

    if request.user.is_authenticated:
        revoke_user_token(request.user)
        logout(request)

    response = Response(status=status.HTTP_204_NO_CONTENT)
    return clear_auth_cookies(response)


# ---------------------------------------------------------------------------
# GitLab OAuth
# ---------------------------------------------------------------------------


@api_view(["GET"])
@permission_classes([AllowAny])
def gitlab_login(request):
    """Kick off the authorization-code flow."""
    try:
        url, _state = build_authorize_url(redirect_to=request.GET.get("next", ""))
    except GitLabError as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
    return redirect(url)


@api_view(["GET"])
@permission_classes([AllowAny])
def gitlab_callback(request):
    """Handle the redirect back from GitLab and issue the JWT pair.

    The pair is what stops this from happening again tomorrow: the previous
    build ended here with a twelve-hour session cookie, so every morning began
    with another trip to GitLab.
    """
    error = request.GET.get("error")
    if error:
        description = request.GET.get("error_description", error)
        return redirect(f"{FRONTEND_URL}/login?error={description}")

    code = request.GET.get("code")
    raw_state = request.GET.get("state")
    if not code or not raw_state:
        return redirect(f"{FRONTEND_URL}/login?error=missing_code_or_state")

    try:
        state = consume_state(raw_state)
        payload = exchange_code_for_token(code)
        user, _token = upsert_user_from_token(payload)
    except GitLabError as exc:
        logger.warning("GitLab OAuth callback failed: %s", exc)
        return redirect(f"{FRONTEND_URL}/login?error=oauth_failed")

    if settings.ENFORCE_EMAIL_DOMAIN_ON_OAUTH:
        domains = allowed_domains()
        if domains and (user.email or "").rsplit("@", 1)[-1].lower() not in domains:
            logger.warning("Rejected OAuth sign-in for out-of-domain address")
            return redirect(f"{FRONTEND_URL}/login?error=wrong_domain")

    # The Django session is kept alongside the JWT so Django admin and the DRF
    # browsable API keep working for the same person.
    login(request, user, backend="django.contrib.auth.backends.ModelBackend")

    destination = state.redirect_to or "/"
    if not destination.startswith("/"):
        # Never redirect off-site on the basis of a query parameter.
        destination = "/"

    response = redirect(f"{FRONTEND_URL}{destination}")
    return set_auth_cookies(response, issue_pair(user, request=request))


@ensure_csrf_cookie
@api_view(["GET"])
@permission_classes([AllowAny])
def auth_config(request):
    """What the login screen needs to explain itself.

    Reachable while signed out, so it is also where the CSRF cookie is first
    minted for an anonymous visitor.
    """
    return Response(
        {
            "gitlab_url": settings.GITLAB_URL,
            "oauth_configured": bool(
                settings.GITLAB_OAUTH_CLIENT_ID and settings.GITLAB_OAUTH_CLIENT_SECRET
            ),
            "service_token_configured": bool(settings.GITLAB_SERVICE_TOKEN),
            "group_configured": bool(settings.GITLAB_GROUP_ID),
            "password_login_enabled": True,
            "allowed_email_domains": allowed_domains(),
            "registration_open": not User.objects.exists(),
        }
    )
