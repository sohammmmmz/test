"""Guards on the OAuth entry point.

These exist because the sign-in link was once pointed at `/api/auth/login` on
the Next.js origin, which 404'd: the path was wrong *and* the origin was wrong.
The flow has to be a full navigation to Django, so the exact URL matters.
"""

import pytest
from django.urls import reverse

pytestmark = pytest.mark.django_db


def test_login_url_is_where_the_frontend_points_it():
    """The frontend builds this path by hand in `lib/config.ts`."""
    assert reverse("gitlab-login") == "/api/auth/gitlab/login"


def test_callback_url_matches_the_configured_redirect_uri(settings):
    """A mismatch here is rejected by GitLab with an opaque error, so it is
    worth failing loudly at test time instead."""
    assert reverse("gitlab-callback") == "/api/auth/gitlab/callback"
    assert settings.GITLAB_OAUTH_REDIRECT_URI.endswith("/api/auth/gitlab/callback")


def test_login_redirects_to_gitlab_with_state_and_redirect_uri(client, settings):
    settings.GITLAB_OAUTH_CLIENT_ID = "cid"

    response = client.get("/api/auth/gitlab/login", {"next": "/projects"})

    assert response.status_code == 302
    location = response["Location"]
    assert location.startswith(f"{settings.GITLAB_URL}/oauth/authorize")
    assert "client_id=cid" in location
    assert "response_type=code" in location
    assert "state=" in location


def test_login_preserves_where_the_user_was_going(client, settings):
    from accounts.models import OAuthState

    settings.GITLAB_OAUTH_CLIENT_ID = "cid"

    client.get("/api/auth/gitlab/login", {"next": "/projects/7"})

    assert OAuthState.objects.latest("created_at").redirect_to == "/projects/7"


def test_callback_refuses_an_offsite_redirect(client, settings, monkeypatch):
    """`next` is attacker-controllable, so it must never send the browser to
    another origin after sign-in."""
    from datetime import timedelta

    from django.utils import timezone

    from accounts.models import OAuthState, User

    settings.GITLAB_OAUTH_CLIENT_ID = "cid"
    state = OAuthState.objects.create(
        state="s1",
        redirect_to="https://evil.example.com/steal",
        expires_at=timezone.now() + timedelta(minutes=5),
    )

    user = User.objects.create_user(username="u", email="u@e.com", gitlab_user_id=1)
    monkeypatch.setattr(
        "accounts.views.exchange_code_for_token", lambda code: {"access_token": "at"}
    )
    monkeypatch.setattr("accounts.views.upsert_user_from_token", lambda p: (user, None))

    response = client.get("/api/auth/gitlab/callback", {"code": "c", "state": state.state})

    assert response.status_code == 302
    assert "evil.example.com" not in response["Location"]
