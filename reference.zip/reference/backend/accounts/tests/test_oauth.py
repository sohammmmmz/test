"""Tests for the GitLab OAuth flow, focused on token rotation safety."""

from datetime import timedelta

import pytest
import responses
from django.utils import timezone

from accounts.models import GitLabOAuthToken, OAuthState, User
from gitlab_integration.exceptions import GitLabAuthError
from gitlab_integration.oauth import (
    build_authorize_url,
    consume_state,
    get_user_client,
    refresh_user_token,
    upsert_user_from_token,
)

GITLAB = "https://gitlab.example.com"
API = f"{GITLAB}/api/v4"

pytestmark = pytest.mark.django_db


class TestState:
    def test_authorize_url_carries_state_and_scopes(self):
        url, state = build_authorize_url(redirect_to="/projects")

        assert url.startswith(f"{GITLAB}/oauth/authorize?")
        assert f"state={state.state}" in url
        assert "response_type=code" in url
        assert state.redirect_to == "/projects"

    def test_state_is_single_use(self):
        _url, state = build_authorize_url()

        consume_state(state.state)

        with pytest.raises(GitLabAuthError, match="already been used"):
            consume_state(state.state)

    def test_expired_state_is_rejected(self):
        state = OAuthState.objects.create(
            state="stale", expires_at=timezone.now() - timedelta(seconds=1)
        )
        with pytest.raises(GitLabAuthError, match="expired"):
            consume_state(state.state)

    def test_unknown_state_is_rejected(self):
        with pytest.raises(GitLabAuthError, match="Unknown OAuth state"):
            consume_state("never-issued")


class TestUpsertUser:
    def test_creates_staff_user_and_stores_token(self, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/user",
            json={"id": 7, "username": "riya", "email": "riya@company.com",
                  "name": "Riya Sharma", "web_url": f"{GITLAB}/riya"},
        )

        user, token = upsert_user_from_token(
            {"access_token": "at", "refresh_token": "rt", "expires_in": 7200}
        )

        assert user.gitlab_user_id == 7
        assert user.is_staff, "every user of an admin-only tool is staff"
        assert token.access_token == "at"
        assert token.expires_at > timezone.now()

    def test_second_login_updates_rather_than_duplicates(self, mocked_responses):
        for _ in range(2):
            mocked_responses.add(
                responses.GET, f"{API}/user",
                json={"id": 7, "username": "riya", "email": "riya@company.com"},
            )

        upsert_user_from_token({"access_token": "at1", "refresh_token": "rt1"})
        _user, token = upsert_user_from_token({"access_token": "at2", "refresh_token": "rt2"})

        assert User.objects.count() == 1
        assert GitLabOAuthToken.objects.count() == 1
        assert token.access_token == "at2"


@pytest.fixture
def expiring_token(db):
    user = User.objects.create_user(username="riya", email="r@c.com", gitlab_user_id=7)
    return GitLabOAuthToken.objects.create(
        user=user,
        access_token="old-at",
        refresh_token="old-rt",
        expires_at=timezone.now() - timedelta(minutes=1),
    )


class TestRefresh:
    """GitLab invalidates both tokens on refresh and issues a new pair, so the
    new refresh token must be persisted or the connection is orphaned."""

    def test_persists_the_rotated_refresh_token(self, expiring_token, mocked_responses):
        mocked_responses.add(
            responses.POST, f"{GITLAB}/oauth/token",
            json={"access_token": "new-at", "refresh_token": "new-rt", "expires_in": 7200},
        )

        refreshed = refresh_user_token(expiring_token)

        assert refreshed.access_token == "new-at"
        assert refreshed.refresh_token == "new-rt", "the rotated token must replace the old one"
        expiring_token.refresh_from_db()
        assert expiring_token.refresh_token == "new-rt"

    def test_keeps_old_refresh_token_when_response_omits_one(
        self, expiring_token, mocked_responses
    ):
        mocked_responses.add(
            responses.POST, f"{GITLAB}/oauth/token",
            json={"access_token": "new-at", "expires_in": 7200},
        )

        refreshed = refresh_user_token(expiring_token)

        assert refreshed.refresh_token == "old-rt"

    def test_skips_refresh_when_another_request_already_did_it(
        self, expiring_token, mocked_responses
    ):
        """Losing the lock race must not trigger a second exchange, which would
        invalidate the pair the winner just stored."""
        GitLabOAuthToken.objects.filter(pk=expiring_token.pk).update(
            access_token="fresh-at", expires_at=timezone.now() + timedelta(hours=2)
        )

        result = refresh_user_token(expiring_token)

        assert result.access_token == "fresh-at"
        assert len(mocked_responses.calls) == 0, "no token exchange should have been attempted"

    def test_repeated_failures_mark_the_token_revoked(self, expiring_token, mocked_responses):
        for _ in range(3):
            mocked_responses.add(
                responses.POST, f"{GITLAB}/oauth/token",
                json={"error": "invalid_grant"}, status=400,
            )

        for _ in range(3):
            with pytest.raises(GitLabAuthError):
                refresh_user_token(expiring_token)
            GitLabOAuthToken.objects.filter(pk=expiring_token.pk).update(
                expires_at=timezone.now() - timedelta(minutes=1)
            )
            expiring_token.refresh_from_db()

        assert expiring_token.is_revoked
        assert expiring_token.refresh_failure_count >= 3

    def test_missing_refresh_token_asks_for_reauthorization(self, expiring_token):
        expiring_token.refresh_token = ""
        expiring_token.save()

        with pytest.raises(GitLabAuthError, match="re-authorize"):
            refresh_user_token(expiring_token)


class TestGetUserClient:
    def test_refreshes_transparently_before_returning(self, expiring_token, mocked_responses):
        mocked_responses.add(
            responses.POST, f"{GITLAB}/oauth/token",
            json={"access_token": "new-at", "refresh_token": "new-rt", "expires_in": 7200},
        )

        client = get_user_client(expiring_token.user)

        assert client.token == "new-at"
        assert client.token_kind == "user"

    def test_revoked_token_raises(self, expiring_token):
        expiring_token.is_revoked = True
        expiring_token.save()

        with pytest.raises(GitLabAuthError, match="re-authorize"):
            get_user_client(expiring_token.user)

    def test_user_without_gitlab_connection_raises(self, db):
        user = User.objects.create_user(username="nobody", email="n@c.com")

        with pytest.raises(GitLabAuthError, match="not connected"):
            get_user_client(user)


class TestIsExpired:
    def test_leeway_treats_soon_to_expire_as_expired(self, expiring_token):
        """Handing out a token with seconds left produces a mid-request 401."""
        expiring_token.expires_at = timezone.now() + timedelta(seconds=30)

        assert expiring_token.is_expired(leeway_seconds=120) is True
        assert expiring_token.is_expired(leeway_seconds=10) is False


class TestEndpoints:
    def test_me_requires_authentication(self, client):
        assert client.get("/api/auth/me").status_code in (401, 403)

    def test_me_returns_profile(self, api_client, admin_user):
        response = api_client.get("/api/auth/me")

        assert response.status_code == 200
        assert response.json()["username"] == admin_user.username

    def test_login_redirects_to_gitlab(self, client, settings):
        settings.GITLAB_OAUTH_CLIENT_ID = "cid"

        response = client.get("/api/auth/gitlab/login")

        assert response.status_code == 302
        assert response["Location"].startswith(f"{GITLAB}/oauth/authorize")

    def test_login_reports_missing_configuration(self, client, settings):
        settings.GITLAB_OAUTH_CLIENT_ID = ""

        response = client.get("/api/auth/gitlab/login")

        assert response.status_code == 503

    def test_config_is_public(self, client):
        response = client.get("/api/auth/config")

        assert response.status_code == 200
        assert response.json()["gitlab_url"] == GITLAB
