"""Password sign-in, the company-domain rule, and JWT refresh rotation.

The behaviour under test is mostly about what is *refused*: an address outside
the company domain, a second registration through an endpoint that was only
ever meant to bootstrap the first account, and a refresh token presented twice.
"""

from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from accounts.authentication import ACCESS_COOKIE, REFRESH_COOKIE
from accounts.models import RefreshSession, User
from accounts.tokens import ACCESS, REFRESH, TokenError, decode, issue_pair, rotate

pytestmark = pytest.mark.django_db

PASSWORD = "correct-horse-battery-7"


@pytest.fixture(autouse=True)
def _domain(settings):
    settings.ALLOWED_EMAIL_DOMAINS = ["solargroup.com"]
    settings.ENFORCE_EMAIL_DOMAIN_ON_OAUTH = False
    return settings


@pytest.fixture
def client():
    return APIClient()


@pytest.fixture
def person(db):
    user = User.objects.create_user(
        username="riya",
        email="riya@solargroup.com",
        password=PASSWORD,
        is_staff=True,
    )
    return user


class TestTheCompanyDomainRule:
    def test_registration_refuses_an_outside_address(self, client):
        response = client.post(
            "/api/auth/register",
            {"email": "riya@gmail.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 400
        assert "solargroup.com" in str(response.data)
        assert not User.objects.exists()

    def test_registration_accepts_the_company_domain(self, client):
        response = client.post(
            "/api/auth/register",
            {"email": "Riya@Solargroup.com", "password": PASSWORD, "full_name": "Riya Sharma"},
            format="json",
        )

        assert response.status_code == 201
        user = User.objects.get()
        assert user.email == "riya@solargroup.com", "stored lower-cased"
        assert user.is_staff, "every account in an admin-only tool is staff"

    def test_a_lookalike_subdomain_is_not_the_company_domain(self, client):
        response = client.post(
            "/api/auth/register",
            {"email": "riya@mail.solargroup.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 400

    def test_signing_in_with_an_outside_address_says_why(self, client, person):
        response = client.post(
            "/api/auth/login",
            {"identifier": "riya@gmail.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 400
        assert "company email" in str(response.data).lower()

    def test_an_empty_domain_list_accepts_anything(self, client, settings):
        settings.ALLOWED_EMAIL_DOMAINS = []

        response = client.post(
            "/api/auth/register",
            {"email": "someone@anywhere.test", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 201


class TestRegistrationIsNotOpen:
    def test_the_first_account_can_be_made_by_anyone(self, client):
        response = client.post(
            "/api/auth/register",
            {"email": "first@solargroup.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 201
        assert User.objects.get().is_superuser, "the bootstrap account administers"
        assert ACCESS_COOKIE in response.cookies, "signed straight in"

    def test_the_second_one_cannot(self, client, person):
        response = client.post(
            "/api/auth/register",
            {"email": "second@solargroup.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 403
        assert User.objects.count() == 1

    def test_an_administrator_can_still_create_accounts(self, client, person):
        client.force_authenticate(user=person)

        response = client.post(
            "/api/auth/register",
            {"email": "second@solargroup.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 201
        assert User.objects.count() == 2

    def test_privilege_flags_in_the_body_are_ignored(self, client):
        client.post(
            "/api/auth/register",
            {
                "email": "first@solargroup.com",
                "password": PASSWORD,
                "is_superuser": True,
                "username": "root",
            },
            format="json",
        )
        # Superuser here comes from being the bootstrap account, not from the
        # body — so the check that matters is the second account.
        admin = User.objects.get()
        client.force_authenticate(user=admin)
        client.post(
            "/api/auth/register",
            {"email": "second@solargroup.com", "password": PASSWORD, "is_superuser": True},
            format="json",
        )

        assert not User.objects.get(email="second@solargroup.com").is_superuser


class TestSigningIn:
    def test_a_user_id_and_password_work(self, client, person):
        response = client.post(
            "/api/auth/login", {"identifier": "riya", "password": PASSWORD}, format="json"
        )

        assert response.status_code == 200
        assert response.data["user"]["email"] == "riya@solargroup.com"
        assert ACCESS_COOKIE in response.cookies
        assert REFRESH_COOKIE in response.cookies

    def test_the_company_email_works_too(self, client, person):
        response = client.post(
            "/api/auth/login",
            {"identifier": "riya@solargroup.com", "password": PASSWORD},
            format="json",
        )

        assert response.status_code == 200

    def test_the_tokens_are_httponly(self, client, person):
        response = client.post(
            "/api/auth/login", {"identifier": "riya", "password": PASSWORD}, format="json"
        )

        for name in (ACCESS_COOKIE, REFRESH_COOKIE):
            assert response.cookies[name]["httponly"], f"{name} must be unreadable by scripts"

    def test_a_wrong_password_does_not_reveal_that_the_account_exists(self, client, person):
        missing = client.post(
            "/api/auth/login",
            {"identifier": "nobody@solargroup.com", "password": PASSWORD},
            format="json",
        )
        wrong = client.post(
            "/api/auth/login",
            {"identifier": "riya", "password": "not-the-password"},
            format="json",
        )

        assert missing.status_code == wrong.status_code == 400
        assert str(missing.data) == str(wrong.data)

    def test_a_disabled_account_cannot_sign_in(self, client, person):
        person.is_active = False
        person.save()

        response = client.post(
            "/api/auth/login", {"identifier": "riya", "password": PASSWORD}, format="json"
        )

        assert response.status_code == 400


class TestTheAccessToken:
    def test_it_authenticates_an_api_call(self, client, person):
        pair = issue_pair(person)
        client.cookies[ACCESS_COOKIE] = pair.access

        assert client.get("/api/auth/me").status_code == 200

    def test_a_bearer_header_works_as_well(self, client, person):
        pair = issue_pair(person)

        response = client.get("/api/auth/me", HTTP_AUTHORIZATION=f"Bearer {pair.access}")

        assert response.status_code == 200

    def test_an_expired_token_is_401_not_403(self, client, person, settings):
        """The frontend refreshes on 401. Reporting 403 would make an ordinary
        expiry look like a permissions problem and strand the user."""
        settings.JWT_ACCESS_TTL_SECONDS = -1
        pair = issue_pair(person)
        client.cookies[ACCESS_COOKIE] = pair.access

        assert client.get("/api/auth/me").status_code == 401

    def test_a_refresh_token_is_not_accepted_as_an_access_token(self, client, person):
        pair = issue_pair(person)
        client.cookies[ACCESS_COOKIE] = pair.refresh

        assert client.get("/api/auth/me").status_code == 401

    def test_a_tampered_token_is_rejected(self, client, person):
        pair = issue_pair(person)
        head, payload, signature = pair.access.split(".")
        client.cookies[ACCESS_COOKIE] = f"{head}.{payload}.{signature[:-2]}xx"

        assert client.get("/api/auth/me").status_code == 401

    def test_the_claims_say_what_they_are(self, person):
        pair = issue_pair(person)

        assert decode(pair.access)["typ"] == ACCESS
        assert decode(pair.refresh)["typ"] == REFRESH


class TestRefreshRotation:
    def test_it_returns_a_new_pair(self, client, person):
        pair = issue_pair(person)
        client.cookies[REFRESH_COOKIE] = pair.refresh

        response = client.post("/api/auth/refresh")

        assert response.status_code == 200
        assert response.cookies[REFRESH_COOKIE].value != pair.refresh

    def test_the_old_token_stops_working(self, person, settings):
        """Once past the race window, a spent token is spent."""
        settings.JWT_REFRESH_GRACE_SECONDS = 0
        pair = issue_pair(person)
        rotate(pair.refresh)

        with pytest.raises(TokenError):
            rotate(pair.refresh)

    def test_replaying_an_old_token_kills_the_whole_session(self, person, settings):
        """The loud failure is the point: a silently rejected replay leaves
        whoever copied the token still holding a working one."""
        settings.JWT_REFRESH_GRACE_SECONDS = 0
        pair = issue_pair(person)
        _user, second = rotate(pair.refresh)

        with pytest.raises(TokenError):
            rotate(pair.refresh)

        with pytest.raises(TokenError):
            rotate(second.refresh)

        session = RefreshSession.objects.get(pk=pair.session.pk)
        assert session.revoked_at is not None
        assert session.revoke_reason == RefreshSession.RevokeReason.REUSED

    def test_two_tabs_refreshing_together_are_not_treated_as_a_replay(self, person):
        """Both tabs hold the same token and both wake up at once. Signing the
        person out for that would look like random flakiness."""
        pair = issue_pair(person)
        rotate(pair.refresh)

        _user, third = rotate(pair.refresh)

        assert third.access, "the racing tab gets a working pair"
        assert RefreshSession.objects.get(pk=pair.session.pk).revoked_at is None

    def test_the_grace_window_does_not_last(self, person):
        pair = issue_pair(person)
        rotate(pair.refresh)

        session = RefreshSession.objects.get(pk=pair.session.pk)
        session.rotated_at = timezone.now() - timedelta(minutes=5)
        session.save(update_fields=["rotated_at"])

        with pytest.raises(TokenError):
            rotate(pair.refresh)

    def test_an_expired_session_cannot_be_refreshed(self, person):
        pair = issue_pair(person)
        RefreshSession.objects.filter(pk=pair.session.pk).update(
            expires_at=timezone.now() - timedelta(seconds=1)
        )

        with pytest.raises(TokenError):
            rotate(pair.refresh)

    def test_a_disabled_account_cannot_refresh(self, person):
        pair = issue_pair(person)
        person.is_active = False
        person.save()

        with pytest.raises(TokenError):
            rotate(pair.refresh)

    def test_refreshing_without_a_cookie_is_401(self, client):
        assert client.post("/api/auth/refresh").status_code == 401

    def test_a_rejected_refresh_clears_the_cookies(self, client, person):
        client.cookies[REFRESH_COOKIE] = "not-a-token"

        response = client.post("/api/auth/refresh")

        assert response.status_code == 401
        # An empty value is how a deletion arrives at the browser.
        assert response.cookies[REFRESH_COOKIE].value == ""

    def test_the_session_expiry_slides_forward(self, person):
        pair = issue_pair(person)
        RefreshSession.objects.filter(pk=pair.session.pk).update(
            expires_at=timezone.now() + timedelta(days=1)
        )

        rotate(pair.refresh)

        session = RefreshSession.objects.get(pk=pair.session.pk)
        assert session.expires_at > timezone.now() + timedelta(days=25), (
            "daily use should never expire a session"
        )


class TestSigningOut:
    def test_it_revokes_the_session(self, client, person):
        pair = issue_pair(person)
        client.cookies[ACCESS_COOKIE] = pair.access
        client.cookies[REFRESH_COOKIE] = pair.refresh

        assert client.post("/api/auth/logout").status_code == 204

        with pytest.raises(TokenError):
            rotate(pair.refresh)

    def test_it_works_after_the_access_token_has_expired(self, client, person, settings):
        """Otherwise signing out fails exactly when someone most wants it to
        work, and the cookies stay in the browser."""
        settings.JWT_ACCESS_TTL_SECONDS = -1
        pair = issue_pair(person)
        client.cookies[REFRESH_COOKIE] = pair.refresh

        assert client.post("/api/auth/logout").status_code == 204
        assert RefreshSession.objects.get(pk=pair.session.pk).revoked_at is not None


class TestChangingAPassword:
    def test_it_signs_out_every_other_device(self, client, person):
        elsewhere = issue_pair(person)
        here = issue_pair(person)
        client.cookies[ACCESS_COOKIE] = here.access

        response = client.post(
            "/api/auth/password",
            {"current_password": PASSWORD, "new_password": "a-completely-new-one-42"},
            format="json",
        )

        assert response.status_code == 200
        with pytest.raises(TokenError):
            rotate(elsewhere.refresh)

    def test_the_current_password_is_required(self, client, person):
        client.cookies[ACCESS_COOKIE] = issue_pair(person).access

        response = client.post(
            "/api/auth/password",
            {"current_password": "wrong", "new_password": "a-completely-new-one-42"},
            format="json",
        )

        assert response.status_code == 400

    def test_a_weak_new_password_is_refused(self, client, person):
        client.cookies[ACCESS_COOKIE] = issue_pair(person).access

        response = client.post(
            "/api/auth/password",
            {"current_password": PASSWORD, "new_password": "password"},
            format="json",
        )

        assert response.status_code == 400


class TestConfig:
    def test_it_tells_the_login_screen_which_domain_to_ask_for(self, client):
        response = client.get("/api/auth/config")

        assert response.data["allowed_email_domains"] == ["solargroup.com"]
        assert response.data["registration_open"] is True

    def test_registration_closes_once_an_account_exists(self, client, person):
        assert client.get("/api/auth/config").data["registration_open"] is False
