"""Guards on the browser write path.

The API is reached from the browser through the Next.js proxy, which forwards
the session cookie. DRF's SessionAuthentication enforces CSRF on every unsafe
method, so a write needs a token — and the token has to have been minted
somewhere first.

The existing suite authenticates with `force_authenticate`, which bypasses
CSRF entirely, so none of it exercises this. These tests use a real session.
"""

import pytest
from rest_framework.test import APIClient

pytestmark = pytest.mark.django_db


@pytest.fixture
def session_client(admin_user):
    """A client holding a real session cookie, with CSRF checks enforced."""
    client = APIClient(enforce_csrf_checks=True)
    client.force_login(admin_user)
    return client


class TestCsrfCookieIsMinted:
    def test_config_sets_the_csrf_cookie_for_anonymous_visitors(self, client):
        """Reachable while signed out, so it is the first chance to mint one."""
        response = client.get("/api/auth/config")

        assert response.status_code == 200
        assert "csrftoken" in response.cookies

    def test_me_sets_the_csrf_cookie(self, session_client):
        response = session_client.get("/api/auth/me")

        assert response.status_code == 200
        assert "csrftoken" in response.cookies


class TestCsrfIsStillEnforced:
    def test_a_write_without_a_token_is_rejected(self, session_client):
        """If this ever passes, CSRF protection has been silently removed."""
        response = session_client.post("/api/projects/", {"name": "No Token"}, format="json")

        assert response.status_code == 403
        assert "CSRF" in str(response.data)

    def test_a_write_with_the_token_is_accepted(self, session_client):
        """Mirrors what the proxy does: read the cookie, send it as a header."""
        session_client.get("/api/auth/config")
        token = session_client.cookies["csrftoken"].value

        response = session_client.post(
            "/api/projects/", {"name": "With Token"}, format="json", HTTP_X_CSRFTOKEN=token
        )

        # Past CSRF and into the view: this user has no GitLab OAuth token, so
        # registration correctly stops there rather than at the CSRF gate.
        assert response.status_code == 401
        assert response.data["code"] == "gitlab_reauthorize_required"


class TestRouterUrlShape:
    """The proxy must forward paths verbatim.

    Next.js strips a trailing slash before a route handler runs unless
    `skipTrailingSlashRedirect` is set, and DRF registers router routes *with*
    one. Django cannot APPEND_SLASH-redirect a POST without discarding the
    body, so a stripped slash turns every write into a 500. These assertions
    pin the shape the frontend has to match.
    """

    @pytest.mark.parametrize(
        "url",
        [
            "/api/projects/",
            "/api/projects/validate-repo/",
            "/api/team/employees/",
            "/api/sync/runs/",
        ],
    )
    def test_router_routes_keep_their_trailing_slash(self, url, session_client):
        assert url.endswith("/")
        # Resolvable as written; a 404 here would mean the shape changed.
        assert session_client.get(url).status_code != 404

    @pytest.mark.parametrize(
        "url", ["/api/auth/me", "/api/auth/config", "/api/sync/status", "/api/sync/trigger"]
    )
    def test_hand_written_routes_have_no_trailing_slash(self, url, session_client):
        assert not url.endswith("/")
        assert session_client.get(url).status_code != 404
