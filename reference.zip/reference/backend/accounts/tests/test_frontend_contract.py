"""Every API path the frontend calls must resolve in Django exactly as written.

This has now bitten three times: a wrong path, a stripped trailing slash, and a
call site missing the slash DRF requires. Each one only showed up in a browser,
because the rest of the suite talks to Django directly and never goes through
the proxy.

So instead of testing another single case, this reads the actual frontend
source, extracts every `/api/proxy/...` URL, and asserts Django resolves it
with no redirect. A mismatched path fails here rather than in the browser.
"""

import re
from pathlib import Path

import pytest
from django.conf import settings
from django.urls import Resolver404, resolve

FRONTEND_SRC = Path(settings.BASE_DIR).parent / "frontend" / "src"
PROXY_PREFIX = "/api/proxy"

CALL_RE = re.compile(r'["\'`](/api/proxy/[^"\'`\s]*)["\'`]')
# `${projectId}` and friends. Substituted with a concrete value so the path can
# actually be resolved — skipping interpolated URLs would leave most endpoints
# unverified, since nearly all of them are per-project.
INTERPOLATION_RE = re.compile(r"\$\{[^}]*\}")


def _concrete(url: str) -> list[str]:
    """Candidate concrete paths for a URL that may contain interpolations.

    Both a numeric and a string substitution are tried, because a segment may
    be an id or a slug and the URLconf accepts different converters.
    """
    if "${" not in url:
        return [url]
    return [INTERPOLATION_RE.sub(value, url) for value in ("1", "x")]


def _discover_calls() -> list[tuple[str, str]]:
    """(source file, upstream Django path) for every proxied call."""
    if not FRONTEND_SRC.exists():
        return []

    found: list[tuple[str, str]] = []
    for path in FRONTEND_SRC.rglob("*.ts*"):
        for match in CALL_RE.finditer(path.read_text(encoding="utf-8")):
            url = match.group(1).split("?")[0]
            upstream = url[len(PROXY_PREFIX) :]
            found.append((str(path.relative_to(FRONTEND_SRC)), upstream))
    return sorted(set(found))


CALLS = _discover_calls()


@pytest.mark.skipif(not FRONTEND_SRC.exists(), reason="frontend source not present")
def test_some_calls_were_discovered():
    """Guards the regex itself — a silent zero would make this suite vacuous."""
    assert CALLS, f"No proxied API calls found under {FRONTEND_SRC}"


@pytest.mark.skipif(not CALLS, reason="no proxied calls discovered")
@pytest.mark.parametrize("source,path", CALLS, ids=[f"{s}:{p}" for s, p in CALLS])
def test_frontend_path_resolves_in_django(source, path):
    """Resolving exactly as written means no APPEND_SLASH redirect.

    A redirect is fatal here in two different ways: Django cannot redirect a
    POST without discarding its body, and a relayed redirect on a GET is
    resolved by the browser against the Next.js origin, producing a 404.
    """
    candidates = _concrete(path)
    if any(_resolves(c) for c in candidates):
        return

    hint = ""
    if any(_resolves(f"{c}/") for c in candidates):
        hint = (
            f" It resolves with a trailing slash — the call site in {source} is "
            "missing the one DRF's router registers."
        )
    pytest.fail(
        f"'{path}' called from {source} does not resolve in Django "
        f"(tried {candidates}).{hint}"
    )


def _resolves(path: str) -> bool:
    try:
        resolve(path)
        return True
    except Resolver404:
        return False
