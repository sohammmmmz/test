"""The leaderboard score.

**This is the file to edit when the scoring logic changes.** Everything else —
the endpoint, the page, the tests for ranking order — is deliberately ignorant
of how a score is arrived at. Adding, removing or reweighting a component
should require touching nothing but this module.

The window
----------
Always rolling and always computed from today: ``end`` is today, ``start`` is
``days - 1`` behind it, so a 30-day window is today plus the twenty-nine days
before it. Nothing is stored or snapshotted. That is a deliberate choice — a
leaderboard people can see is a leaderboard people optimise against, and a
cached figure that disagrees with the calendar on the next screen destroys
trust in both.

The score
---------
Version 1 measures two things, because they are the two things a commit log can
honestly report:

``volume``
    How much landed. Saturating rather than linear: the tenth commit of a day
    is worth less than the first, so the number resists being gamed by
    splitting one change into twenty.

``regularity``
    Whether it landed steadily. Split into ``coverage`` (what share of the
    working days in the window saw any commit) and ``consistency`` (how long
    the longest silent stretch ran). A person who commits every other day and a
    person who commits nothing for three weeks and then lands forty changes
    have similar volume and very different working patterns; the leaderboard
    should not call them equal.

What this deliberately does not measure
---------------------------------------
Difficulty, correctness, review work, mentoring, or anything else a commit
count cannot see. The hardest bug of someone's month is often a one-line diff.
Treat the ranking as a description of commit cadence, which is all it is, and
not as a ranking of people. The same caveat is printed on the page.

Extending it
------------
Write a function taking :class:`Facts` and returning a 0–100 float, or ``None``
when it does not apply to that person, then add a :class:`Component` for it to
``COMPONENTS``. Weights are normalised over whichever components returned a
number, so a new one can be added without rebalancing the others, and a
component that abstains costs nobody anything.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, timedelta

from django.db.models import Count
from django.db.models.functions import TruncDate
from django.utils import timezone

from activity.models import Commit
from team.models import Employee

from .calendar import non_working_dates, working_weekdays

# --------------------------------------------------------------------------
# Tunables
#
# Kept together and named so the shape of the curve is legible without reading
# the functions that use them.
# --------------------------------------------------------------------------

#: Commits in the window that should read as a solid month's output. This is
#: the half-way point of the saturating curve, not a cap or a quota — see
#: ``score_volume`` for what it actually does to the number.
VOLUME_MIDPOINT = 20.0

#: Working days without a commit that pass without penalty. Two is a normal
#: pause: a day of design, a day of review, a day fighting CI.
GAP_GRACE_DAYS = 2

#: Beyond the grace, the gap that scores zero, as a share of the working days
#: in the window. At 30 days (~22 working days) this puts full penalty at
#: around eleven consecutive silent working days.
GAP_ZERO_FRACTION = 0.5

#: Floor for the above, so short windows do not become impossible to pass.
GAP_ZERO_MINIMUM = 5.0


@dataclass
class Facts:
    """Everything the components are allowed to look at, for one person.

    A single struct rather than each component running its own queries: it
    keeps the query count flat as components are added, and it means a
    component cannot quietly start depending on something the tests do not
    control.
    """

    employee: Employee
    start: date
    end: date

    #: {day: commits on that day}. Only days with at least one commit appear.
    commits_by_day: dict[date, int] = field(default_factory=dict)

    #: Working days in the window on which a commit was reasonably expected —
    #: weekdays, less holidays, clipped to their employment.
    expected_days: list[date] = field(default_factory=list)

    @property
    def commits(self) -> int:
        return sum(self.commits_by_day.values())

    @property
    def active_days(self) -> int:
        """Distinct days with a commit, weekends included.

        Weekend work counts here. It is not *expected*, but someone who shipped
        on a Sunday did the work and the score should not be blind to it.
        """
        return len(self.commits_by_day)

    @property
    def expected_day_count(self) -> int:
        return len(self.expected_days)

    @property
    def longest_gap(self) -> int:
        """Longest run of consecutive expected days with no commit.

        Measured over working days only, so a weekend does not read as a
        two-day silence and a public holiday does not read as absence.
        """
        longest = run = 0
        for day in self.expected_days:
            if day in self.commits_by_day:
                run = 0
            else:
                run += 1
                longest = max(longest, run)
        return longest

    @property
    def current_streak(self) -> int:
        """Expected days back from the end of the window with a commit each."""
        streak = 0
        for day in reversed(self.expected_days):
            if day not in self.commits_by_day:
                break
            streak += 1
        return streak

    @property
    def last_commit_on(self) -> date | None:
        return max(self.commits_by_day) if self.commits_by_day else None


# --------------------------------------------------------------------------
# Components
#
# Each returns 0–100, or None when it cannot be computed for this person —
# which is different from zero and must not be scored as zero. Somebody who
# joined two days ago has no coverage figure; they do not have a bad one.
# --------------------------------------------------------------------------


def score_volume(facts: Facts) -> float | None:
    """How much landed, with diminishing returns.

    ``100 * n / (n + k)`` where ``k`` is chosen so ``VOLUME_MIDPOINT`` commits
    score 50. The curve is strictly increasing, so it never produces ties at a
    ceiling, but its slope falls away fast: at the midpoint each further commit
    is worth roughly a quarter of what the first one was. Splitting one change
    into ten commits therefore gains very little, which is the entire reason
    this is not simply a count.
    """
    n = facts.commits
    if n <= 0:
        return 0.0
    return 100.0 * n / (n + VOLUME_MIDPOINT)


def score_coverage(facts: Facts) -> float | None:
    """Share of the window's working days that saw a commit.

    Capped at 100: someone who also commits at weekends cannot exceed full
    coverage, they simply reach it despite a missed weekday. Undefined when
    nothing was expected — a person who joined yesterday, or was on leave for
    the whole window, has no coverage figure rather than a zero.
    """
    if facts.expected_day_count == 0:
        return None
    return min(facts.active_days / facts.expected_day_count, 1.0) * 100.0


def score_consistency(facts: Facts) -> float | None:
    """Penalty for the longest silent stretch.

    Full marks up to ``GAP_GRACE_DAYS``, then falling linearly to zero at half
    the window. This is what separates steady work from a single burst: two
    people with identical commit counts, one spread across the month and one
    landed in a single afternoon, get very different numbers here and identical
    numbers everywhere else.
    """
    if facts.expected_day_count == 0:
        return None

    gap = facts.longest_gap
    if gap <= GAP_GRACE_DAYS:
        return 100.0

    zero_at = max(facts.expected_day_count * GAP_ZERO_FRACTION, GAP_ZERO_MINIMUM)
    if zero_at <= GAP_GRACE_DAYS:
        return 0.0

    remaining = 1.0 - (gap - GAP_GRACE_DAYS) / (zero_at - GAP_GRACE_DAYS)
    return max(0.0, min(1.0, remaining)) * 100.0


@dataclass(frozen=True)
class Component:
    """One named, weighted input to the composite."""

    key: str
    label: str
    weight: float
    description: str
    compute: Callable[[Facts], float | None]


COMPONENTS: tuple[Component, ...] = (
    Component(
        key="volume",
        label="Volume",
        weight=0.40,
        description=(
            "How many commits landed in the window, with diminishing returns so "
            "splitting one change into many gains almost nothing."
        ),
        compute=score_volume,
    ),
    Component(
        key="coverage",
        label="Coverage",
        weight=0.35,
        description=(
            "Share of the working days in the window with at least one commit. "
            "Weekends and holidays are never counted against anyone."
        ),
        compute=score_coverage,
    ),
    Component(
        key="consistency",
        label="Consistency",
        weight=0.25,
        description=(
            "Penalises the longest silent stretch of working days. Two days is "
            "free; a fortnight of silence scores nothing here."
        ),
        compute=score_consistency,
    ),
)


def component_catalogue() -> list[dict]:
    """The components as data, so the page can explain itself without duplicating
    any of the above in TypeScript."""
    return [
        {
            "key": c.key,
            "label": c.label,
            "weight": round(c.weight, 4),
            "description": c.description,
        }
        for c in COMPONENTS
    ]


def score(facts: Facts) -> tuple[float, dict[str, float | None]]:
    """Composite 0–100 and the per-component breakdown behind it.

    Weights are renormalised over the components that returned a number. A
    component that abstains is therefore invisible rather than a silent zero,
    which is what lets somebody in their first week be ranked on volume alone
    instead of being buried by two undefined regularity figures.
    """
    parts: dict[str, float | None] = {}
    weighted = 0.0
    total_weight = 0.0

    for component in COMPONENTS:
        value = component.compute(facts)
        parts[component.key] = None if value is None else round(value, 1)
        if value is None:
            continue
        weighted += value * component.weight
        total_weight += component.weight

    composite = weighted / total_weight if total_weight else 0.0
    return round(composite, 1), parts


# --------------------------------------------------------------------------
# Assembly
# --------------------------------------------------------------------------


def _commits_by_day(employee_ids, start: date, project_id: int | None):
    """{employee_id: {day: count}} over the window."""
    qs = Commit.objects.filter(
        author_employee_id__in=employee_ids, authored_date__date__gte=start
    )
    if project_id:
        qs = qs.filter(repo__project_id=project_id)

    out: dict[int, dict[date, int]] = defaultdict(dict)
    rows = (
        qs.annotate(day=TruncDate("authored_date"))
        .values("author_employee_id", "day")
        .annotate(n=Count("id"))
    )
    for row in rows:
        out[row["author_employee_id"]][row["day"]] = row["n"]
    return out


def _expected_days(employee: Employee, span: list[date], weekdays, holidays) -> list[date]:
    """Working days in the window on which a commit was reasonably expected.

    Mirrors the commit calendar's definition minus the assignment check: the
    leaderboard ranks everybody on the roster, so being on no project is a
    planning gap to fix rather than a reason to disappear from the ranking. It
    still respects joining and leaving dates, weekends and configured holidays,
    because scoring somebody against days they were not employed for is simply
    wrong.
    """
    days = []
    for day in span:
        if employee.joined_on and day < employee.joined_on:
            continue
        if employee.left_on and day > employee.left_on:
            continue
        if day.weekday() not in weekdays or day in holidays:
            continue
        days.append(day)
    return days


def build_leaderboard(*, days: int = 30, project_id: int | None = None) -> dict:
    """Rank every active employee over a rolling window ending today."""
    today = timezone.localdate()
    start = today - timedelta(days=days - 1)
    span = [start + timedelta(days=i) for i in range(days)]
    weekdays = working_weekdays()
    holidays = non_working_dates()

    employees = list(Employee.objects.filter(is_active=True).order_by("full_name"))
    ids = [e.id for e in employees]
    by_day = _commits_by_day(ids, start, project_id)

    rows = []
    for employee in employees:
        facts = Facts(
            employee=employee,
            start=start,
            end=today,
            commits_by_day=by_day.get(employee.id, {}),
            expected_days=_expected_days(employee, span, weekdays, holidays),
        )
        composite, parts = score(facts)

        rows.append(
            {
                "employee_id": employee.id,
                "full_name": employee.full_name,
                "official_email": employee.official_email,
                "department": employee.department,
                "designation": employee.designation,
                "employment_type": employee.employment_type,
                "gitlab_username": employee.gitlab_username,
                "gitlab_avatar_url": employee.gitlab_avatar_url,
                "score": composite,
                "components": parts,
                # The raw figures behind the score. On the page these matter
                # more than the score does: a number nobody can decompose is a
                # number nobody should act on.
                "commits": facts.commits,
                "active_days": facts.active_days,
                "expected_days": facts.expected_day_count,
                "longest_gap": facts.longest_gap,
                "current_streak": facts.current_streak,
                "last_commit_on": (
                    facts.last_commit_on.isoformat() if facts.last_commit_on else None
                ),
                "commits_per_active_day": (
                    round(facts.commits / facts.active_days, 1)
                    if facts.active_days
                    else 0.0
                ),
            }
        )

    # Highest first. Commits break a tie on score, then name, so the order is
    # total and stable rather than dependent on however the rows arrived.
    rows.sort(key=lambda r: (-r["score"], -r["commits"], r["full_name"]))

    # Ranked with ties sharing a position — two people on the same score are
    # equal, and showing them as 3rd and 4th would be a lie the data does not
    # support.
    previous_key: tuple | None = None
    shared_rank = 1
    for index, row in enumerate(rows, start=1):
        key = (row["score"], row["commits"])
        if key != previous_key:
            previous_key = key
            shared_rank = index
        row["rank"] = shared_rank

    scored = [r["score"] for r in rows]
    return {
        "window": {
            "days": days,
            "start": start.isoformat(),
            "end": today.isoformat(),
        },
        "components": component_catalogue(),
        "totals": {
            "people": len(rows),
            "commits": sum(r["commits"] for r in rows),
            "mean_score": round(sum(scored) / len(scored), 1) if scored else None,
            "median_score": (
                sorted(scored)[len(scored) // 2] if scored else None
            ),
        },
        "rows": rows,
    }
