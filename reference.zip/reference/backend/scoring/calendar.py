"""Per-person daily commit cadence, and which days were missed.

This answers one question: is each person committing to the projects they are
assigned to, and on which days did that not happen?

The whole difficulty is in the word *missed*. A day with no commits is only a
miss if a commit was reasonably expected, so a day is excluded when it is a
weekend or configured holiday, when the person had not joined or had left, or
when they were on no project at all. Counting Sundays and pre-hire days as
misses would bury the handful of real gaps under hundreds of fake ones, which
is the failure mode that makes this kind of dashboard get ignored.

"On a project" means an assignment *or* a repository membership. Membership is
synced from GitLab and assignments are typed by hand, and until this read both,
somebody who belonged to four repositories rendered here as "unassigned" with
every one of their days marked as outside the measured period.

A second distinction is kept deliberately: a day with no commits but with review
notes or merged MRs is ``indirect``, not ``missed``. Reviewing someone else's
branch all day is work, and the rest of this system already refuses to record it
as a zero (see ``DailyScore.had_no_commits``).

Commits are read straight from :class:`activity.Commit` rather than from
``DailyScore``, because commits land during a plain sync while daily rollups
only exist once scoring has run. Cadence must be answerable without a Gemini key.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, timedelta

from django.conf import settings
from django.db.models import Count
from django.db.models.functions import TruncDate
from django.utils import timezone

from activity.models import Commit, MergeRequest, ProjectMember, ReviewNote
from team.models import Employee

# Cell states, in the order they are worth a reader's attention.
ACTIVE = "active"
INDIRECT = "indirect"
MISSED = "missed"
OFF = "off"
OUTSIDE = "outside"


def working_weekdays() -> set[int]:
    """Weekday numbers (Mon=0 … Sun=6) a commit is expected on."""
    return {int(d) for d in getattr(settings, "WORKING_WEEKDAYS", [0, 1, 2, 3, 4])}


def non_working_dates() -> set[date]:
    """Configured holidays and shutdown days, parsed leniently.

    A malformed entry is skipped rather than raising: a typo in an env var
    should not take the dashboard down.
    """
    parsed: set[date] = set()
    for raw in getattr(settings, "NON_WORKING_DATES", []) or []:
        try:
            parsed.add(date.fromisoformat(str(raw).strip()))
        except ValueError:
            continue
    return parsed


@dataclass
class Cell:
    """One person, one day."""

    day: date
    commits: int = 0
    reviews: int = 0
    merges: int = 0
    projects: dict[str, int] = field(default_factory=dict)
    state: str = OFF

    def as_dict(self) -> dict:
        payload = {
            "date": self.day.isoformat(),
            "commits": self.commits,
            "state": self.state,
        }
        # Omitted when empty: at ~90 cells per person these keys would otherwise
        # triple the payload to say nothing.
        if self.reviews:
            payload["reviews"] = self.reviews
        if self.merges:
            payload["merges"] = self.merges
        if self.projects:
            payload["projects"] = [
                {"name": name, "commits": n}
                for name, n in sorted(self.projects.items(), key=lambda kv: -kv[1])
            ]
        return payload


def _membership_projects(
    employee_ids, project_id: int | None
) -> dict[int, dict[int, str]]:
    """{employee_id: {project_id: project name}} from repository membership.

    Membership is observed fact synced from GitLab; an assignment is a plan
    someone typed. Reading only the plan is what made a person who belongs to
    four repositories render as "unassigned" on this screen — nothing outside
    the demo seeder had ever written an assignment row.
    """
    out: dict[int, dict[int, str]] = {}
    members = ProjectMember.objects.filter(
        employee_id__in=employee_ids, repo__project__isnull=False
    ).select_related("repo__project")
    if project_id:
        members = members.filter(repo__project_id=project_id)

    for member in members:
        out.setdefault(member.employee_id, {})[member.repo.project_id] = (
            member.repo.project.name
        )
    return out


def _expected_spans(
    employee: Employee,
    project_id: int | None,
    member_project_ids: set[int],
    window_start: date,
) -> list[tuple[date, date | None]]:
    """(start, end) windows during which work was expected of this person.

    ``end`` of ``None`` means open. Two sources feed it:

    Assignments carry real dates, so they are used as written.

    Repository membership carries none — GitLab reports that someone *is* a
    member, never when they became one. Rather than drop those people out of the
    calendar entirely (which is what reading only assignments did, leaving every
    day ``outside`` and every coverage figure undefined), a membership counts
    from the person's joining date, or from the start of the window when no
    joining date is recorded. That over-states history slightly for a repository
    someone was added to last week; the alternative was not measuring them at
    all, which is worse.

    Filtered to one project when the view is scoped, so scoping the calendar
    also scopes what counts as expected.
    """
    spans: list[tuple[date, date | None]] = []
    for assignment in employee.assignments.all():
        if project_id and assignment.project_id != project_id:
            continue
        spans.append((assignment.started_on, assignment.ended_on))

    if member_project_ids:
        start = max(employee.joined_on or window_start, window_start)
        spans.append((start, employee.left_on))

    return spans


def _is_expected(
    day: date,
    *,
    employee: Employee,
    spans: list[tuple[date, date | None]],
    weekdays: set[int],
    holidays: set[date],
) -> tuple[bool, str]:
    """Whether a commit was expected on ``day``, and the state if it was not."""
    if employee.joined_on and day < employee.joined_on:
        return False, OUTSIDE
    if employee.left_on and day > employee.left_on:
        return False, OUTSIDE
    if not any(start <= day and (end is None or end >= day) for start, end in spans):
        return False, OUTSIDE
    if day.weekday() not in weekdays or day in holidays:
        return False, OFF
    return True, MISSED


def _commit_counts(employee_ids, start: date, project_id: int | None):
    """{(employee_id, day): {project_name: count}} over the window."""
    qs = Commit.objects.filter(
        author_employee_id__in=employee_ids,
        authored_date__date__gte=start,
    )
    if project_id:
        qs = qs.filter(repo__project_id=project_id)

    counts: dict[tuple[int, date], dict[str, int]] = defaultdict(dict)
    rows = (
        qs.annotate(day=TruncDate("authored_date"))
        .values("author_employee_id", "day", "repo__project__name")
        .annotate(n=Count("id"))
    )
    for row in rows:
        key = (row["author_employee_id"], row["day"])
        name = row["repo__project__name"] or "(unknown project)"
        counts[key][name] = counts[key].get(name, 0) + row["n"]
    return counts


def _review_counts(employee_ids, start: date, project_id: int | None):
    qs = ReviewNote.objects.filter(
        author_employee_id__in=employee_ids, noted_at__date__gte=start
    )
    if project_id:
        qs = qs.filter(merge_request__repo__project_id=project_id)
    rows = (
        qs.annotate(day=TruncDate("noted_at"))
        .values("author_employee_id", "day")
        .annotate(n=Count("id"))
    )
    return {(r["author_employee_id"], r["day"]): r["n"] for r in rows}


def _merge_counts(employee_ids, start: date, project_id: int | None):
    qs = MergeRequest.objects.filter(
        author_employee_id__in=employee_ids, merged_at__date__gte=start
    )
    if project_id:
        qs = qs.filter(repo__project_id=project_id)
    rows = (
        qs.annotate(day=TruncDate("merged_at"))
        .values("author_employee_id", "day")
        .annotate(n=Count("id"))
    )
    return {(r["author_employee_id"], r["day"]): r["n"] for r in rows}


def _streaks(cells: list[Cell]) -> tuple[int, int, int]:
    """(current streak, longest streak, longest gap) over expected days only.

    Weekends and holidays are transparent rather than streak-breaking: someone
    who commits every weekday has an unbroken streak, which is the intuition
    people already have about these grids.
    """
    considered = [c for c in cells if c.state in (ACTIVE, INDIRECT, MISSED)]

    longest = run = 0
    longest_gap = gap = 0
    for cell in considered:
        if cell.state == MISSED:
            run = 0
            gap += 1
            longest_gap = max(longest_gap, gap)
        else:
            gap = 0
            run += 1
            longest = max(longest, run)

    current = 0
    for cell in reversed(considered):
        if cell.state == MISSED:
            break
        current += 1
    return current, longest, longest_gap


def build_calendar(*, days: int = 90, project_id: int | None = None) -> dict:
    """Commit cadence for every active employee over the trailing ``days``."""
    today = timezone.localdate()
    start = today - timedelta(days=days - 1)
    weekdays = working_weekdays()
    holidays = non_working_dates()

    employees = list(
        Employee.objects.filter(is_active=True).prefetch_related("assignments__project")
    )
    ids = [e.id for e in employees]
    commits = _commit_counts(ids, start, project_id)
    reviews = _review_counts(ids, start, project_id)
    merges = _merge_counts(ids, start, project_id)
    memberships = _membership_projects(ids, project_id)

    span = [start + timedelta(days=i) for i in range(days)]
    rows = []

    for employee in employees:
        member_projects = memberships.get(employee.id, {})
        spans = _expected_spans(employee, project_id, set(member_projects), start)
        if project_id and not spans:
            # Scoped to a project this person is not on: they are not absent
            # from it, they were never expected on it.
            continue

        cells: list[Cell] = []
        for day in span:
            cell = Cell(day=day)
            cell.projects = dict(commits.get((employee.id, day), {}))
            cell.commits = sum(cell.projects.values())
            cell.reviews = reviews.get((employee.id, day), 0)
            cell.merges = merges.get((employee.id, day), 0)

            expected, fallback = _is_expected(
                day, employee=employee, spans=spans, weekdays=weekdays, holidays=holidays
            )
            # Observed activity outranks the expectation window. Someone who
            # committed on a Saturday, or before their recorded start date, did
            # the work — the right response is to show it, not to hide it
            # behind a stale joining date.
            if cell.commits:
                cell.state = ACTIVE
            elif cell.reviews or cell.merges:
                cell.state = INDIRECT
            elif expected:
                cell.state = MISSED
            else:
                cell.state = fallback
            cells.append(cell)

        active = sum(1 for c in cells if c.state == ACTIVE)
        indirect = sum(1 for c in cells if c.state == INDIRECT)
        missed = sum(1 for c in cells if c.state == MISSED)
        expected_days = active + indirect + missed
        current_streak, longest_streak, longest_gap = _streaks(cells)
        last_active = next((c.day for c in reversed(cells) if c.commits), None)
        planned = employee.planned_allocation_percent()

        rows.append(
            {
                "employee_id": employee.id,
                "full_name": employee.full_name,
                "department": employee.department,
                "designation": employee.designation,
                "employment_type": employee.employment_type,
                "gitlab_username": employee.gitlab_username,
                "planned_allocation": planned,
                "is_overallocated": planned > 100,
                # Assignments and repository membership together. A project
                # someone belongs to on GitLab is a project they work on,
                # whether or not anybody wrote the allocation down.
                "projects": sorted(
                    {
                        a.project.name
                        for a in employee.assignments.all()
                        if a.is_currently_active
                        and (not project_id or a.project_id == project_id)
                    }
                    | set(member_projects.values())
                ),
                # Of those, the ones backed only by membership — real work with
                # no allocation recorded against it.
                "unplanned_projects": sorted(
                    set(member_projects.values())
                    - {
                        a.project.name
                        for a in employee.assignments.all()
                        if a.is_currently_active
                    }
                ),
                "commits": sum(c.commits for c in cells),
                "active_days": active,
                "indirect_days": indirect,
                "missed_days": missed,
                "expected_days": expected_days,
                # Share of expected days that saw some contribution. Undefined
                # rather than 0% when nothing was expected — a person on leave
                # all month has no coverage figure, not a bad one.
                "coverage_percent": (
                    round((active + indirect) / expected_days * 100) if expected_days else None
                ),
                "current_streak": current_streak,
                "longest_streak": longest_streak,
                "longest_gap": longest_gap,
                "last_commit_on": last_active.isoformat() if last_active else None,
                "days_since_last_commit": (today - last_active).days if last_active else None,
                "cells": [c.as_dict() for c in cells],
            }
        )

    # Worst coverage first: the point of the screen is the gaps, so they should
    # not be somewhere down an alphabetical list.
    rows.sort(key=lambda r: (r["coverage_percent"] is None, r["coverage_percent"] or 0))

    expected_total = sum(r["expected_days"] for r in rows)
    covered_total = sum(r["active_days"] + r["indirect_days"] for r in rows)

    return {
        "start": start.isoformat(),
        "end": today.isoformat(),
        "days": days,
        "working_weekdays": sorted(weekdays),
        "holidays": sorted(d.isoformat() for d in holidays if start <= d <= today),
        "totals": {
            "people": len(rows),
            "commits": sum(r["commits"] for r in rows),
            "active_days": sum(r["active_days"] for r in rows),
            "missed_days": sum(r["missed_days"] for r in rows),
            "expected_days": expected_total,
            "coverage_percent": (
                round(covered_total / expected_total * 100) if expected_total else None
            ),
        },
        "rows": rows,
    }
