"""Scoring and utilization API."""

from datetime import timedelta

from django.conf import settings
from django.db.models import Avg, Count
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.response import Response

from activity.models import MergeRequest, ReviewNote
from common import cache as cache_ns
from common.cache import cached
from team.models import Employee

from .models import CommitScore, DailyScore, ScoreStatus, ScoringConfig, UtilizationSnapshot
from .serializers import (
    CommitScoreSerializer,
    DailyScoreSerializer,
    ScoreOverrideSerializer,
    ScoringConfigSerializer,
    UtilizationSnapshotSerializer,
)


class CommitScoreViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = CommitScoreSerializer

    def get_queryset(self):
        qs = CommitScore.objects.select_related(
            "commit", "employee", "project", "overridden_by"
        )
        for param, field in (
            ("project", "project_id"),
            ("employee", "employee_id"),
            ("status", "status"),
        ):
            value = self.request.query_params.get(param)
            if value:
                qs = qs.filter(**{field: value})
        return qs

    @action(detail=True, methods=["post"])
    def override(self, request, pk=None):
        """Replace a computed score with a human judgment.

        Overrides persist across re-syncs: a recomputation never silently
        discards a decision a person made and explained.
        """
        score = self.get_object()
        serializer = ScoreOverrideSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        score.override_composite = serializer.validated_data["composite"]
        score.override_reason = serializer.validated_data["reason"]
        score.overridden_by = request.user
        score.overridden_at = timezone.now()
        score.save(
            update_fields=[
                "override_composite", "override_reason", "overridden_by",
                "overridden_at", "updated_at",
            ]
        )
        return Response(CommitScoreSerializer(score).data)

    @action(detail=True, methods=["post"], url_path="clear-override")
    def clear_override(self, request, pk=None):
        score = self.get_object()
        score.override_composite = None
        score.override_reason = ""
        score.overridden_by = None
        score.overridden_at = None
        score.save()
        return Response(CommitScoreSerializer(score).data)

    @action(detail=False, methods=["get"], url_path="review-queue")
    def review_queue(self, request):
        """Commits the model was not confident enough to score.

        Kept out of anyone's rollup until a human looks — an uncertain guess
        about someone's work is worse than no number at all.
        """
        qs = self.get_queryset().filter(
            status__in=[ScoreStatus.NEEDS_REVIEW, ScoreStatus.FAILED]
        )
        return Response(CommitScoreSerializer(qs[:200], many=True).data)


class ScoringConfigViewSet(viewsets.ModelViewSet):
    queryset = ScoringConfig.objects.all()
    serializer_class = ScoringConfigSerializer


class UtilizationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = UtilizationSnapshotSerializer

    def get_queryset(self):
        qs = UtilizationSnapshot.objects.select_related("employee")
        employee_id = self.request.query_params.get("employee")
        if employee_id:
            qs = qs.filter(employee_id=employee_id)
        return qs


def _window_days(request, default: int = 14) -> int:
    """Trailing window for the dashboard, clamped to something answerable."""
    try:
        return max(1, min(int(request.query_params.get("days", default)), 3650))
    except (TypeError, ValueError):
        return default


def _project_filter(request) -> int | None:
    """The optional ``project`` scope, as an id or nothing.

    Parsed before the cache key is built, never after: a key made from the raw
    query string would give "?project=" and "?project=abc" two entries holding
    the identical unscoped answer.
    """
    raw = request.query_params.get("project") or None
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _latest_snapshots(employee_ids) -> dict[int, UtilizationSnapshot]:
    """The most recent snapshot per person, in one query.

    Previously this ran a `filter().order_by().first()` inside the per-employee
    loop, so the roster size was the query count. Ordering ascending and letting
    later rows overwrite earlier ones leaves the newest per employee.
    """
    latest: dict[int, UtilizationSnapshot] = {}
    for snapshot in UtilizationSnapshot.objects.filter(
        employee_id__in=employee_ids
    ).order_by("employee_id", "period_start"):
        latest[snapshot.employee_id] = snapshot
    return latest


def _mean_scores(employee_ids, start) -> dict[int, float]:
    """Mean composite per person since ``start``, in one grouped query."""
    return {
        row["employee_id"]: row["score"]
        for row in DailyScore.objects.filter(
            employee_id__in=employee_ids, date__gte=start
        )
        .values("employee_id")
        .annotate(score=Avg("composite"))
        if row["score"] is not None
    }


def _engagement(employee_ids, start):
    """{employee_id: {reviews, merged}} observed in the window.

    Read from the activity tables rather than from ``DailyScore`` for the same
    reason the commit counts are: rollups only exist once scoring has run.
    """
    reviews = (
        ReviewNote.objects.filter(
            author_employee_id__in=employee_ids, noted_at__date__gte=start
        )
        .values("author_employee_id")
        .annotate(n=Count("id"))
    )
    merged = (
        MergeRequest.objects.filter(
            author_employee_id__in=employee_ids, merged_at__date__gte=start
        )
        .values("author_employee_id")
        .annotate(n=Count("id"))
    )

    out: dict[int, dict] = {}
    for row in reviews:
        out.setdefault(row["author_employee_id"], {})["reviews"] = row["n"]
    for row in merged:
        out.setdefault(row["author_employee_id"], {})["merged"] = row["n"]
    return out


@api_view(["GET"])
def utilization_dashboard(request):
    """Planned allocation against observed engagement, per person.

    Reported side by side rather than as a single number: the difference is the
    finding, and collapsing it into one figure would hide it.

    Every observed figure here comes from the activity tables — ``Commit``,
    ``ReviewNote``, ``MergeRequest`` — and not from ``DailyScore``. The rollups
    are written by the scoring pass, so reading them made the whole column read
    zero on any deployment where scoring had not run or had no Gemini key, while
    the commits sat in the database the entire time. Only ``mean_score``, which
    genuinely has no meaning without scoring, still comes from the rollup.
    """
    days = _window_days(request)
    today = timezone.localdate()

    return Response(
        cached(
            "scoring:dashboard",
            cache_ns.ACTIVITY,
            {"days": days, "today": today},
        )(lambda: _build_dashboard(days, today))
    )


def _build_dashboard(days: int, today) -> dict:
    from team.workload import build_workload

    start = today - timedelta(days=days)

    # Projects come from repository membership and commit history as well as
    # assignments. Reading only the assignments table showed people who are
    # members of several repos as working on nothing, because nothing had ever
    # written an assignment.
    workload = {
        row["employee_id"]: row for row in build_workload(days=days)["rows"]
    }

    employees = list(
        Employee.objects.filter(is_active=True).prefetch_related("assignments__project")
    )
    employee_ids = [e.id for e in employees]
    engagement = _engagement(employee_ids, start)
    snapshots = _latest_snapshots(employee_ids)
    mean_scores = _mean_scores(employee_ids, start)

    rows = []
    for employee in employees:
        snapshot = snapshots.get(employee.id)
        mean_score = mean_scores.get(employee.id)

        planned = employee.planned_allocation_percent()
        involvement = workload.get(employee.id) or {}
        projects = involvement.get("projects", [])
        observed = engagement.get(employee.id, {})

        rows.append(
            {
                "employee_id": employee.id,
                "full_name": employee.full_name,
                "employment_type": employee.employment_type,
                "gitlab_username": employee.gitlab_username,
                "planned_allocation": planned,
                "is_overallocated": planned > 100,
                "assigned_projects": [
                    {
                        "id": p["project_id"],
                        "name": p["project"],
                        "allocation": p["allocation_percent"],
                        "role": p["role"],
                        "sources": p["sources"],
                        "commits": p["commits"],
                        "commits_all_time": p["commits_all_time"],
                        "first_commit_at": p["first_commit_at"],
                        "last_commit_at": p["last_commit_at"],
                        "share_percent": p["share_percent"],
                        "drift": p["drift"],
                        "is_unplanned": p["is_unplanned"],
                        "is_historic": p["is_historic"],
                    }
                    for p in projects
                ],
                "unplanned_count": involvement.get("unplanned_count", 0),
                "commits": involvement.get("commits", 0),
                "review_notes": observed.get("reviews", 0),
                "merge_requests_merged": observed.get("merged", 0),
                "active_days": involvement.get("active_days", 0),
                # The history, so a quiet fortnight is not mistaken for a person
                # who has never committed anything.
                "commits_all_time": involvement.get("commits_all_time", 0),
                "active_days_all_time": involvement.get("active_days_all_time", 0),
                "first_commit_at": involvement.get("first_commit_at"),
                "last_commit_at": involvement.get("last_commit_at"),
                "mean_score": (
                    round(mean_score, 1) if mean_score is not None else None
                ),
                "dormant_assignments": snapshot.dormant_assignments if snapshot else [],
            }
        )

    rows.sort(key=lambda r: (-r["planned_allocation"], r["full_name"]))
    return {
        "period_days": days,
        "period_start": start,
        "totals": {
            "commits": sum(r["commits"] for r in rows),
            "commits_all_time": sum(r["commits_all_time"] for r in rows),
            "people": len(rows),
        },
        "rows": rows,
    }


@api_view(["GET"])
def commit_calendar(request):
    """Daily commit cadence per person, with missed days marked.

    ``days`` bounds the window and ``project`` scopes it. The bound is clamped
    rather than trusted: the payload is one cell per person per day, so an
    unbounded ``days`` is a cheap way to ask for a very expensive response.
    """
    from .calendar import build_calendar

    try:
        days = int(request.query_params.get("days", settings.COMMIT_CALENDAR_DAYS))
    except (TypeError, ValueError):
        days = settings.COMMIT_CALENDAR_DAYS
    days = max(7, min(days, 366))

    project_id = _project_filter(request)
    today = timezone.localdate()

    return Response(
        cached(
            "scoring:calendar",
            cache_ns.ACTIVITY,
            {"days": days, "project": project_id, "today": today},
        )(lambda: build_calendar(days=days, project_id=project_id))
    )


@api_view(["GET"])
def leaderboard(request):
    """Everyone on the roster, ranked over a rolling window ending today.

    ``days`` defaults to 30 and is clamped; ``project`` scopes the commits
    counted. The window is always measured back from today rather than
    snapshotted, and today's date is part of the cache key, so the ranking
    cannot drift out of agreement with the commit calendar beside it.

    The ranking logic itself lives in ``scoring.leaderboard`` and nothing here
    knows anything about it.
    """
    from .leaderboard import build_leaderboard

    try:
        days = int(request.query_params.get("days", 30))
    except (TypeError, ValueError):
        days = 30
    days = max(7, min(days, 366))

    project_id = _project_filter(request)
    today = timezone.localdate()

    return Response(
        cached(
            "scoring:leaderboard",
            cache_ns.ACTIVITY,
            {"days": days, "project": project_id, "today": today},
        )(lambda: build_leaderboard(days=days, project_id=project_id))
    )


@api_view(["GET"])
def employee_scorecard(request, employee_id: int):
    """One person's trend and recent scored commits, with rationales."""
    employee = get_object_or_404(Employee, pk=employee_id)
    days = int(request.query_params.get("days", 30))
    start = timezone.localdate() - timedelta(days=days)

    daily = (
        DailyScore.objects.filter(employee=employee, date__gte=start)
        .select_related("project")
        .order_by("date")
    )
    recent = (
        CommitScore.objects.filter(employee=employee)
        .select_related("commit", "project")
        .order_by("-commit__authored_date")[:50]
    )

    return Response(
        {
            "employee": {
                "id": employee.id,
                "full_name": employee.full_name,
                "employment_type": employee.employment_type,
                "planned_allocation": employee.planned_allocation_percent(),
            },
            "daily": DailyScoreSerializer(daily, many=True).data,
            "recent_commits": CommitScoreSerializer(recent, many=True).data,
        }
    )


@api_view(["POST"])
def trigger_scoring(request):
    """Score queued commits now."""
    from .tasks_proxy import queue_scoring

    project_id = request.data.get("project")
    task_id = queue_scoring(project_id)
    return Response({"queued": True, "task_id": task_id}, status=status.HTTP_202_ACCEPTED)
