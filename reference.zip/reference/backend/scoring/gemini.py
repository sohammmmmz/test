"""Gemini client wrapper.

Nightly scoring has no latency requirement, so batch is the default path — it
costs half of interactive pricing for identical output. An interactive path is
kept for scoring a single commit on demand from the UI.

When no API key is configured the module hands back a stub that returns
low-confidence abstentions. That keeps the whole pipeline exercisable in
development and in tests without a key, and means an unconfigured deployment
degrades to "unscored" rather than crashing every nightly run.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from django.conf import settings

from .prompts import RESPONSE_SCHEMA, SYSTEM_INSTRUCTION, parse_response

logger = logging.getLogger(__name__)


@dataclass
class TextResponse:
    """A free-form generation, used where the caller owns the schema."""

    text: str
    model_version: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    error: str = ""

    @property
    def ok(self) -> bool:
        return not self.error


@dataclass
class ScoringResponse:
    parsed: dict
    model_version: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    error: str = ""

    @property
    def ok(self) -> bool:
        return not self.error


class GeminiScorer:
    """Thin wrapper over the Google GenAI SDK."""

    def __init__(self, api_key: str | None = None, model: str | None = None):
        self.api_key = api_key if api_key is not None else settings.GEMINI_API_KEY
        self.model = model or settings.GEMINI_MODEL
        self._client = None

    @property
    def client(self):
        if self._client is None:
            from google import genai

            self._client = genai.Client(api_key=self.api_key)
        return self._client

    def _config(self):
        from google.genai import types

        return types.GenerateContentConfig(
            system_instruction=SYSTEM_INSTRUCTION,
            response_mime_type="application/json",
            response_schema=RESPONSE_SCHEMA,
            temperature=0.1,
        )

    def score_one(self, prompt: str) -> ScoringResponse:
        """Score a single commit interactively."""
        try:
            response = self.client.models.generate_content(
                model=self.model, contents=prompt, config=self._config()
            )
        except Exception as exc:  # noqa: BLE001 - surfaced on the score row
            logger.warning("Gemini request failed: %s", exc)
            return ScoringResponse({}, self.model, error=str(exc))

        usage = getattr(response, "usage_metadata", None)
        try:
            parsed = parse_response(response.text)
        except ValueError as exc:
            return ScoringResponse({}, self.model, error=f"Unparseable response: {exc}")

        return ScoringResponse(
            parsed=parsed,
            model_version=self.model,
            input_tokens=getattr(usage, "prompt_token_count", None),
            output_tokens=getattr(usage, "candidates_token_count", None),
        )

    def score_batch(self, prompts: dict[str, str]) -> dict[str, ScoringResponse]:
        """Score many commits.

        The SDK's batch API is asynchronous and job-based; rather than block a
        worker polling it, this issues the requests sequentially and lets Celery
        own the concurrency. The interface is batch-shaped so switching to the
        job API later does not ripple outwards.
        """
        return {key: self.score_one(prompt) for key, prompt in prompts.items()}

    def generate_json(self, prompt: str) -> TextResponse:
        """Free-form JSON generation, for prompts with their own schema.

        Separate from :meth:`score_one`, which pins the commit-scoring schema —
        reusing it for codebase indexing would force structure onto a response
        that has nothing to do with scoring.
        """
        from google.genai import types

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json", temperature=0.0
                ),
            )
        except Exception as exc:  # noqa: BLE001 - reported to the caller
            logger.warning("Gemini generation failed: %s", exc)
            return TextResponse("", self.model, error=str(exc))

        usage = getattr(response, "usage_metadata", None)
        return TextResponse(
            text=response.text or "",
            model_version=self.model,
            input_tokens=getattr(usage, "prompt_token_count", None),
            output_tokens=getattr(usage, "candidates_token_count", None),
        )

    def summarize_document(self, raw: bytes, mime_type: str, filename: str) -> str:
        """Extract a business summary from an uploaded BRD or technical document.

        Gemini reads PDFs natively, so the BRD becomes real context for judging
        whether a commit serves the project's stated goals.
        """
        from google.genai import types

        prompt = (
            "Summarise this project document in 200-300 words for an engineer "
            "assessing whether code changes serve the project's goals. Cover the "
            "business objective, key features or deliverables, and any explicit "
            "constraints. Plain prose, no preamble."
        )
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=[
                    types.Part.from_bytes(data=raw, mime_type=mime_type),
                    prompt,
                ],
            )
            return (response.text or "").strip()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Document summarisation failed for %s: %s", filename, exc)
            return ""


class StubScorer:
    """Used when no API key is configured.

    Returns abstentions rather than invented numbers, so an unconfigured
    deployment shows commits as "needs review" instead of quietly fabricating
    scores for people's work.
    """

    def __init__(self, model: str | None = None):
        self.model = model or settings.GEMINI_MODEL

    def score_one(self, prompt: str) -> ScoringResponse:
        return ScoringResponse(
            parsed={
                "relevance": None,
                "substance": None,
                "change_kind": "unknown",
                "confidence": 0.0,
                "rationale": "No Gemini API key configured; commit was not assessed.",
                "matched_issue_iids": [],
            },
            model_version=f"{self.model}(stub)",
        )

    def score_batch(self, prompts: dict[str, str]) -> dict[str, ScoringResponse]:
        return {key: self.score_one(prompt) for key, prompt in prompts.items()}

    def generate_json(self, prompt: str) -> TextResponse:
        """No key configured, so no structure is invented — an empty result."""
        return TextResponse("", f"{self.model}(stub)")

    def summarize_document(self, raw: bytes, mime_type: str, filename: str) -> str:
        return ""


def get_scorer():
    """The configured scorer, or a stub when no key is available."""
    if not settings.GEMINI_API_KEY:
        logger.info("GEMINI_API_KEY is not set; scoring will abstain.")
        return StubScorer()
    return GeminiScorer()
