"""Prompt construction for commit relevance scoring.

The model is asked for exactly the judgments a human reviewer would need code
to make — is this change moving the assigned work forward, what kind of change
is it, how substantial is it — and nothing that can be computed deterministically.

Two instructions matter more than the rest. The model is told to judge substance
by difficulty rather than size, because the hardest bug in a codebase is often a
one-line diff and a scorer that rewards volume gets that exactly backwards. And
it is told to abstain when the context is insufficient, because a confident
guess about someone's work is worse than an admission of ignorance.
"""

from __future__ import annotations

import hashlib
import json

SYSTEM_INSTRUCTION = """\
You are reviewing a single git commit to assess how it relates to a developer's
assigned work on a software project.

Return ONLY a JSON object matching the schema. No prose, no markdown fences.

Scoring guidance:

- relevance (0-100): does this change advance the assigned task(s) and the
  project's stated goals? 80-100 clearly implements the assigned work; 50-79
  related supporting work such as refactors or tests enabling it; 20-49 useful
  but unrelated to what was assigned; 0-19 unrelated or trivial.
  If no task is assigned, judge against the project description and BRD summary.

- substance (0-100): estimated difficulty and engineering weight. Judge by how
  hard the change was to get right, NOT by how many lines it contains. A
  one-line fix to a subtle concurrency bug is high substance. A 500-line
  mechanical rename is low substance. Generated code, formatting and
  dependency bumps are low.

- change_kind: one of feature, fix, refactor, test, docs, config, chore, revert,
  unknown.

- confidence (0.0-1.0): how confident you are given the context provided. Use
  below 0.4 when the diff was heavily truncated, the assigned tasks are absent
  or unclear, or you genuinely cannot tell what the change does. Abstaining is
  correct and expected; do not guess to appear decisive.

- rationale: two or three sentences a reviewer could disagree with, naming what
  the change actually does and how it relates (or fails to relate) to the
  assigned work. This is shown to a human, so be specific and factual.

- matched_issue_iids: issue numbers from the provided list that this commit
  plausibly advances. Empty list if none.

Never infer anything about the developer as a person. Judge only the change.
"""

RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "relevance": {"type": "number"},
        "substance": {"type": "number"},
        "change_kind": {
            "type": "string",
            "enum": [
                "feature", "fix", "refactor", "test", "docs",
                "config", "chore", "revert", "unknown",
            ],
        },
        "confidence": {"type": "number"},
        "rationale": {"type": "string"},
        "matched_issue_iids": {"type": "array", "items": {"type": "integer"}},
    },
    "required": ["relevance", "substance", "change_kind", "confidence", "rationale"],
}


def _issue_block(issues) -> str:
    if not issues:
        return "(none recorded)"
    lines = []
    for issue in issues:
        milestone = f" [milestone: {issue.milestone.title}]" if issue.milestone else ""
        labels = f" labels: {', '.join(issue.labels)}" if issue.labels else ""
        description = (issue.description or "").strip().replace("\r", "")
        if len(description) > 600:
            description = description[:600] + " ..."
        lines.append(
            f"- #{issue.iid} ({issue.state}){milestone}{labels}\n"
            f"  title: {issue.title}\n"
            f"  description: {description or '(empty)'}"
        )
    return "\n".join(lines)


def _vault_block(vault_context: list[str]) -> str:
    return "\n\n".join(vault_context) if vault_context else "(no module context available)"


def build_prompt(
    *,
    commit,
    project,
    diff_payload: dict,
    assigned_issues: list,
    referenced_issues: list,
    brd_summary: str = "",
    vault_context: list[str] | None = None,
) -> str:
    """Assemble the user-turn prompt for one commit."""
    truncation_note = ""
    if diff_payload.get("budget_exhausted") or diff_payload.get("truncated_files"):
        truncation_note = (
            f"\nNOTE: the diff was trimmed — {diff_payload.get('included_count', 0)} of "
            f"{diff_payload.get('total_files', 0)} files included, "
            f"{diff_payload.get('truncated_files', 0)} truncated. Lower your "
            f"confidence accordingly.\n"
        )

    ignored = diff_payload.get("ignored_paths") or []
    ignored_note = (
        f"\nGenerated/vendored paths excluded: {', '.join(ignored[:10])}"
        f"{' ...' if len(ignored) > 10 else ''}\n"
        if ignored
        else ""
    )

    return f"""\
# Project
Name: {project.name}
Description: {(project.description or "(none)").strip()[:1000]}

## Business requirements summary
{(brd_summary or "(no BRD summary available)").strip()[:3000]}

## Current project state (from the project vault)
{_vault_block(vault_context or [])}

# Developer's assigned open tasks
{_issue_block(assigned_issues)}

# Tasks this commit references by number
{_issue_block(referenced_issues)}

# Commit
Author: {commit.author_name or "unknown"}
Date: {commit.authored_date.isoformat()}
Message:
{(commit.message or "").strip()[:2000]}

Files changed: {diff_payload.get("total_files", 0)}
Branches: {", ".join(commit.branch_names or []) or "(unknown)"}
{truncation_note}{ignored_note}
# Diff
```diff
{diff_payload.get("text", "") or "(no textual diff available)"}
```

Assess this commit and return the JSON object.
"""


def prompt_hash(prompt: str, model_version: str) -> str:
    """Identifies a scoring input, so a re-score with identical input is skippable."""
    return hashlib.sha256(f"{model_version}\x00{prompt}".encode()).hexdigest()


def parse_response(text: str) -> dict:
    """Parse the model's JSON, tolerating stray fences or prose around it."""
    cleaned = (text or "").strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1] if "```" in cleaned[3:] else cleaned[3:]
        cleaned = cleaned.removeprefix("json").strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start == -1 or end <= start:
            raise ValueError(f"No JSON object in model response: {text[:200]!r}") from None
        data = json.loads(cleaned[start : end + 1])

    if not isinstance(data, dict):
        raise ValueError("Model response was not a JSON object.")

    return {
        "relevance": _clamp(data.get("relevance"), 0, 100),
        "substance": _clamp(data.get("substance"), 0, 100),
        "change_kind": str(data.get("change_kind") or "unknown").lower(),
        "confidence": _clamp(data.get("confidence"), 0.0, 1.0),
        "rationale": str(data.get("rationale") or "").strip(),
        "matched_issue_iids": [
            int(i) for i in (data.get("matched_issue_iids") or []) if str(i).isdigit()
        ],
    }


def _clamp(value, low, high):
    if value is None:
        return None
    try:
        return max(low, min(high, float(value)))
    except (TypeError, ValueError):
        return None
