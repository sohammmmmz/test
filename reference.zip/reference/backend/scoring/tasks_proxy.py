"""Indirection so scoring views can queue work without importing sync tasks.

``sync.tasks`` imports from ``scoring.pipeline``; having the scoring views
import ``sync.tasks`` directly would close that loop at module level.
"""


def queue_scoring(project_id: int | None = None) -> str:
    from sync.tasks import score_pending_commits

    return score_pending_commits.delay(project_id=project_id).id


def queue_utilization(period_days: int = 14) -> str:
    from sync.tasks import refresh_utilization

    return refresh_utilization.delay(period_days=period_days).id
