"""Commit scoring and utilization.

Design stance: deterministic signals first, LLM second. Issue linkage, tests
touched, MR merge state and review activity need no model at all, cannot be
hallucinated, and cost nothing. Gemini is reserved for the genuinely subjective
judgments — whether a diff actually advances the assigned task, and what kind
of change it is.

Every score records the model version it came from and the reasoning behind it.
A score without a rationale is unchallengeable, and a score without a pinned
model version is not comparable across time, because a model upgrade shifts the
whole distribution.
"""

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from common.models import TimeStampedModel


class ChangeKind(models.TextChoices):
    FEATURE = "feature", "Feature"
    FIX = "fix", "Bug fix"
    REFACTOR = "refactor", "Refactor"
    TEST = "test", "Tests"
    DOCS = "docs", "Documentation"
    CONFIG = "config", "Configuration"
    CHORE = "chore", "Chore"
    REVERT = "revert", "Revert"
    UNKNOWN = "unknown", "Unknown"


class ScoringConfig(TimeStampedModel):
    """Runtime-tunable composite weights.

    Singleton-ish: the most recently created active row wins, so weights can be
    retuned without a deploy and old scores keep the weights they were computed
    under.
    """

    name = models.CharField(max_length=64, default="default")
    is_active = models.BooleanField(default=True)

    weight_relevance = models.FloatField(default=0.40)
    weight_substance = models.FloatField(default=0.25)
    weight_quality = models.FloatField(default=0.20)
    weight_linkage = models.FloatField(default=0.15)

    min_confidence = models.FloatField(
        default=0.4,
        help_text="Below this the model abstains and the commit goes to review.",
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"scoring config '{self.name}'"

    @property
    def weights(self) -> dict:
        return {
            "relevance": self.weight_relevance,
            "substance": self.weight_substance,
            "quality": self.weight_quality,
            "linkage": self.weight_linkage,
        }

    @classmethod
    def current(cls):
        return cls.objects.filter(is_active=True).first()


class ScoreStatus(models.TextChoices):
    PENDING = "pending", "Queued for scoring"
    SCORED = "scored", "Scored"
    NEEDS_REVIEW = "needs_review", "Low confidence — needs review"
    SKIPPED = "skipped", "Skipped (no scoreable content)"
    FAILED = "failed", "Scoring failed"


class CommitScore(TimeStampedModel):
    """Scores for a single commit.

    ``diff_hash`` is the cache key: the same diff is never sent to the model
    twice, which is what keeps a nightly batch cheap.
    """

    commit = models.OneToOneField(
        "activity.Commit", on_delete=models.CASCADE, related_name="score"
    )
    employee = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="commit_scores",
    )
    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="commit_scores"
    )
    status = models.CharField(
        max_length=16, choices=ScoreStatus.choices, default=ScoreStatus.PENDING, db_index=True
    )

    # --- Model-judged (0-100) ---
    relevance = models.FloatField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Does this diff advance the assigned task, given project state?",
    )
    substance = models.FloatField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Estimated complexity. Explicitly not lines of code.",
    )
    change_kind = models.CharField(
        max_length=16, choices=ChangeKind.choices, default=ChangeKind.UNKNOWN
    )

    # --- Deterministic (0-100), computed without the model ---
    quality = models.FloatField(null=True, blank=True)
    linkage = models.FloatField(null=True, blank=True)
    # The raw booleans/counts behind `quality` and `linkage`, so the number is
    # explainable: tests_touched, mr_merged, ci_passed, references_issue, ...
    deterministic_signals = models.JSONField(default=dict, blank=True)

    composite = models.FloatField(null=True, blank=True, db_index=True)
    weights_used = models.JSONField(default=dict, blank=True)

    confidence = models.FloatField(null=True, blank=True)
    rationale = models.TextField(
        blank=True, help_text="The model's stated reasoning. Required for the score to be arguable."
    )
    matched_issue_iids = models.JSONField(default=list, blank=True)

    # --- Provenance ---
    diff_hash = models.CharField(max_length=64, blank=True, db_index=True)
    prompt_hash = models.CharField(max_length=64, blank=True)
    model_version = models.CharField(max_length=64, blank=True)
    scored_at = models.DateTimeField(null=True, blank=True)
    input_tokens = models.PositiveIntegerField(null=True, blank=True)
    output_tokens = models.PositiveIntegerField(null=True, blank=True)
    error_message = models.TextField(blank=True)

    # --- Human override ---
    # Overrides survive re-syncs: recomputation never silently overwrites a
    # human judgment.
    override_composite = models.FloatField(null=True, blank=True)
    override_reason = models.TextField(blank=True)
    overridden_by = models.ForeignKey(
        "accounts.User", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="score_overrides",
    )
    overridden_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["employee", "-created_at"]),
            models.Index(fields=["project", "status"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        return f"score {self.effective_composite} for {self.commit.short_id}"

    @property
    def effective_composite(self):
        """The override when present, otherwise the computed score."""
        return self.override_composite if self.override_composite is not None else self.composite

    @property
    def is_overridden(self) -> bool:
        return self.override_composite is not None


class DailyScore(TimeStampedModel):
    """A person's rolled-up score for one day on one project.

    ``had_no_commits`` exists so absence of commits reads as "no commit
    activity" rather than a zero. A day spent reviewing, pairing or debugging is
    not a day of no work, and collapsing the two produces a misleading trend.
    """

    employee = models.ForeignKey(
        "team.Employee", on_delete=models.CASCADE, related_name="daily_scores"
    )
    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="daily_scores"
    )
    date = models.DateField(db_index=True)

    commit_count = models.PositiveIntegerField(default=0)
    scored_commit_count = models.PositiveIntegerField(default=0)
    composite = models.FloatField(null=True, blank=True)
    mean_relevance = models.FloatField(null=True, blank=True)
    mean_substance = models.FloatField(null=True, blank=True)

    # Contribution that leaves no commits behind.
    review_note_count = models.PositiveIntegerField(default=0)
    merge_requests_opened = models.PositiveIntegerField(default=0)
    merge_requests_merged = models.PositiveIntegerField(default=0)
    issues_closed = models.PositiveIntegerField(default=0)

    had_no_commits = models.BooleanField(default=False)
    signals = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["employee", "project", "date"], name="uniq_daily_score"
            )
        ]
        indexes = [models.Index(fields=["employee", "-date"])]
        ordering = ["-date"]

    def __str__(self):
        return f"{self.employee.full_name} {self.date} {self.project.slug}"


class UtilizationSnapshot(TimeStampedModel):
    """Planned allocation versus observed engagement over a period.

    The gap between the two columns is the point of this table.
    """

    employee = models.ForeignKey(
        "team.Employee", on_delete=models.CASCADE, related_name="utilization_snapshots"
    )
    period_start = models.DateField(db_index=True)
    period_end = models.DateField()

    planned_allocation_percent = models.PositiveIntegerField(default=0)
    active_project_count = models.PositiveIntegerField(default=0)
    engaged_project_count = models.PositiveIntegerField(
        default=0, help_text="Projects with observed activity in the period."
    )
    active_days = models.PositiveIntegerField(default=0)
    total_commits = models.PositiveIntegerField(default=0)
    mean_daily_score = models.FloatField(null=True, blank=True)

    # Assigned but silent: the most actionable output here.
    dormant_assignments = models.JSONField(default=list, blank=True)
    is_overallocated = models.BooleanField(default=False)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["employee", "period_start", "period_end"], name="uniq_utilization_period"
            )
        ]
        ordering = ["-period_start"]

    def __str__(self):
        return f"{self.employee.full_name} {self.period_start}..{self.period_end}"


class ScoringBatch(TimeStampedModel):
    """A submitted Gemini batch job.

    Nightly scoring is latency-insensitive, so batch is the default path — it
    costs half of interactive pricing.
    """

    class Status(models.TextChoices):
        PREPARING = "preparing", "Preparing"
        SUBMITTED = "submitted", "Submitted"
        RUNNING = "running", "Running"
        SUCCEEDED = "succeeded", "Succeeded"
        FAILED = "failed", "Failed"
        CANCELLED = "cancelled", "Cancelled"

    sync_run = models.ForeignKey(
        "sync.SyncRun", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="scoring_batches",
    )
    provider_batch_name = models.CharField(max_length=255, blank=True, db_index=True)
    model_version = models.CharField(max_length=64)
    status = models.CharField(
        max_length=16, choices=Status.choices, default=Status.PREPARING, db_index=True
    )
    commit_count = models.PositiveIntegerField(default=0)
    succeeded_count = models.PositiveIntegerField(default=0)
    failed_count = models.PositiveIntegerField(default=0)
    submitted_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"batch {self.provider_batch_name or self.pk} [{self.status}]"
