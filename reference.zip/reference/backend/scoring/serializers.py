from rest_framework import serializers

from .models import CommitScore, DailyScore, ScoringConfig, UtilizationSnapshot


class CommitScoreSerializer(serializers.ModelSerializer):
    commit_sha = serializers.CharField(source="commit.short_id", read_only=True)
    commit_title = serializers.CharField(source="commit.title", read_only=True)
    commit_url = serializers.CharField(source="commit.web_url", read_only=True)
    authored_date = serializers.DateTimeField(source="commit.authored_date", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    project_name = serializers.CharField(source="project.name", read_only=True)
    effective_composite = serializers.FloatField(read_only=True)
    is_overridden = serializers.BooleanField(read_only=True)
    overridden_by_name = serializers.CharField(
        source="overridden_by.username", read_only=True
    )

    class Meta:
        model = CommitScore
        fields = [
            "id", "commit", "commit_sha", "commit_title", "commit_url", "authored_date",
            "employee", "employee_name", "project", "project_name", "status",
            "relevance", "substance", "quality", "linkage", "change_kind",
            "composite", "effective_composite", "confidence", "rationale",
            "deterministic_signals", "matched_issue_iids", "weights_used",
            "model_version", "scored_at", "input_tokens", "output_tokens",
            "error_message", "override_composite", "override_reason",
            "overridden_by", "overridden_by_name", "overridden_at", "is_overridden",
        ]


class ScoreOverrideSerializer(serializers.Serializer):
    composite = serializers.FloatField(min_value=0, max_value=100)
    reason = serializers.CharField(min_length=5)

    def validate_reason(self, value):
        # An override without a stated reason is just as opaque as the number
        # it replaces.
        if not value.strip():
            raise serializers.ValidationError("An override must state a reason.")
        return value.strip()


class DailyScoreSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source="project.name", read_only=True)
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)

    class Meta:
        model = DailyScore
        fields = [
            "id", "employee", "employee_name", "project", "project_name", "date",
            "commit_count", "scored_commit_count", "composite", "mean_relevance",
            "mean_substance", "review_note_count", "merge_requests_opened",
            "merge_requests_merged", "issues_closed", "had_no_commits", "signals",
        ]


class UtilizationSnapshotSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)

    class Meta:
        model = UtilizationSnapshot
        fields = [
            "id", "employee", "employee_name", "period_start", "period_end",
            "planned_allocation_percent", "active_project_count",
            "engaged_project_count", "active_days", "total_commits",
            "mean_daily_score", "dormant_assignments", "is_overallocated",
        ]


class ScoringConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScoringConfig
        fields = [
            "id", "name", "is_active", "weight_relevance", "weight_substance",
            "weight_quality", "weight_linkage", "min_confidence", "created_at",
        ]

    def validate(self, attrs):
        weights = [
            attrs.get("weight_relevance", 0.40),
            attrs.get("weight_substance", 0.25),
            attrs.get("weight_quality", 0.20),
            attrs.get("weight_linkage", 0.15),
        ]
        if any(w < 0 for w in weights):
            raise serializers.ValidationError("Weights cannot be negative.")
        if sum(weights) <= 0:
            raise serializers.ValidationError("At least one weight must be positive.")
        return attrs
