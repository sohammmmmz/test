"""Tests for diff trimming, deterministic signals, and the scoring pipeline."""

import pytest
import responses
from django.utils import timezone

from activity.models import Commit, Issue, MergeRequest
from scoring.diffs import build_diff_payload, diff_hash_for, is_ignored, truncate_file_diff
from scoring.gemini import ScoringResponse, StubScorer
from scoring.models import ChangeKind, CommitScore, DailyScore, ScoreStatus, ScoringConfig
from scoring.pipeline import (
    compute_utilization,
    enqueue_unscored_commits,
    rollup_daily_scores,
    score_pending,
)
from scoring.prompts import build_prompt, parse_response
from scoring.signals import (
    composite_score,
    compute_linkage,
    compute_quality,
    is_low_effort_message,
    touches_tests,
)

API = "https://gitlab.example.com/api/v4"

pytestmark = pytest.mark.django_db


class TestIgnorePatterns:
    @pytest.mark.parametrize(
        "path",
        [
            "package-lock.json", "yarn.lock", "poetry.lock", "go.sum",
            "frontend/node_modules/x/index.js", "backend/app/migrations/0001_initial.py",
            "static/logo.svg", "dist/bundle.min.js", "docs/BRD.pdf",
        ],
    )
    def test_generated_and_vendored_paths_are_excluded(self, path):
        assert is_ignored(path) is True

    @pytest.mark.parametrize(
        "path", ["src/auth/login.py", "frontend/src/app/page.tsx", "README.md"]
    )
    def test_real_source_is_kept(self, path):
        assert is_ignored(path) is False


class TestTruncation:
    def test_short_diffs_pass_through_untouched(self):
        text, truncated = truncate_file_diff("a\nb\nc", max_lines=10)

        assert text == "a\nb\nc"
        assert truncated is False

    def test_long_diffs_keep_their_hunk_headers(self):
        """A truncated diff with no location is far less useful."""
        lines = ["@@ -1,5 +1,5 @@"] + ["+line"] * 50 + ["@@ -200,3 +200,4 @@"] + ["+more"] * 10
        text, truncated = truncate_file_diff("\n".join(lines), max_lines=20)

        assert truncated is True
        assert "@@ -200,3 +200,4 @@" in text
        assert "more lines" in text


class TestDiffPayload:
    def test_drops_ignored_paths_and_keeps_source(self):
        payload = build_diff_payload(
            [
                {"new_path": "src/auth.py", "diff": "@@\n+code"},
                {"new_path": "package-lock.json", "diff": "@@\n+" + "x" * 5000},
            ]
        )

        assert payload["included_count"] == 1
        assert "package-lock.json" in payload["ignored_paths"]
        assert payload["changed_paths"] == ["src/auth.py", "package-lock.json"]

    def test_binary_files_are_skipped(self):
        payload = build_diff_payload(
            [{"new_path": "img.dat", "diff": "", "binary": True}]
        )

        assert payload["included_count"] == 0

    def test_stops_at_the_byte_budget(self, settings):
        settings.GEMINI_MAX_DIFF_BYTES = 500
        diffs = [
            {"new_path": f"src/f{i}.py", "diff": "@@\n" + "+x" * 200} for i in range(20)
        ]

        payload = build_diff_payload(diffs)

        assert payload["budget_exhausted"] is True
        assert payload["included_count"] < 20

    def test_hash_is_order_independent_and_content_sensitive(self):
        a = [{"new_path": "a.py", "diff": "x"}, {"new_path": "b.py", "diff": "y"}]
        b = list(reversed(a))
        c = [{"new_path": "a.py", "diff": "z"}, {"new_path": "b.py", "diff": "y"}]

        assert diff_hash_for(a) == diff_hash_for(b)
        assert diff_hash_for(a) != diff_hash_for(c)


class TestDeterministicSignals:
    @pytest.mark.parametrize(
        "path,expected",
        [
            ("tests/test_auth.py", True),
            ("src/__tests__/login.spec.ts", True),
            ("src/auth.test.js", True),
            ("src/auth.py", False),
        ],
    )
    def test_detects_test_paths(self, path, expected):
        assert touches_tests([path]) is expected

    @pytest.mark.parametrize("message", ["wip", "fix", "Update", "asdf", "."])
    def test_detects_low_effort_messages(self, message):
        assert is_low_effort_message(message) is True

    def test_a_real_message_is_not_low_effort(self):
        assert is_low_effort_message("fix: handle null session on logout") is False

    def test_linkage_rewards_referencing_an_assigned_issue(self, repo, employee):
        issue = Issue.objects.create(repo=repo, iid=42, title="Login", state="opened")
        issue.assignees.add(employee)
        commit = Commit.objects.create(
            repo=repo, sha="a" * 40, message="fix: login #42",
            authored_date=timezone.now(), author_employee=employee,
            referenced_issue_iids=[42],
        )

        score, evidence = compute_linkage(commit, [issue])

        assert score >= 65
        assert evidence["matched_assigned_issue"] is True

    def test_linkage_is_zero_without_references(self, repo, employee):
        commit = Commit.objects.create(
            repo=repo, sha="b" * 40, message="stuff", authored_date=timezone.now()
        )

        score, evidence = compute_linkage(commit, [])

        assert score == 0
        assert evidence["references_issue"] is False

    def test_quality_rewards_tests_and_merged_mrs(self, repo, employee):
        commit = Commit.objects.create(
            repo=repo, sha="c" * 40, title="feat: add login validation logic",
            message="feat: add login validation logic", authored_date=timezone.now(),
            branch_names=["feature/login"],
        )
        MergeRequest.objects.create(
            repo=repo, iid=1, source_branch="feature/login", state="merged",
            user_notes_count=3, has_pipeline_success=True,
        )

        score, evidence = compute_quality(
            commit, {"changed_paths": ["src/auth.py", "tests/test_auth.py"]}, []
        )

        assert score > 80
        assert evidence["touches_tests"] is True
        assert evidence["merged_via_mr"] is True

    def test_quality_penalises_an_empty_message(self, repo):
        commit = Commit.objects.create(
            repo=repo, sha="d" * 40, title="wip", message="wip",
            authored_date=timezone.now(),
        )

        score, evidence = compute_quality(commit, {"changed_paths": ["src/a.py"]}, [])

        assert score < 50
        assert evidence["low_effort_message"] is True

    def test_quality_starts_neutral_not_zero(self, repo):
        """A change is not low quality merely because there was nothing to test."""
        commit = Commit.objects.create(
            repo=repo, sha="e" * 40, title="chore: bump the log level for debugging",
            message="chore: bump the log level for debugging",
            authored_date=timezone.now(),
        )

        score, _ = compute_quality(commit, {"changed_paths": ["src/settings.py"]}, [])

        assert 40 <= score <= 70


class TestComposite:
    def test_weighted_mean(self):
        parts = {"relevance": 80, "substance": 60, "quality": 70, "linkage": 100}
        weights = {"relevance": 0.4, "substance": 0.25, "quality": 0.2, "linkage": 0.15}

        assert composite_score(parts, weights) == pytest.approx(76.0, abs=0.5)

    def test_renormalises_when_the_model_abstained(self):
        """A missing relevance score must not silently penalise the commit."""
        parts = {"relevance": None, "substance": None, "quality": 80, "linkage": 60}
        weights = {"relevance": 0.4, "substance": 0.25, "quality": 0.2, "linkage": 0.15}

        result = composite_score(parts, weights)

        assert result == pytest.approx((80 * 0.2 + 60 * 0.15) / 0.35, abs=0.1)

    def test_no_components_yields_zero(self):
        assert composite_score({}, {"relevance": 1.0}) == 0.0


class TestParseResponse:
    def test_parses_plain_json(self):
        parsed = parse_response(
            '{"relevance": 80, "substance": 60, "change_kind": "feature", '
            '"confidence": 0.9, "rationale": "Adds the endpoint."}'
        )

        assert parsed["relevance"] == 80
        assert parsed["change_kind"] == "feature"

    def test_tolerates_markdown_fences(self):
        parsed = parse_response(
            '```json\n{"relevance": 50, "substance": 50, "change_kind": "fix", '
            '"confidence": 0.5, "rationale": "r"}\n```'
        )

        assert parsed["relevance"] == 50

    def test_clamps_out_of_range_values(self):
        parsed = parse_response(
            '{"relevance": 500, "substance": -20, "change_kind": "fix", '
            '"confidence": 3.0, "rationale": "r"}'
        )

        assert parsed["relevance"] == 100
        assert parsed["substance"] == 0
        assert parsed["confidence"] == 1.0

    def test_unparseable_output_raises(self):
        with pytest.raises(ValueError):
            parse_response("I cannot answer that.")


class TestEnqueue:
    def test_creates_pending_rows(self, project, repo, employee):
        for i in range(3):
            Commit.objects.create(
                repo=repo, sha=f"{i}" * 40, authored_date=timezone.now(),
                author_employee=employee,
            )

        assert enqueue_unscored_commits(project) == 3
        assert CommitScore.objects.filter(status=ScoreStatus.PENDING).count() == 3

    def test_merge_commits_are_skipped_not_scored(self, project, repo, employee):
        """Otherwise whoever pressed merge gets credited with someone else's branch."""
        Commit.objects.create(
            repo=repo, sha="m" * 40, authored_date=timezone.now(),
            author_employee=employee, is_merge_commit=True, parent_ids=["a", "b"],
        )

        enqueue_unscored_commits(project)

        assert CommitScore.objects.get().status == ScoreStatus.SKIPPED

    def test_does_not_re_enqueue_already_scored_commits(self, project, repo, employee):
        Commit.objects.create(
            repo=repo, sha="a" * 40, authored_date=timezone.now(), author_employee=employee
        )
        enqueue_unscored_commits(project)

        assert enqueue_unscored_commits(project) == 0
        assert CommitScore.objects.count() == 1


class FakeScorer:
    """Returns a fixed high-confidence judgment."""

    model = "fake-model-1"

    def __init__(self, confidence=0.9):
        self.confidence = confidence
        self.calls = 0

    def score_one(self, prompt):
        self.calls += 1
        return ScoringResponse(
            parsed={
                "relevance": 85.0, "substance": 70.0, "change_kind": "feature",
                "confidence": self.confidence, "rationale": "Implements the endpoint.",
                "matched_issue_iids": [42],
            },
            model_version=self.model,
            input_tokens=1200,
            output_tokens=150,
        )


@pytest.fixture
def scoreable_commit(project, repo, employee, mocked_responses):
    commit = Commit.objects.create(
        repo=repo, sha="a" * 40, short_id="aaaaaaaa",
        title="feat: add login endpoint", message="feat: add login endpoint #42",
        authored_date=timezone.now(), author_employee=employee,
        referenced_issue_iids=[42], branch_names=["feature/login"],
    )
    Issue.objects.create(repo=repo, iid=42, title="Login endpoint", state="opened")
    enqueue_unscored_commits(project)
    mocked_responses.add(
        responses.GET, f"{API}/projects/555/repository/commits/{'a' * 40}/diff",
        json=[{"new_path": "src/auth/login.py", "diff": "@@ -1 +1,5 @@\n+def login():\n+    pass"}],
    )
    return commit


class TestScorePending:
    def test_scores_a_commit_end_to_end(self, project, scoreable_commit, monkeypatch):
        fake = FakeScorer()
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: fake)

        counts = score_pending(project=project)

        assert counts["scored"] == 1
        score = CommitScore.objects.get()
        assert score.status == ScoreStatus.SCORED
        assert score.relevance == 85.0
        assert score.change_kind == ChangeKind.FEATURE
        assert score.rationale, "a score without a rationale is unchallengeable"
        assert score.model_version == "fake-model-1"
        assert score.composite is not None

    def test_low_confidence_goes_to_review_not_into_the_rollup(
        self, project, scoreable_commit, monkeypatch
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer(confidence=0.1))

        counts = score_pending(project=project)

        assert counts["needs_review"] == 1
        assert CommitScore.objects.get().status == ScoreStatus.NEEDS_REVIEW

    def test_records_the_pinned_model_version(self, project, scoreable_commit, monkeypatch):
        """A model upgrade shifts the whole distribution, so scores are not
        comparable across versions unless the version is recorded."""
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())

        score_pending(project=project)

        assert CommitScore.objects.get().model_version == "fake-model-1"

    def test_identical_diffs_reuse_the_cached_judgment(
        self, project, repo, employee, monkeypatch, mocked_responses
    ):
        """The diff_hash cache is what keeps a nightly run affordable."""
        fake = FakeScorer()
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: fake)

        for sha in ("a" * 40, "b" * 40):
            Commit.objects.create(
                repo=repo, sha=sha, title="feat: x", message="feat: x",
                authored_date=timezone.now(), author_employee=employee,
            )
            mocked_responses.add(
                responses.GET, f"{API}/projects/555/repository/commits/{sha}/diff",
                json=[{"new_path": "src/a.py", "diff": "@@\n+identical"}],
            )
        enqueue_unscored_commits(project)

        first = score_pending(project=project, limit=1)
        # The second commit has no diff_hash until its diff is fetched, so it
        # is scored once and only then becomes cacheable.
        second = score_pending(project=project, limit=1)
        third_commit = Commit.objects.create(
            repo=repo, sha="c" * 40, title="feat: x", message="feat: x",
            authored_date=timezone.now(), author_employee=employee,
            diff_hash=Commit.objects.get(sha="a" * 40).diff_hash,
        )
        enqueue_unscored_commits(project)
        third = score_pending(project=project, limit=1)

        assert first["scored"] == 1
        assert second["scored"] == 1
        assert third["cached"] == 1
        cached_row = CommitScore.objects.get(commit=third_commit)
        assert cached_row.deterministic_signals["from_cache"] is True

    def test_a_commit_with_only_generated_files_is_skipped(
        self, project, repo, employee, monkeypatch, mocked_responses
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())
        Commit.objects.create(
            repo=repo, sha="f" * 40, title="chore: lockfile",
            authored_date=timezone.now(), author_employee=employee,
        )
        enqueue_unscored_commits(project)
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits/{'f' * 40}/diff",
            json=[{"new_path": "package-lock.json", "diff": "@@\n+deps"}],
        )

        counts = score_pending(project=project)

        assert counts["skipped"] == 1

    def test_a_diff_fetch_failure_records_the_error(
        self, project, repo, employee, monkeypatch, mocked_responses
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())
        Commit.objects.create(
            repo=repo, sha="e" * 40, authored_date=timezone.now(), author_employee=employee
        )
        enqueue_unscored_commits(project)
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/commits/{'e' * 40}/diff",
            json={"message": "500"}, status=500,
        )

        counts = score_pending(project=project)

        assert counts["failed"] == 1
        assert "Diff fetch failed" in CommitScore.objects.get().error_message

    def test_the_stub_scorer_abstains_rather_than_inventing_numbers(
        self, project, scoreable_commit, monkeypatch
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: StubScorer())

        counts = score_pending(project=project)

        assert counts["needs_review"] == 1
        score = CommitScore.objects.get()
        assert score.relevance is None
        assert "No Gemini API key" in score.rationale

    def test_fetching_the_diff_records_changed_paths(
        self, project, scoreable_commit, monkeypatch
    ):
        """Which is also what the vault's module clustering reads."""
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())

        score_pending(project=project)

        scoreable_commit.refresh_from_db()
        assert scoreable_commit.changed_paths == ["src/auth/login.py"]


class TestPromptConstruction:
    def test_includes_assigned_tasks_and_brd_summary(self, project, repo, employee):
        commit = Commit.objects.create(
            repo=repo, sha="a" * 40, title="t", message="m",
            authored_date=timezone.now(), author_employee=employee,
        )
        issue = Issue.objects.create(
            repo=repo, iid=42, title="Login endpoint", description="Do the thing",
            state="opened",
        )

        prompt = build_prompt(
            commit=commit, project=project,
            diff_payload={"text": "diff", "total_files": 1},
            assigned_issues=[issue], referenced_issues=[],
            brd_summary="Build a portal.",
        )

        assert "#42" in prompt
        assert "Build a portal." in prompt
        assert "Do the thing" in prompt

    def test_flags_truncation_so_the_model_lowers_confidence(self, project, repo):
        commit = Commit.objects.create(
            repo=repo, sha="a" * 40, authored_date=timezone.now()
        )

        prompt = build_prompt(
            commit=commit, project=project,
            diff_payload={
                "text": "d", "total_files": 50, "included_count": 3,
                "truncated_files": 3, "budget_exhausted": True,
            },
            assigned_issues=[], referenced_issues=[],
        )

        assert "trimmed" in prompt
        assert "Lower your" in prompt


class TestRollups:
    def test_daily_rollup_averages_scored_commits(
        self, project, scoreable_commit, employee, monkeypatch
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())
        score_pending(project=project)

        rollup_daily_scores(project)

        daily = DailyScore.objects.get(employee=employee)
        assert daily.commit_count == 1
        assert daily.composite is not None

    def test_a_day_of_review_only_work_is_not_a_zero(self, project, repo, employee):
        """Review, pairing and debugging leave no commits; collapsing that into
        zero misreads a week of unblocking others as idleness."""
        from activity.models import MergeRequest, ReviewNote

        merge_request = MergeRequest.objects.create(
            repo=repo, iid=1, state="opened", source_branch="f"
        )
        ReviewNote.objects.create(
            merge_request=merge_request, gitlab_note_id=1,
            author_employee=employee, noted_at=timezone.now(), body="please rename this",
        )

        rollup_daily_scores(project)

        daily = DailyScore.objects.get(employee=employee)
        assert daily.had_no_commits is True
        assert daily.review_note_count == 1
        assert daily.composite is None, "absence of commits is not a score of zero"

    def test_utilization_flags_a_dormant_assignment(self, project, repo, employee):
        """Assigned but silent is the most actionable output here."""
        from team.models import Assignment

        Assignment.objects.create(employee=employee, project=project, allocation_percent=60)

        compute_utilization()

        from scoring.models import UtilizationSnapshot

        snapshot = UtilizationSnapshot.objects.get(employee=employee)
        assert snapshot.planned_allocation_percent == 60
        assert snapshot.engaged_project_count == 0
        assert snapshot.dormant_assignments[0]["project"] == project.name

    def test_utilization_flags_overallocation(self, project, employee, db):
        from projects.models import Project
        from team.models import Assignment

        other = Project.objects.create(name="Zeus", slug="zeus")
        Assignment.objects.create(employee=employee, project=project, allocation_percent=70)
        Assignment.objects.create(employee=employee, project=other, allocation_percent=60)

        compute_utilization()

        from scoring.models import UtilizationSnapshot

        assert UtilizationSnapshot.objects.get(employee=employee).is_overallocated is True


class TestOverrides:
    def test_override_takes_precedence_and_records_who_and_why(
        self, api_client, project, scoreable_commit, monkeypatch, admin_user
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())
        score_pending(project=project)
        score = CommitScore.objects.get()

        response = api_client.post(
            f"/api/scoring/commit-scores/{score.pk}/override/",
            {"composite": 95, "reason": "Unblocked three people; the diff hides that."},
        )

        assert response.status_code == 200
        score.refresh_from_db()
        assert score.effective_composite == 95
        assert score.overridden_by == admin_user
        assert score.is_overridden

    def test_an_override_requires_a_reason(
        self, api_client, project, scoreable_commit, monkeypatch
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())
        score_pending(project=project)
        score = CommitScore.objects.get()

        response = api_client.post(
            f"/api/scoring/commit-scores/{score.pk}/override/", {"composite": 95, "reason": ""}
        )

        assert response.status_code == 400

    def test_overrides_survive_re_scoring(self, project, scoreable_commit, monkeypatch, admin_user):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer())
        score_pending(project=project)
        score = CommitScore.objects.get()
        score.override_composite = 95
        score.override_reason = "context the diff cannot show"
        score.save()

        score_pending(project=project)

        score.refresh_from_db()
        assert score.effective_composite == 95


class TestScoringConfig:
    def test_active_config_supplies_the_weights(self, db):
        ScoringConfig.objects.create(
            name="custom", weight_relevance=0.7, weight_substance=0.1,
            weight_quality=0.1, weight_linkage=0.1,
        )

        assert ScoringConfig.current().weights["relevance"] == 0.7

    def test_weights_must_not_be_negative(self, api_client):
        response = api_client.post(
            "/api/scoring/config/", {"name": "bad", "weight_relevance": -1}
        )

        assert response.status_code == 400


class TestEndpoints:
    def test_review_queue_lists_abstentions(
        self, api_client, project, scoreable_commit, monkeypatch
    ):
        monkeypatch.setattr("scoring.pipeline.get_scorer", lambda: FakeScorer(confidence=0.1))
        score_pending(project=project)

        rows = api_client.get("/api/scoring/commit-scores/review-queue/").json()

        assert len(rows) == 1
        assert rows[0]["status"] == "needs_review"

    def test_utilization_dashboard_reports_planned_and_actual_side_by_side(
        self, api_client, project, employee
    ):
        from team.models import Assignment

        Assignment.objects.create(employee=employee, project=project, allocation_percent=60)

        row = api_client.get("/api/scoring/dashboard").json()["rows"][0]

        assert row["planned_allocation"] == 60
        assert row["commits"] == 0
        assert row["assigned_projects"][0]["name"] == project.name
