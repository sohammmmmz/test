"""What the leaderboard score rewards, and what it refuses to.

These tests are the specification for ``scoring.leaderboard``. When the logic is
enhanced, this file is where the intended behaviour is argued: each test names a
property the score should have rather than pinning a magic number, so a
reweighting that preserves the intent does not break the suite.
"""

from datetime import timedelta

import pytest
from django.utils import timezone

from activity.models import Commit
from scoring.leaderboard import (
    COMPONENTS,
    Facts,
    build_leaderboard,
    score,
    score_consistency,
    score_coverage,
    score_volume,
)
from team.models import AuthorAlias, Employee

pytestmark = pytest.mark.django_db


def _weekdays_back(count: int, *, skip: int = 0):
    """The most recent ``count`` weekdays, most recent first, skipping some."""
    days, cursor = [], timezone.localdate()
    while len(days) < count + skip:
        if cursor.weekday() < 5:
            days.append(cursor)
        cursor -= timedelta(days=1)
    return days[skip:]


def _commit(repo, employee, day, sha):
    return Commit.objects.create(
        repo=repo,
        sha=sha,
        author_email=employee.official_email,
        author_employee=employee,
        authored_date=timezone.make_aware(
            timezone.datetime(day.year, day.month, day.day, 12, 0)
        ),
    )


def _person(name, email):
    employee = Employee.objects.create(official_email=email, full_name=name)
    AuthorAlias.objects.create(
        employee=employee, email=email, source=AuthorAlias.Source.OFFICIAL
    )
    return employee


def _facts(commits_by_day, expected_days):
    return Facts(
        employee=Employee(full_name="x"),
        start=timezone.localdate() - timedelta(days=29),
        end=timezone.localdate(),
        commits_by_day=commits_by_day,
        expected_days=expected_days,
    )


def _row(data, employee):
    return next(r for r in data["rows"] if r["employee_id"] == employee.id)


class TestVolume:
    def test_no_commits_scores_zero(self):
        assert score_volume(_facts({}, [])) == 0.0

    def test_more_commits_always_score_higher(self):
        """Strictly increasing, so the curve never produces ties at a ceiling."""
        days = _weekdays_back(1)
        previous = -1.0
        for n in (1, 5, 20, 100, 500):
            value = score_volume(_facts({days[0]: n}, days))
            assert value > previous
            previous = value

    def test_returns_diminish(self):
        """The point of the curve: the first commits are worth far more than the
        hundredth, so splitting one change into twenty gains almost nothing."""
        day = _weekdays_back(1)[0]
        first_five = score_volume(_facts({day: 5}, [day]))
        next_five = score_volume(_facts({day: 10}, [day])) - first_five

        assert next_five < first_five

    def test_it_is_bounded(self):
        day = _weekdays_back(1)[0]
        assert score_volume(_facts({day: 100_000}, [day])) < 100.0


class TestCoverage:
    def test_committing_every_working_day_is_full_marks(self):
        days = _weekdays_back(10)
        assert score_coverage(_facts(dict.fromkeys(days, 1), days)) == 100.0

    def test_half_the_days_is_half_the_score(self):
        days = _weekdays_back(10)
        assert score_coverage(_facts(dict.fromkeys(days[:5], 1), days)) == 50.0

    def test_weekend_work_cannot_push_it_over_full(self):
        days = _weekdays_back(5)
        saturday = timezone.localdate() - timedelta(days=timezone.localdate().weekday() + 2)
        commits = dict.fromkeys(days, 1)
        commits[saturday] = 3

        assert score_coverage(_facts(commits, days)) == 100.0

    def test_it_abstains_when_nothing_was_expected(self):
        """Someone who joined yesterday has no coverage figure. That is not the
        same as a coverage of zero and must not be scored as one."""
        assert score_coverage(_facts({}, [])) is None


class TestConsistency:
    def test_a_short_pause_is_free(self):
        """Two silent working days is a normal week, not a finding."""
        days = _weekdays_back(10)
        commits = dict.fromkeys(days, 1)
        del commits[days[3]]
        del commits[days[4]]

        assert score_consistency(_facts(commits, days)) == 100.0

    def test_a_long_silence_is_penalised(self):
        days = _weekdays_back(20)
        # Committed only on the most recent day; everything before is silence.
        commits = {days[0]: 1}

        assert score_consistency(_facts(commits, days)) < 50.0

    def test_a_burst_scores_below_steady_work_at_equal_volume(self):
        """The whole reason regularity is measured separately from volume."""
        days = _weekdays_back(20)
        steady = dict.fromkeys(days, 1)
        burst = {days[0]: 20}

        assert sum(steady.values()) == sum(burst.values())
        assert score_consistency(_facts(burst, days)) < score_consistency(
            _facts(steady, days)
        )

    def test_it_abstains_when_nothing_was_expected(self):
        assert score_consistency(_facts({}, [])) is None


class TestComposite:
    def test_weights_are_renormalised_over_applicable_components(self):
        """A brand-new joiner is ranked on volume alone rather than being buried
        by two components that do not apply to them."""
        day = timezone.localdate()
        composite, parts = score(_facts({day: 5}, []))

        assert parts["coverage"] is None
        assert parts["consistency"] is None
        assert composite == pytest.approx(score_volume(_facts({day: 5}, [])), abs=0.1)

    def test_every_component_is_reported_even_when_it_abstains(self):
        _composite, parts = score(_facts({}, []))

        assert set(parts) == {c.key for c in COMPONENTS}

    def test_a_perfect_month_approaches_but_does_not_reach_the_top(self):
        """Volume saturates, so nobody ever scores 100. There is always somewhere
        further to go, and no reason to grind for a round number."""
        days = _weekdays_back(22)
        composite, _parts = score(_facts(dict.fromkeys(days, 3), days))

        assert 0 < composite < 100

    def test_doing_nothing_scores_zero(self):
        days = _weekdays_back(22)
        composite, _parts = score(_facts({}, days))

        assert composite == 0.0


class TestRanking:
    def test_steady_work_outranks_an_equal_sized_burst(self, project, repo):
        steady = _person("Steady Sam", "sam@company.com")
        bursty = _person("Bursty Bea", "bea@company.com")

        for i, day in enumerate(_weekdays_back(15)):
            _commit(repo, steady, day, f"a{i:039d}")
        burst_day = _weekdays_back(1)[0]
        for i in range(15):
            _commit(repo, bursty, burst_day, f"b{i:039d}")

        data = build_leaderboard(days=30)

        assert _row(data, steady)["score"] > _row(data, bursty)["score"]
        assert _row(data, steady)["rank"] < _row(data, bursty)["rank"]

    def test_everyone_on_the_roster_appears(self, project, repo):
        """Including people with nothing — a leaderboard that hides the bottom
        is not reporting, it is flattering."""
        _person("Quiet Quinn", "quinn@company.com")
        busy = _person("Busy Bo", "bo@company.com")
        for i, day in enumerate(_weekdays_back(5)):
            _commit(repo, busy, day, f"c{i:039d}")

        data = build_leaderboard(days=30)

        assert len(data["rows"]) == 2
        assert data["rows"][-1]["full_name"] == "Quiet Quinn"
        assert data["rows"][-1]["score"] == 0.0

    def test_ties_share_a_rank(self, project, repo):
        first = _person("Ada One", "ada@company.com")
        second = _person("Bea Two", "bea2@company.com")
        for person, prefix in ((first, "d"), (second, "e")):
            for i, day in enumerate(_weekdays_back(5)):
                _commit(repo, person, day, f"{prefix}{i:039d}")

        data = build_leaderboard(days=30)

        assert [r["rank"] for r in data["rows"]] == [1, 1]

    def test_inactive_people_are_excluded(self, employee, project, repo):
        employee.is_active = False
        employee.save()

        assert build_leaderboard(days=30)["rows"] == []

    def test_commits_outside_the_window_do_not_count(self, employee, project, repo):
        _commit(repo, employee, timezone.localdate() - timedelta(days=90), "f" * 40)

        row = _row(build_leaderboard(days=30), employee)

        assert row["commits"] == 0
        assert row["score"] == 0.0

    def test_days_before_joining_are_not_held_against_anyone(
        self, employee, project, repo
    ):
        """Employment dates bound the expected days, so a new joiner is not
        scored against a month they were not there for."""
        employee.joined_on = timezone.localdate() - timedelta(days=2)
        employee.save()

        row = _row(build_leaderboard(days=30), employee)

        assert row["expected_days"] <= 3


class TestWindow:
    def test_the_window_is_rolling_and_ends_today(self):
        data = build_leaderboard(days=30)

        assert data["window"]["end"] == timezone.localdate().isoformat()
        assert data["window"]["start"] == (
            timezone.localdate() - timedelta(days=29)
        ).isoformat()

    def test_the_window_length_is_configurable(self):
        assert build_leaderboard(days=7)["window"]["days"] == 7


class TestEndpoint:
    def test_it_ranks_and_explains_itself(self, api_client, employee, project, repo):
        for i, day in enumerate(_weekdays_back(4)):
            _commit(repo, employee, day, f"g{i:039d}")

        response = api_client.get("/api/scoring/leaderboard")

        assert response.status_code == 200
        assert response.data["window"]["days"] == 30
        assert response.data["rows"][0]["rank"] == 1
        assert response.data["rows"][0]["commits"] == 4
        # The page must be able to explain the number without restating the
        # formula in TypeScript.
        assert {c["key"] for c in response.data["components"]} == {
            c.key for c in COMPONENTS
        }

    def test_the_window_is_clamped(self, api_client, employee):
        assert api_client.get("/api/scoring/leaderboard?days=9000").data["window"][
            "days"
        ] == 366
        assert api_client.get("/api/scoring/leaderboard?days=1").data["window"][
            "days"
        ] == 7

    def test_a_junk_window_falls_back_to_thirty(self, api_client, employee):
        response = api_client.get("/api/scoring/leaderboard?days=lots")

        assert response.data["window"]["days"] == 30
