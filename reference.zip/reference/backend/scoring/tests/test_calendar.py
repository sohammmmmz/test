"""What counts as a missed commit day.

The value of this screen rests entirely on not crying wolf. A weekend, a day
before someone joined, or a day they held no assignment must not be flagged —
otherwise the genuine gaps are lost in the noise and the whole view gets
ignored. These tests pin each exclusion.
"""

from datetime import date, timedelta

import pytest
from django.utils import timezone

from activity.models import Commit
from scoring.calendar import build_calendar
from team.models import Assignment, Employee

pytestmark = pytest.mark.django_db


def _monday(weeks_ago: int = 0) -> date:
    """A recent Monday, so weekday-sensitive assertions are stable."""
    today = timezone.localdate()
    return today - timedelta(days=today.weekday() + 7 * weeks_ago)


def _commit(repo, employee, day: date, sha: str):
    return Commit.objects.create(
        repo=repo,
        sha=sha,
        short_id=sha[:8],
        title="work",
        author_email=employee.official_email,
        author_employee=employee,
        authored_date=timezone.make_aware(
            timezone.datetime(day.year, day.month, day.day, 12, 0)
        ),
    )


def _cells(result, employee_id):
    row = next(r for r in result["rows"] if r["employee_id"] == employee_id)
    return row, {c["date"]: c for c in row["cells"]}


@pytest.fixture
def assigned(employee, project):
    Assignment.objects.create(
        employee=employee,
        project=project,
        allocation_percent=100,
        started_on=timezone.localdate() - timedelta(days=365),
    )
    employee.joined_on = timezone.localdate() - timedelta(days=365)
    employee.save()
    return employee


class TestDayStates:
    def test_a_day_with_commits_is_active(self, assigned, repo):
        monday = _monday(1)
        _commit(repo, assigned, monday, "a" * 40)

        _row, cells = _cells(build_calendar(days=30), assigned.id)

        assert cells[monday.isoformat()]["state"] == "active"
        assert cells[monday.isoformat()]["commits"] == 1

    def test_a_working_day_without_commits_is_missed(self, assigned, repo):
        tuesday = _monday(1) + timedelta(days=1)

        _row, cells = _cells(build_calendar(days=30), assigned.id)

        assert cells[tuesday.isoformat()]["state"] == "missed"

    def test_a_weekend_is_off_not_missed(self, assigned, repo):
        saturday = _monday(1) + timedelta(days=5)

        _row, cells = _cells(build_calendar(days=30), assigned.id)

        assert cells[saturday.isoformat()]["state"] == "off", (
            "flagging weekends would drown the real gaps"
        )

    def test_a_configured_holiday_is_off(self, assigned, repo, settings):
        holiday = _monday(1) + timedelta(days=2)
        settings.NON_WORKING_DATES = [holiday.isoformat()]

        result = build_calendar(days=30)
        _row, cells = _cells(result, assigned.id)

        assert cells[holiday.isoformat()]["state"] == "off"
        assert holiday.isoformat() in result["holidays"]

    def test_a_malformed_holiday_is_skipped_rather_than_raising(
        self, assigned, repo, settings
    ):
        settings.NON_WORKING_DATES = ["not-a-date", ""]

        assert build_calendar(days=14)["holidays"] == []

    def test_working_weekdays_are_configurable(self, assigned, repo, settings):
        settings.WORKING_WEEKDAYS = [0, 1, 2, 3, 4, 5]
        saturday = _monday(1) + timedelta(days=5)

        _row, cells = _cells(build_calendar(days=30), assigned.id)

        assert cells[saturday.isoformat()]["state"] == "missed"


class TestExclusions:
    def test_days_before_joining_are_outside_not_missed(self, assigned, repo):
        assigned.joined_on = timezone.localdate() - timedelta(days=3)
        assigned.save()

        _row, cells = _cells(build_calendar(days=30), assigned.id)
        older = (timezone.localdate() - timedelta(days=20)).isoformat()

        assert cells[older]["state"] == "outside"

    def test_days_after_leaving_are_outside(self, assigned, repo):
        assigned.left_on = timezone.localdate() - timedelta(days=10)
        assigned.save()

        _row, cells = _cells(build_calendar(days=30), assigned.id)
        recent = (timezone.localdate() - timedelta(days=1)).isoformat()

        assert cells[recent]["state"] == "outside"

    def test_someone_with_no_assignment_is_never_marked_missed(self, employee, repo):
        """Unassigned is a planning gap, not an attendance one."""
        row, _cells_by_date = _cells(build_calendar(days=30), employee.id)

        assert row["missed_days"] == 0
        assert row["expected_days"] == 0
        assert row["coverage_percent"] is None, "no expectation means no percentage"

    def test_expectation_starts_at_the_assignment_not_the_window(
        self, employee, project, repo
    ):
        started = timezone.localdate() - timedelta(days=5)
        Assignment.objects.create(
            employee=employee, project=project, allocation_percent=50, started_on=started
        )

        _row, cells = _cells(build_calendar(days=30), employee.id)
        before = (started - timedelta(days=3)).isoformat()

        assert cells[before]["state"] == "outside"


class TestIndirectContribution:
    def test_review_activity_without_commits_is_not_a_miss(
        self, assigned, repo, project
    ):
        """A day spent reviewing is not a day of no work — the rest of the
        system already refuses to score it as zero."""
        from activity.models import MergeRequest, ReviewNote

        day = _monday(1) + timedelta(days=1)
        merge_request = MergeRequest.objects.create(
            repo=repo, iid=1, title="mr", source_branch="f", target_branch="main"
        )
        ReviewNote.objects.create(
            merge_request=merge_request,
            gitlab_note_id=1,
            author_employee=assigned,
            body="looks good",
            noted_at=timezone.make_aware(
                timezone.datetime(day.year, day.month, day.day, 10, 0)
            ),
        )

        row, cells = _cells(build_calendar(days=30), assigned.id)

        assert cells[day.isoformat()]["state"] == "indirect"
        assert row["indirect_days"] >= 1


class TestSummaries:
    def test_streaks_treat_weekends_as_transparent(self, assigned, repo):
        """Committing every weekday is an unbroken streak, not a two-day one."""
        monday = _monday(1)
        for offset in range(5):
            _commit(repo, assigned, monday + timedelta(days=offset), f"{offset:040d}")

        row, _cells_by_date = _cells(build_calendar(days=30), assigned.id)

        assert row["longest_streak"] >= 5

    def test_coverage_counts_only_expected_days(self, assigned, repo):
        monday = _monday(1)
        for offset in range(5):
            _commit(repo, assigned, monday + timedelta(days=offset), f"{offset:040d}")

        row, _cells_by_date = _cells(build_calendar(days=7), assigned.id)

        assert row["expected_days"] <= 5, "weekends must not inflate the denominator"

    def test_last_commit_is_reported_with_its_age(self, assigned, repo):
        day = timezone.localdate() - timedelta(days=4)
        _commit(repo, assigned, day, "b" * 40)

        row, _cells_by_date = _cells(build_calendar(days=30), assigned.id)

        assert row["last_commit_on"] == day.isoformat()
        assert row["days_since_last_commit"] == 4

    def test_worst_coverage_sorts_first(self, assigned, repo, project):
        """The gaps are the point of the screen, so they lead."""
        busy = Employee.objects.create(
            official_email="dev@company.com", full_name="Busy Dev"
        )
        Assignment.objects.create(
            employee=busy,
            project=project,
            started_on=timezone.localdate() - timedelta(days=365),
        )
        for offset in range(14):
            _commit(repo, busy, timezone.localdate() - timedelta(days=offset), f"{offset:040d}")

        rows = build_calendar(days=14)["rows"]

        assert rows[0]["employee_id"] == assigned.id
        assert rows[-1]["employee_id"] == busy.id


class TestProjectScope:
    def test_scoping_to_a_project_excludes_people_not_on_it(
        self, assigned, project, repo
    ):
        from projects.models import Project

        other = Project.objects.create(name="Zephyr", slug="zephyr")

        ids = [r["employee_id"] for r in build_calendar(days=14, project_id=other.id)["rows"]]

        assert assigned.id not in ids, (
            "someone not on the project is not absent from it"
        )


class TestEndpoint:
    def test_the_endpoint_returns_a_calendar(self, api_client, assigned, repo):
        response = api_client.get("/api/scoring/commit-calendar?days=30")

        assert response.status_code == 200
        body = response.json()
        assert body["days"] == 30
        assert len(body["rows"][0]["cells"]) == 30

    def test_the_window_is_clamped(self, api_client, assigned):
        """One cell per person per day: an unbounded window is a cheap way to
        ask for a very expensive response."""
        assert api_client.get("/api/scoring/commit-calendar?days=99999").json()["days"] == 366
        assert api_client.get("/api/scoring/commit-calendar?days=1").json()["days"] == 7
        assert api_client.get("/api/scoring/commit-calendar?days=abc").status_code == 200


class TestMembershipCountsAsBeingOnAProject:
    """The reported bug: people who belong to repositories read as "unassigned".

    Repository membership is synced from GitLab; assignments are typed by hand
    and nothing outside the demo seeder had ever written one. Reading only the
    planning table left everybody's project list empty on this screen, and left
    every one of their days ``outside`` so no coverage figure existed either.
    """

    def test_membership_projects_are_listed(self, employee, project, repo):
        from activity.models import ProjectMember

        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )

        row, _cells_by_date = _cells(build_calendar(days=30), employee.id)

        assert row["projects"] == [project.name]
        assert row["unplanned_projects"] == [project.name]

    def test_membership_creates_an_expectation(self, employee, project, repo):
        from activity.models import ProjectMember

        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )

        row, _cells_by_date = _cells(build_calendar(days=30), employee.id)

        assert row["expected_days"] > 0
        assert row["coverage_percent"] is not None

    def test_an_assignment_is_not_reported_as_unplanned(
        self, assigned, project, repo
    ):
        from activity.models import ProjectMember

        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=assigned
        )

        row, _cells_by_date = _cells(build_calendar(days=30), assigned.id)

        assert row["projects"] == [project.name]
        assert row["unplanned_projects"] == []

    def test_membership_does_not_backdate_before_joining(
        self, employee, project, repo
    ):
        """GitLab never says when membership was granted, so it runs from the
        joining date — but not before it."""
        from activity.models import ProjectMember

        employee.joined_on = timezone.localdate() - timedelta(days=5)
        employee.save()
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )

        _row, cells = _cells(build_calendar(days=30), employee.id)
        before = (timezone.localdate() - timedelta(days=20)).isoformat()

        assert cells[before]["state"] == "outside"

    def test_on_nothing_at_all_is_still_never_marked_missed(self, employee, repo):
        """No assignment and no membership: still a planning gap, not an
        attendance one."""
        row, _cells_by_date = _cells(build_calendar(days=30), employee.id)

        assert row["projects"] == []
        assert row["missed_days"] == 0
        assert row["coverage_percent"] is None
