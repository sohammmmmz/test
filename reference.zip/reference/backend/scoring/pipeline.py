"""Scoring orchestration and rollups."""

from __future__ import annotations

import logging
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.db.models import Count, Max, Q
from django.utils import timezone

from activity.models import Commit, MergeRequest, ReviewNote
from projects.models import DocumentKind, Project
from team.models import Employee, active_assignments_q
from vault.models import NodeType, VaultNode

from .diffs import fetch_commit_diff
from .gemini import get_scorer
from .models import (
    ChangeKind,
    CommitScore,
    DailyScore,
    ScoreStatus,
    ScoringConfig,
    UtilizationSnapshot,
)
from .prompts import build_prompt, prompt_hash
from .signals import (
    assigned_issues_for,
    composite_score,
    compute_linkage,
    compute_quality,
    match_issues,
)

logger = logging.getLogger(__name__)


def _weights() -> dict:
    config = ScoringConfig.current()
    return config.weights if config else dict(settings.SCORING_DEFAULT_WEIGHTS)


def _min_confidence() -> float:
    config = ScoringConfig.current()
    return config.min_confidence if config else settings.SCORING_MIN_CONFIDENCE


def enqueue_unscored_commits(project: Project, *, sync_run=None, limit: int = 500) -> int:
    """Create pending score rows for commits that do not have one yet.

    Merge commits are marked skipped rather than scored: they are bookkeeping,
    and scoring them would credit whoever pressed the merge button with the
    contents of someone else's branch.
    """
    repo = getattr(project, "repo", None)
    if repo is None:
        return 0

    unscored = (
        Commit.objects.filter(repo=repo, score__isnull=True)
        .order_by("-authored_date")[:limit]
    )

    rows = [
        CommitScore(
            commit=commit,
            project=project,
            employee=commit.author_employee,
            status=ScoreStatus.SKIPPED if commit.is_merge_commit else ScoreStatus.PENDING,
            diff_hash=commit.diff_hash or "",
            deterministic_signals=(
                {"reason": "merge commit"} if commit.is_merge_commit else {}
            ),
        )
        for commit in unscored
    ]
    CommitScore.objects.bulk_create(rows, ignore_conflicts=True)
    return len(rows)


def _vault_context(project: Project, changed_paths: list[str], limit: int = 3) -> list[str]:
    """Module notes covering the paths a commit touched.

    This is why the vault being markdown pays off twice: the same files a human
    browses in Obsidian are the ideal serialisation of project state to hand a
    model.
    """
    if not changed_paths:
        return []

    prefixes = {"/".join(p.split("/")[:2]) for p in changed_paths if p}
    query = Q()
    for prefix in prefixes:
        query |= Q(title__istartswith=prefix.split("/")[0])

    nodes = VaultNode.objects.filter(
        project=project, node_type=NodeType.MODULE, is_current=True
    ).filter(query)[:limit]

    return [f"### {n.title}\n{n.body[:1200]}" for n in nodes]


def _brd_summary(project: Project) -> str:
    document = project.documents.filter(kind=DocumentKind.BRD).first()
    return document.summary if document else ""


@transaction.atomic
def _apply_result(score: CommitScore, parsed: dict, response, quality, quality_evidence,
                  linkage, linkage_evidence, matched_iids, prompt_digest) -> CommitScore:
    weights = _weights()
    parts = {
        "relevance": parsed.get("relevance"),
        "substance": parsed.get("substance"),
        "quality": quality,
        "linkage": linkage,
    }

    score.relevance = parsed.get("relevance")
    score.substance = parsed.get("substance")
    score.change_kind = (
        parsed.get("change_kind")
        if parsed.get("change_kind") in ChangeKind.values
        else ChangeKind.UNKNOWN
    )
    score.quality = quality
    score.linkage = linkage
    score.deterministic_signals = {**quality_evidence, **linkage_evidence}
    score.composite = composite_score(parts, weights)
    score.weights_used = weights
    score.confidence = parsed.get("confidence")
    score.rationale = parsed.get("rationale", "")
    score.matched_issue_iids = parsed.get("matched_issue_iids") or matched_iids
    score.model_version = response.model_version
    score.prompt_hash = prompt_digest
    score.input_tokens = response.input_tokens
    score.output_tokens = response.output_tokens
    score.scored_at = timezone.now()
    score.error_message = ""

    confidence = parsed.get("confidence")
    if confidence is None or confidence < _min_confidence():
        # An uncertain judgment about someone's work belongs in a review queue,
        # not in their rollup.
        score.status = ScoreStatus.NEEDS_REVIEW
    else:
        score.status = ScoreStatus.SCORED

    score.save()
    return score


def score_commit(score: CommitScore, *, client=None, scorer=None) -> CommitScore:
    """Score one commit: fetch the diff, compute signals, ask the model."""
    from gitlab_integration.client import GitLabClient

    commit = score.commit
    client = client or GitLabClient.for_service()
    scorer = scorer or get_scorer()

    try:
        diff_payload = fetch_commit_diff(commit, client)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Diff fetch failed for %s: %s", commit.sha[:8], exc)
        score.status = ScoreStatus.FAILED
        score.error_message = f"Diff fetch failed: {exc}"
        score.save(update_fields=["status", "error_message", "updated_at"])
        return score

    # A commit whose every file is generated or vendored has nothing to judge.
    if not diff_payload.get("text"):
        score.status = ScoreStatus.SKIPPED
        score.deterministic_signals = {
            "reason": "no reviewable content",
            "ignored_paths": diff_payload.get("ignored_paths", [])[:20],
        }
        score.diff_hash = diff_payload.get("diff_hash", "")
        score.save()
        return score

    referenced = match_issues(commit)
    assigned = assigned_issues_for(commit)
    quality, quality_evidence = compute_quality(commit, diff_payload, referenced)
    linkage, linkage_evidence = compute_linkage(commit, referenced)

    prompt = build_prompt(
        commit=commit,
        project=score.project,
        diff_payload=diff_payload,
        assigned_issues=assigned,
        referenced_issues=referenced,
        brd_summary=_brd_summary(score.project),
        vault_context=_vault_context(score.project, diff_payload.get("changed_paths", [])),
    )
    digest = prompt_hash(prompt, scorer.model if hasattr(scorer, "model") else "")

    response = scorer.score_one(prompt)
    if not response.ok:
        score.status = ScoreStatus.FAILED
        score.error_message = response.error
        score.diff_hash = diff_payload.get("diff_hash", "")
        score.prompt_hash = digest
        score.save()
        return score

    score.diff_hash = diff_payload.get("diff_hash", "")
    return _apply_result(
        score, response.parsed, response, quality, quality_evidence,
        linkage, linkage_evidence, [i.iid for i in referenced], digest,
    )


def score_pending(*, project: Project | None = None, limit: int | None = None) -> dict:
    """Score queued commits, skipping anything already scored for the same diff.

    The ``diff_hash`` cache is what keeps a nightly run cheap: an amended or
    cherry-picked commit with identical content reuses the existing judgment
    rather than paying for it again.
    """
    from gitlab_integration.client import GitLabClient

    limit = limit or settings.GEMINI_BATCH_SIZE
    queryset = CommitScore.objects.filter(status=ScoreStatus.PENDING).select_related(
        "commit", "commit__repo", "project", "employee"
    )
    if project:
        queryset = queryset.filter(project=project)

    pending = list(queryset.order_by("-commit__authored_date")[:limit])
    if not pending:
        return {"scored": 0, "cached": 0, "failed": 0, "needs_review": 0, "skipped": 0}

    client = GitLabClient.for_service()
    scorer = get_scorer()
    counts = {"scored": 0, "cached": 0, "failed": 0, "needs_review": 0, "skipped": 0}

    for score in pending:
        cached = _cached_score_for(score)
        if cached is not None:
            _copy_from_cache(score, cached)
            counts["cached"] += 1
            continue

        result = score_commit(score, client=client, scorer=scorer)
        if result.status == ScoreStatus.SCORED:
            counts["scored"] += 1
        elif result.status == ScoreStatus.NEEDS_REVIEW:
            counts["needs_review"] += 1
        elif result.status == ScoreStatus.SKIPPED:
            counts["skipped"] += 1
        else:
            counts["failed"] += 1

    return counts


def _cached_score_for(score: CommitScore) -> CommitScore | None:
    if not score.commit.diff_hash:
        return None
    return (
        CommitScore.objects.filter(
            diff_hash=score.commit.diff_hash,
            status__in=[ScoreStatus.SCORED, ScoreStatus.NEEDS_REVIEW],
        )
        .exclude(pk=score.pk)
        .order_by("-scored_at")
        .first()
    )


def _copy_from_cache(score: CommitScore, cached: CommitScore) -> None:
    score.relevance = cached.relevance
    score.substance = cached.substance
    score.change_kind = cached.change_kind
    score.quality = cached.quality
    score.linkage = cached.linkage
    score.deterministic_signals = {**cached.deterministic_signals, "from_cache": True}
    score.composite = cached.composite
    score.weights_used = cached.weights_used
    score.confidence = cached.confidence
    score.rationale = cached.rationale
    score.matched_issue_iids = cached.matched_issue_iids
    score.model_version = cached.model_version
    score.prompt_hash = cached.prompt_hash
    score.diff_hash = cached.diff_hash
    score.scored_at = timezone.now()
    score.status = cached.status
    score.save()


# ---------------------------------------------------------------------------
# Rollups
# ---------------------------------------------------------------------------


def rollup_daily_scores(project: Project, *, days: int = 30) -> int:
    """Aggregate commit scores into per-person, per-day rows.

    Days on which someone contributed without committing — review, pairing,
    debugging — are recorded with ``had_no_commits`` rather than a zero, so the
    trend does not misread a week of unblocking colleagues as idleness.
    """
    start = timezone.localdate() - timedelta(days=days)
    repo = getattr(project, "repo", None)
    if repo is None:
        return 0

    written = 0
    scores = (
        CommitScore.objects.filter(
            project=project,
            employee__isnull=False,
            commit__authored_date__date__gte=start,
        )
        .select_related("commit", "employee")
    )

    buckets: dict[tuple[int, object], list[CommitScore]] = {}
    for score in scores:
        key = (score.employee_id, timezone.localtime(score.commit.authored_date).date())
        buckets.setdefault(key, []).append(score)

    # Contribution that leaves no commits behind, so it is not read as absence.
    note_counts = (
        ReviewNote.objects.filter(
            merge_request__repo=repo, author_employee__isnull=False, noted_at__date__gte=start
        )
        .values("author_employee_id", "noted_at__date")
        .annotate(n=Count("id"))
    )
    notes_by_key = {
        (row["author_employee_id"], row["noted_at__date"]): row["n"] for row in note_counts
    }

    mr_opened = (
        MergeRequest.objects.filter(
            repo=repo, author_employee__isnull=False, gitlab_created_at__date__gte=start
        )
        .values("author_employee_id", "gitlab_created_at__date")
        .annotate(n=Count("id"))
    )
    opened_by_key = {
        (r["author_employee_id"], r["gitlab_created_at__date"]): r["n"] for r in mr_opened
    }

    mr_merged = (
        MergeRequest.objects.filter(
            repo=repo, author_employee__isnull=False, merged_at__date__gte=start
        )
        .values("author_employee_id", "merged_at__date")
        .annotate(n=Count("id"))
    )
    merged_by_key = {
        (r["author_employee_id"], r["merged_at__date"]): r["n"] for r in mr_merged
    }

    for key in set(buckets) | set(notes_by_key) | set(opened_by_key) | set(merged_by_key):
        employee_id, day = key
        group = buckets.get(key, [])
        rated = [
            s for s in group
            if s.effective_composite is not None and s.status == ScoreStatus.SCORED
        ]

        DailyScore.objects.update_or_create(
            employee_id=employee_id,
            project=project,
            date=day,
            defaults={
                "commit_count": len(group),
                "scored_commit_count": len(rated),
                "composite": (
                    round(sum(s.effective_composite for s in rated) / len(rated), 2)
                    if rated else None
                ),
                "mean_relevance": _mean([s.relevance for s in rated]),
                "mean_substance": _mean([s.substance for s in rated]),
                "review_note_count": notes_by_key.get(key, 0),
                "merge_requests_opened": opened_by_key.get(key, 0),
                "merge_requests_merged": merged_by_key.get(key, 0),
                "had_no_commits": len(group) == 0,
                "signals": {
                    "needs_review": sum(
                        1 for s in group if s.status == ScoreStatus.NEEDS_REVIEW
                    ),
                    "overridden": sum(1 for s in group if s.is_overridden),
                },
            },
        )
        written += 1

    return written


def _mean(values):
    present = [v for v in values if v is not None]
    return round(sum(present) / len(present), 2) if present else None


def compute_utilization(*, period_days: int = 14) -> int:
    """Snapshot planned allocation against observed engagement.

    The gap is the output that matters: an assignment with no activity behind it
    is either a person who is blocked, a plan that changed without anyone
    updating it, or work happening somewhere this tool cannot see.
    """
    end = timezone.localdate()
    start = end - timedelta(days=period_days)
    written = 0

    for employee in Employee.objects.filter(is_active=True).prefetch_related("assignments"):
        assignments = list(
            employee.assignments.filter(active_assignments_q()).select_related("project")
        )
        planned = sum(a.allocation_percent for a in assignments)

        daily = DailyScore.objects.filter(
            employee=employee, date__gte=start, date__lte=end
        ).select_related("project")

        engaged_projects = {d.project_id for d in daily if d.commit_count or d.review_note_count}
        active_days = len({d.date for d in daily if d.commit_count or d.review_note_count})
        total_commits = sum(d.commit_count for d in daily)
        scored = [d.composite for d in daily if d.composite is not None]

        dormant = [
            {
                "project": a.project.name,
                "project_id": a.project_id,
                "allocation_percent": a.allocation_percent,
                "last_activity": _last_activity_iso(employee, a.project_id),
            }
            for a in assignments
            if a.project_id not in engaged_projects
        ]

        UtilizationSnapshot.objects.update_or_create(
            employee=employee,
            period_start=start,
            period_end=end,
            defaults={
                "planned_allocation_percent": planned,
                "active_project_count": len(assignments),
                "engaged_project_count": len(engaged_projects),
                "active_days": active_days,
                "total_commits": total_commits,
                "mean_daily_score": (
                    round(sum(scored) / len(scored), 2) if scored else None
                ),
                "dormant_assignments": dormant,
                "is_overallocated": planned > 100,
            },
        )
        written += 1

    return written


def _last_activity_iso(employee: Employee, project_id: int) -> str | None:
    latest = Commit.objects.filter(
        author_employee=employee, repo__project_id=project_id
    ).aggregate(latest=Max("authored_date"))["latest"]
    return latest.isoformat() if latest else None
