"""Deterministic scoring signals.

These are computed from data already synced: no model call, no cost, nothing
that can be hallucinated, and every number traceable to a fact. They carry the
``quality`` and ``linkage`` components of the composite outright, and they are
what makes a score arguable in a conversation rather than an opaque verdict.

The LLM is reserved for the two judgments that genuinely require reading the
code: whether a change advances the assigned task, and how substantial it is.
"""

from __future__ import annotations

import re

from activity.models import Commit, Issue, MergeRequest

TEST_PATH_RE = re.compile(
    r"(^|/)(tests?|spec|__tests__|e2e)(/|$)|"
    r"(^|/)test_[^/]+\.[a-z]+$|"
    r"[._-](test|spec)\.[a-z]+$",
    re.IGNORECASE,
)

# Conventional Commits, e.g. "feat(auth): add login endpoint".
CONVENTIONAL_RE = re.compile(
    r"^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\([^)]+\))?!?:\s+.+",
    re.IGNORECASE,
)

# Messages that say nothing. Common, and worth distinguishing from real ones.
LOW_EFFORT_MESSAGES = {
    "wip", "fix", "fixes", "fixed", "update", "updates", "updated", "changes",
    "test", "tests", "temp", "tmp", "asdf", "commit", "minor", "misc", ".",
    "final", "done", "stuff", "cleanup", "typo",
}


def touches_tests(paths: list[str]) -> bool:
    return any(TEST_PATH_RE.search(p or "") for p in paths or [])


def is_low_effort_message(message: str) -> bool:
    text = (message or "").strip()
    first = text.splitlines()[0] if text else ""
    normalized = first.strip().strip(".").lower()
    # An empty subject (or one that was nothing but punctuation) says nothing.
    return not normalized or normalized in LOW_EFFORT_MESSAGES


def compute_linkage(commit: Commit, matched_issues: list[Issue]) -> tuple[float, dict]:
    """How well the commit ties itself to declared work.

    A commit that names its issue is self-documenting and traceable, which is
    the entire point of this system. It is also the cheapest signal available.
    """
    refs = commit.referenced_issue_iids or []
    evidence = {
        "references_issue": bool(refs),
        "referenced_iids": refs,
        "matched_issue_iids": [i.iid for i in matched_issues],
        "matched_assigned_issue": False,
        "on_merge_request": False,
    }

    score = 0.0
    if refs:
        score += 40
    if matched_issues:
        score += 25

    # Strongest form: the referenced issue is actually assigned to the author.
    if commit.author_employee_id and any(
        commit.author_employee_id in {a.pk for a in issue.assignees.all()}
        for issue in matched_issues
    ):
        evidence["matched_assigned_issue"] = True
        score += 25

    if MergeRequest.objects.filter(
        repo_id=commit.repo_id, source_branch__in=commit.branch_names or []
    ).exists():
        evidence["on_merge_request"] = True
        score += 10

    return min(score, 100.0), evidence


def compute_quality(
    commit: Commit, diff_payload: dict, matched_issues: list[Issue]
) -> tuple[float, dict]:
    """Practices that make a change safe to ship.

    Starts from a neutral baseline rather than zero: a change is not low quality
    merely because there was nothing to test.
    """
    paths = diff_payload.get("changed_paths") or commit.changed_paths or []
    tests = touches_tests(paths)
    conventional = bool(CONVENTIONAL_RE.match((commit.message or "").strip()))
    low_effort = is_low_effort_message(commit.message)
    descriptive = len((commit.title or "").strip()) >= 15

    merged = MergeRequest.objects.filter(
        repo_id=commit.repo_id,
        source_branch__in=commit.branch_names or [],
        state="merged",
    ).first()

    evidence = {
        "touches_tests": tests,
        "conventional_commit": conventional,
        "low_effort_message": low_effort,
        "descriptive_title": descriptive,
        "merged_via_mr": bool(merged),
        "mr_iid": merged.iid if merged else None,
        "ci_passed": merged.has_pipeline_success if merged else None,
        "review_comments": merged.user_notes_count if merged else 0,
        "is_merge_commit": commit.is_merge_commit,
        "files_changed": len(paths),
    }

    score = 50.0
    if tests:
        score += 20
    if conventional:
        score += 8
    if descriptive:
        score += 7
    if merged:
        score += 10
        if merged.user_notes_count:
            score += 5
        if merged.has_pipeline_success:
            score += 5
    if low_effort:
        score -= 20
    if commit.is_merge_commit:
        # Merge commits are bookkeeping, not authored work.
        score -= 15

    return max(0.0, min(score, 100.0)), evidence


def match_issues(commit: Commit) -> list[Issue]:
    """Issues this commit refers to, resolved against the repo."""
    refs = commit.referenced_issue_iids or []
    if not refs:
        return []
    return list(
        Issue.objects.filter(repo_id=commit.repo_id, iid__in=refs)
        .select_related("milestone")
        .prefetch_related("assignees")
    )


def assigned_issues_for(commit: Commit, limit: int = 8) -> list[Issue]:
    """Open issues assigned to the commit's author.

    Supplies the model with what the person was *supposed* to be working on
    when the commit references no issue at all, which is the common case.
    """
    if not commit.author_employee_id:
        return []
    return list(
        Issue.objects.filter(
            repo_id=commit.repo_id,
            assignees__id=commit.author_employee_id,
            state="opened",
        )
        .select_related("milestone")
        .prefetch_related("assignees")
        .order_by("-gitlab_updated_at")[:limit]
    )


def composite_score(parts: dict, weights: dict) -> float:
    """Weighted mean over whichever components are present.

    Renormalises across available components so a commit the model abstained on
    is not silently penalised for a missing relevance score.
    """
    available = {k: v for k, v in parts.items() if v is not None and k in weights}
    if not available:
        return 0.0
    total_weight = sum(weights[k] for k in available)
    if total_weight <= 0:
        return 0.0
    return round(sum(available[k] * weights[k] for k in available) / total_weight, 2)
