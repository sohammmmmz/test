"""Fetching and trimming commit diffs for scoring.

A one-million-token context window does not make it sensible to send a
5,000-file refactor to a model. Diffs are therefore reduced before they leave
the building: generated and vendored paths are dropped entirely, each remaining
file is truncated to a leading slice with its hunk headers intact, and the whole
payload is capped. What survives is enough for a model to judge what a change is
doing without paying for a lockfile.
"""

from __future__ import annotations

import fnmatch
import hashlib
import logging

from django.conf import settings
from django.utils import timezone

from activity.models import Commit

logger = logging.getLogger(__name__)


def is_ignored(path: str) -> bool:
    """True for generated, vendored or binary paths that add tokens, not signal."""
    if not path:
        return True
    normalized = path if path.startswith("/") else f"/{path}"
    return any(
        fnmatch.fnmatch(path, pattern) or fnmatch.fnmatch(normalized, pattern)
        for pattern in settings.SCORING_IGNORE_PATTERNS
    )


def truncate_file_diff(diff_text: str, max_lines: int) -> tuple[str, bool]:
    """Keep the first ``max_lines`` lines, preserving hunk headers.

    Hunk headers (``@@ ... @@``) are what tell a reader *where* in the file the
    change is, so they are kept even past the cut-off — a truncated diff with no
    location is far less useful than one with a few extra header lines.
    """
    lines = (diff_text or "").splitlines()
    if len(lines) <= max_lines:
        return diff_text or "", False

    kept = lines[:max_lines]
    remaining_headers = [ln for ln in lines[max_lines:] if ln.startswith("@@")]
    if remaining_headers:
        kept.append(f"... {len(lines) - max_lines} more lines ...")
        kept.extend(remaining_headers[:20])
    else:
        kept.append(f"... {len(lines) - max_lines} more lines ...")

    return "\n".join(kept), True


def build_diff_payload(diffs: list[dict]) -> dict:
    """Reduce a raw GitLab diff response to a trimmed, bounded payload."""
    max_bytes = settings.GEMINI_MAX_DIFF_BYTES
    max_lines = settings.GEMINI_MAX_LINES_PER_FILE

    included: list[str] = []
    all_paths: list[str] = []
    ignored_paths: list[str] = []
    truncated_files = 0
    total = 0
    budget_hit = False

    for entry in diffs:
        path = entry.get("new_path") or entry.get("old_path") or ""
        all_paths.append(path)

        if is_ignored(path):
            ignored_paths.append(path)
            continue

        if entry.get("binary"):
            ignored_paths.append(path)
            continue

        body, was_truncated = truncate_file_diff(entry.get("diff", ""), max_lines)
        truncated_files += int(was_truncated)

        marker = ""
        if entry.get("new_file"):
            marker = " (new file)"
        elif entry.get("deleted_file"):
            marker = " (deleted)"
        elif entry.get("renamed_file"):
            marker = f" (renamed from {entry.get('old_path')})"

        block = f"--- {path}{marker}\n{body}"
        if total + len(block) > max_bytes:
            budget_hit = True
            break

        included.append(block)
        total += len(block)

    return {
        "text": "\n\n".join(included),
        "changed_paths": [p for p in all_paths if p],
        "included_count": len(included),
        "ignored_paths": ignored_paths,
        "truncated_files": truncated_files,
        "budget_exhausted": budget_hit,
        "total_files": len(all_paths),
    }


def diff_hash_for(diffs: list[dict]) -> str:
    """Stable hash over the raw diff — the scoring cache key.

    Hashes the raw response rather than the trimmed payload so that changing a
    truncation setting does not silently invalidate every cached score.
    """
    hasher = hashlib.sha256()
    for entry in sorted(diffs, key=lambda d: (d.get("new_path") or d.get("old_path") or "")):
        hasher.update(((entry.get("new_path") or "") + "\x00").encode())
        hasher.update(((entry.get("diff") or "") + "\x00").encode())
    return hasher.hexdigest()


def fetch_commit_diff(commit: Commit, client) -> dict:
    """Fetch, trim and cache a commit's diff.

    Records ``changed_paths`` and ``diff_hash`` on the commit, which the vault's
    module clustering and the scoring cache both depend on.
    """
    diffs = client.get_commit_diff(commit.repo.gitlab_project_id, commit.sha)
    payload = build_diff_payload(diffs)
    digest = diff_hash_for(diffs)

    Commit.objects.filter(pk=commit.pk).update(
        changed_paths=payload["changed_paths"][:200],
        diff_hash=digest,
        diff_fetched_at=timezone.now(),
    )
    commit.changed_paths = payload["changed_paths"][:200]
    commit.diff_hash = digest

    payload["diff_hash"] = digest
    return payload
