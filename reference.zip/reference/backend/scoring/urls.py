from django.urls import path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("commit-scores", views.CommitScoreViewSet, basename="commit-score")
router.register("config", views.ScoringConfigViewSet, basename="scoring-config")
router.register("utilization", views.UtilizationViewSet, basename="utilization")

urlpatterns = [
    path("dashboard", views.utilization_dashboard, name="utilization-dashboard"),
    path("commit-calendar", views.commit_calendar, name="commit-calendar"),
    path("leaderboard", views.leaderboard, name="leaderboard"),
    path("scorecard/<int:employee_id>", views.employee_scorecard, name="employee-scorecard"),
    path("trigger", views.trigger_scoring, name="trigger-scoring"),
    *router.urls,
]
