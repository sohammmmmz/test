"""Repository membership must count as working on a project.

The bug this pins: ``Assignment`` was never created by any code path outside
the demo seeder, and the team and utilization screens read only that table. So
somebody who was a GitLab member of four repositories — visible as such on the
project screen — showed up as working on nothing.

The fix is a join, not a merge. Membership is observed fact and an assignment
is a plan; collapsing them would make planned equal actual by construction and
leave the utilization screen measuring nothing.
"""

from datetime import timedelta

import pytest
from django.utils import timezone

from activity.models import Commit, ProjectMember
from projects.models import GitLabRepo, Project
from team.models import Assignment
from team.workload import assign_from_memberships, build_workload

pytestmark = pytest.mark.django_db


def _commit(repo, employee, days_ago, sha):
    return Commit.objects.create(
        repo=repo,
        sha=sha,
        author_email=employee.official_email,
        author_employee=employee,
        authored_date=timezone.now() - timedelta(days=days_ago),
    )


def _second_project():
    project = Project.objects.create(name="Zephyr", slug="zephyr")
    repo = GitLabRepo.objects.create(
        project=project,
        gitlab_project_id=777,
        path_with_namespace="acme/zephyr",
        name="zephyr",
        web_url="https://gitlab.example.com/acme/zephyr",
    )
    return project, repo


def _row(data, employee):
    return next(r for r in data["rows"] if r["employee_id"] == employee.id)


class TestMembershipCounts:
    def test_a_repo_member_is_not_reported_as_working_on_nothing(
        self, employee, project, repo
    ):
        """The exact reported bug."""
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", employee=employee
        )

        row = _row(build_workload(days=30), employee)

        assert row["project_count"] == 1
        assert row["projects"][0]["project"] == project.name
        assert row["projects"][0]["sources"] == ["member"]

    def test_membership_without_a_plan_is_flagged_unplanned(
        self, employee, project, repo
    ):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, employee=employee
        )

        row = _row(build_workload(days=30), employee)

        assert row["projects"][0]["is_unplanned"] is True
        assert row["unplanned_count"] == 1
        assert row["projects"][0]["allocation_percent"] is None

    def test_a_project_that_is_both_planned_and_observed_appears_once(
        self, employee, project, repo
    ):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        Assignment.objects.create(
            employee=employee, project=project, allocation_percent=50
        )

        row = _row(build_workload(days=30), employee)

        assert row["project_count"] == 1, "the union must not duplicate"
        assert set(row["projects"][0]["sources"]) == {"assigned", "member"}

    def test_an_assignment_without_repo_access_is_flagged(
        self, employee, project, repo
    ):
        """Planned but no membership: the assignment is stale, or access was
        never granted."""
        Assignment.objects.create(
            employee=employee, project=project, allocation_percent=50
        )

        row = _row(build_workload(days=30), employee)

        assert row["projects"][0]["has_access"] is False


class TestMultipleProjects:
    def test_workload_splits_across_every_project_a_person_touches(
        self, employee, project, repo
    ):
        other_project, other_repo = _second_project()
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        ProjectMember.objects.create(
            repo=other_repo, gitlab_user_id=1001, employee=employee
        )
        for i in range(3):
            _commit(repo, employee, i, f"a{i:039d}")
        _commit(other_repo, employee, 1, "b" * 40)

        row = _row(build_workload(days=30), employee)

        assert row["project_count"] == 2
        assert row["commits"] == 4
        shares = {p["project"]: p["share_percent"] for p in row["projects"]}
        assert shares[project.name] == 75
        assert shares[other_project.name] == 25

    def test_drift_is_the_gap_between_plan_and_observation(
        self, employee, project, repo
    ):
        other_project, other_repo = _second_project()
        # Planned 50/50, but every commit landed on one of them.
        Assignment.objects.create(employee=employee, project=project, allocation_percent=50)
        Assignment.objects.create(
            employee=employee, project=other_project, allocation_percent=50
        )
        for i in range(4):
            _commit(repo, employee, i, f"a{i:039d}")

        row = _row(build_workload(days=30), employee)
        by_name = {p["project"]: p for p in row["projects"]}

        assert by_name[project.name]["drift"] == 50
        assert by_name[other_project.name]["drift"] == -50

    def test_drift_is_none_when_there_is_nothing_to_compare(
        self, employee, project, repo
    ):
        """No commits in the window means no observed share, so no drift — not
        a drift of minus the whole allocation."""
        Assignment.objects.create(employee=employee, project=project, allocation_percent=60)

        row = _row(build_workload(days=30), employee)

        assert row["projects"][0]["share_percent"] is None
        assert row["projects"][0]["drift"] is None

    def test_the_busiest_project_leads(self, employee, project, repo):
        other_project, other_repo = _second_project()
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        ProjectMember.objects.create(
            repo=other_repo, gitlab_user_id=1001, employee=employee
        )
        _commit(repo, employee, 1, "a" * 40)
        for i in range(5):
            _commit(other_repo, employee, i, f"b{i:039d}")

        row = _row(build_workload(days=30), employee)

        assert row["projects"][0]["project"] == other_project.name


class TestPlanFromRepos:
    def test_it_creates_assignments_for_unplanned_memberships(
        self, employee, project, repo
    ):
        other_project, other_repo = _second_project()
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        ProjectMember.objects.create(
            repo=other_repo, gitlab_user_id=1001, employee=employee
        )

        result = assign_from_memberships(employee)

        assert result["created"] == 2
        assert Assignment.objects.filter(employee=employee).count() == 2
        # Remaining capacity split evenly rather than an invented figure.
        assert result["allocation_percent"] == 50

    def test_an_existing_plan_is_never_overwritten(self, employee, project, repo):
        """A stated plan outranks an inferred one."""
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        Assignment.objects.create(
            employee=employee, project=project, allocation_percent=25
        )

        assign_from_memberships(employee)

        assert Assignment.objects.get(employee=employee).allocation_percent == 25

    def test_it_reports_when_there_is_nothing_to_do(self, employee, project, repo):
        Assignment.objects.create(employee=employee, project=project)

        assert assign_from_memberships(employee)["created"] == 0

    def test_an_explicit_allocation_wins(self, employee, project, repo):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        assign_from_memberships(employee, allocation_percent=80)

        assert Assignment.objects.get(employee=employee).allocation_percent == 80


class TestEndpoints:
    def test_the_roster_reports_membership_projects(
        self, api_client, employee, project, repo
    ):
        """The team screen's own data source, not just the internals."""
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        rows = api_client.get("/api/team/employees/roster/").json()
        row = next(r for r in rows if r["id"] == employee.id)

        assert row["project_count"] == 1
        assert row["unplanned_count"] == 1

    def test_the_utilization_dashboard_reports_them_too(
        self, api_client, employee, project, repo
    ):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        rows = api_client.get("/api/scoring/dashboard").json()["rows"]
        row = next(r for r in rows if r["employee_id"] == employee.id)

        assert [p["name"] for p in row["assigned_projects"]] == [project.name]
        assert row["unplanned_count"] == 1

    def test_plan_from_repos_over_the_api(self, api_client, employee, project, repo):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        response = api_client.post(
            f"/api/team/employees/{employee.id}/assign-from-repos/", {}
        )

        assert response.status_code == 200
        assert response.json()["created"] == 1
        assert Assignment.objects.filter(employee=employee).exists()

    def test_the_workload_endpoint_lists_everyone(
        self, api_client, employee, project, repo
    ):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        body = api_client.get("/api/team/workload/?days=30").json()

        assert body["totals"]["unplanned"] == 1
        assert body["rows"][0]["projects"][0]["project"] == project.name
