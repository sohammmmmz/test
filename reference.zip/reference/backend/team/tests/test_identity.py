"""Tests for commit-author attribution — the chain that keeps activity from
being silently dropped when a git config does not match an official address."""

import pytest

from activity.models import Commit
from team.identity import AuthorResolver, claim_unmapped_author, normalize_email
from team.models import AuthorAlias, Employee, UnmappedAuthor

pytestmark = pytest.mark.django_db


def test_normalize_email_lowercases_and_strips():
    assert normalize_email("  Riya@Company.COM ") == "riya@company.com"
    assert normalize_email(None) == ""


class TestResolution:
    def test_matches_official_email_case_insensitively(self, employee):
        resolver = AuthorResolver()

        assert resolver.resolve("RIYA@company.com") == employee

    def test_matches_a_registered_alias(self, employee):
        AuthorAlias.objects.create(employee=employee, email="riya.personal@gmail.com")
        resolver = AuthorResolver()

        assert resolver.resolve("riya.personal@gmail.com") == employee

    def test_gitlab_user_id_wins_over_email(self, employee, db):
        """Webhook payloads carry a resolved account; trust it over a stray
        git config address."""
        resolver = AuthorResolver()

        assert resolver.resolve("someone-else@nowhere.com", gitlab_user_id=1001) == employee

    def test_unknown_email_returns_none_and_is_queued(self, db):
        resolver = AuthorResolver()

        assert resolver.resolve("ghost@nowhere.com", name="Ghost") is None
        assert resolver.pending_unmapped == {"ghost@nowhere.com": "Ghost"}

    def test_blank_email_resolves_to_none_without_queueing(self, db):
        resolver = AuthorResolver()

        assert resolver.resolve("") is None
        assert resolver.pending_unmapped == {}

    def test_lookups_are_cached_across_calls(self, employee, django_assert_num_queries):
        resolver = AuthorResolver()
        resolver.resolve("riya@company.com")

        with django_assert_num_queries(0):
            for _ in range(20):
                resolver.resolve("riya@company.com")


class TestFlushUnmapped:
    def test_creates_review_queue_entries(self, db):
        resolver = AuthorResolver()
        resolver.resolve("ghost@nowhere.com", name="Ghost")

        assert resolver.flush_unmapped() == 1

        entry = UnmappedAuthor.objects.get(email="ghost@nowhere.com")
        assert entry.name == "Ghost"
        assert entry.commit_count == 1

    def test_repeat_sightings_increment_rather_than_duplicate(self, db):
        for _ in range(3):
            resolver = AuthorResolver()
            resolver.resolve("ghost@nowhere.com", name="Ghost")
            resolver.flush_unmapped()

        entry = UnmappedAuthor.objects.get(email="ghost@nowhere.com")
        assert entry.commit_count == 3
        assert UnmappedAuthor.objects.count() == 1

    def test_flush_is_idempotent_when_nothing_pending(self, db):
        assert AuthorResolver().flush_unmapped() == 0


class TestClaim:
    def test_claiming_backfills_historical_commits(self, employee, repo):
        """Without backfill, claiming an alias only fixes future commits and the
        person's past work stays invisible."""
        from django.utils import timezone

        for i in range(3):
            Commit.objects.create(
                repo=repo, sha=f"sha{i}", author_email="ghost@nowhere.com",
                author_name="Ghost", authored_date=timezone.now(),
            )
        unmapped = UnmappedAuthor.objects.create(
            email="ghost@nowhere.com", name="Ghost", commit_count=3
        )

        backfilled = claim_unmapped_author(unmapped, employee)

        assert backfilled == 3
        assert Commit.objects.filter(author_employee=employee).count() == 3
        assert AuthorAlias.objects.filter(email="ghost@nowhere.com").exists()

    def test_claiming_does_not_reassign_already_attributed_commits(self, employee, repo, db):
        from django.utils import timezone

        other = Employee.objects.create(
            official_email="dev@company.com", full_name="Other Dev"
        )
        Commit.objects.create(
            repo=repo, sha="claimed", author_email="ghost@nowhere.com",
            authored_date=timezone.now(), author_employee=other,
        )
        unmapped = UnmappedAuthor.objects.create(email="ghost@nowhere.com")

        assert claim_unmapped_author(unmapped, employee) == 0
        assert Commit.objects.get(sha="claimed").author_employee == other


class TestEndpoints:
    def test_creating_an_employee_registers_their_official_alias(self, api_client):
        response = api_client.post(
            "/api/team/employees/",
            {"official_email": "new@company.com", "full_name": "New Person"},
        )

        assert response.status_code == 201
        assert AuthorAlias.objects.filter(email="new@company.com").exists()

    def test_roster_reports_overallocation(self, api_client, employee, project):
        from projects.models import Project
        from team.models import Assignment

        second = Project.objects.create(name="Zeus", slug="zeus")
        Assignment.objects.create(employee=employee, project=project, allocation_percent=70)
        Assignment.objects.create(employee=employee, project=second, allocation_percent=60)

        row = api_client.get("/api/team/employees/roster/").json()[0]

        assert row["active_project_count"] == 2
        assert row["planned_allocation"] == 130
        assert row["is_overallocated"] is True

    def test_unmapped_queue_hides_resolved_entries(self, api_client, employee):
        UnmappedAuthor.objects.create(email="open@x.com", commit_count=1)
        UnmappedAuthor.objects.create(
            email="done@x.com", commit_count=1, resolved_to=employee
        )

        response = api_client.get("/api/team/unmapped-authors/").json()
        emails = [r["email"] for r in response["results"]]

        assert emails == ["open@x.com"]

    def test_claim_endpoint_backfills(self, api_client, employee, repo):
        from django.utils import timezone

        Commit.objects.create(
            repo=repo, sha="s1", author_email="ghost@nowhere.com",
            authored_date=timezone.now(),
        )
        unmapped = UnmappedAuthor.objects.create(email="ghost@nowhere.com", commit_count=1)

        response = api_client.post(
            f"/api/team/unmapped-authors/{unmapped.pk}/claim/", {"employee_id": employee.pk}
        )

        assert response.status_code == 200
        assert response.json()["commits_backfilled"] == 1

    def test_ignore_endpoint_removes_from_queue(self, api_client):
        unmapped = UnmappedAuthor.objects.create(email="bot@ci.local", commit_count=9)

        url = f"/api/team/unmapped-authors/{unmapped.pk}/ignore/"
        assert api_client.post(url).status_code == 204
        assert api_client.get("/api/team/unmapped-authors/").json()["count"] == 0

    def test_endpoints_reject_anonymous_callers(self, client):
        assert client.get("/api/team/employees/").status_code in (401, 403)
