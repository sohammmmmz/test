"""Commits must be counted from the commits, and history must survive the window.

Two bugs are pinned here.

The first: the utilization table sourced its commit, review and merge counts
from ``scoring.DailyScore``. Those rows are written by the scoring pass, so on
any deployment where scoring had not run — or had no Gemini key — every person
read as zero commits while the commits themselves sat in the database. Cadence
already read ``activity.Commit`` directly (see ``scoring.calendar``); the table
beside it did not.

The second: everything was scoped to a trailing window, so a person who had
committed for a year but not in the last fortnight was indistinguishable from
one who had never committed at all. The two are now reported separately.
"""

from datetime import timedelta

import pytest
from django.utils import timezone

from activity.models import Commit, ProjectMember
from projects.models import GitLabRepo, Project
from team.models import Assignment
from team.workload import build_workload

pytestmark = pytest.mark.django_db


def _commit(repo, employee, days_ago, sha):
    return Commit.objects.create(
        repo=repo,
        sha=sha,
        author_email=employee.official_email,
        author_employee=employee,
        authored_date=timezone.now() - timedelta(days=days_ago),
    )


def _row(data, employee):
    return next(r for r in data["rows"] if r["employee_id"] == employee.id)


class TestCommitsComeFromCommits:
    def test_the_dashboard_counts_commits_without_any_scoring(
        self, api_client, employee, project, repo
    ):
        """The reported bug: no DailyScore rows exist anywhere in this test."""
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        for i in range(5):
            _commit(repo, employee, i, f"a{i:039d}")

        response = api_client.get("/api/scoring/dashboard?days=14")

        assert response.status_code == 200
        row = next(
            r for r in response.data["rows"] if r["employee_id"] == employee.id
        )
        assert row["commits"] == 5
        assert row["active_days"] == 5
        # Nothing was scored, so there is genuinely no mean to report.
        assert row["mean_score"] is None

    def test_active_days_counts_days_not_commits(self, employee, project, repo):
        """Three commits on one day is one active day."""
        for i in range(3):
            _commit(repo, employee, 2, f"a{i:039d}")

        row = _row(build_workload(days=14), employee)

        assert row["commits"] == 3
        assert row["active_days"] == 1

    def test_a_day_on_two_projects_is_one_active_day(self, employee, project, repo):
        """Summing per-project day counts would report two, which would let the
        figure exceed the length of the window."""
        other = Project.objects.create(name="Zephyr", slug="zephyr")
        other_repo = GitLabRepo.objects.create(
            project=other,
            gitlab_project_id=777,
            path_with_namespace="acme/zephyr",
            name="zephyr",
            web_url="https://gitlab.example.com/acme/zephyr",
        )
        _commit(repo, employee, 1, "a" * 40)
        _commit(other_repo, employee, 1, "b" * 40)

        row = _row(build_workload(days=14), employee)

        assert row["commits"] == 2
        assert row["active_days"] == 1


class TestHistoryOutlivesTheWindow:
    def test_past_commits_are_reported_beside_the_window(
        self, employee, project, repo
    ):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)
        _commit(repo, employee, 200, "a" * 40)
        _commit(repo, employee, 150, "b" * 40)

        row = _row(build_workload(days=14), employee)

        # Quiet in the window, but demonstrably not a person who has never
        # committed — which is what the old single figure said.
        assert row["commits"] == 0
        assert row["commits_all_time"] == 2
        assert row["first_commit_at"] is not None
        assert row["last_commit_at"] is not None

    def test_never_committed_reads_differently_from_quiet(
        self, employee, project, repo
    ):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        row = _row(build_workload(days=14), employee)

        assert row["commits_all_time"] == 0
        assert row["first_commit_at"] is None

    def test_a_project_they_have_left_is_still_listed(self, employee, project, repo):
        """No assignment, no membership, but they committed here — that is part
        of what this person has done and should not vanish."""
        _commit(repo, employee, 300, "a" * 40)

        row = _row(build_workload(days=14), employee)
        entry = next(p for p in row["projects"] if p["project_id"] == project.id)

        assert entry["is_historic"] is True
        assert entry["sources"] == ["historic"]
        assert entry["commits_all_time"] == 1

    def test_a_project_they_have_left_is_not_a_planning_gap(
        self, employee, project, repo
    ):
        """``unplanned`` means "go and write an assignment". A finished project
        is history, so counting it would make the number grow forever."""
        _commit(repo, employee, 300, "a" * 40)

        row = _row(build_workload(days=14), employee)

        assert row["unplanned_count"] == 0

    def test_current_repo_access_with_no_plan_still_is_one(
        self, employee, project, repo
    ):
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        row = _row(build_workload(days=14), employee)

        assert row["unplanned_count"] == 1

    def test_lifetime_totals_do_not_double_count_a_shared_day(
        self, employee, project, repo
    ):
        other = Project.objects.create(name="Zephyr", slug="zephyr")
        other_repo = GitLabRepo.objects.create(
            project=other,
            gitlab_project_id=777,
            path_with_namespace="acme/zephyr",
            name="zephyr",
            web_url="https://gitlab.example.com/acme/zephyr",
        )
        _commit(repo, employee, 400, "a" * 40)
        _commit(other_repo, employee, 400, "b" * 40)

        row = _row(build_workload(days=14), employee)

        assert row["commits_all_time"] == 2
        assert row["active_days_all_time"] == 1


class TestSummaryCounts:
    def test_a_repo_member_is_not_counted_as_unassigned(
        self, api_client, employee, project, repo
    ):
        """The reported symptom: everybody is on a project, several still read
        as unassigned, because only the planning table was consulted."""
        ProjectMember.objects.create(repo=repo, gitlab_user_id=1001, employee=employee)

        response = api_client.get("/api/team/summary/")

        summary = response.data[0] if isinstance(response.data, list) else response.data
        assert summary["unassigned"] == 0
        # They are still a planning gap, reported as its own number.
        assert summary["unplanned"] == 1

    def test_somebody_on_nothing_at_all_is_still_unassigned(
        self, api_client, employee
    ):
        response = api_client.get("/api/team/summary/")

        summary = response.data[0] if isinstance(response.data, list) else response.data
        assert summary["unassigned"] == 1
        assert summary["unplanned"] == 0

    def test_an_assignment_alone_is_enough(self, api_client, employee, project):
        Assignment.objects.create(
            employee=employee, project=project, allocation_percent=100
        )

        response = api_client.get("/api/team/summary/")

        summary = response.data[0] if isinstance(response.data, list) else response.data
        assert summary["unassigned"] == 0
        assert summary["unplanned"] == 0
