"""Commits are attributed through the GitLab account, not through an email.

The reported bug: the official email is typed by hand at registration, the
email in someone's git config is whatever their laptop was set up with, and
when the two disagree the person's commits were credited to nobody and vanished
from every screen.

Matching now goes through the GitLab account, reached by whichever of several
routes works: the account id, an explicit username, a known address, the email's
local part read as a handle, or the display name. The inference routes are held
to a stricter standard than the exact ones — an ambiguous match must produce no
attribution rather than a guess, because a commit credited to the wrong person
is worse than one sitting in the review queue.
"""

from datetime import timedelta

import pytest
from django.utils import timezone

from activity.models import Commit, ProjectMember
from team.identity import (
    AuthorResolver,
    email_local_part,
    normalize_handle,
    reattribute_activity,
)
from team.models import AuthorAlias, Employee

pytestmark = pytest.mark.django_db


def _commit(repo, *, email, name="", username="", sha="a" * 40, employee=None):
    return Commit.objects.create(
        repo=repo,
        sha=sha,
        author_email=email,
        author_name=name,
        author_username=username,
        author_employee=employee,
        authored_date=timezone.now() - timedelta(days=1),
    )


class TestNormalisation:
    @pytest.mark.parametrize(
        "value,expected",
        [
            ("Riya Sharma", "riyasharma"),
            ("riya.sharma", "riyasharma"),
            ("riya-sharma", "riyasharma"),
            ("riya_sharma", "riyasharma"),
            ("  RIYA   SHARMA ", "riyasharma"),
        ],
    )
    def test_handles_and_names_fold_to_the_same_key(self, value, expected):
        assert normalize_handle(value) == expected

    @pytest.mark.parametrize(
        "email,expected",
        [
            ("riya.sharma@gmail.com", "riya.sharma"),
            ("RIYA@Company.COM", "riya"),
            ("12345+riya@users.noreply.gitlab.com", "riya"),
            ("not-an-email", ""),
            (None, ""),
        ],
    )
    def test_local_parts_are_extracted(self, email, expected):
        assert email_local_part(email) == expected


class TestResolutionRoutes:
    def test_the_gitlab_account_id_wins(self, employee):
        employee.gitlab_user_id = 4242
        employee.save()

        resolved, username = AuthorResolver().resolve_identity(
            "someone-else@nowhere.test", gitlab_user_id=4242
        )

        assert resolved == employee
        assert username == employee.gitlab_username

    def test_an_explicit_username_matches(self, employee):
        """employee fixture has gitlab_username "riya"."""
        resolved, username = AuthorResolver().resolve_identity(
            "personal@gmail.com", username="riya"
        )

        assert resolved == employee
        assert username == "riya"

    def test_a_personal_email_matching_the_username_is_attributed(self, employee):
        """The exact reported case: registered as riya@company.com, commits from
        riya@gmail.com. The local part is the GitLab handle."""
        resolved, _username = AuthorResolver().resolve_identity("riya@gmail.com")

        assert resolved == employee

    def test_separators_between_handle_and_email_do_not_matter(self, employee):
        employee.gitlab_username = "riya.sharma"
        employee.save()

        resolved, _username = AuthorResolver().resolve_identity("riya-sharma@gmail.com")

        assert resolved == employee

    def test_the_git_display_name_matches_the_roster_name(self, employee):
        """Nothing about the address is recognisable, but git's user.name is the
        person's real name and GitLab holds the same string."""
        resolved, _username = AuthorResolver().resolve_identity(
            "dev@laptop.local", name="Riya Sharma"
        )

        assert resolved == employee

    def test_a_repo_member_username_resolves_without_roster_gitlab_fields(
        self, employee, repo
    ):
        """The roster's GitLab fields are typed by hand and often empty. The
        membership rows are populated by GitLab and are the better source."""
        employee.gitlab_username = ""
        employee.gitlab_user_id = None
        employee.save()
        ProjectMember.objects.create(
            repo=repo,
            gitlab_user_id=9001,
            username="r.sharma",
            name="Riya Sharma",
            employee=employee,
        )

        resolved, username = AuthorResolver().resolve_identity("r.sharma@personal.io")

        assert resolved == employee
        assert username == "r.sharma"

    def test_an_unknown_author_still_resolves_to_nobody(self, employee):
        resolver = AuthorResolver()

        resolved, _username = resolver.resolve_identity(
            "stranger@elsewhere.test", name="Someone Else"
        )

        assert resolved is None
        assert "stranger@elsewhere.test" in resolver.pending_unmapped


class TestAmbiguityIsRefused:
    def test_two_people_with_the_same_name_match_neither(self, repo):
        for i, email in enumerate(("alex1@company.com", "alex2@company.com")):
            person = Employee.objects.create(official_email=email, full_name="Alex Kim")
            AuthorAlias.objects.create(
                employee=person, email=email, source=AuthorAlias.Source.OFFICIAL
            )
            person.gitlab_username = f"alexkim{i}"
            person.save()

        resolved, _username = AuthorResolver().resolve_identity(
            "alex@laptop.local", name="Alex Kim"
        )

        assert resolved is None, "a coin flip is worse than the review queue"

    def test_a_generic_mailbox_is_never_matched_by_local_part(self, repo):
        """Otherwise every CI commit from admin@ lands on whoever is called
        Admin on the roster."""
        person = Employee.objects.create(
            official_email="real@company.com", full_name="Real Person"
        )
        person.gitlab_username = "admin"
        person.save()

        resolved, _username = AuthorResolver().resolve_identity("admin@ci.example.com")

        assert resolved is None

    def test_an_exact_address_still_wins_over_the_generic_rule(self, repo):
        """Being cautious about inference must not break the exact match."""
        person = Employee.objects.create(
            official_email="admin@company.com", full_name="Real Admin"
        )
        AuthorAlias.objects.create(
            employee=person, email="admin@company.com", source=AuthorAlias.Source.OFFICIAL
        )

        resolved, _username = AuthorResolver().resolve_identity("admin@company.com")

        assert resolved == person


class TestReattribution:
    def test_it_repairs_commits_a_normal_sync_would_never_revisit(
        self, employee, project, repo
    ):
        """The whole point: a sync upserts on (repo, sha) and only re-fetches a
        recent window, so history keeps whatever attribution it first got."""
        _commit(repo, email="riya@gmail.com", name="Riya Sharma", sha="b" * 40)
        _commit(repo, email="riya@gmail.com", name="Riya Sharma", sha="c" * 40)

        assert Commit.objects.filter(author_employee__isnull=True).count() == 2

        result = reattribute_activity()

        assert result["commits_attributed"] == 2
        assert result["commits_still_unattributed"] == 0
        assert Commit.objects.filter(author_employee=employee).count() == 2

    def test_it_records_the_username_it_matched_on(self, employee, project, repo):
        _commit(repo, email="riya@gmail.com", sha="d" * 40)

        reattribute_activity()

        assert Commit.objects.get(sha="d" * 40).author_username == "riya"

    def test_existing_attribution_is_left_alone_by_default(
        self, employee, project, repo
    ):
        """A manual correction must not be silently overwritten."""
        other = Employee.objects.create(
            official_email="other@company.com", full_name="Other Person"
        )
        _commit(repo, email="riya@gmail.com", sha="e" * 40, employee=other)

        reattribute_activity()

        assert Commit.objects.get(sha="e" * 40).author_employee == other

    def test_passing_all_re_decides_everything(self, employee, project, repo):
        other = Employee.objects.create(
            official_email="other@company.com", full_name="Other Person"
        )
        _commit(repo, email="riya@gmail.com", sha="f" * 40, employee=other)

        reattribute_activity(only_unattributed=False)

        assert Commit.objects.get(sha="f" * 40).author_employee == employee

    def test_the_review_queue_is_cleared_of_anything_now_matched(
        self, employee, project, repo
    ):
        from team.models import UnmappedAuthor

        UnmappedAuthor.objects.create(email="riya@gmail.com", name="Riya Sharma")

        result = reattribute_activity()

        assert result["unmapped_authors_resolved"] == 1
        assert UnmappedAuthor.objects.get(email="riya@gmail.com").resolved_to == employee

    def test_it_reports_what_it_could_not_match(self, employee, project, repo):
        _commit(repo, email="ghost@nowhere.test", name="Ghost", sha="0" * 40)

        result = reattribute_activity()

        assert result["commits_still_unattributed"] == 1


class TestEndpoint:
    def test_it_runs_over_the_api(self, api_client, employee, project, repo):
        _commit(repo, email="riya@gmail.com", sha="1" * 40)

        response = api_client.post("/api/team/reattribute/", {}, format="json")

        assert response.status_code == 200
        assert response.data["commits_attributed"] == 1

    def test_scope_all_is_opt_in(self, api_client, employee, project, repo):
        other = Employee.objects.create(
            official_email="other@company.com", full_name="Other Person"
        )
        _commit(repo, email="riya@gmail.com", sha="2" * 40, employee=other)

        api_client.post("/api/team/reattribute/", {}, format="json")
        assert Commit.objects.get(sha="2" * 40).author_employee == other

        api_client.post("/api/team/reattribute/", {"scope": "all"}, format="json")
        assert Commit.objects.get(sha="2" * 40).author_employee == employee
