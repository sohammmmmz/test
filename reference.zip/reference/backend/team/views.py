from django.db.models import Count, Sum
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from activity.models import ProjectMember
from common import cache as cache_ns
from common.cache import cached

from .identity import claim_unmapped_author, link_gitlab_member, reattribute_activity
from .models import Assignment, AuthorAlias, Employee, UnmappedAuthor, active_assignments_q
from .serializers import (
    AssignmentSerializer,
    AuthorAliasSerializer,
    ClaimUnmappedAuthorSerializer,
    CreateEmployeeFromMemberSerializer,
    EmployeeSerializer,
    EmployeeWriteSerializer,
    LinkMemberSerializer,
    UnmappedAuthorSerializer,
)
from .workload import assign_from_memberships, build_workload


def _window_days(request, default: int = 30) -> int:
    """Trailing window for workload views, clamped to something sane."""
    try:
        return max(1, min(int(request.query_params.get("days", default)), 366))
    except (TypeError, ValueError):
        return default


def _cached_workload(days: int) -> dict:
    """The workload join, computed once per window per sync.

    Both the roster and the workload screens are built from this, and they are
    routinely open at the same time, so the second one costs nothing. Today's
    date is in the key because the window is relative to it — without that, the
    answer would silently stop moving at midnight.
    """
    return cached(
        "team:workload",
        cache_ns.ACTIVITY,
        {"days": days, "today": timezone.localdate()},
    )(lambda: build_workload(days=days))


class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.prefetch_related("aliases").all()

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return EmployeeWriteSerializer
        return EmployeeSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        is_active = self.request.query_params.get("is_active")
        if is_active is not None:
            qs = qs.filter(is_active=is_active.lower() in ("1", "true", "yes"))
        employment_type = self.request.query_params.get("employment_type")
        if employment_type:
            qs = qs.filter(employment_type=employment_type)
        return qs

    @action(detail=True, methods=["get"])
    def assignments(self, request, pk=None):
        employee = self.get_object()
        qs = employee.assignments.select_related("project")
        if request.query_params.get("active") == "true":
            qs = qs.filter(active_assignments_q())
        return Response(AssignmentSerializer(qs, many=True).data)

    @action(detail=True, methods=["get"])
    def workload(self, request, pk=None):
        """One person's projects, planned allocation against observed share."""
        days = _window_days(request)
        data = build_workload(days=days, employee_ids=[self.get_object().pk])
        return Response(data["rows"][0] if data["rows"] else {})

    @action(detail=True, methods=["post"], url_path="assign-from-repos")
    def assign_from_repos(self, request, pk=None):
        """Record assignments for the repositories this person already belongs to.

        Repository membership is observed fact and allocation is a plan, so the
        two are never merged automatically — but typing out an assignment per
        project is the reason the planning table sits empty. This turns the
        memberships GitLab already reports into a starting plan in one action.
        """
        employee = self.get_object()
        allocation = request.data.get("allocation_percent")
        if allocation is not None:
            try:
                allocation = max(0, min(int(allocation), 100))
            except (TypeError, ValueError):
                return Response(
                    {"detail": "allocation_percent must be a whole number 0-100."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        result = assign_from_memberships(
            employee, allocation_percent=allocation, role=request.data.get("role") or None
        )
        return Response(result)

    @action(detail=False, methods=["get"])
    def roster(self, request):
        """Compact roster for the team screen.

        Projects come from repository membership as well as assignments. Reading
        only the assignments table is what made people who are members of five
        repositories appear here as working on nothing: membership is synced
        from GitLab, assignments are typed by hand, and nothing had ever created
        one.
        """
        data = _cached_workload(_window_days(request))
        return Response(
            [
                {
                    "id": row["employee_id"],
                    "full_name": row["full_name"],
                    "official_email": row["official_email"],
                    "employment_type": row["employment_type"],
                    "department": row["department"],
                    "designation": row["designation"],
                    "gitlab_username": row["gitlab_username"],
                    "active_project_count": row["assigned_count"],
                    "project_count": row["project_count"],
                    "unplanned_count": row["unplanned_count"],
                    "commits": row["commits"],
                    "commits_all_time": row["commits_all_time"],
                    "first_commit_at": row["first_commit_at"],
                    "last_commit_at": row["last_commit_at"],
                    "planned_allocation": row["planned_allocation"],
                    "is_overallocated": row["is_overallocated"],
                    "projects": row["projects"],
                }
                for row in data["rows"]
            ]
        )


class ReattributeViewSet(viewsets.ViewSet):
    """Re-run commit attribution over history already in the database.

    The repair path for the case this whole chain exists to fix: commits landed
    under an email nobody recognised, so they were credited to no one. Changing
    the rules — or correcting somebody's GitLab username on the roster — does
    not retroactively fix those rows, because a sync upserts on ``(repo, sha)``
    and only re-fetches a recent window. This re-decides them locally, with no
    GitLab calls at all.
    """

    def create(self, request):
        # Default is conservative: only rows nobody is credited for. Passing
        # ``all`` re-decides everything, including manual corrections, which is
        # what you want after fixing a username but not something to do by
        # accident.
        only_unattributed = str(request.data.get("scope", "unattributed")) != "all"
        return Response(reattribute_activity(only_unattributed=only_unattributed))


class AssignmentViewSet(viewsets.ModelViewSet):
    queryset = Assignment.objects.select_related("employee", "project").all()
    serializer_class = AssignmentSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        project_id = self.request.query_params.get("project")
        if project_id:
            qs = qs.filter(project_id=project_id)
        employee_id = self.request.query_params.get("employee")
        if employee_id:
            qs = qs.filter(employee_id=employee_id)
        if self.request.query_params.get("active") == "true":
            qs = qs.filter(active_assignments_q())
        return qs


class AuthorAliasViewSet(viewsets.ModelViewSet):
    queryset = AuthorAlias.objects.select_related("employee").all()
    serializer_class = AuthorAliasSerializer


class UnmappedAuthorViewSet(viewsets.ReadOnlyModelViewSet):
    """Review queue for commit authors that matched no employee."""

    serializer_class = UnmappedAuthorSerializer

    def get_queryset(self):
        qs = UnmappedAuthor.objects.select_related("resolved_to")
        if self.request.query_params.get("include_resolved") != "true":
            qs = qs.filter(resolved_to__isnull=True, is_ignored=False)
        return qs

    @action(detail=True, methods=["post"])
    def claim(self, request, pk=None):
        """Attach this address to an employee and backfill their past commits."""
        unmapped = self.get_object()
        serializer = ClaimUnmappedAuthorSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        employee = Employee.objects.get(pk=serializer.validated_data["employee_id"])
        backfilled = claim_unmapped_author(unmapped, employee)

        return Response(
            {
                "email": unmapped.email,
                "employee": employee.full_name,
                "commits_backfilled": backfilled,
            }
        )

    @action(detail=True, methods=["post"])
    def ignore(self, request, pk=None):
        """Mark as a bot or service account so it stops appearing."""
        unmapped = self.get_object()
        unmapped.is_ignored = True
        unmapped.save(update_fields=["is_ignored", "updated_at"])
        return Response(status=status.HTTP_204_NO_CONTENT)


class UnlinkedMemberViewSet(viewsets.ViewSet):
    """"Others" — GitLab accounts on tracked repos that match nobody on the roster.

    Distinct from the unmapped-authors queue: that one is about commit *email*
    addresses, this one is about repository *membership*. Someone can appear
    here without ever having committed, which is exactly the case worth seeing
    — access granted but no work landing.
    """

    def list(self, request):
        from activity.models import ProjectMember

        rows: dict[int, dict] = {}
        members = (
            ProjectMember.objects.filter(employee__isnull=True)
            .select_related("repo__project")
            .order_by("username")
        )
        for member in members:
            entry = rows.setdefault(
                member.gitlab_user_id,
                {
                    "gitlab_user_id": member.gitlab_user_id,
                    "username": member.username,
                    "name": member.name,
                    "email": member.email,
                    "max_access_level": member.access_level,
                    "access_level_display": member.access_level_display,
                    "projects": [],
                },
            )
            entry["projects"].append(
                {
                    "id": member.repo.project_id,
                    "name": member.repo.project.name,
                    "access_level": member.access_level_display,
                }
            )
            if member.access_level > entry["max_access_level"]:
                entry["max_access_level"] = member.access_level
                entry["access_level_display"] = member.access_level_display
            if member.email and not entry["email"]:
                entry["email"] = member.email

        return Response(sorted(rows.values(), key=lambda r: -len(r["projects"])))

    @action(detail=False, methods=["post"])
    def link(self, request):
        """Attach an unlinked GitLab account to an existing employee."""
        serializer = LinkMemberSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        employee = Employee.objects.get(pk=serializer.validated_data["employee_id"])
        try:
            result = link_gitlab_member(
                serializer.validated_data["gitlab_user_id"], employee
            )
        except ValueError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)

        return Response({"employee": employee.full_name, **result})

    @action(detail=False, methods=["post"], url_path="create-employee")
    def create_employee(self, request):
        """Add an unlinked GitLab account to the roster as a new person."""
        serializer = CreateEmployeeFromMemberSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        employee = Employee.objects.create(
            official_email=data["official_email"],
            full_name=data["full_name"],
            department=data.get("department", ""),
            designation=data.get("designation", ""),
            employment_type=data.get("employment_type", "employee"),
        )
        AuthorAlias.objects.get_or_create(
            email=employee.official_email.lower(),
            defaults={"employee": employee, "source": AuthorAlias.Source.OFFICIAL},
        )

        try:
            result = link_gitlab_member(data["gitlab_user_id"], employee)
        except ValueError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)

        return Response(
            {"employee": EmployeeSerializer(employee).data, **result},
            status=status.HTTP_201_CREATED,
        )


class TeamSummaryViewSet(viewsets.ViewSet):
    """Aggregate counts for the team dashboard header."""

    def list(self, request):
        return Response(
            cached("team:summary", cache_ns.TEAM, {"today": timezone.localdate()})(
                self._build
            )
        )

    @staticmethod
    def _build() -> dict:
        active = Employee.objects.filter(is_active=True)

        # "Unassigned" has to mean "on no project at all", not "has no row in
        # the assignments table". Repository membership is synced from GitLab
        # and assignments are typed by hand, so counting only the latter
        # reported people who are members of several repos as unassigned.
        assigned_ids = set(
            Assignment.objects.filter(active_assignments_q())
            .values_list("employee_id", flat=True)
        )
        member_ids = set(
            ProjectMember.objects.filter(employee__isnull=False)
            .values_list("employee_id", flat=True)
        )
        on_a_project = assigned_ids | member_ids

        # One grouped query rather than a `planned_allocation_percent()` call
        # per person, which was a query per row of the roster.
        overallocated = (
            Assignment.objects.filter(active_assignments_q(), employee__is_active=True)
            .values("employee_id")
            .annotate(total=Sum("allocation_percent"))
            .filter(total__gt=100)
            .count()
        )

        return {
            "total_active": active.count(),
            "employees": active.filter(employment_type="employee").count(),
            "interns": active.filter(employment_type="intern").count(),
            "contractors": active.filter(employment_type="contractor").count(),
            "unassigned": active.exclude(id__in=on_a_project).count(),
            # On a repository, but with no allocation written down. This is the
            # number that used to be reported as "unassigned", and it is a
            # planning gap rather than an idle person.
            "unplanned": active.filter(id__in=member_ids - assigned_ids).count(),
            "unmapped_authors": UnmappedAuthor.objects.filter(
                resolved_to__isnull=True, is_ignored=False
            ).aggregate(n=Count("id"))["n"],
            # Repo members matching nobody on the roster — access granted
            # without a person behind it.
            "unlinked_members": ProjectMember.objects.filter(employee__isnull=True)
            .values("gitlab_user_id")
            .distinct()
            .count(),
            "overallocated": overallocated,
        }


class WorkloadViewSet(viewsets.ViewSet):
    """Per-person project workload across every project they touch.

    Answers the question the team screen could not: one person is on several
    projects — how is their time actually split, and does it match the plan?
    """

    def list(self, request):
        days = _window_days(request)
        return Response(_cached_workload(days))
