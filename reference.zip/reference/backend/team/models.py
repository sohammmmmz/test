"""Team roster, identity mapping, and project assignments."""

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils import timezone

from common.models import TimeStampedModel


class EmploymentType(models.TextChoices):
    EMPLOYEE = "employee", "Employee"
    INTERN = "intern", "Intern"
    CONTRACTOR = "contractor", "Contractor"


class ProjectRole(models.TextChoices):
    TECH_LEAD = "tech_lead", "Tech Lead"
    DEVELOPER = "developer", "Developer"
    QA = "qa", "QA"
    DESIGNER = "designer", "Designer"
    ANALYST = "analyst", "Business Analyst"
    MANAGER = "manager", "Project Manager"


def active_assignments_q(as_of=None, prefix: str = ""):
    """Queryset filter for assignments live on a given date.

    ``prefix`` is the relation path when filtering from another model — an
    aggregate like ``Count("assignments", filter=...)`` resolves field names
    against the *base* model, so the lookups need to be written as
    ``assignments__started_on`` rather than ``started_on``.
    """
    as_of = as_of or timezone.localdate()
    p = f"{prefix}__" if prefix else ""
    return models.Q(**{f"{p}started_on__lte": as_of}) & (
        models.Q(**{f"{p}ended_on__isnull": True})
        | models.Q(**{f"{p}ended_on__gte": as_of})
    )


class Employee(TimeStampedModel):
    """A member of the team.

    ``official_email`` is the canonical identity — everyone joins with a
    company address. Git configs still drift, so commit attribution goes
    through :class:`AuthorAlias` rather than matching on this field alone.
    """

    official_email = models.EmailField(unique=True, db_index=True)
    full_name = models.CharField(max_length=255)
    employment_type = models.CharField(
        max_length=32, choices=EmploymentType.choices, default=EmploymentType.EMPLOYEE
    )
    department = models.CharField(max_length=128, blank=True, db_index=True)
    designation = models.CharField(max_length=255, blank=True)

    gitlab_user_id = models.BigIntegerField(null=True, blank=True, db_index=True)
    gitlab_username = models.CharField(max_length=255, blank=True, db_index=True)
    gitlab_avatar_url = models.URLField(blank=True)

    weekly_capacity_hours = models.DecimalField(
        max_digits=5, decimal_places=2, default=40,
        help_text="Nominal weekly hours; interns are often part-time.",
    )
    joined_on = models.DateField(null=True, blank=True)
    left_on = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True, db_index=True)

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return f"{self.full_name} <{self.official_email}>"

    def planned_allocation_percent(self, as_of=None) -> int:
        """Sum of allocation across assignments active on ``as_of``.

        Over 100 means the person is committed to more than they have; the
        utilization dashboard flags that.
        """
        total = self.assignments.filter(active_assignments_q(as_of)).aggregate(
            total=models.Sum("allocation_percent")
        )["total"]
        return total or 0


class AuthorAlias(TimeStampedModel):
    """Maps a git author email to an :class:`Employee`.

    Commits carry ``author_email``/``author_name``, not a GitLab user id. Even
    with company-issued accounts, people commit from laptops configured with a
    personal address, a bare hostname, or different casing. Unmatched emails
    land in :class:`UnmappedAuthor` for review instead of being dropped.
    """

    class Source(models.TextChoices):
        MANUAL = "manual", "Added manually"
        GITLAB = "gitlab", "Resolved from GitLab account"
        OFFICIAL = "official", "Official email"

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="aliases")
    email = models.EmailField(unique=True, db_index=True)
    source = models.CharField(max_length=16, choices=Source.choices, default=Source.MANUAL)
    note = models.CharField(max_length=255, blank=True)

    class Meta:
        verbose_name_plural = "author aliases"
        ordering = ["email"]

    def __str__(self):
        return f"{self.email} -> {self.employee.full_name}"

    def save(self, *args, **kwargs):
        self.email = self.email.strip().lower()
        super().save(*args, **kwargs)


class UnmappedAuthor(TimeStampedModel):
    """A commit author email that matched no employee or alias.

    Surfaced as a review queue so activity is never silently lost: the admin
    either claims it for an employee (creating an alias and backfilling the
    affected commits) or marks it ignored, e.g. for bots and CI accounts.
    """

    email = models.EmailField(unique=True, db_index=True)
    name = models.CharField(max_length=255, blank=True)
    commit_count = models.PositiveIntegerField(default=0)
    first_seen_at = models.DateTimeField(default=timezone.now)
    last_seen_at = models.DateTimeField(default=timezone.now)
    is_ignored = models.BooleanField(
        default=False, help_text="Bots, CI service accounts, and other non-people."
    )
    resolved_to = models.ForeignKey(
        Employee, null=True, blank=True, on_delete=models.SET_NULL,
        related_name="resolved_unmapped_authors",
    )

    class Meta:
        ordering = ["-commit_count", "email"]

    def __str__(self):
        return f"{self.name or '(no name)'} <{self.email}> x{self.commit_count}"


class Assignment(TimeStampedModel):
    """Planned allocation of an employee to a project.

    The interesting output is not this number on its own but the gap between it
    and observed GitLab activity — someone allocated 60% who has not committed
    to the project in three weeks is the signal worth surfacing.
    """

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="assignments")
    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="assignments"
    )
    role = models.CharField(
        max_length=32, choices=ProjectRole.choices, default=ProjectRole.DEVELOPER
    )
    allocation_percent = models.PositiveIntegerField(
        default=100, validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    started_on = models.DateField(default=timezone.localdate)
    ended_on = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["employee", "project"],
                condition=models.Q(ended_on__isnull=True),
                name="uniq_active_assignment_per_employee_project",
            )
        ]
        ordering = ["-started_on"]

    def __str__(self):
        return f"{self.employee.full_name} @ {self.project.name} ({self.allocation_percent}%)"

    @property
    def is_currently_active(self) -> bool:
        today = timezone.localdate()
        if self.started_on and self.started_on > today:
            return False
        return self.ended_on is None or self.ended_on >= today
