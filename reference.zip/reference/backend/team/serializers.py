from rest_framework import serializers

from .models import Assignment, AuthorAlias, Employee, EmploymentType, UnmappedAuthor


class AuthorAliasSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthorAlias
        fields = ["id", "employee", "email", "source", "note", "created_at"]
        read_only_fields = ["created_at"]


class AssignmentSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    project_name = serializers.CharField(source="project.name", read_only=True)
    project_slug = serializers.CharField(source="project.slug", read_only=True)
    is_active = serializers.BooleanField(source="is_currently_active", read_only=True)

    class Meta:
        model = Assignment
        fields = [
            "id", "employee", "employee_name", "project", "project_name", "project_slug",
            "role", "allocation_percent", "started_on", "ended_on", "notes", "is_active",
        ]

    def validate(self, attrs):
        started = attrs.get("started_on") or getattr(self.instance, "started_on", None)
        ended = attrs.get("ended_on") or getattr(self.instance, "ended_on", None)
        if started and ended and ended < started:
            raise serializers.ValidationError(
                {"ended_on": "An assignment cannot end before it starts."}
            )
        return attrs


class EmployeeSerializer(serializers.ModelSerializer):
    aliases = AuthorAliasSerializer(many=True, read_only=True)
    planned_allocation = serializers.SerializerMethodField()
    active_project_count = serializers.SerializerMethodField()
    is_overallocated = serializers.SerializerMethodField()

    class Meta:
        model = Employee
        fields = [
            "id", "official_email", "full_name", "employment_type", "department",
            "designation", "gitlab_user_id", "gitlab_username", "gitlab_avatar_url",
            "weekly_capacity_hours", "joined_on", "left_on", "is_active",
            "aliases", "planned_allocation", "active_project_count", "is_overallocated",
        ]

    def get_planned_allocation(self, obj) -> int:
        return obj.planned_allocation_percent()

    def get_active_project_count(self, obj) -> int:
        from .models import active_assignments_q

        return obj.assignments.filter(active_assignments_q()).count()

    def get_is_overallocated(self, obj) -> bool:
        return obj.planned_allocation_percent() > 100


class EmployeeWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = [
            "id", "official_email", "full_name", "employment_type", "department",
            "designation", "gitlab_user_id", "gitlab_username", "weekly_capacity_hours",
            "joined_on", "left_on", "is_active",
        ]

    def create(self, validated_data):
        employee = super().create(validated_data)
        # The official address is an alias by definition; registering it here
        # means attribution works before anyone touches the alias screen.
        AuthorAlias.objects.get_or_create(
            email=employee.official_email.lower(),
            defaults={"employee": employee, "source": AuthorAlias.Source.OFFICIAL},
        )
        return employee


class UnmappedAuthorSerializer(serializers.ModelSerializer):
    resolved_to_name = serializers.CharField(source="resolved_to.full_name", read_only=True)

    class Meta:
        model = UnmappedAuthor
        fields = [
            "id", "email", "name", "commit_count", "first_seen_at", "last_seen_at",
            "is_ignored", "resolved_to", "resolved_to_name",
        ]
        read_only_fields = ["email", "commit_count", "first_seen_at", "last_seen_at"]


class ClaimUnmappedAuthorSerializer(serializers.Serializer):
    employee_id = serializers.IntegerField()

    def validate_employee_id(self, value):
        if not Employee.objects.filter(pk=value).exists():
            raise serializers.ValidationError("No such employee.")
        return value


class LinkMemberSerializer(serializers.Serializer):
    """Attach an existing employee to a GitLab account seen on a repository."""

    gitlab_user_id = serializers.IntegerField()
    employee_id = serializers.IntegerField()

    def validate_employee_id(self, value):
        if not Employee.objects.filter(pk=value).exists():
            raise serializers.ValidationError("No such employee.")
        return value


class CreateEmployeeFromMemberSerializer(serializers.Serializer):
    """Add an unlinked GitLab account to the roster as a new person."""

    gitlab_user_id = serializers.IntegerField()
    full_name = serializers.CharField(max_length=255)
    official_email = serializers.EmailField()
    department = serializers.CharField(required=False, allow_blank=True, default="")
    designation = serializers.CharField(required=False, allow_blank=True, default="")
    employment_type = serializers.ChoiceField(
        choices=EmploymentType.choices, required=False, default=EmploymentType.EMPLOYEE
    )

    def validate_official_email(self, value):
        if Employee.objects.filter(official_email__iexact=value).exists():
            raise serializers.ValidationError(
                "Someone with this email is already on the roster — link to them instead."
            )
        return value.lower()
