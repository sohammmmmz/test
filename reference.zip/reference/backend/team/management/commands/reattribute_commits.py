"""Re-run commit attribution over history already in the database.

Run after correcting a GitLab username on the roster, or after linking an
account under "Others". A normal sync will not do it: commits upsert on
``(repo, sha)`` and an incremental run only re-fetches a few days, so anything
older keeps whatever attribution it was given when it first arrived.
"""

from django.core.management.base import BaseCommand

from team.identity import reattribute_activity


class Command(BaseCommand):
    help = "Re-attribute commits, merge requests and review notes to employees."

    def add_arguments(self, parser):
        parser.add_argument(
            "--all",
            action="store_true",
            help=(
                "Re-decide every row, not just the unattributed ones. This "
                "overwrites manual corrections, so it is off by default."
            ),
        )

    def handle(self, *args, **options):
        result = reattribute_activity(only_unattributed=not options["all"])
        for key, value in result.items():
            self.stdout.write(f"{key.replace('_', ' '):<32} {value}")
        if result["commits_still_unattributed"]:
            self.stdout.write(
                self.style.WARNING(
                    f"\n{result['commits_still_unattributed']} commit(s) still match "
                    "nobody. Check the unattributed-authors queue on the Team screen."
                )
            )
        else:
            self.stdout.write(self.style.SUCCESS("\nEvery commit is attributed."))
