"""Resolving git commit authors to employees.

Commits carry ``author_email`` and ``author_name``, never a GitLab user id and
never a username. Matching on the email alone is what made people's commits
disappear: the address on the roster is typed by hand at registration, the
address in someone's git config is whatever their laptop was set up with, and
the two agree far less often than anyone expects.

So attribution goes through the **GitLab account** instead, and the email is
only one of several ways of finding it. In order:

1. GitLab already resolved the commit to an account (webhook payloads and some
   API responses include one) — match on ``gitlab_user_id``.
2. An explicit GitLab username on the payload.
3. An explicit :class:`~team.models.AuthorAlias` for the email, or the
   employee's official email.
4. The local part of the commit email read as a username — ``r.sharma@gmail.com``
   finding the account ``r.sharma``. This is the case the email-only chain
   missed most often: a personal address whose local part is the username.
5. The commit's display name against the GitLab account name or the roster
   name. Git's ``user.name`` is usually the person's real name, and GitLab
   holds the same string.
6. Nothing matched — record the address in :class:`~team.models.UnmappedAuthor`
   so the activity surfaces as a review item instead of vanishing.

Steps 4 and 5 are inferences rather than facts, so they are held to a stricter
standard: a candidate that matches **more than one** person is discarded. Two
people called "Alex" must produce no attribution at all rather than a coin
flip, because a commit silently credited to the wrong person is worse than one
sitting in the review queue.

The resolver caches per instance because a single sync resolves thousands of
commits against a handful of distinct authors.
"""

from __future__ import annotations

import logging
import re

from django.db import transaction
from django.db.models import F
from django.utils import timezone

from common import cache

from .models import AuthorAlias, Employee, UnmappedAuthor

logger = logging.getLogger(__name__)

# Separators that differ between a git config and a GitLab handle:
# "Riya Sharma" / "riya.sharma" / "riya-sharma" / "riya_sharma" are one person.
_SEPARATORS = re.compile(r"[\s._\-+]+")

#: Local parts that identify a service, not a person. Matching on these would
#: attribute every bot commit in the group to whoever happens to be called
#: "admin" on the roster.
GENERIC_LOCAL_PARTS = frozenset(
    {
        "admin", "administrator", "bot", "build", "ci", "cd", "deploy", "dev",
        "developer", "git", "gitlab", "info", "jenkins", "mail", "no-reply",
        "noreply", "root", "runner", "service", "support", "sysadmin", "test",
        "user", "www-data",
    }
)


def normalize_email(email: str | None) -> str:
    return (email or "").strip().lower()


def normalize_handle(value: str | None) -> str:
    """Fold a name or username to a comparable key.

    Case and separators are dropped, so ``Riya Sharma``, ``riya.sharma`` and
    ``riya-sharma`` all collapse to ``riyasharma``. Deliberately lossy: this is
    used to *find* candidates, and every candidate found this way is then
    checked for ambiguity before it is trusted.
    """
    return _SEPARATORS.sub("", (value or "").strip().lower())


def email_local_part(email: str | None) -> str:
    """The part before the ``@``, or empty when there is nothing usable.

    GitHub-style noreply addresses (``12345+handle@users.noreply.github.com``)
    carry the handle after a ``+``; GitLab has the same convention. Taking the
    whole local part would produce a key nothing matches, so the tail is used.
    """
    normalized = normalize_email(email)
    if "@" not in normalized:
        return ""
    local = normalized.split("@", 1)[0]
    if "+" in local:
        local = local.rsplit("+", 1)[-1]
    return local


class GitLabIdentityIndex:
    """Every way we know of naming a person, folded into lookup tables.

    Built once and held for the life of a resolver. The GitLab accounts come
    from two places — the ``gitlab_username``/``gitlab_user_id`` on the roster,
    and the :class:`~activity.models.ProjectMember` rows synced from each
    repository — and the second is the more complete of the two, because it is
    populated by GitLab rather than typed by a person.

    Handle and name tables record *every* employee that claimed a key, not just
    the first. A key claimed twice is ambiguous and resolves to nothing; see
    the module docstring for why that is the right answer.
    """

    def __init__(self):
        self.by_gitlab_id: dict[int, Employee] = {}
        self.by_username: dict[str, Employee] = {}
        self.by_email: dict[str, Employee] = {}
        # key -> set of employee ids, so ambiguity is detectable.
        self._handle_claims: dict[str, set[int]] = {}
        self._name_claims: dict[str, set[int]] = {}
        self._handles: dict[str, Employee] = {}
        self._names: dict[str, Employee] = {}
        self._load()

    def _claim(self, table, claims, key: str, employee: Employee) -> None:
        if not key:
            return
        claims.setdefault(key, set()).add(employee.id)
        table[key] = employee

    def _load(self) -> None:
        from activity.models import ProjectMember

        employees = {e.id: e for e in Employee.objects.all()}

        for employee in employees.values():
            if employee.gitlab_user_id:
                self.by_gitlab_id[employee.gitlab_user_id] = employee
            if employee.gitlab_username:
                username = employee.gitlab_username.strip().lower()
                self.by_username[username] = employee
                self._claim(
                    self._handles, self._handle_claims, normalize_handle(username), employee
                )
            self.by_email[normalize_email(employee.official_email)] = employee
            self._claim(
                self._names, self._name_claims, normalize_handle(employee.full_name), employee
            )

        for alias in AuthorAlias.objects.all():
            employee = employees.get(alias.employee_id)
            if employee is not None:
                self.by_email.setdefault(normalize_email(alias.email), employee)

        # GitLab's own view of who is on each repository. Authoritative for
        # usernames, and the reason this works without anyone maintaining the
        # roster's GitLab fields by hand.
        members = ProjectMember.objects.filter(employee__isnull=False).values(
            "employee_id", "gitlab_user_id", "username", "name", "email"
        )
        for member in members:
            employee = employees.get(member["employee_id"])
            if employee is None:
                continue
            if member["gitlab_user_id"]:
                self.by_gitlab_id.setdefault(member["gitlab_user_id"], employee)
            if member["username"]:
                username = member["username"].strip().lower()
                self.by_username.setdefault(username, employee)
                self._claim(
                    self._handles, self._handle_claims, normalize_handle(username), employee
                )
            if member["name"]:
                self._claim(
                    self._names, self._name_claims, normalize_handle(member["name"]), employee
                )
            if member["email"]:
                self.by_email.setdefault(normalize_email(member["email"]), employee)

    # -- unambiguous lookups ----------------------------------------------

    def match_handle(self, value: str | None) -> Employee | None:
        """A username-shaped string, matched only when it names exactly one person."""
        key = normalize_handle(value)
        if not key or len(self._handle_claims.get(key, ())) != 1:
            return None
        return self._handles[key]

    def match_name(self, value: str | None) -> Employee | None:
        """A display name, matched only when it names exactly one person."""
        key = normalize_handle(value)
        if not key or len(self._name_claims.get(key, ())) != 1:
            return None
        return self._names[key]

    def username_for(self, employee: Employee) -> str:
        """The GitLab handle to record against this person's commits."""
        if employee.gitlab_username:
            return employee.gitlab_username.strip().lower()
        for username, candidate in self.by_username.items():
            if candidate.id == employee.id:
                return username
        return ""


class AuthorResolver:
    """Resolves a commit author to an :class:`Employee` via their GitLab account.

    Caches per instance: one sync resolves thousands of commits against a
    handful of distinct authors, and the index behind it is a handful of
    queries however many commits arrive.
    """

    def __init__(self, index: GitLabIdentityIndex | None = None):
        self._index = index
        self._cache: dict[tuple, tuple[Employee | None, str]] = {}
        self._unmapped: dict[str, str] = {}

    @property
    def index(self) -> GitLabIdentityIndex:
        # Built lazily so constructing a resolver costs nothing until it is
        # used — several call sites create one and never resolve anything.
        if self._index is None:
            self._index = GitLabIdentityIndex()
        return self._index

    # -- lookup ------------------------------------------------------------

    def resolve(
        self,
        email: str | None,
        name: str = "",
        gitlab_user_id: int | None = None,
        username: str | None = None,
    ) -> Employee | None:
        """Best-effort attribution. Records unmapped addresses as a side effect."""
        return self.resolve_identity(
            email, name=name, gitlab_user_id=gitlab_user_id, username=username
        )[0]

    def resolve_identity(
        self,
        email: str | None,
        name: str = "",
        gitlab_user_id: int | None = None,
        username: str | None = None,
    ) -> tuple[Employee | None, str]:
        """``(employee, gitlab_username)`` — the account as well as the person.

        The username is returned so it can be stored on the commit. Attribution
        that cannot be inspected cannot be corrected, and "why is this commit
        credited to her?" needs an answer better than "the code said so".
        """
        key = (normalize_email(email), (username or "").lower(), gitlab_user_id, name)
        if key in self._cache:
            employee, resolved_username = self._cache[key]
        else:
            employee, resolved_username = self._lookup(email, name, gitlab_user_id, username)
            self._cache[key] = (employee, resolved_username)

        if employee is None:
            normalized = normalize_email(email)
            if normalized:
                # Remember the display name so the review queue is readable.
                self._unmapped[normalized] = name or self._unmapped.get(normalized, "")

        return employee, resolved_username

    def _lookup(
        self,
        email: str | None,
        name: str,
        gitlab_user_id: int | None,
        username: str | None,
    ) -> tuple[Employee | None, str]:
        index = self.index

        # 1. GitLab told us the account outright.
        if gitlab_user_id is not None:
            employee = index.by_gitlab_id.get(gitlab_user_id)
            if employee:
                return employee, index.username_for(employee)

        # 2. An explicit username on the payload.
        if username:
            handle = username.strip().lower()
            employee = index.by_username.get(handle) or index.match_handle(handle)
            if employee:
                return employee, handle

        normalized = normalize_email(email)

        # 3. A known address: an alias, an official email, or a member email.
        if normalized:
            employee = index.by_email.get(normalized)
            if employee:
                return employee, index.username_for(employee)

        # 4. The local part read as a handle. Generic mailboxes are excluded —
        #    matching "admin@" against a person called Admin would attribute
        #    every service account's work to them.
        local = email_local_part(email)
        if local and local not in GENERIC_LOCAL_PARTS:
            employee = index.by_username.get(local) or index.match_handle(local)
            if employee:
                return employee, index.username_for(employee) or local

        # 5. The display name from the git config against the GitLab account
        #    name or the roster name.
        if name:
            employee = index.match_name(name) or index.match_handle(name)
            if employee:
                return employee, index.username_for(employee)

        return None, ""

    # -- side effects ------------------------------------------------------

    def flush_unmapped(self) -> int:
        """Persist the unmapped addresses seen during this resolver's life.

        Counts are incremented in SQL so concurrent syncs do not clobber each
        other's totals.
        """
        if not self._unmapped:
            return 0

        now = timezone.now()
        for email, name in self._unmapped.items():
            with transaction.atomic():
                obj, created = UnmappedAuthor.objects.get_or_create(
                    email=email,
                    defaults={
                        "name": name,
                        "commit_count": 1,
                        "first_seen_at": now,
                        "last_seen_at": now,
                    },
                )
                if not created:
                    UnmappedAuthor.objects.filter(pk=obj.pk).update(
                        commit_count=F("commit_count") + 1,
                        last_seen_at=now,
                        name=obj.name or name,
                    )

        count = len(self._unmapped)
        self._unmapped.clear()
        return count

    @property
    def pending_unmapped(self) -> dict[str, str]:
        return dict(self._unmapped)


def reattribute_activity(*, only_unattributed: bool = True, batch_size: int = 2000) -> dict:
    """Re-run attribution over activity already in the database.

    Needed because the resolution rules changed and a normal sync will not fix
    the past: commits are upserted on ``(repo, sha)`` and an incremental run
    only re-fetches a few days, so everything older keeps whatever attribution
    it was given when it first arrived. A full backfill would eventually repair
    it by re-writing every row from GitLab, but that is thousands of API calls
    to fix something that needs no network at all.

    ``only_unattributed`` is the safe default: rows that already point at
    somebody are left alone, so a manual correction made in the admin is never
    silently overwritten. Passing ``False`` re-decides every row, which is what
    you want after fixing a username on the roster.
    """
    from activity.models import Commit, MergeRequest, ReviewNote

    index = GitLabIdentityIndex()
    resolver = AuthorResolver(index=index)

    commits_matched = 0
    commits = Commit.objects.all()
    if only_unattributed:
        commits = commits.filter(author_employee__isnull=True)

    # Iterated in batches and written back in bulk: this runs over the whole
    # commit history and a save() per row would take minutes.
    pending: list[Commit] = []
    for commit in commits.only(
        "id", "author_email", "author_name", "author_username", "author_employee"
    ).iterator(chunk_size=batch_size):
        employee, username = resolver.resolve_identity(
            commit.author_email,
            name=commit.author_name,
            username=commit.author_username or None,
        )
        if employee is None:
            continue
        commit.author_employee = employee
        commit.author_username = username or commit.author_username
        pending.append(commit)
        commits_matched += 1

        if len(pending) >= batch_size:
            Commit.objects.bulk_update(pending, ["author_employee", "author_username"])
            pending.clear()

    if pending:
        Commit.objects.bulk_update(pending, ["author_employee", "author_username"])

    # Merge requests and review notes carry the GitLab account id directly, so
    # they only need the index, not the inference chain.
    merge_requests = 0
    for gitlab_id, employee in index.by_gitlab_id.items():
        qs = MergeRequest.objects.filter(author_gitlab_id=gitlab_id)
        if only_unattributed:
            qs = qs.filter(author_employee__isnull=True)
        merge_requests += qs.update(author_employee=employee)

    review_notes = 0
    for gitlab_id, employee in index.by_gitlab_id.items():
        qs = ReviewNote.objects.filter(author_gitlab_id=gitlab_id)
        if only_unattributed:
            qs = qs.filter(author_employee__isnull=True)
        review_notes += qs.update(author_employee=employee)

    # Anything now attributed is no longer an open question for the reviewer.
    resolved_queue = 0
    for unmapped in UnmappedAuthor.objects.filter(resolved_to__isnull=True, is_ignored=False):
        employee, _username = resolver.resolve_identity(unmapped.email, name=unmapped.name)
        if employee is not None:
            unmapped.resolved_to = employee
            unmapped.save(update_fields=["resolved_to", "updated_at"])
            resolved_queue += 1

    still_unattributed = Commit.objects.filter(author_employee__isnull=True).count()
    logger.info(
        "Re-attributed %s commits, %s merge requests, %s review notes",
        commits_matched, merge_requests, review_notes,
    )
    # This moves commits between people, which is the input to every cached
    # screen. Without the bump the button would appear to have done nothing
    # until the cache aged out on its own.
    cache.bump(cache.ACTIVITY, cache.TEAM)
    return {
        "commits_attributed": commits_matched,
        "merge_requests_attributed": merge_requests,
        "review_notes_attributed": review_notes,
        "unmapped_authors_resolved": resolved_queue,
        "commits_still_unattributed": still_unattributed,
    }


@transaction.atomic
def claim_unmapped_author(unmapped: UnmappedAuthor, employee: Employee) -> int:
    """Attach an unmapped address to an employee and backfill their history.

    Backfilling matters: without it, claiming an alias only fixes future
    commits and the person's past work stays invisible.
    """
    from activity.models import Commit

    AuthorAlias.objects.update_or_create(
        email=unmapped.email,
        defaults={"employee": employee, "source": AuthorAlias.Source.MANUAL},
    )

    backfilled = Commit.objects.filter(
        author_email__iexact=unmapped.email, author_employee__isnull=True
    ).update(author_employee=employee)

    unmapped.resolved_to = employee
    unmapped.save(update_fields=["resolved_to", "updated_at"])

    logger.info(
        "Claimed %s for %s; backfilled %s commits", unmapped.email, employee, backfilled
    )
    return backfilled


@transaction.atomic
def link_gitlab_member(gitlab_user_id: int, employee: Employee) -> dict:
    """Attach a GitLab account seen on a repository to an employee.

    This is the "Others" path: someone has access to a tracked repository but
    matched nobody on the roster. Linking here fixes attribution going forward
    (sync resolves on the GitLab account id first) and backfills whatever the
    past data supports.

    Backfill is only possible where an email is known — GitLab usually withholds
    member emails, so the count is often zero and the honest answer is to say so
    rather than imply the history was repaired.
    """
    from activity.models import Commit, MergeRequest, ProjectMember

    members = list(ProjectMember.objects.filter(gitlab_user_id=gitlab_user_id))
    if not members:
        raise ValueError(f"No repository membership found for GitLab user {gitlab_user_id}.")

    if not employee.gitlab_user_id:
        employee.gitlab_user_id = gitlab_user_id
    if not employee.gitlab_username:
        employee.gitlab_username = next((m.username for m in members if m.username), "")
    employee.save(update_fields=["gitlab_user_id", "gitlab_username", "updated_at"])

    ProjectMember.objects.filter(gitlab_user_id=gitlab_user_id).update(employee=employee)

    merge_requests = MergeRequest.objects.filter(
        author_gitlab_id=gitlab_user_id, author_employee__isnull=True
    ).update(author_employee=employee)

    commits_backfilled = 0
    emails = {normalize_email(m.email) for m in members if m.email}
    for email in emails:
        AuthorAlias.objects.update_or_create(
            email=email,
            defaults={"employee": employee, "source": AuthorAlias.Source.GITLAB},
        )
        commits_backfilled += Commit.objects.filter(
            author_email__iexact=email, author_employee__isnull=True
        ).update(author_employee=employee)

    logger.info(
        "Linked GitLab user %s to %s across %s membership(s)",
        gitlab_user_id, employee, len(members),
    )
    return {
        "memberships_linked": len(members),
        "merge_requests_backfilled": merge_requests,
        "commits_backfilled": commits_backfilled,
        "emails_known": sorted(emails),
    }


def sync_employee_gitlab_identity(employee: Employee, gitlab_user: dict) -> None:
    """Attach GitLab account details, and alias the account email if it is new."""
    employee.gitlab_user_id = gitlab_user.get("id") or employee.gitlab_user_id
    employee.gitlab_username = gitlab_user.get("username") or employee.gitlab_username
    employee.gitlab_avatar_url = gitlab_user.get("avatar_url") or employee.gitlab_avatar_url
    employee.save(
        update_fields=["gitlab_user_id", "gitlab_username", "gitlab_avatar_url", "updated_at"]
    )

    account_email = normalize_email(gitlab_user.get("email"))
    if account_email and account_email != normalize_email(employee.official_email):
        AuthorAlias.objects.get_or_create(
            email=account_email,
            defaults={"employee": employee, "source": AuthorAlias.Source.GITLAB},
        )
