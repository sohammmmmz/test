"""Who is working on what, and how much of it.

This bridges two things the rest of the system deliberately keeps apart:

``activity.ProjectMember``
    Observed fact, synced from GitLab. Someone has access to a repository.

``team.Assignment``
    A planning statement. Someone is *supposed* to spend N% of their time on a
    project, from a date, in a role.

The utilization screen exists to compare them, so they must not be collapsed
into each other — auto-creating an assignment from every repo membership would
make planned equal actual by construction and leave nothing to measure.

What was missing was the join. A person could be a member of five repositories
and still read as "unassigned", because only the planning table was consulted.
Here the two are merged into one per-person list with the source of each entry
labelled, so a project shows up whether it was planned, observed, or both.

``share_percent`` is the observed counterpart to ``allocation_percent``: of the
commits this person actually made in the window, the proportion that landed in
each project. Where both exist, the difference between them is the finding.
"""

from __future__ import annotations

from datetime import timedelta

from django.db.models import Count, Max, Min
from django.db.models.functions import TruncDate
from django.utils import timezone

from activity.models import Commit, ProjectMember

from .models import Assignment, Employee, active_assignments_q

# Sources a project can appear under for a person. The first two can be true at
# once; ``historic`` is only set when neither is — they committed here, but the
# plan and the access have both since gone.
SOURCE_ASSIGNED = "assigned"
SOURCE_MEMBER = "member"
SOURCE_HISTORIC = "historic"


def _commit_stats(employee_ids, start=None):
    """{(employee_id, project_id): {commits, active_days, first, last}}.

    ``start`` of ``None`` means every commit ever synced. Both are needed: the
    trailing window answers "are they working now", the lifetime figure answers
    "what have they done here", and a window-only view makes someone who has
    been on a project for two years look identical to someone who joined it
    last week.
    """
    qs = Commit.objects.filter(author_employee_id__in=employee_ids)
    if start is not None:
        qs = qs.filter(authored_date__date__gte=start)

    rows = (
        qs.annotate(day=TruncDate("authored_date"))
        .values("author_employee_id", "repo__project_id")
        .annotate(
            commits=Count("id"),
            active_days=Count("day", distinct=True),
            first=Min("authored_date"),
            last=Max("authored_date"),
        )
    )
    return {
        (r["author_employee_id"], r["repo__project_id"]): {
            "commits": r["commits"],
            "active_days": r["active_days"],
            "first": r["first"],
            "last": r["last"],
        }
        for r in rows
    }


def _memberships(employee_ids):
    """{employee_id: {project_id: membership dict}}.

    Highest access level wins when someone holds membership both directly and
    through a parent group.
    """
    out: dict[int, dict[int, dict]] = {}
    members = ProjectMember.objects.filter(
        employee_id__in=employee_ids, repo__project__isnull=False
    ).select_related("repo__project")

    for member in members:
        by_project = out.setdefault(member.employee_id, {})
        project = member.repo.project
        current = by_project.get(project.id)
        if current is None or member.access_level > current["access_level"]:
            by_project[project.id] = {
                "project_id": project.id,
                "project": project.name,
                "access_level": member.access_level,
                "access_level_display": member.access_level_display,
                "is_inherited": member.is_inherited,
            }
    return out


def _assignments(employee_ids, as_of=None):
    """{employee_id: {project_id: assignment dict}} for live assignments."""
    out: dict[int, dict[int, dict]] = {}
    rows = (
        Assignment.objects.filter(employee_id__in=employee_ids)
        .filter(active_assignments_q(as_of))
        .select_related("project")
    )
    for assignment in rows:
        out.setdefault(assignment.employee_id, {})[assignment.project_id] = {
            "assignment_id": assignment.id,
            "project_id": assignment.project_id,
            "project": assignment.project.name,
            "role": assignment.get_role_display(),
            "allocation_percent": assignment.allocation_percent,
            "started_on": assignment.started_on.isoformat() if assignment.started_on else None,
            "ended_on": assignment.ended_on.isoformat() if assignment.ended_on else None,
        }
    return out


def _person_totals(employee_ids, start=None) -> dict[int, dict]:
    """{employee_id: {commits, active_days, first, last}}, all projects together.

    Grouped by person rather than by (person, project) on purpose. Summing the
    per-project rows would double-count a day on which someone committed to two
    repositories, which is precisely the sort of number that quietly exceeds the
    length of the window and destroys trust in the screen.
    """
    qs = Commit.objects.filter(author_employee_id__in=employee_ids)
    if start is not None:
        qs = qs.filter(authored_date__date__gte=start)

    rows = (
        qs.annotate(day=TruncDate("authored_date"))
        .values("author_employee_id")
        .annotate(
            commits=Count("id"),
            active_days=Count("day", distinct=True),
            first=Min("authored_date"),
            last=Max("authored_date"),
        )
    )
    return {
        r["author_employee_id"]: {
            "commits": r["commits"],
            "active_days": r["active_days"],
            "first": r["first"],
            "last": r["last"],
        }
        for r in rows
    }


def _project_names(project_ids) -> dict[int, str]:
    """{project_id: name} for projects reached only through commit history.

    A project someone has left has neither an assignment nor a membership to
    take the name from, so it has to be looked up directly.
    """
    from projects.models import Project

    wanted = {pid for pid in project_ids if pid is not None}
    if not wanted:
        return {}
    return dict(Project.objects.filter(id__in=wanted).values_list("id", "name"))


def build_workload(*, days: int = 30, employee_ids=None) -> dict:
    """Per-person project workload: planned allocation against observed share."""
    today = timezone.localdate()
    start = today - timedelta(days=days)

    employees = Employee.objects.filter(is_active=True)
    if employee_ids is not None:
        employees = employees.filter(id__in=list(employee_ids))
    employees = list(employees.order_by("full_name"))
    ids = [e.id for e in employees]

    memberships = _memberships(ids)
    assignments = _assignments(ids)
    stats = _commit_stats(ids, start)
    # Everything ever synced, so a project someone has worked on for a year but
    # not touched this fortnight still appears with its history intact.
    lifetime = _commit_stats(ids)
    window_totals = _person_totals(ids, start)
    lifetime_totals = _person_totals(ids)
    names = _project_names(pid for (_eid, pid) in lifetime)

    rows = []
    for employee in employees:
        member_projects = memberships.get(employee.id, {})
        assigned_projects = assignments.get(employee.id, {})

        # The union is the point: a project counts as theirs if it was planned,
        # observed now, or observed at any time in the past. The third case is
        # what keeps history on the screen — a project someone spent six months
        # on and has since handed over is still part of what they have done,
        # even with no live assignment and no commits this fortnight.
        historic_projects = {
            pid for (eid, pid) in lifetime if eid == employee.id and pid is not None
        }
        project_ids = set(member_projects) | set(assigned_projects) | historic_projects
        total_commits = sum(
            stats.get((employee.id, pid), {}).get("commits", 0) for pid in project_ids
        )

        projects = []
        for project_id in project_ids:
            membership = member_projects.get(project_id)
            assignment = assigned_projects.get(project_id)
            observed = stats.get((employee.id, project_id), {})
            ever = lifetime.get((employee.id, project_id), {})
            commits = observed.get("commits", 0)

            sources = []
            if assignment:
                sources.append(SOURCE_ASSIGNED)
            if membership:
                sources.append(SOURCE_MEMBER)
            # Neither planned nor currently a member, but they committed here.
            # Recorded as its own source so the screen can say why it is listed.
            if not sources and ever:
                sources.append(SOURCE_HISTORIC)

            allocation = assignment["allocation_percent"] if assignment else None
            share = round(commits / total_commits * 100) if total_commits else None

            projects.append(
                {
                    "project_id": project_id,
                    "project": (
                        (assignment or membership or {}).get("project")
                        or names.get(project_id)
                        or "(unknown project)"
                    ),
                    "sources": sources,
                    # Present but unplanned: they have access or are committing
                    # now, with no allocation recorded against it. A project they
                    # have already left is history, not a planning gap, so it is
                    # excluded — otherwise the count grows forever and stops
                    # meaning "go and write an assignment".
                    "is_unplanned": assignment is None and bool(membership or commits),
                    # Listed only because they committed here in the past: no
                    # live plan, no current repository access.
                    "is_historic": SOURCE_HISTORIC in sources,
                    # Planned but with no repository access, which usually means
                    # the assignment is stale or access was never granted.
                    "has_access": membership is not None,
                    "access_level": membership["access_level_display"] if membership else None,
                    "is_inherited": membership["is_inherited"] if membership else False,
                    "assignment_id": assignment["assignment_id"] if assignment else None,
                    "role": assignment["role"] if assignment else None,
                    "allocation_percent": allocation,
                    "commits": commits,
                    "active_days": observed.get("active_days", 0),
                    # Lifetime, not window: what they have done here in total,
                    # and when it started and stopped.
                    "commits_all_time": ever.get("commits", 0),
                    "active_days_all_time": ever.get("active_days", 0),
                    "first_commit_at": (
                        ever["first"].isoformat() if ever.get("first") else None
                    ),
                    "last_commit_at": (
                        (observed.get("last") or ever.get("last")).isoformat()
                        if (observed.get("last") or ever.get("last"))
                        else None
                    ),
                    "share_percent": share,
                    # The gap this whole screen exists for. Only meaningful when
                    # a plan exists and something was observed to compare it to.
                    "drift": (
                        share - allocation
                        if share is not None and allocation is not None
                        else None
                    ),
                }
            )

        # Busiest first: the project someone actually spends their time on leads,
        # falling back to the plan, then to lifetime history, when nothing was
        # observed in the window. Without the last tie-break every dormant
        # project sorts arbitrarily.
        projects.sort(
            key=lambda p: (
                -p["commits"],
                -(p["allocation_percent"] or 0),
                -p["commits_all_time"],
            )
        )

        in_window = window_totals.get(employee.id, {})
        ever_total = lifetime_totals.get(employee.id, {})

        planned = employee.planned_allocation_percent()
        rows.append(
            {
                "employee_id": employee.id,
                "full_name": employee.full_name,
                "official_email": employee.official_email,
                "department": employee.department,
                "designation": employee.designation,
                "employment_type": employee.employment_type,
                "gitlab_username": employee.gitlab_username,
                "planned_allocation": planned,
                "is_overallocated": planned > 100,
                "project_count": len(projects),
                "assigned_count": len(assigned_projects),
                "member_count": len(member_projects),
                # Repos they work in with no allocation recorded. The actionable
                # number on the team screen.
                "unplanned_count": sum(1 for p in projects if p["is_unplanned"]),
                "commits": total_commits,
                # Distinct days, counted across every project at once: a day
                # spent on two repositories is one working day, not two.
                "active_days": in_window.get("active_days", 0),
                # The history. Kept separate from the window rather than
                # replacing it: "quiet this fortnight" and "has never committed"
                # are different findings and must not read the same.
                "commits_all_time": ever_total.get("commits", 0),
                "active_days_all_time": ever_total.get("active_days", 0),
                "first_commit_at": (
                    ever_total["first"].isoformat() if ever_total.get("first") else None
                ),
                "last_commit_at": (
                    ever_total["last"].isoformat() if ever_total.get("last") else None
                ),
                "projects": projects,
            }
        )

    return {
        "days": days,
        "start": start.isoformat(),
        "end": today.isoformat(),
        "rows": rows,
        "totals": {
            "people": len(rows),
            "unplanned": sum(r["unplanned_count"] for r in rows),
            "overallocated": sum(1 for r in rows if r["is_overallocated"]),
            "commits": sum(r["commits"] for r in rows),
            "commits_all_time": sum(r["commits_all_time"] for r in rows),
        },
    }


def assign_from_memberships(
    employee: Employee, *, allocation_percent: int | None = None, role: str | None = None
) -> dict:
    """Create assignments for every repo the person belongs to but is not assigned to.

    The convenience that makes the planning table usable: rather than typing out
    an assignment per project, take the repositories GitLab already says they
    are on and record them as planned work.

    When no allocation is given the remaining capacity is split evenly across
    the new projects, so the total lands at 100% rather than at some invented
    figure. Existing assignments are never touched — a stated plan is not
    overwritten by an inferred one.
    """
    from .models import ProjectRole

    membership_projects = _memberships([employee.id]).get(employee.id, {})
    already = set(_assignments([employee.id]).get(employee.id, {}))
    missing = [pid for pid in membership_projects if pid not in already]

    if not missing:
        return {
            "created": 0,
            "projects": [],
            "detail": "Already assigned to every repository they belong to.",
        }

    if allocation_percent is None:
        remaining = max(100 - employee.planned_allocation_percent(), 0)
        # At least 1% so an already-full person still gets a recorded plan
        # rather than a row that claims they do nothing.
        allocation_percent = max(remaining // len(missing), 1)

    created = []
    for project_id in missing:
        assignment, was_created = Assignment.objects.get_or_create(
            employee=employee,
            project_id=project_id,
            ended_on=None,
            defaults={
                "allocation_percent": allocation_percent,
                "role": role or ProjectRole.DEVELOPER,
                "started_on": timezone.localdate(),
            },
        )
        if was_created:
            created.append(membership_projects[project_id]["project"])

    return {
        "created": len(created),
        "projects": created,
        "allocation_percent": allocation_percent,
        "detail": f"Assigned to {len(created)} project(s) at {allocation_percent}% each.",
    }
