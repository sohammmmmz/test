from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("employees", views.EmployeeViewSet, basename="employee")
router.register("assignments", views.AssignmentViewSet, basename="assignment")
router.register("aliases", views.AuthorAliasViewSet, basename="author-alias")
router.register("unmapped-authors", views.UnmappedAuthorViewSet, basename="unmapped-author")
router.register(
    "unlinked-members", views.UnlinkedMemberViewSet, basename="unlinked-member"
)
router.register("reattribute", views.ReattributeViewSet, basename="reattribute")
router.register("summary", views.TeamSummaryViewSet, basename="team-summary")
router.register("workload", views.WorkloadViewSet, basename="workload")

urlpatterns = router.urls
