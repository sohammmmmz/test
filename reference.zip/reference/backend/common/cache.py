"""Caching for the read-heavy dashboard endpoints.

The problem this solves: every dashboard recomputes from scratch on every
request. The utilisation view joins commits, assignments, repository
memberships and review notes across the whole roster; the calendar builds a
cell per person per day; the leaderboard scores everyone over a rolling window.
None of it is cheap, and — this is the important part — *none of it changes
between syncs*. Recomputing it per page load is work done to produce an answer
that was already known.

Two ideas do the whole job:

**A version stamp per data family.** Cache keys embed a counter, and a sync
bumps the counter rather than hunting down keys to delete. Everything derived
from the old data becomes unreachable in one atomic step, whatever it was keyed
by, and Redis reclaims it on its own schedule. Explicit invalidation would mean
enumerating every parameter combination a page might have been rendered with,
which is not knowable.

**Failure is a miss, never an error.** Redis restarting, a network blip, an
eviction under memory pressure — all of it degrades to "compute it again",
because a cache that can take the site down is worse than no cache.
"""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Callable
from pickle import PicklingError
from typing import Any, TypeVar

from django.conf import settings
from django.core.cache import cache
from django.core.cache.backends.base import DEFAULT_TIMEOUT
from django.core.cache.backends.redis import RedisCache
from redis.exceptions import RedisError

logger = logging.getLogger(__name__)

#: What "Redis is not available" actually looks like. ``RedisError`` covers
#: connection loss, timeouts and protocol faults; ``OSError`` covers DNS and
#: socket failures that never reach the client library; ``PicklingError``
#: covers a value that cannot be stored. Anything else is a bug in this code or
#: in the configuration, and hiding it helps nobody.
CACHE_FAILURES = (RedisError, OSError, PicklingError)

T = TypeVar("T")

# Data families, versioned independently. A commit sync should not invalidate
# the project registry, and re-scoring should not invalidate either.
ACTIVITY = "activity"
TEAM = "team"
PROJECTS = "projects"
SCORING = "scoring"

ALL_NAMESPACES = (ACTIVITY, TEAM, PROJECTS, SCORING)


class ResilientRedisCache(RedisCache):
    """Django's Redis cache, with connection failures downgraded to misses.

    Django's own backend raises ``redis.ConnectionError`` straight through to
    the view. That is defensible for a cache you have decided to depend on; it
    is not what we want here, where Redis is an accelerator and the database is
    still the source of truth. Anything that goes wrong talking to Redis is
    logged once and treated as though the key was absent.

    Writes swallow failures too, and deliberately do not retry: the caller has
    already computed the real answer and is about to return it.
    """

    def _safe(self, operation: str, fallback: T, *args, **kwargs) -> T:
        """Call the real backend, treating a Redis failure as a miss.

        Deliberately narrow. Catching everything here once hid a genuine
        configuration error — an unsupported connection option — behind a
        friendly warning, so the cache silently did nothing for as long as
        nobody read the log. A ``TypeError`` from a bad setting is a bug and
        must be allowed to surface; an unreachable server is not.
        """
        try:
            return getattr(super(), operation)(*args, **kwargs)
        except CACHE_FAILURES:
            logger.warning(
                "Cache %s failed; falling through to the database", operation, exc_info=True
            )
            return fallback

    def get(self, key, default=None, version=None):
        return self._safe("get", default, key, default, version)

    def set(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        return self._safe("set", None, key, value, timeout, version)

    def add(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        return self._safe("add", False, key, value, timeout, version)

    def touch(self, key, timeout=DEFAULT_TIMEOUT, version=None):
        return self._safe("touch", False, key, timeout, version)

    def delete(self, key, version=None):
        return self._safe("delete", False, key, version)

    def get_many(self, keys, version=None):
        return self._safe("get_many", {}, keys, version)

    def set_many(self, data, timeout=DEFAULT_TIMEOUT, version=None):
        return self._safe("set_many", [], data, timeout, version)

    def delete_many(self, keys, version=None):
        return self._safe("delete_many", None, keys, version)

    def has_key(self, key, version=None):
        return self._safe("has_key", False, key, version)

    def incr(self, key, delta=1, version=None):
        # ValueError ("key does not exist") is a real answer, not a failure, and
        # callers branch on it — so it is allowed through.
        try:
            return super().incr(key, delta, version)
        except ValueError:
            raise
        except CACHE_FAILURES:
            logger.warning("Cache incr failed; version stamp not advanced", exc_info=True)
            return delta

    def clear(self):
        return self._safe("clear", None)


# ---------------------------------------------------------------------------
# Version stamps
# ---------------------------------------------------------------------------


def _version_key(namespace: str) -> str:
    return f"version:{namespace}"


def data_version(namespace: str) -> int:
    """The current stamp for a family of data.

    A miss returns 1 and does not write, because the write would race with a
    concurrent bump. The consequence of a wrong guess is a cache miss, and a
    miss is already the safe outcome everywhere here.
    """
    value = cache.get(_version_key(namespace))
    return int(value) if isinstance(value, int) else 1


def bump(*namespaces: str) -> None:
    """Invalidate everything derived from these families.

    Called after a sync writes, after attribution is repaired, and after the
    roster is edited. Cheap enough to call defensively: it is one INCR, and the
    cost of forgetting is a screen showing yesterday's numbers.
    """
    for namespace in namespaces or ALL_NAMESPACES:
        key = _version_key(namespace)
        try:
            cache.incr(key)
        except ValueError:
            # Not present yet. Two racing writers both landing on 2 is fine —
            # they agree, which is all the stamp has to achieve.
            cache.set(key, 2, timeout=None)


# ---------------------------------------------------------------------------
# Read-through
# ---------------------------------------------------------------------------


def build_key(prefix: str, namespace: str, params: dict[str, Any] | None = None) -> str:
    """A stable key from a prefix, the family, its version stamp and the params.

    The namespace is in the key as well as in the version lookup. Without it,
    two families that happen to sit at the same version number would collide
    whenever the prefix and parameters matched — which sounds unlikely until you
    notice that every family starts at version 1.

    The parameter dict is hashed rather than spelled out: a key has to be short
    and free of the characters Django's key validator rejects, and the reader
    never sees it.
    """
    payload = json.dumps(params or {}, sort_keys=True, default=str)
    digest = hashlib.sha1(payload.encode("utf-8")).hexdigest()[:16]
    return f"{prefix}:{namespace}:v{data_version(namespace)}:{digest}"


def cached(
    prefix: str,
    namespace: str,
    params: dict[str, Any] | None = None,
    *,
    timeout: int | None = None,
) -> Callable[[Callable[[], T]], T]:
    """Decorator-free read-through: ``cached(...)(lambda: expensive())``.

    Written to take a thunk rather than to wrap a function because the callers
    are view bodies that have already parsed and clamped their arguments; the
    cache key must be built from those *validated* values, not from whatever
    arrived in the query string.
    """

    def run(compute: Callable[[], T]) -> T:
        if not getattr(settings, "CACHE_ENABLED", True):
            return compute()

        key = build_key(prefix, namespace, params)
        hit = cache.get(key)
        if hit is not None:
            return hit

        value = compute()
        cache.set(key, value, timeout=timeout or settings.CACHE_DEFAULT_TIMEOUT)
        return value

    return run
