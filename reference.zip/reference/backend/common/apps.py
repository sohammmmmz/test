from django.apps import AppConfig


class CommonConfig(AppConfig):
    name = "common"
    verbose_name = "Shared"

    def ready(self):
        from .invalidation import register

        register()
