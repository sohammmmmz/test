"""Read-through caching, and what happens when Redis is not there.

Two properties matter more than the speed-up itself.

A cached dashboard must not outlive the data it was built from. Invalidation
works by bumping a version stamp that every key embeds, so a sync retires every
derived answer at once rather than the code having to enumerate which parameter
combinations were rendered — which is not knowable.

And a cache must never be able to take the site down. Redis going away has to
degrade to "compute it again", not to a 500 on every page.
"""

import pytest
from django.core.cache import cache

from common import cache as cache_ns
from common.cache import build_key, cached, data_version

pytestmark = pytest.mark.django_db


@pytest.fixture(autouse=True)
def _clean():
    cache.clear()
    yield
    cache.clear()


class TestReadThrough:
    def test_the_second_call_does_not_recompute(self, caching_on):
        calls = []

        def compute():
            calls.append(1)
            return {"answer": 42}

        assert cached("t", cache_ns.ACTIVITY, {"days": 7})(compute) == {"answer": 42}
        assert cached("t", cache_ns.ACTIVITY, {"days": 7})(compute) == {"answer": 42}

        assert len(calls) == 1

    def test_different_parameters_are_different_answers(self, caching_on):
        cached("t", cache_ns.ACTIVITY, {"days": 7})(lambda: "week")
        result = cached("t", cache_ns.ACTIVITY, {"days": 30})(lambda: "month")

        assert result == "month"

    def test_parameter_order_does_not_change_the_key(self, caching_on):
        first = build_key("t", cache_ns.ACTIVITY, {"days": 7, "project": 1})
        second = build_key("t", cache_ns.ACTIVITY, {"project": 1, "days": 7})

        assert first == second

    def test_it_can_be_switched_off_entirely(self, settings):
        settings.CACHE_ENABLED = False
        calls = []

        for _ in range(3):
            cached("t", cache_ns.ACTIVITY)(lambda: calls.append(1))

        assert len(calls) == 3


class TestInvalidation:
    def test_bumping_retires_every_key_in_that_family(self, caching_on):
        cached("t", cache_ns.ACTIVITY, {"days": 7})(lambda: "stale")

        cache_ns.bump(cache_ns.ACTIVITY)

        assert cached("t", cache_ns.ACTIVITY, {"days": 7})(lambda: "fresh") == "fresh"

    def test_one_family_does_not_disturb_another(self, caching_on):
        cached("t", cache_ns.TEAM, {})(lambda: "team")

        cache_ns.bump(cache_ns.ACTIVITY)

        assert cached("t", cache_ns.TEAM, {})(lambda: "recomputed") == "team"

    def test_bumping_with_no_arguments_retires_everything(self, caching_on):
        cached("t", cache_ns.TEAM, {})(lambda: "team")
        cached("t", cache_ns.PROJECTS, {})(lambda: "projects")

        cache_ns.bump()

        assert cached("t", cache_ns.TEAM, {})(lambda: "new") == "new"
        assert cached("t", cache_ns.PROJECTS, {})(lambda: "new") == "new"

    def test_the_first_bump_starts_the_counter(self):
        assert data_version(cache_ns.ACTIVITY) == 1

        cache_ns.bump(cache_ns.ACTIVITY)

        assert data_version(cache_ns.ACTIVITY) == 2


class TestSignals:
    def test_editing_a_person_retires_the_team_dashboards(self, caching_on, employee):
        cached("t", cache_ns.TEAM, {})(lambda: "before")

        employee.designation = "Staff Engineer"
        employee.save()

        assert cached("t", cache_ns.TEAM, {})(lambda: "after") == "after"

    def test_registering_a_project_retires_the_project_dashboards(
        self, caching_on, project
    ):
        cached("t", cache_ns.PROJECTS, {})(lambda: "before")

        project.name = "Apollo II"
        project.save()

        assert cached("t", cache_ns.PROJECTS, {})(lambda: "after") == "after"

    def test_a_sync_retires_everything(self, caching_on, project, sync_run):
        from sync.models import RunStatus
        from sync.pipeline import _finish

        for namespace in cache_ns.ALL_NAMESPACES:
            cached("t", namespace, {})(lambda: "before")

        _finish(sync_run, RunStatus.SUCCESS)

        for namespace in cache_ns.ALL_NAMESPACES:
            assert cached("t", namespace, {})(lambda: "after") == "after"


class TestRedisBeingDown:
    """A cache that raises turns an accelerator into a hard dependency."""

    def test_a_failing_read_is_a_miss_not_an_error(self, caching_on, monkeypatch):
        from django.core.cache.backends.locmem import LocMemCache

        def explode(*_args, **_kwargs):
            raise ConnectionError("Redis is gone")

        monkeypatch.setattr(LocMemCache, "get", explode)

        # The real backend subclasses RedisCache, but the failure handling under
        # test is the same wrapper; exercising it directly keeps the test from
        # needing a live Redis to kill.
        from common.cache import ResilientRedisCache

        broken = ResilientRedisCache("redis://127.0.0.1:65535/0", {})
        assert broken.get("anything") is None

    def test_a_failing_write_does_not_raise(self):
        from common.cache import ResilientRedisCache

        broken = ResilientRedisCache("redis://127.0.0.1:65535/0", {})

        # No assertion beyond "this returns": the caller has already computed
        # the real answer and is about to return it to the user.
        broken.set("anything", "value")

    def test_a_dashboard_still_renders_with_no_cache(self):
        from common.cache import ResilientRedisCache

        broken = ResilientRedisCache("redis://127.0.0.1:65535/0", {})

        assert broken.get("k", "fallback") == "fallback"
        assert broken.get_many(["a", "b"]) == {}
        assert broken.has_key("k") is False
