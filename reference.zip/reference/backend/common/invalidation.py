"""Retire cached dashboards when the data behind them changes.

Signals rather than explicit calls in each view, for one reason: the same row
can be written from a DRF endpoint, from Django admin, from a management
command or from a Celery task, and a cache invalidated in only some of those
places is worse than one that is never invalidated at all — it is wrong
occasionally and unpredictably, which is the hardest kind of wrong to notice.

Only the *low-volume* tables are wired up here. Commits and review notes are
written in bulk by the thousand during a sync, and a signal per row would be
thousands of round-trips to Redis to achieve what one bump at the end of the
run already achieves — which is why ``sync.pipeline._finish`` does it there.
"""

import logging

from django.db.models.signals import post_delete, post_save

from . import cache

logger = logging.getLogger(__name__)


def _connect(model, *namespaces: str) -> None:
    def invalidate(sender, **_kwargs):
        cache.bump(*namespaces)

    # A distinct dispatch_uid per model keeps a double import (autoreload, a
    # test that reloads apps) from registering the same receiver twice.
    uid = f"cache-invalidate-{model._meta.label_lower}"
    post_save.connect(invalidate, sender=model, weak=False, dispatch_uid=uid)
    post_delete.connect(invalidate, sender=model, weak=False, dispatch_uid=uid)


def register() -> None:
    """Wire the receivers. Called from ``CommonConfig.ready``, so every model
    below is importable by the time this runs."""
    from activity.models import ProjectMember
    from projects.models import GitLabRepo, Project
    from team.models import Assignment, AuthorAlias, Employee, UnmappedAuthor

    # Editing a person or an allocation changes the workload join, the team
    # summary and the leaderboard roster, so both families go.
    for model in (Employee, Assignment, AuthorAlias, UnmappedAuthor):
        _connect(model, cache.TEAM, cache.ACTIVITY)

    # Repository membership decides who counts as being on a project at all.
    # Rewritten wholesale by each sync, but at a few rows per repo rather than
    # a row per commit, so a signal is affordable here.
    _connect(ProjectMember, cache.TEAM, cache.ACTIVITY)

    for model in (Project, GitLabRepo):
        _connect(model, cache.PROJECTS, cache.ACTIVITY)
