from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path


def healthz(_request):
    return JsonResponse({"status": "ok"})


urlpatterns = [
    path("admin/", admin.site.urls),
    path("healthz", healthz),
    path("api/auth/", include("accounts.urls")),
    path("api/team/", include("team.urls")),
    path("api/projects/", include("projects.urls")),
    path("api/activity/", include("activity.urls")),
    path("api/compliance/", include("compliance.urls")),
    path("api/vault/", include("vault.urls")),
    path("api/scoring/", include("scoring.urls")),
    path("api/sync/", include("sync.urls")),
    path("api/gitlab/", include("gitlab_integration.urls")),
]
