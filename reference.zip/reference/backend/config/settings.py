"""Django settings for employee_util_tracker.

All deployment-specific values come from the environment so the same image runs
locally (docker-compose) and on AWS (RDS Postgres + ElastiCache Redis).
"""

from pathlib import Path

import environ

BASE_DIR = Path(__file__).resolve().parent.parent

env = environ.Env(
    DEBUG=(bool, False),
    ALLOWED_HOSTS=(list, ["*"]),
    CORS_ALLOWED_ORIGINS=(list, ["http://localhost:3000"]),
    CSRF_TRUSTED_ORIGINS=(list, ["http://localhost:3000"]),
    SESSION_COOKIE_SECURE=(bool, False),
    CSRF_COOKIE_SECURE=(bool, False),
)

# Read .env from the repo root when present (local dev); on AWS the environment
# is populated by the task definition instead.
_env_file = BASE_DIR.parent / ".env"
if _env_file.exists():
    env.read_env(str(_env_file))

SECRET_KEY = env("DJANGO_SECRET_KEY", default="dev-insecure-key-change-me")
DEBUG = env("DEBUG")
ALLOWED_HOSTS = env("ALLOWED_HOSTS")

# --------------------------------------------------------------------------
# Applications
# --------------------------------------------------------------------------

DJANGO_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]

THIRD_PARTY_APPS = [
    "rest_framework",
    "corsheaders",
    "django_celery_beat",
    "django_celery_results",
]

LOCAL_APPS = [
    "common",
    "accounts",
    "gitlab_integration",
    "team",
    "projects",
    "activity",
    "compliance",
    "vault",
    "scoring",
    "sync",
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

# --------------------------------------------------------------------------
# Database — RDS Postgres in deployment
# --------------------------------------------------------------------------

DATABASES = {
    "default": env.db(
        "DATABASE_URL",
        default="postgres://postgres:postgres@localhost:5432/util_tracker",
    )
}
DATABASES["default"]["CONN_MAX_AGE"] = env.int("DB_CONN_MAX_AGE", default=60)

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
AUTH_USER_MODEL = "accounts.User"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# --------------------------------------------------------------------------
# I18N / static
# --------------------------------------------------------------------------

LANGUAGE_CODE = "en-us"
TIME_ZONE = env("TIME_ZONE", default="UTC")
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
}

# --------------------------------------------------------------------------
# Sessions / CORS / CSRF
#
# Next.js talks to Django server-side and holds only an httpOnly session
# cookie. The GitLab client secret and the Gemini key never reach the browser.
# --------------------------------------------------------------------------

SESSION_COOKIE_NAME = "eut_session"
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_SECURE = env("SESSION_COOKIE_SECURE")
SESSION_COOKIE_AGE = env.int("SESSION_COOKIE_AGE", default=60 * 60 * 12)
CSRF_COOKIE_SECURE = env("CSRF_COOKIE_SECURE")
CSRF_TRUSTED_ORIGINS = env("CSRF_TRUSTED_ORIGINS")
CORS_ALLOWED_ORIGINS = env("CORS_ALLOWED_ORIGINS")
CORS_ALLOW_CREDENTIALS = True

REST_FRAMEWORK = {
    # JWT first: it is what the frontend actually presents. Sessions stay
    # enabled so Django admin and the browsable API keep working for the same
    # person without a second sign-in.
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "accounts.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "accounts.permissions.IsAdminUser",
    ],
    "DEFAULT_RENDERER_CLASSES": [
        "rest_framework.renderers.JSONRenderer",
    ],
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 50,
    "TEST_REQUEST_DEFAULT_FORMAT": "json",
    "DEFAULT_THROTTLE_RATES": {
        # Applies only to the password endpoints, which declare this scope.
        # Everything else is behind admin authentication already.
        "login": env("LOGIN_RATE_LIMIT", default="10/min"),
    },
}

# --------------------------------------------------------------------------
# Authentication
#
# Two ways in — a company password or GitLab OAuth — both ending in the same
# JWT pair, held in httpOnly cookies. The access token is short so a leaked one
# stops working quickly; the refresh token is long and rotated on every use, so
# the tool stops asking for a fresh GitLab sign-in every single day.
# --------------------------------------------------------------------------

JWT_SIGNING_KEY = env("JWT_SIGNING_KEY", default="") or SECRET_KEY
JWT_ACCESS_TTL_SECONDS = env.int("JWT_ACCESS_TTL_SECONDS", default=30 * 60)
JWT_REFRESH_TTL_SECONDS = env.int("JWT_REFRESH_TTL_SECONDS", default=30 * 24 * 60 * 60)
# How long a just-rotated refresh token stays acceptable, so two tabs racing to
# refresh do not read as a stolen token being replayed.
JWT_REFRESH_GRACE_SECONDS = env.int("JWT_REFRESH_GRACE_SECONDS", default=30)

# Password accounts must use a company address. Set to an empty list to accept
# any domain.
ALLOWED_EMAIL_DOMAINS = env.list("ALLOWED_EMAIL_DOMAINS", default=["solargroup.com"])

# The same rule for GitLab sign-in. Off by default because a GitLab account's
# primary address is frequently personal, and turning this on without checking
# would lock out the very administrators who could turn it back off.
ENFORCE_EMAIL_DOMAIN_ON_OAUTH = env.bool("ENFORCE_EMAIL_DOMAIN_ON_OAUTH", default=False)

# --------------------------------------------------------------------------
# Cache — Redis (ElastiCache in deployment)
#
# The dashboards read wide: a utilisation page joins commits, assignments,
# memberships and review notes across every person and every repository, and
# recomputes it on every request. None of that data changes between syncs, so
# it is computed once and served from Redis until a sync says otherwise (see
# ``common.cache``).
#
# A different logical database from the Celery broker on purpose. `FLUSHDB` on
# the cache — or an eviction policy that drops keys under pressure — must never
# be able to take queued jobs with it.
# --------------------------------------------------------------------------


REDIS_URL = env("REDIS_URL", default="redis://localhost:6379/0")


def _cache_url(broker_url: str) -> str:
    """Point the cache at db 1 of the same server the broker uses."""
    base, sep, tail = broker_url.rpartition("/")
    if sep and tail.isdigit():
        return f"{base}/{int(tail) + 1}"
    return f"{broker_url.rstrip('/')}/1"


CACHE_URL = env("CACHE_URL", default=_cache_url(REDIS_URL))
CACHE_DEFAULT_TIMEOUT = env.int("CACHE_DEFAULT_TIMEOUT", default=300)

CACHES = {
    "default": {
        # Not Django's RedisCache directly: a cache that raises when Redis is
        # unreachable turns an optimisation into a hard dependency, and every
        # page would 500 the moment the broker restarts.
        "BACKEND": "common.cache.ResilientRedisCache",
        "LOCATION": CACHE_URL,
        "TIMEOUT": CACHE_DEFAULT_TIMEOUT,
        "KEY_PREFIX": env("CACHE_KEY_PREFIX", default="eut"),
    }
}

# Off in tests, where a shared Redis between runs would leak state across them.
CACHE_ENABLED = env.bool("CACHE_ENABLED", default=True)

# --------------------------------------------------------------------------
# Celery — nightly sync, manual sync, webhook processing, scoring batches
# --------------------------------------------------------------------------

CELERY_BROKER_URL = REDIS_URL
CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = env.int("CELERY_TASK_TIME_LIMIT", default=60 * 30)
CELERY_TASK_SOFT_TIME_LIMIT = env.int("CELERY_TASK_SOFT_TIME_LIMIT", default=60 * 25)
CELERY_BEAT_SCHEDULER = "django_celery_beat.schedulers:DatabaseScheduler"
CELERY_TIMEZONE = TIME_ZONE
CELERY_TASK_ALWAYS_EAGER = env.bool("CELERY_TASK_ALWAYS_EAGER", default=False)

# When the broker is unreachable, run the job in-process instead of failing.
# Convenient locally (the app stays usable without Redis) but it blocks the
# request for the duration of the sync, so it defaults off outside DEBUG.
CELERY_INLINE_FALLBACK = env.bool("CELERY_INLINE_FALLBACK", default=DEBUG)

# Nightly sync time (used to seed the DB-backed beat schedule on first run;
# afterwards it is editable in Django Admin without a deploy).
NIGHTLY_SYNC_HOUR = env.int("NIGHTLY_SYNC_HOUR", default=2)
NIGHTLY_SYNC_MINUTE = env.int("NIGHTLY_SYNC_MINUTE", default=0)

# --------------------------------------------------------------------------
# GitLab
# --------------------------------------------------------------------------

GITLAB_URL = env("GITLAB_URL", default="https://gitlab.com").rstrip("/")
GITLAB_API_URL = f"{GITLAB_URL}/api/v4"

# User OAuth — login and "is this repo accessible to me?" validation only.
GITLAB_OAUTH_CLIENT_ID = env("GITLAB_OAUTH_CLIENT_ID", default="")
GITLAB_OAUTH_CLIENT_SECRET = env("GITLAB_OAUTH_CLIENT_SECRET", default="")
GITLAB_OAUTH_REDIRECT_URI = env(
    "GITLAB_OAUTH_REDIRECT_URI",
    default="http://localhost:8000/api/auth/gitlab/callback",
)
GITLAB_OAUTH_SCOPES = env("GITLAB_OAUTH_SCOPES", default="read_user api")

# Service credential — owns ALL scheduled syncing, repo creation and webhooks.
# Deliberately separate from user OAuth: GitLab access tokens live 2 hours and
# refreshing rotates the refresh token, so a nightly job cannot depend on any
# individual staying logged in (or employed).
GITLAB_SERVICE_TOKEN = env("GITLAB_SERVICE_TOKEN", default="")
GITLAB_GROUP_ID = env("GITLAB_GROUP_ID", default="")
GITLAB_GROUP_PATH = env("GITLAB_GROUP_PATH", default="")

# Webhook verification. Prefer the HMAC-SHA256 signing token over the legacy
# plaintext X-Gitlab-Token header.
GITLAB_WEBHOOK_SIGNING_TOKEN = env("GITLAB_WEBHOOK_SIGNING_TOKEN", default="")
GITLAB_WEBHOOK_SECRET_TOKEN = env("GITLAB_WEBHOOK_SECRET_TOKEN", default="")
GITLAB_WEBHOOK_URL = env("GITLAB_WEBHOOK_URL", default="")

GITLAB_TIMEOUT = env.int("GITLAB_TIMEOUT", default=30)
GITLAB_MAX_RETRIES = env.int("GITLAB_MAX_RETRIES", default=4)
GITLAB_PER_PAGE = env.int("GITLAB_PER_PAGE", default=100)

# Repo defaults when the app has to create one.
GITLAB_DEFAULT_BRANCH = env("GITLAB_DEFAULT_BRANCH", default="main")
GITLAB_DEFAULT_VISIBILITY = env("GITLAB_DEFAULT_VISIBILITY", default="private")
DOCUMENTATION_BRANCH = env("DOCUMENTATION_BRANCH", default="documentation")

# GitLab rate-limits requests over 20MB to 3 per 30s and rejects over 300MB.
MAX_DOCUMENT_UPLOAD_BYTES = env.int("MAX_DOCUMENT_UPLOAD_BYTES", default=20 * 1024 * 1024)

# --------------------------------------------------------------------------
# Sync behaviour
# --------------------------------------------------------------------------

# The nightly sweep re-fetches this window to heal anything webhooks dropped.
# GitLab suppresses push webhooks entirely when a push touches more than 3
# branches, so reconciliation is not optional.
SYNC_LOOKBACK_DAYS = env.int("SYNC_LOOKBACK_DAYS", default=7)
# First sync of a repo reaches back this far.
SYNC_INITIAL_BACKFILL_DAYS = env.int("SYNC_INITIAL_BACKFILL_DAYS", default=365)
# The window the sync buttons use: "catch me up with today", not "reconcile
# everything since the last run". One page of commits per repository rather
# than a week's worth, which is what makes an on-demand sync feel immediate.
SYNC_QUICK_WINDOW_DAYS = env.int("SYNC_QUICK_WINDOW_DAYS", default=1)
BRANCH_STALE_DAYS = env.int("BRANCH_STALE_DAYS", default=30)

# --------------------------------------------------------------------------
# Scoring (Gemini)
# --------------------------------------------------------------------------

GEMINI_API_KEY = env("GEMINI_API_KEY", default="")
GEMINI_MODEL = env("GEMINI_MODEL", default="gemini-3.6-flash")
# Nightly scoring is latency-insensitive and batch pricing is half of
# interactive, so batch is the default path.
GEMINI_USE_BATCH = env.bool("GEMINI_USE_BATCH", default=True)
GEMINI_MAX_DIFF_BYTES = env.int("GEMINI_MAX_DIFF_BYTES", default=24_000)
GEMINI_MAX_LINES_PER_FILE = env.int("GEMINI_MAX_LINES_PER_FILE", default=120)
GEMINI_BATCH_SIZE = env.int("GEMINI_BATCH_SIZE", default=50)
# Scores below this confidence go to a review queue instead of into a person's
# rollup.
SCORING_MIN_CONFIDENCE = env.float("SCORING_MIN_CONFIDENCE", default=0.4)

# Paths excluded from diffs sent to the model: generated, vendored, or lockfiles
# that add tokens without adding signal.
SCORING_IGNORE_PATTERNS = [
    "*.lock", "*-lock.json", "*.lockb", "package-lock.json", "yarn.lock",
    "pnpm-lock.yaml", "poetry.lock", "Pipfile.lock", "Cargo.lock",
    "go.sum", "composer.lock", "*.min.js", "*.min.css", "*.map",
    "*/node_modules/*", "*/vendor/*", "*/dist/*", "*/build/*",
    "*/.next/*", "*/__pycache__/*", "*/migrations/*", "*.svg", "*.png",
    "*.jpg", "*.jpeg", "*.gif", "*.ico", "*.woff", "*.woff2", "*.ttf",
    "*.pdf", "*.docx", "*.xlsx", "*.zip", "*.tar.gz",
]

# --------------------------------------------------------------------------
# Commit cadence
# --------------------------------------------------------------------------

# Weekdays on which a commit is expected, as Python weekday numbers
# (Mon=0 … Sun=6). A quiet Sunday is not a missed day, and marking it as one
# would bury the handful of real gaps under hundreds of false ones.
WORKING_WEEKDAYS = env.list("WORKING_WEEKDAYS", cast=int, default=[0, 1, 2, 3, 4])
# Public holidays and shutdown days, ISO format: 2026-01-26,2026-08-15
NON_WORKING_DATES = env.list("NON_WORKING_DATES", default=[])
COMMIT_CALENDAR_DAYS = env.int("COMMIT_CALENDAR_DAYS", default=90)

# Composite score weights — editable in admin at runtime via ScoringConfig.
SCORING_DEFAULT_WEIGHTS = {
    "relevance": 0.40,
    "substance": 0.25,
    "quality": 0.20,
    "linkage": 0.15,
}

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "{levelname} {asctime} {name} {message}",
            "style": "{",
        },
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "verbose"},
    },
    "root": {"handlers": ["console"], "level": env("LOG_LEVEL", default="INFO")},
    "loggers": {
        "django.db.backends": {"level": "WARNING", "propagate": True},
    },
}
