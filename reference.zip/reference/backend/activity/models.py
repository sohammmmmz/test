"""Synced GitLab activity: commits, branches, merge requests, issues, milestones.

Every model here is upserted on a natural key so the nightly sweep, the manual
sync button and the webhook receiver can all run concurrently without producing
duplicates.
"""

from django.db import models

from common.models import TimeStampedModel


class Commit(TimeStampedModel):
    """A single commit, keyed on (repo, sha).

    ``author_employee`` is nullable on purpose: attribution can fail, and an
    unattributed commit is still a real commit. The email goes to the unmapped
    authors queue rather than the commit being discarded.
    """

    repo = models.ForeignKey(
        "projects.GitLabRepo", on_delete=models.CASCADE, related_name="commits"
    )
    sha = models.CharField(max_length=64, db_index=True)
    short_id = models.CharField(max_length=32, blank=True)

    title = models.TextField(blank=True)
    message = models.TextField(blank=True)

    author_name = models.CharField(max_length=255, blank=True)
    author_email = models.EmailField(blank=True, db_index=True)
    # The GitLab account this commit was attributed to. Git itself carries no
    # such field — it is derived during sync (see ``team.identity``) and stored
    # so attribution is auditable and can be grouped on directly, rather than
    # being re-derived from an email that may not match anything.
    author_username = models.CharField(max_length=255, blank=True, db_index=True)
    committer_name = models.CharField(max_length=255, blank=True)
    committer_email = models.EmailField(blank=True)
    authored_date = models.DateTimeField(db_index=True)
    committed_date = models.DateTimeField(null=True, blank=True)

    author_employee = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="commits",
    )

    web_url = models.URLField(blank=True)
    parent_ids = models.JSONField(default=list, blank=True)
    is_merge_commit = models.BooleanField(default=False)

    additions = models.IntegerField(null=True, blank=True)
    deletions = models.IntegerField(null=True, blank=True)
    total_changes = models.IntegerField(null=True, blank=True)

    # Branches this commit was observed on. A commit can live on several.
    branch_names = models.JSONField(default=list, blank=True)

    # Issue iids referenced in the message (#123, Closes #45). Deterministic,
    # zero-cost, and one of the strongest signals in scoring.
    referenced_issue_iids = models.JSONField(default=list, blank=True)

    # File paths this commit touched. Populated when the diff is fetched (for
    # scoring), so it drives the vault's module clustering too. Commits whose
    # diffs have not been fetched simply contribute nothing rather than being
    # clustered incorrectly.
    changed_paths = models.JSONField(default=list, blank=True)

    # Hash of the normalised diff; the scoring cache key.
    diff_hash = models.CharField(max_length=64, blank=True, db_index=True)
    diff_fetched_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["repo", "sha"], name="uniq_commit_per_repo")
        ]
        indexes = [
            models.Index(fields=["repo", "-authored_date"]),
            models.Index(fields=["author_employee", "-authored_date"]),
        ]
        ordering = ["-authored_date"]

    def __str__(self):
        return f"{self.short_id or self.sha[:8]} {self.title[:50]}"


class Branch(TimeStampedModel):
    """A branch, tracked for attribution and staleness."""

    repo = models.ForeignKey(
        "projects.GitLabRepo", on_delete=models.CASCADE, related_name="branches"
    )
    name = models.CharField(max_length=512)
    is_default = models.BooleanField(default=False)
    is_protected = models.BooleanField(default=False)
    is_merged = models.BooleanField(default=False)

    last_commit_sha = models.CharField(max_length=64, blank=True)
    last_commit_at = models.DateTimeField(null=True, blank=True, db_index=True)
    last_commit_author_email = models.EmailField(blank=True)
    last_commit_author = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="owned_branches",
    )
    web_url = models.URLField(blank=True)

    # Set to False when a sync no longer sees the branch (deleted upstream).
    is_present = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["repo", "name"], name="uniq_branch_per_repo")
        ]
        ordering = ["repo", "name"]
        verbose_name_plural = "branches"

    def __str__(self):
        return f"{self.repo.path_with_namespace}:{self.name}"


class MergeRequest(TimeStampedModel):
    """A merge request, keyed on (repo, iid)."""

    repo = models.ForeignKey(
        "projects.GitLabRepo", on_delete=models.CASCADE, related_name="merge_requests"
    )
    iid = models.PositiveIntegerField()
    gitlab_id = models.BigIntegerField(null=True, blank=True)

    title = models.TextField(blank=True)
    description = models.TextField(blank=True)
    state = models.CharField(max_length=32, blank=True, db_index=True)
    source_branch = models.CharField(max_length=512, blank=True)
    target_branch = models.CharField(max_length=512, blank=True)

    author_gitlab_id = models.BigIntegerField(null=True, blank=True)
    author_employee = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="authored_merge_requests",
    )

    gitlab_created_at = models.DateTimeField(null=True, blank=True)
    gitlab_updated_at = models.DateTimeField(null=True, blank=True)
    merged_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    milestone = models.ForeignKey(
        "activity.Milestone", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="merge_requests",
    )
    labels = models.JSONField(default=list, blank=True)
    web_url = models.URLField(blank=True)

    has_pipeline_success = models.BooleanField(null=True, blank=True)
    user_notes_count = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["repo", "iid"], name="uniq_mr_per_repo")
        ]
        ordering = ["-gitlab_updated_at"]

    def __str__(self):
        return f"!{self.iid} {self.title[:50]}"

    @property
    def cycle_time_hours(self):
        if self.merged_at and self.gitlab_created_at:
            return (self.merged_at - self.gitlab_created_at).total_seconds() / 3600
        return None


class ReviewNote(TimeStampedModel):
    """A comment authored on a merge request.

    Tracked as a first-class contribution signal. Review work is otherwise
    completely invisible to commit-based measurement, which would make a person
    who spends a week unblocking others look idle.
    """

    merge_request = models.ForeignKey(
        MergeRequest, on_delete=models.CASCADE, related_name="notes"
    )
    gitlab_note_id = models.BigIntegerField()
    author_gitlab_id = models.BigIntegerField(null=True, blank=True)
    author_employee = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="review_notes",
    )
    body = models.TextField(blank=True)
    is_system = models.BooleanField(default=False)
    is_resolvable = models.BooleanField(default=False)
    noted_at = models.DateTimeField(db_index=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["merge_request", "gitlab_note_id"], name="uniq_note_per_mr"
            )
        ]
        ordering = ["-noted_at"]

    def __str__(self):
        return f"note {self.gitlab_note_id} on !{self.merge_request.iid}"


class Milestone(TimeStampedModel):
    """A GitLab milestone — the project's timeline, and compliance rule #1."""

    repo = models.ForeignKey(
        "projects.GitLabRepo", on_delete=models.CASCADE, related_name="milestones"
    )
    gitlab_id = models.BigIntegerField()
    iid = models.PositiveIntegerField(null=True, blank=True)

    title = models.CharField(max_length=512)
    description = models.TextField(blank=True)
    state = models.CharField(max_length=32, blank=True, db_index=True)
    start_date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    expired = models.BooleanField(default=False)
    web_url = models.URLField(blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["repo", "gitlab_id"], name="uniq_milestone_per_repo")
        ]
        ordering = ["due_date", "title"]

    def __str__(self):
        return self.title


class Issue(TimeStampedModel):
    """A GitLab issue — the unit of assigned work that commits are scored against."""

    repo = models.ForeignKey(
        "projects.GitLabRepo", on_delete=models.CASCADE, related_name="issues"
    )
    iid = models.PositiveIntegerField()
    gitlab_id = models.BigIntegerField(null=True, blank=True)

    title = models.TextField()
    description = models.TextField(blank=True)
    state = models.CharField(max_length=32, blank=True, db_index=True)
    labels = models.JSONField(default=list, blank=True)

    milestone = models.ForeignKey(
        Milestone, null=True, blank=True, on_delete=models.SET_NULL, related_name="issues"
    )
    assignee_gitlab_ids = models.JSONField(default=list, blank=True)
    assignees = models.ManyToManyField(
        "team.Employee", blank=True, related_name="assigned_issues"
    )

    due_date = models.DateField(null=True, blank=True)
    gitlab_created_at = models.DateTimeField(null=True, blank=True)
    gitlab_updated_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    web_url = models.URLField(blank=True)
    time_estimate_seconds = models.PositiveIntegerField(default=0)
    time_spent_seconds = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["repo", "iid"], name="uniq_issue_per_repo")
        ]
        ordering = ["-gitlab_updated_at"]

    def __str__(self):
        return f"#{self.iid} {self.title[:50]}"


class ProjectMember(TimeStampedModel):
    """A GitLab project member — compliance rule #3, and role ground truth."""

    ACCESS_LEVELS = {
        5: "Minimal access",
        10: "Guest",
        20: "Reporter",
        30: "Developer",
        40: "Maintainer",
        50: "Owner",
    }

    repo = models.ForeignKey(
        "projects.GitLabRepo", on_delete=models.CASCADE, related_name="members"
    )
    gitlab_user_id = models.BigIntegerField()
    username = models.CharField(max_length=255, blank=True)
    name = models.CharField(max_length=255, blank=True)
    # GitLab often omits member emails for privacy, so this is frequently blank
    # and linking has to work from the GitLab account id instead.
    email = models.EmailField(blank=True)
    access_level = models.PositiveSmallIntegerField(default=30)
    employee = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="gitlab_memberships",
    )
    # True when the membership comes from a parent group rather than the project.
    is_inherited = models.BooleanField(default=False)
    expires_at = models.DateField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["repo", "gitlab_user_id"], name="uniq_member_per_repo"
            )
        ]
        ordering = ["-access_level", "username"]

    def __str__(self):
        return f"{self.username} ({self.access_level_display})"

    @property
    def access_level_display(self) -> str:
        return self.ACCESS_LEVELS.get(self.access_level, str(self.access_level))
