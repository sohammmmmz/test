"""Read-only API over synced GitLab activity."""

from django.db.models import Count
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from gitlab_integration.exceptions import GitLabError
from projects.models import Project
from team.models import Employee

from .models import Branch, Commit, Issue, MergeRequest, Milestone, ProjectMember
from .planning import PlanningError, create_issue, create_milestone
from .serializers import (
    BranchSerializer,
    CommitSerializer,
    IssueCreateSerializer,
    IssueSerializer,
    MergeRequestSerializer,
    MilestoneCreateSerializer,
    MilestoneSerializer,
    ProjectMemberSerializer,
)


class _RepoScopedViewSet(viewsets.ReadOnlyModelViewSet):
    """Shared ``?project=`` and ``?employee=`` filtering."""

    project_path = "repo__project_id"
    employee_path: str | None = None

    def get_queryset(self):
        qs = self.queryset
        project_id = self.request.query_params.get("project")
        if project_id:
            qs = qs.filter(**{self.project_path: project_id})
        employee_id = self.request.query_params.get("employee")
        if employee_id and self.employee_path:
            qs = qs.filter(**{self.employee_path: employee_id})
        return qs


class _WritableRepoScopedViewSet(_RepoScopedViewSet, viewsets.mixins.CreateModelMixin):
    """Read-only plus create — writes go to GitLab, never straight to the DB."""


class CommitViewSet(_RepoScopedViewSet):
    queryset = Commit.objects.select_related("repo__project", "author_employee").all()
    serializer_class = CommitSerializer
    employee_path = "author_employee_id"

    def get_queryset(self):
        qs = super().get_queryset()
        since = self.request.query_params.get("since")
        if since:
            qs = qs.filter(authored_date__gte=since)
        branch = self.request.query_params.get("branch")
        if branch:
            qs = qs.filter(branch_names__contains=[branch])
        if self.request.query_params.get("unattributed") == "true":
            qs = qs.filter(author_employee__isnull=True)
        return qs

    @action(detail=False, methods=["get"])
    def activity(self, request):
        """Daily commit counts, for the activity chart."""
        from datetime import timedelta

        days = int(request.query_params.get("days", 30))
        start = timezone.now() - timedelta(days=days)

        qs = self.get_queryset().filter(authored_date__gte=start)
        rows = (
            qs.values("authored_date__date")
            .annotate(count=Count("id"))
            .order_by("authored_date__date")
        )
        return Response(
            [{"date": r["authored_date__date"], "count": r["count"]} for r in rows]
        )


class BranchViewSet(_RepoScopedViewSet):
    queryset = Branch.objects.select_related("repo__project", "last_commit_author").all()
    serializer_class = BranchSerializer
    employee_path = "last_commit_author_id"

    def get_queryset(self):
        qs = super().get_queryset()
        if self.request.query_params.get("stale") == "true":
            from datetime import timedelta

            from django.conf import settings

            cutoff = timezone.now() - timedelta(days=settings.BRANCH_STALE_DAYS)
            qs = qs.filter(is_present=True, is_merged=False, last_commit_at__lt=cutoff)
        return qs


class MergeRequestViewSet(_RepoScopedViewSet):
    queryset = MergeRequest.objects.select_related("repo__project", "author_employee").all()
    serializer_class = MergeRequestSerializer
    employee_path = "author_employee_id"

    def get_queryset(self):
        qs = super().get_queryset()
        state = self.request.query_params.get("state")
        return qs.filter(state=state) if state else qs


class IssueViewSet(_WritableRepoScopedViewSet):
    """Read synced issues, and author new ones into GitLab."""

    queryset = (
        Issue.objects.select_related("repo__project", "milestone")
        .prefetch_related("assignees")
        .all()
    )
    serializer_class = IssueSerializer

    def create(self, request, *args, **kwargs):
        serializer = IssueCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        project = get_object_or_404(Project, pk=data["project"])
        milestone = (
            Milestone.objects.filter(pk=data["milestone"]).first()
            if data.get("milestone")
            else None
        )
        assignees = list(Employee.objects.filter(pk__in=data.get("assignees", [])))

        try:
            issue = create_issue(
                project,
                title=data["title"],
                description=data.get("description", ""),
                milestone=milestone,
                assignees=assignees,
                due_date=data.get("due_date"),
                labels=data.get("labels"),
            )
        except PlanningError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        except GitLabError as exc:
            return Response(
                {"detail": f"GitLab rejected the issue: {exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        return Response(IssueSerializer(issue).data, status=status.HTTP_201_CREATED)

    def get_queryset(self):
        qs = super().get_queryset()
        employee_id = self.request.query_params.get("employee")
        if employee_id:
            qs = qs.filter(assignees__id=employee_id)
        state = self.request.query_params.get("state")
        return qs.filter(state=state) if state else qs


class MilestoneViewSet(_WritableRepoScopedViewSet):
    """Read synced milestones, and author new ones into GitLab."""

    queryset = Milestone.objects.select_related("repo__project").all()
    serializer_class = MilestoneSerializer

    def create(self, request, *args, **kwargs):
        """Create a milestone in GitLab, then mirror it back.

        Written upstream rather than stored only here, so the team's own GitLab
        boards and this tracker can never disagree about the timeline.
        """
        serializer = MilestoneCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        project = get_object_or_404(Project, pk=data["project"])
        try:
            milestone = create_milestone(
                project,
                title=data["title"],
                description=data.get("description", ""),
                start_date=data.get("start_date"),
                due_date=data.get("due_date"),
            )
        except PlanningError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        except GitLabError as exc:
            return Response(
                {"detail": f"GitLab rejected the milestone: {exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        return Response(
            MilestoneSerializer(milestone).data, status=status.HTTP_201_CREATED
        )


class ProjectMemberViewSet(_RepoScopedViewSet):
    queryset = ProjectMember.objects.select_related("repo__project", "employee").all()
    serializer_class = ProjectMemberSerializer
    employee_path = "employee_id"
