from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("commits", views.CommitViewSet, basename="commit")
router.register("branches", views.BranchViewSet, basename="branch")
router.register("merge-requests", views.MergeRequestViewSet, basename="merge-request")
router.register("issues", views.IssueViewSet, basename="issue")
router.register("milestones", views.MilestoneViewSet, basename="milestone")
router.register("members", views.ProjectMemberViewSet, basename="project-member")

urlpatterns = router.urls
