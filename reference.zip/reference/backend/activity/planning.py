"""Authoring project timelines into GitLab.

Everything else in this app reads from GitLab. This module writes: milestones
and issues created here are pushed upstream and then read back, so GitLab
remains the single source of truth and nothing can drift between the two.

The alternative — storing timelines only in this database — would leave the
team's own GitLab boards disagreeing with the tracker, and the boards are what
they actually work from.
"""

from __future__ import annotations

import logging

from django.db import transaction

from gitlab_integration.client import GitLabClient
from projects.models import Project

from .models import Issue, Milestone

logger = logging.getLogger(__name__)


class PlanningError(Exception):
    """A timeline could not be written to GitLab, with a reason for the admin."""


def _repo_or_raise(project: Project):
    repo = getattr(project, "repo", None)
    if repo is None:
        raise PlanningError("This project has no GitLab repository.")
    return repo


@transaction.atomic
def create_milestone(
    project: Project,
    *,
    title: str,
    description: str = "",
    start_date=None,
    due_date=None,
    client: GitLabClient | None = None,
) -> Milestone:
    """Create a milestone in GitLab and mirror it locally."""
    repo = _repo_or_raise(project)
    client = client or GitLabClient.for_service()

    payload = client.create_milestone(
        repo.gitlab_project_id,
        title=title,
        description=description,
        start_date=start_date,
        due_date=due_date,
    )

    milestone, _ = Milestone.objects.update_or_create(
        repo=repo,
        gitlab_id=payload["id"],
        defaults={
            "iid": payload.get("iid"),
            "title": payload.get("title", title),
            "description": payload.get("description", "") or "",
            "state": payload.get("state", "active"),
            "start_date": payload.get("start_date"),
            "due_date": payload.get("due_date"),
            "expired": bool(payload.get("expired")),
            "web_url": payload.get("web_url", "") or "",
        },
    )
    logger.info("Created milestone %r on %s", title, repo.path_with_namespace)
    return milestone


@transaction.atomic
def create_issue(
    project: Project,
    *,
    title: str,
    description: str = "",
    milestone: Milestone | None = None,
    assignees=None,
    due_date=None,
    labels: list[str] | None = None,
    client: GitLabClient | None = None,
) -> Issue:
    """Create an issue in GitLab and mirror it locally.

    Assignees are passed as GitLab account ids, so only employees whose GitLab
    identity is known can be assigned — assigning someone GitLab does not
    recognise would silently produce an unassigned issue.
    """
    repo = _repo_or_raise(project)
    client = client or GitLabClient.for_service()

    employees = list(assignees or [])
    assignee_ids = [e.gitlab_user_id for e in employees if e.gitlab_user_id]
    unknown = [e.full_name for e in employees if not e.gitlab_user_id]
    if unknown:
        raise PlanningError(
            f"No GitLab account is linked for: {', '.join(unknown)}. Link them from "
            "the Team tab before assigning work, otherwise GitLab would drop the "
            "assignment."
        )

    payload = client.create_issue(
        repo.gitlab_project_id,
        title=title,
        description=description,
        milestone_id=milestone.gitlab_id if milestone else None,
        assignee_ids=assignee_ids or None,
        due_date=due_date,
        labels=labels,
    )

    issue, _ = Issue.objects.update_or_create(
        repo=repo,
        iid=payload["iid"],
        defaults={
            "gitlab_id": payload.get("id"),
            "title": payload.get("title", title),
            "description": payload.get("description", "") or "",
            "state": payload.get("state", "opened"),
            "labels": payload.get("labels") or [],
            "milestone": milestone,
            "assignee_gitlab_ids": assignee_ids,
            "due_date": payload.get("due_date"),
            "web_url": payload.get("web_url", "") or "",
        },
    )
    if employees:
        issue.assignees.set(employees)

    logger.info("Created issue #%s on %s", issue.iid, repo.path_with_namespace)
    return issue
