from rest_framework import serializers

from .models import Branch, Commit, Issue, MergeRequest, Milestone, ProjectMember


class CommitSerializer(serializers.ModelSerializer):
    author_display = serializers.SerializerMethodField()
    project_name = serializers.CharField(source="repo.project.name", read_only=True)
    project_id = serializers.IntegerField(source="repo.project_id", read_only=True)
    score = serializers.SerializerMethodField()

    class Meta:
        model = Commit
        fields = [
            "id", "sha", "short_id", "title", "author_name", "author_email",
            "author_employee", "author_display", "authored_date", "web_url",
            "additions", "deletions", "total_changes", "branch_names",
            "referenced_issue_iids", "changed_paths", "is_merge_commit",
            "project_id", "project_name", "score",
        ]

    def get_author_display(self, obj) -> str:
        if obj.author_employee:
            return obj.author_employee.full_name
        # Unattributed is a real state, not a blank — it means the address is
        # sitting in the review queue.
        return f"{obj.author_name or 'Unknown'} (unattributed)"

    def get_score(self, obj):
        score = getattr(obj, "score", None)
        if score is None:
            return None
        return {
            "composite": score.effective_composite,
            "status": score.status,
            "change_kind": score.change_kind,
            "confidence": score.confidence,
            "is_overridden": score.is_overridden,
        }


class BranchSerializer(serializers.ModelSerializer):
    last_commit_author_name = serializers.CharField(
        source="last_commit_author.full_name", read_only=True
    )
    project_name = serializers.CharField(source="repo.project.name", read_only=True)
    days_since_commit = serializers.SerializerMethodField()

    class Meta:
        model = Branch
        fields = [
            "id", "name", "is_default", "is_protected", "is_merged", "is_present",
            "last_commit_sha", "last_commit_at", "last_commit_author",
            "last_commit_author_name", "days_since_commit", "web_url", "project_name",
        ]

    def get_days_since_commit(self, obj):
        if not obj.last_commit_at:
            return None
        from django.utils import timezone

        return (timezone.now() - obj.last_commit_at).days


class MergeRequestSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(source="author_employee.full_name", read_only=True)
    milestone_title = serializers.CharField(source="milestone.title", read_only=True)
    cycle_time_hours = serializers.FloatField(read_only=True)

    class Meta:
        model = MergeRequest
        fields = [
            "id", "iid", "title", "state", "source_branch", "target_branch",
            "author_employee", "author_name", "gitlab_created_at", "merged_at",
            "closed_at", "milestone", "milestone_title", "labels", "web_url",
            "user_notes_count", "cycle_time_hours",
        ]


class MilestoneSerializer(serializers.ModelSerializer):
    issue_count = serializers.SerializerMethodField()
    closed_issue_count = serializers.SerializerMethodField()
    project_name = serializers.CharField(source="repo.project.name", read_only=True)

    class Meta:
        model = Milestone
        fields = [
            "id", "gitlab_id", "iid", "title", "description", "state",
            "start_date", "due_date", "expired", "web_url", "project_name",
            "issue_count", "closed_issue_count",
        ]

    def get_issue_count(self, obj) -> int:
        return obj.issues.count()

    def get_closed_issue_count(self, obj) -> int:
        return obj.issues.filter(state="closed").count()


class IssueSerializer(serializers.ModelSerializer):
    assignee_names = serializers.SerializerMethodField()
    milestone_title = serializers.CharField(source="milestone.title", read_only=True)
    project_name = serializers.CharField(source="repo.project.name", read_only=True)

    class Meta:
        model = Issue
        fields = [
            "id", "iid", "title", "description", "state", "labels", "milestone",
            "milestone_title", "assignees", "assignee_names", "due_date",
            "gitlab_created_at", "gitlab_updated_at", "closed_at", "web_url",
            "time_estimate_seconds", "time_spent_seconds", "project_name",
        ]

    def get_assignee_names(self, obj) -> list[str]:
        return [a.full_name for a in obj.assignees.all()]


class ProjectMemberSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source="employee.full_name", read_only=True)
    access_level_display = serializers.CharField(read_only=True)
    project_name = serializers.CharField(source="repo.project.name", read_only=True)

    class Meta:
        model = ProjectMember
        fields = [
            "id", "gitlab_user_id", "username", "name", "access_level",
            "access_level_display", "employee", "employee_name", "is_inherited",
            "expires_at", "project_name",
        ]


class MilestoneCreateSerializer(serializers.Serializer):
    """Input for authoring a milestone into GitLab."""

    project = serializers.IntegerField()
    title = serializers.CharField(max_length=512)
    description = serializers.CharField(required=False, allow_blank=True, default="")
    start_date = serializers.DateField(required=False, allow_null=True)
    due_date = serializers.DateField(required=False, allow_null=True)

    def validate(self, attrs):
        start, due = attrs.get("start_date"), attrs.get("due_date")
        if start and due and due < start:
            raise serializers.ValidationError(
                {"due_date": "A milestone cannot be due before it starts."}
            )
        if not due:
            # The compliance rule requires a due date, so a milestone without
            # one would be created and immediately reported as non-compliant.
            raise serializers.ValidationError(
                {"due_date": "A due date is required — without one there is no timeline."}
            )
        return attrs


class IssueCreateSerializer(serializers.Serializer):
    """Input for authoring an issue into GitLab."""

    project = serializers.IntegerField()
    title = serializers.CharField(max_length=512)
    description = serializers.CharField(required=False, allow_blank=True, default="")
    milestone = serializers.IntegerField(required=False, allow_null=True)
    assignees = serializers.ListField(
        child=serializers.IntegerField(), required=False, default=list
    )
    due_date = serializers.DateField(required=False, allow_null=True)
    labels = serializers.ListField(
        child=serializers.CharField(), required=False, default=list
    )
