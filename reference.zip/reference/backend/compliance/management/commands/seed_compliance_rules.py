from django.core.management.base import BaseCommand

from compliance.engine import seed_default_rules
from compliance.models import ComplianceRule


class Command(BaseCommand):
    help = "Create the built-in compliance rules if they do not already exist."

    def handle(self, *args, **options):
        created = seed_default_rules()
        total = ComplianceRule.objects.count()
        enabled = ComplianceRule.objects.filter(is_enabled=True).count()

        if created:
            self.stdout.write(self.style.SUCCESS(f"Created {created} rule(s)."))
        else:
            self.stdout.write("All built-in rules already exist; left unchanged.")
        self.stdout.write(f"{total} rule(s) total, {enabled} enabled.")
