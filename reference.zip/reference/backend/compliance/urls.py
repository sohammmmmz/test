from django.urls import path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("rules", views.ComplianceRuleViewSet, basename="compliance-rule")
router.register("evaluations", views.RuleEvaluationViewSet, basename="rule-evaluation")

urlpatterns = [
    path("dashboard", views.dashboard, name="compliance-dashboard"),
    path("matrix", views.compliance_matrix, name="compliance-matrix"),
    path("project/<int:project_id>", views.project_compliance, name="project-compliance"),
    *router.urls,
]
