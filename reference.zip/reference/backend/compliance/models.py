"""Compliance rules engine.

Rather than hardcoding the three project requirements as booleans, each rule is
a row evaluated per project per sync, producing pass/fail plus the evidence
behind the verdict. Adding a fourth rule becomes configuration, not a migration.
"""

from django.db import models

from common.models import TimeStampedModel


class Severity(models.TextChoices):
    CRITICAL = "critical", "Critical"
    WARNING = "warning", "Warning"
    INFO = "info", "Info"


class ComplianceRule(TimeStampedModel):
    """A single checkable requirement.

    ``code`` maps to a checker registered in ``compliance.checkers``.
    """

    code = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    severity = models.CharField(
        max_length=16, choices=Severity.choices, default=Severity.WARNING
    )
    is_enabled = models.BooleanField(default=True)
    # Per-rule tuning, e.g. {"min_milestones": 1, "require_due_date": true}.
    config = models.JSONField(default=dict, blank=True)
    remediation_hint = models.TextField(
        blank=True, help_text="Shown to the admin when the rule fails."
    )
    display_order = models.PositiveSmallIntegerField(default=100)

    class Meta:
        ordering = ["display_order", "code"]

    def __str__(self):
        return f"{self.code} ({self.get_severity_display()})"


class RuleEvaluation(TimeStampedModel):
    """The outcome of one rule against one project at a point in time.

    Kept as history rather than overwritten, so compliance drift over time is
    visible and a regression can be traced to the sync that introduced it.
    """

    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="rule_evaluations"
    )
    rule = models.ForeignKey(
        ComplianceRule, on_delete=models.CASCADE, related_name="evaluations"
    )
    sync_run = models.ForeignKey(
        "sync.SyncRun", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="rule_evaluations",
    )

    passed = models.BooleanField()
    message = models.TextField(blank=True)
    # What the checker actually saw: counts, paths, ids. Makes a verdict
    # arguable instead of opaque.
    evidence = models.JSONField(default=dict, blank=True)
    evaluated_at = models.DateTimeField(db_index=True)
    # True when this is the newest evaluation of this rule for this project;
    # lets the dashboard read current state with one indexed filter.
    is_current = models.BooleanField(default=True, db_index=True)

    class Meta:
        indexes = [
            models.Index(fields=["project", "is_current"]),
            models.Index(fields=["project", "rule", "-evaluated_at"]),
        ]
        ordering = ["-evaluated_at"]

    def __str__(self):
        verdict = "PASS" if self.passed else "FAIL"
        return f"{self.rule.code} {verdict} for {self.project.name}"
