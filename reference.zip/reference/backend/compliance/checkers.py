"""Compliance checkers.

Each checker answers one question about a project and returns a verdict plus
the evidence behind it. Evidence matters: "this project fails the milestone
rule" is an argument, "it has 2 milestones but neither has a due date" is a
fact the admin can act on.

Checkers are registered by code so rules stay data. Adding a fourth requirement
means writing one function and inserting a row, not changing the engine.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field

from django.conf import settings
from django.utils import timezone

from activity.models import Milestone, ProjectMember
from projects.models import Document, DocumentKind, Project

logger = logging.getLogger(__name__)

CheckerFn = Callable[[Project, dict], "CheckResult"]
_REGISTRY: dict[str, CheckerFn] = {}


@dataclass
class CheckResult:
    passed: bool
    message: str
    evidence: dict = field(default_factory=dict)


def checker(code: str):
    def decorator(fn: CheckerFn) -> CheckerFn:
        _REGISTRY[code] = fn
        return fn

    return decorator


def get_checker(code: str) -> CheckerFn | None:
    return _REGISTRY.get(code)


def registered_codes() -> list[str]:
    return sorted(_REGISTRY)


# ---------------------------------------------------------------------------
# Rule 1 — milestones and timelines
# ---------------------------------------------------------------------------


@checker("HAS_MILESTONES")
def check_has_milestones(project: Project, config: dict) -> CheckResult:
    """The project must have milestones that actually express a timeline.

    A milestone with no due date is a label, not a plan, so ``require_due_date``
    defaults to on — otherwise the rule passes for projects with no schedule at
    all, which is precisely the situation it exists to catch.
    """
    minimum = config.get("min_milestones", 1)
    require_due_date = config.get("require_due_date", True)

    repo = getattr(project, "repo", None)
    if repo is None:
        return CheckResult(False, "Project has no repository.", {"milestone_count": 0})

    milestones = list(Milestone.objects.filter(repo=repo))
    active = [m for m in milestones if m.state == "active"]
    dated = [m for m in active if m.due_date]
    qualifying = dated if require_due_date else active

    evidence = {
        "total": len(milestones),
        "active": len(active),
        "active_with_due_date": len(dated),
        "required": minimum,
        "titles": [m.title for m in qualifying[:10]],
    }

    if len(qualifying) >= minimum:
        nearest = min((m.due_date for m in dated), default=None)
        evidence["nearest_due_date"] = nearest.isoformat() if nearest else None
        return CheckResult(
            True, f"{len(qualifying)} active milestone(s) with a timeline.", evidence
        )

    if active and not dated and require_due_date:
        return CheckResult(
            False,
            f"{len(active)} active milestone(s), but none has a due date — "
            "there is no timeline to track against.",
            evidence,
        )
    return CheckResult(
        False,
        f"No milestones defined in GitLab (need at least {minimum}).",
        evidence,
    )


# ---------------------------------------------------------------------------
# Rule 2 — BRD and technical document
# ---------------------------------------------------------------------------


@checker("HAS_DOCUMENTS")
def check_has_documents(project: Project, config: dict) -> CheckResult:
    """Both a BRD and a technical document must exist on the documentation branch.

    Checks the repository rather than only this app's upload records, because a
    document committed by hand is still a document. Falls back to the recorded
    uploads when GitLab cannot be reached, so a network blip does not
    momentarily report every project as non-compliant.
    """
    required = config.get("required_kinds", [DocumentKind.BRD, DocumentKind.TECHNICAL])

    repo = getattr(project, "repo", None)
    if repo is None:
        return CheckResult(False, "Project has no repository.", {})

    recorded = set(
        Document.objects.filter(project=project).values_list("kind", flat=True)
    )
    in_repo: dict[str, str] = {}
    scan_failed = False

    try:
        from projects.documents import find_documents_in_repo

        in_repo = find_documents_in_repo(repo)
    except Exception as exc:  # noqa: BLE001
        scan_failed = True
        logger.warning("Documentation-branch scan failed for %s: %s", project.name, exc)

    present = set(in_repo) | recorded
    missing = [k for k in required if k not in present]

    evidence = {
        "branch": settings.DOCUMENTATION_BRANCH,
        "found_in_repo": in_repo,
        "recorded_uploads": sorted(recorded),
        "missing": missing,
        "repo_scan_failed": scan_failed,
    }

    if not missing:
        return CheckResult(True, "BRD and technical document are both present.", evidence)

    labels = {DocumentKind.BRD: "BRD", DocumentKind.TECHNICAL: "technical document"}
    names = ", ".join(labels.get(k, k) for k in missing)
    return CheckResult(
        False,
        f"Missing on the '{settings.DOCUMENTATION_BRANCH}' branch: {names}.",
        evidence,
    )


# ---------------------------------------------------------------------------
# Rule 3 — members
# ---------------------------------------------------------------------------


@checker("HAS_MEMBERS")
def check_has_members(project: Project, config: dict) -> CheckResult:
    """The project must have real members with write access.

    The service account is excluded from the count: it is on every repository
    by construction, so counting it would make every project pass.
    """
    minimum = config.get("min_members", 1)
    min_access = config.get("min_access_level", 30)  # Developer

    repo = getattr(project, "repo", None)
    if repo is None:
        return CheckResult(False, "Project has no repository.", {"member_count": 0})

    members = list(ProjectMember.objects.filter(repo=repo, access_level__gte=min_access))
    service_username = (settings.GITLAB_GROUP_PATH or "").lower()
    people = [
        m
        for m in members
        if not m.username.lower().startswith("group_")
        and m.username.lower() != service_username
    ]

    evidence = {
        "with_write_access": len(members),
        "excluding_service_accounts": len(people),
        "required": minimum,
        "usernames": [m.username for m in people[:20]],
        "unmatched_to_employees": [m.username for m in people if m.employee_id is None][:20],
    }

    if len(people) >= minimum:
        return CheckResult(True, f"{len(people)} member(s) with write access.", evidence)

    if members and not people:
        return CheckResult(
            False,
            "Only service accounts have access — no team members are assigned in GitLab.",
            evidence,
        )
    return CheckResult(
        False, f"No members with Developer access (need at least {minimum}).", evidence
    )


# ---------------------------------------------------------------------------
# Optional extra rules — disabled by default, enabled from the admin.
# ---------------------------------------------------------------------------


@checker("NO_STALE_BRANCHES")
def check_no_stale_branches(project: Project, config: dict) -> CheckResult:
    """Flag unmerged branches with no commits for a configurable period."""
    from activity.models import Branch

    max_days = config.get("max_stale_days", settings.BRANCH_STALE_DAYS)
    cutoff = timezone.now() - timezone.timedelta(days=max_days)

    repo = getattr(project, "repo", None)
    if repo is None:
        return CheckResult(False, "Project has no repository.", {})

    stale = list(
        Branch.objects.filter(
            repo=repo, is_present=True, is_merged=False, last_commit_at__lt=cutoff
        ).exclude(is_default=True)[:50]
    )

    evidence = {
        "max_stale_days": max_days,
        "stale_branches": [
            {"name": b.name, "last_commit_at": b.last_commit_at.isoformat()}
            for b in stale
            if b.last_commit_at
        ],
    }

    if not stale:
        return CheckResult(True, f"No unmerged branches idle over {max_days} days.", evidence)
    return CheckResult(
        False,
        f"{len(stale)} unmerged branch(es) with no commits in {max_days}+ days.",
        evidence,
    )


@checker("HAS_ACTIVITY")
def check_has_activity(project: Project, config: dict) -> CheckResult:
    """Flag projects with no commits at all in a recent window."""
    from activity.models import Commit

    max_days = config.get("max_idle_days", 14)
    cutoff = timezone.now() - timezone.timedelta(days=max_days)

    repo = getattr(project, "repo", None)
    if repo is None:
        return CheckResult(False, "Project has no repository.", {})

    recent = Commit.objects.filter(repo=repo, authored_date__gte=cutoff).count()
    evidence = {
        "window_days": max_days,
        "commits_in_window": recent,
        "last_activity_at": (
            project.last_activity_at.isoformat() if project.last_activity_at else None
        ),
    }

    if recent:
        return CheckResult(True, f"{recent} commit(s) in the last {max_days} days.", evidence)
    return CheckResult(False, f"No commits in the last {max_days} days.", evidence)
