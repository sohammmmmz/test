from rest_framework import serializers

from .checkers import registered_codes
from .models import ComplianceRule, RuleEvaluation


class ComplianceRuleSerializer(serializers.ModelSerializer):
    has_checker = serializers.SerializerMethodField()

    class Meta:
        model = ComplianceRule
        fields = [
            "id", "code", "name", "description", "severity", "is_enabled",
            "config", "remediation_hint", "display_order", "has_checker",
        ]

    def get_has_checker(self, obj) -> bool:
        return obj.code in registered_codes()

    def validate_code(self, value):
        if value not in registered_codes():
            raise serializers.ValidationError(
                f"No checker is registered for '{value}'. Available: "
                f"{', '.join(registered_codes())}."
            )
        return value


class RuleEvaluationSerializer(serializers.ModelSerializer):
    rule_code = serializers.CharField(source="rule.code", read_only=True)
    rule_name = serializers.CharField(source="rule.name", read_only=True)
    severity = serializers.CharField(source="rule.severity", read_only=True)
    remediation_hint = serializers.CharField(source="rule.remediation_hint", read_only=True)
    project_name = serializers.CharField(source="project.name", read_only=True)

    class Meta:
        model = RuleEvaluation
        fields = [
            "id", "project", "project_name", "rule", "rule_code", "rule_name",
            "severity", "passed", "message", "evidence", "remediation_hint",
            "evaluated_at", "is_current",
        ]
