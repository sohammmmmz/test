"""Evaluating compliance rules against projects."""

from __future__ import annotations

import logging

from django.db import transaction
from django.utils import timezone

from projects.models import HealthState, Project

from .checkers import get_checker
from .models import ComplianceRule, RuleEvaluation, Severity

logger = logging.getLogger(__name__)


@transaction.atomic
def evaluate_project(project: Project, *, sync_run=None) -> list[RuleEvaluation]:
    """Run every enabled rule against a project and refresh its health.

    Previous evaluations are kept but demoted from ``is_current``, so compliance
    drift stays traceable to the sync that introduced it.
    """
    rules = ComplianceRule.objects.filter(is_enabled=True)
    now = timezone.now()
    evaluations: list[RuleEvaluation] = []

    RuleEvaluation.objects.filter(project=project, is_current=True).update(is_current=False)

    for rule in rules:
        fn = get_checker(rule.code)
        if fn is None:
            logger.warning("Rule %s has no registered checker; skipping", rule.code)
            continue

        try:
            result = fn(project, rule.config or {})
        except Exception as exc:  # noqa: BLE001 - a broken checker is a failed check
            logger.exception("Checker %s raised for %s", rule.code, project.name)
            evaluations.append(
                RuleEvaluation(
                    project=project, rule=rule, sync_run=sync_run, passed=False,
                    message=f"Check could not be completed: {exc}",
                    evidence={"error": str(exc)}, evaluated_at=now, is_current=True,
                )
            )
            continue

        evaluations.append(
            RuleEvaluation(
                project=project, rule=rule, sync_run=sync_run, passed=result.passed,
                message=result.message, evidence=result.evidence,
                evaluated_at=now, is_current=True,
            )
        )

    RuleEvaluation.objects.bulk_create(evaluations)
    _refresh_health(project, evaluations, now)
    return evaluations


def _refresh_health(project: Project, evaluations: list[RuleEvaluation], now) -> None:
    """Denormalise a health verdict onto the project for list views.

    Severity drives the state rather than the raw pass rate: a project missing
    its BRD is not "80% healthy", it is failing something that was declared
    mandatory.
    """
    if not evaluations:
        Project.objects.filter(pk=project.pk).update(
            health_state=HealthState.UNKNOWN, health_score=0, last_evaluated_at=now
        )
        return

    passed = sum(1 for e in evaluations if e.passed)
    score = round(100 * passed / len(evaluations))

    failed = [e for e in evaluations if not e.passed]
    if any(e.rule.severity == Severity.CRITICAL for e in failed):
        state = HealthState.CRITICAL
    elif failed:
        state = HealthState.WARNING
    else:
        state = HealthState.HEALTHY

    Project.objects.filter(pk=project.pk).update(
        health_state=state, health_score=score, last_evaluated_at=now
    )
    project.health_state, project.health_score = state, score


def evaluate_all_projects(*, sync_run=None) -> dict:
    counts = {"projects": 0, "passed": 0, "failed": 0}
    for project in Project.objects.select_related("repo").exclude(status="archived"):
        evaluations = evaluate_project(project, sync_run=sync_run)
        counts["projects"] += 1
        counts["passed"] += sum(1 for e in evaluations if e.passed)
        counts["failed"] += sum(1 for e in evaluations if not e.passed)
    return counts


DEFAULT_RULES = [
    {
        "code": "HAS_MILESTONES",
        "name": "Milestones and timelines",
        "description": (
            "The project must have at least one active GitLab milestone with a due "
            "date, so there is a timeline to track progress against."
        ),
        "severity": Severity.CRITICAL,
        "config": {"min_milestones": 1, "require_due_date": True},
        "remediation_hint": (
            "Open the project in GitLab, go to Plan > Milestones, and create a "
            "milestone with a start and due date."
        ),
        "display_order": 10,
    },
    {
        "code": "HAS_DOCUMENTS",
        "name": "BRD and technical document",
        "description": (
            "Both a business requirements document and a technical document must "
            "exist on the documentation branch."
        ),
        "severity": Severity.CRITICAL,
        "config": {"required_kinds": ["brd", "technical"]},
        "remediation_hint": (
            "Upload the missing document from the project page; it will be "
            "committed to the documentation branch automatically."
        ),
        "display_order": 20,
    },
    {
        "code": "HAS_MEMBERS",
        "name": "Members assigned",
        "description": (
            "At least one real team member must have Developer access in GitLab. "
            "Service accounts do not count."
        ),
        "severity": Severity.CRITICAL,
        "config": {"min_members": 1, "min_access_level": 30},
        "remediation_hint": "Add team members to the GitLab project with the Developer role.",
        "display_order": 30,
    },
    {
        "code": "NO_STALE_BRANCHES",
        "name": "No stale branches",
        "description": "Unmerged branches should not sit idle indefinitely.",
        "severity": Severity.WARNING,
        "is_enabled": False,
        "config": {"max_stale_days": 30},
        "remediation_hint": "Merge or delete branches that are no longer being worked on.",
        "display_order": 40,
    },
    {
        "code": "HAS_ACTIVITY",
        "name": "Recent activity",
        "description": "The project should have commits in the recent past.",
        "severity": Severity.INFO,
        "is_enabled": False,
        "config": {"max_idle_days": 14},
        "remediation_hint": "Confirm the project is still active, or move it to On hold.",
        "display_order": 50,
    },
]


def seed_default_rules() -> int:
    """Create the built-in rules if they do not exist. Idempotent.

    Existing rows are left alone so admin retuning survives redeploys.
    """
    created = 0
    for spec in DEFAULT_RULES:
        spec = dict(spec)
        code = spec.pop("code")
        _obj, was_created = ComplianceRule.objects.get_or_create(code=code, defaults=spec)
        created += int(was_created)
    return created
