"""Tests for the compliance rules engine and its three mandatory rules."""

from datetime import date, timedelta

import pytest
import responses
from django.utils import timezone

from activity.models import Milestone, ProjectMember
from compliance.checkers import check_has_documents, check_has_members, check_has_milestones
from compliance.engine import evaluate_project, seed_default_rules
from compliance.models import ComplianceRule, RuleEvaluation, Severity
from projects.models import Document, DocumentKind, HealthState

API = "https://gitlab.example.com/api/v4"

pytestmark = pytest.mark.django_db


@pytest.fixture
def rules(db):
    seed_default_rules()
    return ComplianceRule.objects.filter(is_enabled=True)


class TestHasMilestones:
    def test_passes_with_an_active_dated_milestone(self, project, repo):
        Milestone.objects.create(
            repo=repo, gitlab_id=1, title="M1", state="active",
            due_date=date(2026, 9, 1),
        )

        result = check_has_milestones(project, {})

        assert result.passed
        assert result.evidence["active_with_due_date"] == 1

    def test_fails_when_milestones_have_no_due_date(self, project, repo):
        """A milestone with no due date is a label, not a plan — and this rule
        exists precisely to catch projects with no schedule."""
        Milestone.objects.create(repo=repo, gitlab_id=1, title="Someday", state="active")

        result = check_has_milestones(project, {})

        assert not result.passed
        assert "none has a due date" in result.message

    def test_passes_without_due_dates_when_configured_to(self, project, repo):
        Milestone.objects.create(repo=repo, gitlab_id=1, title="Someday", state="active")

        assert check_has_milestones(project, {"require_due_date": False}).passed

    def test_fails_with_no_milestones_at_all(self, project, repo):
        result = check_has_milestones(project, {})

        assert not result.passed
        assert "No milestones defined" in result.message

    def test_closed_milestones_do_not_count(self, project, repo):
        Milestone.objects.create(
            repo=repo, gitlab_id=1, title="Done", state="closed",
            due_date=date(2026, 1, 1),
        )

        assert not check_has_milestones(project, {}).passed


class TestHasDocuments:
    def test_passes_when_both_documents_are_in_the_repo(
        self, project, repo, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[
                {"type": "blob", "name": "BRD.pdf", "path": "docs/BRD.pdf"},
                {"type": "blob", "name": "TECHNICAL.md", "path": "docs/TECHNICAL.md"},
            ],
        )

        result = check_has_documents(project, {})

        assert result.passed

    def test_names_the_missing_document(self, project, repo, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[{"type": "blob", "name": "BRD.pdf", "path": "docs/BRD.pdf"}],
        )

        result = check_has_documents(project, {})

        assert not result.passed
        assert "technical document" in result.message
        assert result.evidence["missing"] == ["technical"]

    def test_falls_back_to_recorded_uploads_when_gitlab_is_unreachable(
        self, project, repo, mocked_responses
    ):
        """A network blip must not report every project as non-compliant."""
        for kind in (DocumentKind.BRD, DocumentKind.TECHNICAL):
            Document.objects.create(
                project=project, kind=kind, filename=f"{kind}.pdf",
                repo_path=f"docs/{kind}.pdf", content_hash="h",
            )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json={"message": "500"}, status=500,
        )

        result = check_has_documents(project, {})

        assert result.passed
        assert result.evidence["repo_scan_failed"] is True


class TestHasMembers:
    def test_passes_with_a_developer(self, project, repo, employee):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya",
            access_level=30, employee=employee,
        )

        assert check_has_members(project, {}).passed

    def test_guests_do_not_count(self, project, repo):
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1, username="observer", access_level=10
        )

        assert not check_has_members(project, {}).passed

    def test_service_accounts_are_excluded(self, project, repo):
        """The service account is on every repository by construction, so
        counting it would make every project pass."""
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=2, username="group_555_bot", access_level=40
        )

        result = check_has_members(project, {})

        assert not result.passed
        assert "Only service accounts" in result.message


class TestEvaluateProject:
    def test_records_one_evaluation_per_enabled_rule(self, project, repo, rules, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree", json=[]
        )

        evaluations = evaluate_project(project)

        assert len(evaluations) == rules.count()
        assert RuleEvaluation.objects.filter(is_current=True).count() == rules.count()

    def test_failing_a_critical_rule_marks_the_project_critical(
        self, project, repo, rules, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree", json=[]
        )

        evaluate_project(project)

        project.refresh_from_db()
        assert project.health_state == HealthState.CRITICAL
        assert project.health_score == 0

    def test_a_fully_compliant_project_is_healthy(
        self, project, repo, employee, rules, mocked_responses
    ):
        Milestone.objects.create(
            repo=repo, gitlab_id=1, title="M1", state="active",
            due_date=timezone.localdate() + timedelta(days=30),
        )
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya",
            access_level=30, employee=employee,
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[
                {"type": "blob", "name": "BRD.pdf", "path": "docs/BRD.pdf"},
                {"type": "blob", "name": "TECHNICAL.md", "path": "docs/TECHNICAL.md"},
            ],
        )

        evaluate_project(project)

        project.refresh_from_db()
        assert project.health_state == HealthState.HEALTHY
        assert project.health_score == 100

    def test_previous_evaluations_are_kept_as_history(
        self, project, repo, rules, mocked_responses
    ):
        for _ in range(2):
            mocked_responses.add(
                responses.GET, f"{API}/projects/555/repository/tree", json=[]
            )

        evaluate_project(project)
        evaluate_project(project)

        assert RuleEvaluation.objects.count() == rules.count() * 2
        assert RuleEvaluation.objects.filter(is_current=True).count() == rules.count()

    def test_a_broken_checker_fails_the_rule_rather_than_the_run(self, project, repo, db):
        ComplianceRule.objects.create(
            code="HAS_MILESTONES", name="Milestones", severity=Severity.WARNING
        )

        from unittest.mock import patch

        with patch("compliance.engine.get_checker") as mock:
            mock.return_value = lambda *_a, **_k: (_ for _ in ()).throw(RuntimeError("boom"))
            evaluations = evaluate_project(project)

        assert len(evaluations) == 1
        assert evaluations[0].passed is False
        assert "boom" in evaluations[0].message

    def test_an_unregistered_rule_code_is_skipped(self, project, repo, db):
        ComplianceRule.objects.create(code="NOT_REAL", name="Nope")

        assert evaluate_project(project) == []


class TestSeeding:
    def test_is_idempotent(self, db):
        assert seed_default_rules() == 5
        assert seed_default_rules() == 0
        assert ComplianceRule.objects.count() == 5

    def test_admin_retuning_survives_reseeding(self, db):
        seed_default_rules()
        ComplianceRule.objects.filter(code="HAS_MILESTONES").update(
            is_enabled=False, config={"min_milestones": 3}
        )

        seed_default_rules()

        rule = ComplianceRule.objects.get(code="HAS_MILESTONES")
        assert rule.is_enabled is False
        assert rule.config == {"min_milestones": 3}


class TestEndpoints:
    def test_dashboard_lists_failing_rules(
        self, api_client, project, repo, rules, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree", json=[]
        )
        evaluate_project(project)

        data = api_client.get("/api/compliance/dashboard").json()

        assert data["project_count"] == 1
        assert data["warning_count"] == 3
        assert {w["rule_code"] for w in data["warnings"]} == {
            "HAS_MILESTONES",
            "HAS_DOCUMENTS",
            "HAS_MEMBERS",
        }

    def test_matrix_returns_a_grid(self, api_client, project, repo, rules, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree", json=[]
        )
        evaluate_project(project)

        data = api_client.get("/api/compliance/matrix").json()

        assert len(data["rules"]) == 3
        assert len(data["projects"][0]["results"]) == 3

    def test_rule_creation_rejects_an_unknown_code(self, api_client):
        response = api_client.post(
            "/api/compliance/rules/", {"code": "MADE_UP", "name": "x", "severity": "warning"}
        )

        assert response.status_code == 400
        assert "No checker is registered" in str(response.json())
