from django.db.models import Count, Q
from rest_framework import viewsets
from rest_framework.decorators import action, api_view
from rest_framework.response import Response

from activity.models import Commit
from projects.models import HealthState, Project, ProjectStatus
from sync.models import RunStatus, SyncRun
from team.models import UnmappedAuthor

from .engine import evaluate_project
from .models import ComplianceRule, RuleEvaluation
from .serializers import ComplianceRuleSerializer, RuleEvaluationSerializer


class ComplianceRuleViewSet(viewsets.ModelViewSet):
    queryset = ComplianceRule.objects.all()
    serializer_class = ComplianceRuleSerializer


class RuleEvaluationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = RuleEvaluationSerializer

    def get_queryset(self):
        qs = RuleEvaluation.objects.select_related("rule", "project")
        project_id = self.request.query_params.get("project")
        if project_id:
            qs = qs.filter(project_id=project_id)
        if self.request.query_params.get("history") != "true":
            qs = qs.filter(is_current=True)
        if self.request.query_params.get("failed_only") == "true":
            qs = qs.filter(passed=False)
        return qs

    @action(detail=False, methods=["post"], url_path="evaluate")
    def evaluate(self, request):
        """Re-run the rules now, without waiting for a sync."""
        project_id = request.data.get("project")
        projects = Project.objects.select_related("repo")
        if project_id:
            projects = projects.filter(pk=project_id)

        results = {}
        for project in projects:
            evaluations = evaluate_project(project)
            results[project.slug] = {
                "passed": sum(1 for e in evaluations if e.passed),
                "failed": sum(1 for e in evaluations if not e.passed),
            }
        return Response(results)


@api_view(["GET"])
def dashboard(request):
    """Aggregates for the landing page."""
    projects = Project.objects.exclude(status=ProjectStatus.ARCHIVED)
    total = projects.count()

    failing = (
        RuleEvaluation.objects.filter(is_current=True, passed=False)
        .select_related("rule", "project")
        .order_by("rule__display_order", "project__name")
    )

    last_sync = (
        SyncRun.objects.filter(
            parent__isnull=True, status__in=[RunStatus.SUCCESS, RunStatus.PARTIAL, RunStatus.FAILED]
        )
        .order_by("-finished_at")
        .first()
    )

    stale_count = sum(1 for p in projects if p.is_stale)

    return Response(
        {
            "project_count": total,
            "active_project_count": projects.filter(status=ProjectStatus.ACTIVE).count(),
            "compliant_project_count": projects.filter(
                health_state=HealthState.HEALTHY
            ).count(),
            "critical_project_count": projects.filter(
                health_state=HealthState.CRITICAL
            ).count(),
            "warning_count": failing.count(),
            "stale_project_count": stale_count,
            "unmapped_author_count": UnmappedAuthor.objects.filter(
                resolved_to__isnull=True, is_ignored=False
            ).count(),
            "commit_count": Commit.objects.count(),
            "last_sync": (
                {
                    "id": last_sync.id,
                    "status": last_sync.status,
                    "trigger": last_sync.trigger,
                    "finished_at": last_sync.finished_at,
                    "duration_seconds": last_sync.duration_seconds,
                }
                if last_sync
                else None
            ),
            "warnings": [
                {
                    "project_id": e.project_id,
                    "project_name": e.project.name,
                    "project_slug": e.project.slug,
                    "rule_code": e.rule.code,
                    "rule_name": e.rule.name,
                    "severity": e.rule.severity,
                    "message": e.message,
                    "remediation_hint": e.rule.remediation_hint,
                }
                for e in failing[:100]
            ],
        }
    )


@api_view(["GET"])
def project_compliance(request, project_id: int):
    """Current rule verdicts for one project, including passing ones."""
    project = Project.objects.get(pk=project_id)
    evaluations = (
        RuleEvaluation.objects.filter(project=project, is_current=True)
        .select_related("rule")
        .order_by("rule__display_order")
    )
    return Response(
        {
            "project": {
                "id": project.id,
                "name": project.name,
                "health_state": project.health_state,
                "health_score": project.health_score,
                "last_evaluated_at": project.last_evaluated_at,
            },
            "rules": RuleEvaluationSerializer(evaluations, many=True).data,
        }
    )


@api_view(["GET"])
def compliance_matrix(request):
    """Project-by-rule grid for an at-a-glance view of the whole portfolio."""
    rules = list(ComplianceRule.objects.filter(is_enabled=True))
    projects = (
        Project.objects.exclude(status=ProjectStatus.ARCHIVED)
        .annotate(
            failed=Count(
                "rule_evaluations",
                filter=Q(rule_evaluations__is_current=True, rule_evaluations__passed=False),
            )
        )
        .order_by("name")
    )

    current = {
        (e.project_id, e.rule_id): e
        for e in RuleEvaluation.objects.filter(is_current=True)
    }

    return Response(
        {
            "rules": [
                {"id": r.id, "code": r.code, "name": r.name, "severity": r.severity}
                for r in rules
            ],
            "projects": [
                {
                    "id": p.id,
                    "name": p.name,
                    "slug": p.slug,
                    "health_state": p.health_state,
                    "health_score": p.health_score,
                    "results": [
                        {
                            "rule_id": r.id,
                            "passed": (
                                current[(p.id, r.id)].passed
                                if (p.id, r.id) in current
                                else None
                            ),
                            "message": (
                                current[(p.id, r.id)].message
                                if (p.id, r.id) in current
                                else "Not yet evaluated"
                            ),
                        }
                        for r in rules
                    ],
                }
                for p in projects
            ],
        }
    )
