import logging

from django.conf import settings
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response

from gitlab_integration.exceptions import (
    GitLabAuthError,
    GitLabError,
    GitLabInsufficientScope,
)
from gitlab_integration.oauth import get_user_client
from team.models import Employee

from .documents import DocumentUploadError, upload_document
from .models import Project
from .serializers import (
    DocumentSerializer,
    DocumentUploadSerializer,
    ProjectListSerializer,
    ProjectRegistrationSerializer,
    ProjectSerializer,
    RepoValidationRequestSerializer,
)
from .services import RepoValidationError, register_project, validate_repo_reference

logger = logging.getLogger(__name__)


class ProjectViewSet(viewsets.ModelViewSet):
    queryset = (
        Project.objects.select_related("repo", "owner")
        .prefetch_related("documents")
        .all()
    )
    serializer_class = ProjectSerializer

    def get_serializer_class(self):
        if self.action == "list":
            return ProjectListSerializer
        return ProjectSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        status_filter = self.request.query_params.get("status")
        if status_filter:
            qs = qs.filter(status=status_filter)
        health = self.request.query_params.get("health_state")
        if health:
            qs = qs.filter(health_state=health)
        return qs

    def create(self, request, *args, **kwargs):
        """Register a project, validating or creating its mandatory repository."""
        serializer = ProjectRegistrationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        try:
            user_client = get_user_client(request.user)
        except GitLabAuthError as exc:
            return Response(
                {"detail": str(exc), "code": "gitlab_reauthorize_required"},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        owner = None
        if data.get("owner_id"):
            owner = Employee.objects.filter(pk=data["owner_id"]).first()

        try:
            project = register_project(
                name=data["name"],
                description=data.get("description", ""),
                repo_reference=data.get("repo_reference") or None,
                user_client=user_client,
                owner=owner,
                status=data.get("status"),
                started_on=data.get("started_on"),
                target_end_on=data.get("target_end_on"),
            )
        except RepoValidationError as exc:
            return Response(
                {"detail": str(exc.message), "code": "repo_validation_failed"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except GitLabError as exc:
            logger.exception("Project registration failed")
            return Response(
                {"detail": str(exc), "code": "gitlab_error"},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        # The code map is what lets scoring judge a change against the code it
        # touches, so it is built up front rather than on first sync.
        from sync.dispatch import dispatch_task
        from sync.tasks import index_project_code_task

        indexing = dispatch_task(index_project_code_task, project.pk)

        payload = ProjectSerializer(project).data
        payload["indexing"] = {
            "queued": indexing.queued,
            "ran_inline": indexing.ran_inline,
            "detail": indexing.detail,
        }
        return Response(payload, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"])
    def members(self, request, pk=None):
        """GitLab members of this project, and whether each is on the roster.

        Shown per project because that is where the question arises: you are
        looking at a repository and want to know who has access and whether
        the tool knows who they are.
        """
        from activity.models import ProjectMember

        project = self.get_object()
        repo = getattr(project, "repo", None)
        if repo is None:
            return Response({"members": [], "unlinked_count": 0})

        rows = (
            ProjectMember.objects.filter(repo=repo)
            .select_related("employee")
            .order_by("-access_level", "username")
        )
        return Response(
            {
                "members": [
                    {
                        "gitlab_user_id": m.gitlab_user_id,
                        "username": m.username,
                        "name": m.name,
                        "email": m.email,
                        "access_level": m.access_level,
                        "access_level_display": m.access_level_display,
                        "employee": (
                            {
                                "id": m.employee.id,
                                "full_name": m.employee.full_name,
                                "department": m.employee.department,
                                "designation": m.employee.designation,
                                "employment_type": m.employee.employment_type,
                            }
                            if m.employee
                            else None
                        ),
                    }
                    for m in rows
                ],
                "unlinked_count": sum(1 for m in rows if m.employee_id is None),
            }
        )

    def destroy(self, request, *args, **kwargs):
        """Delete a project and everything derived from it.

        The GitLab repository is deliberately left alone — this app tracks
        repositories, it does not own them, and deleting someone's code because
        they stopped tracking it would be indefensible.
        """
        project = self.get_object()
        name = project.name
        repo_path = project.repo.path_with_namespace if hasattr(project, "repo") else None

        # Counted before deletion so the response can say what actually went.
        from activity.models import Branch, Commit, Issue, MergeRequest, Milestone
        from vault.code_models import CodeFile, CodeSymbol
        from vault.models import VaultNode

        removed = {
            "commits": Commit.objects.filter(repo__project=project).count(),
            "branches": Branch.objects.filter(repo__project=project).count(),
            "merge_requests": MergeRequest.objects.filter(repo__project=project).count(),
            "issues": Issue.objects.filter(repo__project=project).count(),
            "milestones": Milestone.objects.filter(repo__project=project).count(),
            "documents": project.documents.count(),
            "vault_nodes": VaultNode.objects.filter(project=project).count(),
            "code_files": CodeFile.objects.filter(project=project).count(),
            "code_symbols": CodeSymbol.objects.filter(project=project).count(),
            "assignments": project.assignments.count(),
        }

        project.delete()
        logger.info("Deleted project %s (%s) and all derived records", name, repo_path)

        return Response(
            {
                "deleted": name,
                "repository_kept": repo_path,
                "removed": removed,
                "detail": (
                    f"'{name}' and all its tracked data were removed. The GitLab "
                    f"repository {repo_path or ''} was not touched."
                ),
            },
            status=status.HTTP_200_OK,
        )

    @action(detail=False, methods=["get"], url_path="available-repos")
    def available_repos(self, request):
        """Search repositories that can be linked, across every namespace.

        Searched with the service token rather than the caller's, because that
        is the identity that will do the syncing — so everything returned here
        is guaranteed to work once registered, with no per-repo setup.

        `?search=` is passed to GitLab rather than filtered locally: this runs
        on every keystroke, so enumerating the whole account each time is what
        made the picker slow. With no query it returns a single page of the
        most recently active repositories, which costs one request.

        A query that looks like a path or URL is resolved directly first, so a
        pasted link lands on its project immediately.
        """
        from gitlab_integration.client import GitLabClient

        from .models import GitLabRepo
        from .services import MIN_SEARCH_LENGTH, resolve_repo_reference, search_accessible_repos

        if not settings.GITLAB_SERVICE_TOKEN:
            return Response(
                {
                    "detail": (
                        "GITLAB_SERVICE_TOKEN is not set, so no repositories can be "
                        "listed. A Personal Access Token from your own account with "
                        "the 'api' scope makes everything you can access available "
                        "here."
                    ),
                    "code": "service_token_missing",
                    "repos": [],
                },
                status=status.HTTP_200_OK,
            )

        query = request.query_params.get("search", "").strip()
        # Below the threshold a query matches most of an account, so the round
        # trip is skipped rather than wasted.
        if query and len(query) < MIN_SEARCH_LENGTH:
            return Response(
                {
                    "count": 0,
                    "repos": [],
                    "query": query,
                    "code": "query_too_short",
                    "detail": f"Type at least {MIN_SEARCH_LENGTH} characters to search.",
                }
            )

        try:
            client = GitLabClient.for_service()

            direct = resolve_repo_reference(client, query) if query else None
            repos = search_accessible_repos(client, query=query)

            if direct:
                # Surface the exact match first, without duplicating it.
                repos = [direct] + [r for r in repos if r.get("id") != direct.get("id")]
        except GitLabInsufficientScope:
            return Response(
                {
                    "detail": (
                        "GITLAB_SERVICE_TOKEN is valid but does not carry the 'api' "
                        "scope, so it cannot list projects. Scopes cannot be added "
                        "to an existing token — create a new one with 'api' ticked "
                        "and replace the value in your .env."
                    ),
                    "code": "service_token_scope",
                    "repos": [],
                },
                status=status.HTTP_200_OK,
            )
        except GitLabAuthError:
            return Response(
                {
                    "detail": (
                        "GITLAB_SERVICE_TOKEN was rejected by GitLab — it is "
                        "invalid, revoked, or expired."
                    ),
                    "code": "service_token_invalid",
                    "repos": [],
                },
                status=status.HTTP_200_OK,
            )
        except GitLabError as exc:
            return Response(
                {"detail": str(exc), "code": "gitlab_error", "repos": []},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        linked = {
            row["gitlab_project_id"]: row["project__name"]
            for row in GitLabRepo.objects.values("gitlab_project_id", "project__name")
        }

        return Response(
            {
                "count": len(repos),
                "query": query,
                "matched_directly": bool(direct),
                "repos": [
                    {
                        "gitlab_project_id": r["id"],
                        "name": r.get("name", ""),
                        "path_with_namespace": r.get("path_with_namespace", ""),
                        "namespace": (r.get("namespace") or {}).get("full_path", ""),
                        "web_url": r.get("web_url", ""),
                        "default_branch": r.get("default_branch"),
                        "visibility": r.get("visibility", ""),
                        "last_activity_at": r.get("last_activity_at"),
                        "linked_to": linked.get(r["id"]),
                    }
                    for r in repos
                ],
            }
        )

    @action(detail=False, methods=["post"], url_path="validate-repo")
    def validate_repo(self, request):
        """Pre-flight check so the admin sees problems before submitting."""
        serializer = RepoValidationRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            user_client = get_user_client(request.user)
            validation = validate_repo_reference(
                serializer.validated_data["repo_reference"], user_client
            )
        except RepoValidationError as exc:
            return Response(
                {"valid": False, "detail": str(exc.message)}, status=status.HTTP_200_OK
            )
        except GitLabAuthError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_401_UNAUTHORIZED)

        return Response(
            {
                "valid": validation.is_usable,
                "path_with_namespace": validation.path_with_namespace,
                "gitlab_project_id": validation.gitlab_project_id,
                "name": validation.name,
                "web_url": validation.web_url,
                "default_branch": validation.default_branch,
                "visibility": validation.visibility,
                "already_linked_to": validation.already_linked_to,
                "detail": (
                    f"Already linked to '{validation.already_linked_to}'."
                    if validation.already_linked_to
                    else "Repository is accessible to you and to the sync service account."
                ),
            }
        )

    @action(
        detail=True,
        methods=["get", "post"],
        url_path="documents",
        parser_classes=[MultiPartParser, FormParser, JSONParser],
    )
    def documents(self, request, pk=None):
        """List the project's documents, or upload one to the documentation branch."""
        project = self.get_object()

        if request.method == "GET":
            return Response(DocumentSerializer(project.documents.all(), many=True).data)

        repo = getattr(project, "repo", None)
        if repo is None:
            return Response(
                {"detail": "This project has no repository."},
                status=status.HTTP_409_CONFLICT,
            )

        serializer = DocumentUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        upload = serializer.validated_data["file"]

        try:
            document = upload_document(
                repo,
                kind=serializer.validated_data["kind"],
                filename=upload.name,
                raw=upload.read(),
                uploaded_by=request.user,
                content_type=getattr(upload, "content_type", "") or "",
            )
        except DocumentUploadError as exc:
            return Response(
                {"detail": str(exc.message)}, status=status.HTTP_400_BAD_REQUEST
            )
        except GitLabError as exc:
            logger.exception("Document commit failed for %s", project.name)
            return Response({"detail": str(exc)}, status=status.HTTP_502_BAD_GATEWAY)

        return Response(DocumentSerializer(document).data, status=status.HTTP_201_CREATED)
