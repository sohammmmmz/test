"""Committing BRD and technical documents to the documentation branch.

Documents are uploaded through the app but stored in git, on a dedicated
``documentation`` branch alongside the generated vault. That keeps them
versioned with the project, verifiable by the compliance checker as a real file
existence check, and readable by anyone who clones the repo.

Branch creation is not a separate step. Passing ``start_branch`` on the commit
call creates the branch as part of the same commit, so "create the branch if
missing, then add the file" is one atomic operation rather than a two-call
sequence that can leave an empty branch behind if the second call fails.
"""

from __future__ import annotations

import base64
import hashlib
import logging
from dataclasses import dataclass

from django.conf import settings
from django.utils import timezone

from gitlab_integration.client import GitLabClient
from gitlab_integration.exceptions import GitLabError, GitLabNotFound

from .models import Document, DocumentKind, GitLabRepo

logger = logging.getLogger(__name__)

DOC_DIRECTORY = "docs"

# Text extensions are committed as UTF-8 so they diff properly in git; anything
# else goes up base64-encoded.
TEXT_EXTENSIONS = {".md", ".txt", ".rst", ".adoc", ".csv", ".json", ".yaml", ".yml"}


class DocumentUploadError(GitLabError):
    """The document could not be committed, with a reason for the admin."""


@dataclass
class PreparedFile:
    path: str
    content: str
    encoding: str
    size_bytes: int
    content_hash: str


def prepare_file(filename: str, raw: bytes, kind: str) -> PreparedFile:
    """Validate size and encode the payload for the commit API."""
    if not raw:
        raise DocumentUploadError(f"{filename} is empty.")

    limit = settings.MAX_DOCUMENT_UPLOAD_BYTES
    if len(raw) > limit:
        # GitLab throttles requests over 20MB to 3 per 30 seconds and rejects
        # anything over 300MB outright, so the cap is enforced before the call.
        raise DocumentUploadError(
            f"{filename} is {len(raw) / 1_048_576:.1f}MB, over the "
            f"{limit / 1_048_576:.0f}MB limit for repository uploads."
        )

    suffix = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    safe_name = _safe_filename(filename, kind)
    path = f"{DOC_DIRECTORY}/{safe_name}"
    content_hash = hashlib.sha256(raw).hexdigest()

    if suffix in TEXT_EXTENSIONS:
        try:
            return PreparedFile(path, raw.decode("utf-8"), "text", len(raw), content_hash)
        except UnicodeDecodeError:
            pass  # Mislabelled binary; fall through to base64.

    return PreparedFile(
        path, base64.b64encode(raw).decode("ascii"), "base64", len(raw), content_hash
    )


def _safe_filename(filename: str, kind: str) -> str:
    """Normalise to a predictable name so the compliance check knows where to look."""
    suffix = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    stem = "BRD" if kind == DocumentKind.BRD else "TECHNICAL"
    # Strip anything that could escape the docs/ directory.
    suffix = "".join(c for c in suffix if c.isalnum() or c == ".")[:12]
    return f"{stem}{suffix}"


def ensure_documentation_branch(repo: GitLabRepo, client: GitLabClient | None = None) -> bool:
    """Make sure the documentation branch exists, creating it if not.

    Returns True when the branch already existed. Callers that are about to
    commit do not need this — ``commit_documents`` handles creation atomically —
    but the vault mirror uses it to decide whether it can read current state.
    """
    client = client or GitLabClient.for_service()
    branch = settings.DOCUMENTATION_BRANCH

    if client.branch_exists(repo.gitlab_project_id, branch):
        if not repo.documentation_branch_ready:
            repo.documentation_branch_ready = True
            repo.save(update_fields=["documentation_branch_ready", "updated_at"])
        return True

    client.create_commit(
        repo.gitlab_project_id,
        branch=branch,
        commit_message=f"Create {branch} branch",
        actions=[
            {
                "action": "create",
                "file_path": f"{DOC_DIRECTORY}/README.md",
                "content": _docs_readme(repo),
            }
        ],
        start_branch=repo.default_branch,
    )
    repo.documentation_branch_ready = True
    repo.save(update_fields=["documentation_branch_ready", "updated_at"])
    return False


def _docs_readme(repo: GitLabRepo) -> str:
    return (
        f"# {repo.project.name} — documentation\n\n"
        "Maintained by Employee Util Tracker.\n\n"
        f"- `{DOC_DIRECTORY}/BRD.*` — business requirements document\n"
        f"- `{DOC_DIRECTORY}/TECHNICAL.*` — technical document\n"
        "- `vault/` — generated project-state vault (open in Obsidian)\n"
    )


def commit_documents(
    repo: GitLabRepo,
    files: list[tuple[str, PreparedFile]],
    *,
    client: GitLabClient | None = None,
    commit_message: str | None = None,
) -> dict:
    """Commit prepared documents to the documentation branch in one commit.

    ``files`` is a list of ``(kind, PreparedFile)``.
    """
    if not files:
        raise DocumentUploadError("No documents were supplied.")

    client = client or GitLabClient.for_service()
    branch = settings.DOCUMENTATION_BRANCH
    branch_exists = client.branch_exists(repo.gitlab_project_id, branch)

    actions = []
    for _kind, prepared in files:
        # `create` fails if the path exists and `update` fails if it does not,
        # so the action depends on current branch content.
        action = "create"
        if branch_exists and client.file_exists(repo.gitlab_project_id, prepared.path, branch):
            action = "update"
        actions.append(
            {
                "action": action,
                "file_path": prepared.path,
                "content": prepared.content,
                "encoding": prepared.encoding,
            }
        )

    if not branch_exists:
        actions.insert(
            0,
            {
                "action": "create",
                "file_path": f"{DOC_DIRECTORY}/README.md",
                "content": _docs_readme(repo),
            },
        )

    kinds = ", ".join(sorted({k for k, _ in files}))
    result = client.create_commit(
        repo.gitlab_project_id,
        branch=branch,
        commit_message=commit_message or f"Add/update project documents ({kinds})",
        actions=actions,
        # Only on first creation: passing start_branch for an existing branch
        # makes GitLab reject the commit.
        start_branch=repo.default_branch if not branch_exists else None,
    )

    if not repo.documentation_branch_ready:
        repo.documentation_branch_ready = True
        repo.save(update_fields=["documentation_branch_ready", "updated_at"])

    return result


def upload_document(
    repo: GitLabRepo,
    *,
    kind: str,
    filename: str,
    raw: bytes,
    uploaded_by=None,
    content_type: str = "",
) -> Document:
    """Prepare, commit and record a single project document."""
    prepared = prepare_file(filename, raw, kind)

    existing = Document.objects.filter(project=repo.project, kind=kind).first()
    if existing and existing.content_hash == prepared.content_hash:
        logger.info("%s for %s is unchanged; skipping commit", kind, repo.project.name)
        return existing

    result = commit_documents(repo, [(kind, prepared)])

    document, _ = Document.objects.update_or_create(
        project=repo.project,
        kind=kind,
        defaults={
            "filename": filename,
            "repo_path": prepared.path,
            "content_type": content_type,
            "size_bytes": prepared.size_bytes,
            "content_hash": prepared.content_hash,
            "committed_sha": (result or {}).get("id", ""),
            "committed_at": timezone.now(),
            "uploaded_by": uploaded_by,
            # A new file invalidates the previous extraction.
            "summary": "",
            "summary_model_version": "",
            "summary_generated_at": None,
        },
    )
    return document


def find_documents_in_repo(repo: GitLabRepo, client: GitLabClient | None = None) -> dict[str, str]:
    """Scan the documentation branch for documents present in git.

    Used by the compliance checker so the verdict reflects the repository
    rather than only what was uploaded through this app — someone may have
    committed a BRD by hand.
    """
    client = client or GitLabClient.for_service()
    branch = settings.DOCUMENTATION_BRANCH
    found: dict[str, str] = {}

    try:
        entries = list(client.list_tree(repo.gitlab_project_id, ref=branch, path=DOC_DIRECTORY))
    except GitLabNotFound:
        return found

    for entry in entries:
        if entry.get("type") != "blob":
            continue
        stem = entry["name"].rsplit(".", 1)[0].upper()
        if stem == "BRD":
            found[DocumentKind.BRD] = entry["path"]
        elif stem in ("TECHNICAL", "TECH", "TECHNICAL_DESIGN"):
            found[DocumentKind.TECHNICAL] = entry["path"]

    return found
