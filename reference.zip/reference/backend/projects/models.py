"""Projects and their mandatory GitLab repositories."""

from django.db import models
from django.utils import timezone

from common.models import TimeStampedModel


class ProjectStatus(models.TextChoices):
    PLANNING = "planning", "Planning"
    ACTIVE = "active", "Active"
    ON_HOLD = "on_hold", "On hold"
    COMPLETED = "completed", "Completed"
    ARCHIVED = "archived", "Archived"


class HealthState(models.TextChoices):
    HEALTHY = "healthy", "Healthy"
    WARNING = "warning", "Warning"
    CRITICAL = "critical", "Critical"
    UNKNOWN = "unknown", "Not yet evaluated"


class Project(TimeStampedModel):
    """A tracked project. Always backed by exactly one GitLab repo."""

    name = models.CharField(max_length=255, unique=True)
    slug = models.SlugField(max_length=255, unique=True)
    description = models.TextField(blank=True)
    status = models.CharField(
        max_length=32, choices=ProjectStatus.choices, default=ProjectStatus.PLANNING
    )
    started_on = models.DateField(null=True, blank=True)
    target_end_on = models.DateField(null=True, blank=True)

    owner = models.ForeignKey(
        "team.Employee", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="owned_projects",
    )

    # Denormalised from the latest compliance evaluation so list views do not
    # have to aggregate on every request.
    health_state = models.CharField(
        max_length=16, choices=HealthState.choices, default=HealthState.UNKNOWN
    )
    health_score = models.PositiveIntegerField(
        default=0, help_text="0-100, share of rules passing."
    )
    last_evaluated_at = models.DateTimeField(null=True, blank=True)

    # Denormalised activity markers, refreshed by sync.
    last_activity_at = models.DateTimeField(null=True, blank=True, db_index=True)
    last_synced_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    @property
    def is_stale(self) -> bool:
        if self.last_activity_at is None:
            return True
        return (timezone.now() - self.last_activity_at).days > 14


class GitLabRepo(TimeStampedModel):
    """The GitLab repository backing a project.

    Mandatory and one-to-one: a project without a repository is not a valid
    project, so registration either validates a supplied repo or creates one.
    """

    project = models.OneToOneField(Project, on_delete=models.CASCADE, related_name="repo")

    gitlab_project_id = models.BigIntegerField(unique=True, db_index=True)
    path_with_namespace = models.CharField(max_length=512, unique=True)
    name = models.CharField(max_length=255)
    web_url = models.URLField()
    ssh_url_to_repo = models.CharField(max_length=512, blank=True)
    http_url_to_repo = models.CharField(max_length=512, blank=True)
    default_branch = models.CharField(max_length=255, default="main")
    visibility = models.CharField(max_length=32, default="private")
    namespace_id = models.BigIntegerField(null=True, blank=True)
    namespace_path = models.CharField(max_length=512, blank=True)

    # True when this app created the repo rather than linking an existing one.
    created_by_app = models.BooleanField(default=False)
    # Set once the documentation branch exists.
    documentation_branch_ready = models.BooleanField(default=False)

    gitlab_created_at = models.DateTimeField(null=True, blank=True)
    last_activity_at = models.DateTimeField(null=True, blank=True)

    # Cursor for incremental sync: the newest commit date seen so far.
    last_commit_synced_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "GitLab repository"
        verbose_name_plural = "GitLab repositories"

    def __str__(self):
        return self.path_with_namespace


class DocumentKind(models.TextChoices):
    BRD = "brd", "Business Requirements Document"
    TECHNICAL = "technical", "Technical Document"


class Document(TimeStampedModel):
    """A BRD or technical document committed to the documentation branch.

    The file itself lives in git, not in this database — the row records where
    it landed, what it hashes to, and the model-extracted summary that gives
    commit scoring real business context to judge relevance against.
    """

    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="documents")
    kind = models.CharField(max_length=32, choices=DocumentKind.choices)
    filename = models.CharField(max_length=255)
    repo_path = models.CharField(max_length=512, help_text="Path on the documentation branch.")
    content_type = models.CharField(max_length=128, blank=True)
    size_bytes = models.PositiveBigIntegerField(default=0)
    content_hash = models.CharField(max_length=64, db_index=True)

    committed_sha = models.CharField(max_length=64, blank=True)
    committed_at = models.DateTimeField(null=True, blank=True)
    uploaded_by = models.ForeignKey(
        "accounts.User", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="uploaded_documents",
    )

    # Populated by the Gemini extraction step; feeds the scoring prompt.
    summary = models.TextField(blank=True)
    summary_model_version = models.CharField(max_length=64, blank=True)
    summary_generated_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["project", "kind"], name="uniq_document_per_kind")
        ]
        ordering = ["project", "kind"]

    def __str__(self):
        return f"{self.get_kind_display()} for {self.project.name}"
