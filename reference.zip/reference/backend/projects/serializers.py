from rest_framework import serializers

from .models import Document, GitLabRepo, Project, ProjectStatus


class GitLabRepoSerializer(serializers.ModelSerializer):
    class Meta:
        model = GitLabRepo
        fields = [
            "gitlab_project_id", "path_with_namespace", "name", "web_url",
            "ssh_url_to_repo", "http_url_to_repo", "default_branch", "visibility",
            "namespace_path", "created_by_app", "documentation_branch_ready",
            "last_activity_at", "last_commit_synced_at",
        ]


class DocumentSerializer(serializers.ModelSerializer):
    kind_display = serializers.CharField(source="get_kind_display", read_only=True)

    class Meta:
        model = Document
        fields = [
            "id", "kind", "kind_display", "filename", "repo_path", "size_bytes",
            "content_hash", "committed_sha", "committed_at", "summary",
            "summary_model_version", "summary_generated_at",
        ]


class ProjectSerializer(serializers.ModelSerializer):
    repo = GitLabRepoSerializer(read_only=True)
    documents = DocumentSerializer(many=True, read_only=True)
    owner_name = serializers.CharField(source="owner.full_name", read_only=True)
    is_stale = serializers.BooleanField(read_only=True)
    member_count = serializers.SerializerMethodField()
    assignment_count = serializers.SerializerMethodField()

    class Meta:
        model = Project
        fields = [
            "id", "name", "slug", "description", "status", "started_on", "target_end_on",
            "owner", "owner_name", "health_state", "health_score", "last_evaluated_at",
            "last_activity_at", "last_synced_at", "is_stale", "repo", "documents",
            "member_count", "assignment_count", "created_at",
        ]
        read_only_fields = ["slug", "health_state", "health_score", "last_evaluated_at"]

    def get_member_count(self, obj) -> int:
        repo = getattr(obj, "repo", None)
        return repo.members.count() if repo else 0

    def get_assignment_count(self, obj) -> int:
        return obj.assignments.count()


class ProjectListSerializer(serializers.ModelSerializer):
    repo_path = serializers.CharField(source="repo.path_with_namespace", read_only=True)
    repo_url = serializers.CharField(source="repo.web_url", read_only=True)
    is_stale = serializers.BooleanField(read_only=True)

    class Meta:
        model = Project
        fields = [
            "id", "name", "slug", "status", "health_state", "health_score",
            "last_activity_at", "last_synced_at", "is_stale", "repo_path", "repo_url",
        ]


class ProjectRegistrationSerializer(serializers.Serializer):
    """Input for registering a project.

    ``repo_reference`` is optional: leaving it blank means "create a repository
    for me". It is never optional for the resulting project to *have* one.
    """

    name = serializers.CharField(max_length=255)
    description = serializers.CharField(required=False, allow_blank=True, default="")
    repo_reference = serializers.CharField(
        required=False, allow_blank=True, default="",
        help_text="GitLab URL or namespace/path. Blank creates a new repository.",
    )
    owner_id = serializers.IntegerField(required=False, allow_null=True)
    status = serializers.ChoiceField(
        choices=ProjectStatus.choices, required=False, default=ProjectStatus.PLANNING
    )
    started_on = serializers.DateField(required=False, allow_null=True)
    target_end_on = serializers.DateField(required=False, allow_null=True)

    def validate_name(self, value):
        if Project.objects.filter(name__iexact=value.strip()).exists():
            raise serializers.ValidationError("A project with this name already exists.")
        return value.strip()

    def validate(self, attrs):
        started, target = attrs.get("started_on"), attrs.get("target_end_on")
        if started and target and target < started:
            raise serializers.ValidationError(
                {"target_end_on": "The target end date cannot precede the start date."}
            )
        return attrs


class RepoValidationRequestSerializer(serializers.Serializer):
    repo_reference = serializers.CharField()


class DocumentUploadSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=["brd", "technical"])
    file = serializers.FileField()
