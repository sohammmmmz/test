"""Tests for repo reference parsing, validation and project registration."""

import json

import pytest
import responses

from gitlab_integration.client import GitLabClient
from projects.models import GitLabRepo, Project
from projects.repo_url import InvalidRepoReference, parse_repo_reference
from projects.services import (
    RepoValidationError,
    create_repo_for_project,
    register_project,
    validate_repo_reference,
)

API = "https://gitlab.example.com/api/v4"
GITLAB = "https://gitlab.example.com"

PROJECT_PAYLOAD = {
    "id": 555,
    "name": "Apollo",
    "path_with_namespace": "acme/apollo",
    "web_url": f"{GITLAB}/acme/apollo",
    "ssh_url_to_repo": "git@gitlab.example.com:acme/apollo.git",
    "http_url_to_repo": f"{GITLAB}/acme/apollo.git",
    "default_branch": "main",
    "visibility": "private",
    "namespace": {"id": 42, "full_path": "acme"},
}


class TestParseRepoReference:
    @pytest.mark.parametrize(
        "reference",
        [
            "acme/apollo",
            "https://gitlab.example.com/acme/apollo",
            "https://gitlab.example.com/acme/apollo.git",
            "https://gitlab.example.com/acme/apollo/",
            "git@gitlab.example.com:acme/apollo.git",
            "ssh://git@gitlab.example.com/acme/apollo.git",
            "https://gitlab.example.com/acme/apollo/-/tree/main",
            "https://gitlab.example.com/acme/apollo/-/merge_requests/12",
        ],
    )
    def test_accepts_every_form_people_paste(self, reference):
        assert parse_repo_reference(reference, gitlab_url=GITLAB) == "acme/apollo"

    def test_handles_nested_subgroups(self):
        assert (
            parse_repo_reference("https://gitlab.example.com/acme/team/apollo", gitlab_url=GITLAB)
            == "acme/team/apollo"
        )

    def test_rejects_a_different_gitlab_host(self):
        with pytest.raises(InvalidRepoReference, match="not the configured GitLab host"):
            parse_repo_reference("https://github.com/acme/apollo", gitlab_url=GITLAB)

    @pytest.mark.parametrize("reference", ["", "   ", "apollo", "/"])
    def test_rejects_unusable_input(self, reference):
        with pytest.raises(InvalidRepoReference):
            parse_repo_reference(reference, gitlab_url=GITLAB)


@pytest.fixture
def user_client():
    return GitLabClient(token="user-tok", api_url=API, token_kind="user", max_retries=0)


@pytest.mark.django_db
class TestValidateRepoReference:
    def test_accepts_a_repo_both_identities_can_see(self, user_client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fapollo", json=PROJECT_PAYLOAD
        )
        mocked_responses.add(responses.GET, f"{API}/projects/555", json=PROJECT_PAYLOAD)

        validation = validate_repo_reference("acme/apollo", user_client)

        assert validation.is_usable
        assert validation.gitlab_project_id == 555
        assert validation.namespace_id == 42

    def test_rejects_a_repo_the_admin_cannot_see(self, user_client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fghost",
            json={"message": "404 Project Not Found"}, status=404,
        )

        with pytest.raises(RepoValidationError, match="not visible to your GitLab account"):
            validate_repo_reference("acme/ghost", user_client)

    def test_rejects_when_the_service_account_lacks_access(self, user_client, mocked_responses):
        """Registering would otherwise succeed and then never sync."""
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fapollo", json=PROJECT_PAYLOAD
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555", json={"message": "404"}, status=404
        )

        with pytest.raises(RepoValidationError, match="GITLAB_SERVICE_TOKEN cannot"):
            validate_repo_reference("acme/apollo", user_client)

    def test_reports_a_repo_already_linked_elsewhere(self, user_client, mocked_responses, repo):
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fapollo", json=PROJECT_PAYLOAD
        )
        mocked_responses.add(responses.GET, f"{API}/projects/555", json=PROJECT_PAYLOAD)

        validation = validate_repo_reference("acme/apollo", user_client)

        assert validation.already_linked_to == repo.project.name
        assert not validation.is_usable

    def test_defaults_branch_when_gitlab_reports_none(self, user_client, mocked_responses):
        """A freshly created empty project reports default_branch as null."""
        payload = {**PROJECT_PAYLOAD, "default_branch": None}
        mocked_responses.add(responses.GET, f"{API}/projects/acme%2Fapollo", json=payload)
        mocked_responses.add(responses.GET, f"{API}/projects/555", json=payload)

        assert validate_repo_reference("acme/apollo", user_client).default_branch == "main"


@pytest.mark.django_db
class TestCreateRepo:
    def test_creates_under_the_configured_group(self, mocked_responses):
        mocked_responses.add(
            responses.POST, f"{API}/projects", json=PROJECT_PAYLOAD, status=201
        )

        create_repo_for_project("Apollo", description="d")

        body = json.loads(mocked_responses.calls[0].request.body)
        assert body["namespace_id"] == "42"
        assert body["initialize_with_readme"] is True
        assert body["path"] == "apollo"

    # A group is no longer required — without one, GitLab creates the project
    # in the token owner's own namespace. Covered in test_discovery.py.

    def test_surfaces_a_path_collision_readably(self, mocked_responses):
        mocked_responses.add(
            responses.POST, f"{API}/projects",
            json={"message": {"path": ["has already been taken"]}}, status=400,
        )

        with pytest.raises(RepoValidationError, match="may already exist"):
            create_repo_for_project("Apollo")


@pytest.mark.django_db
class TestRegisterProject:
    def test_links_an_existing_repo(self, user_client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fapollo", json=PROJECT_PAYLOAD
        )
        mocked_responses.add(responses.GET, f"{API}/projects/555", json=PROJECT_PAYLOAD)

        project = register_project(
            name="Apollo", user_client=user_client, repo_reference="acme/apollo"
        )

        assert project.repo.gitlab_project_id == 555
        assert project.repo.created_by_app is False
        assert project.slug == "apollo"

    def test_creates_a_repo_when_none_is_supplied(self, user_client, mocked_responses):
        """Every project must have a repository, so absence means create."""
        mocked_responses.add(
            responses.POST, f"{API}/projects", json=PROJECT_PAYLOAD, status=201
        )

        project = register_project(name="Apollo", user_client=user_client)

        assert project.repo.created_by_app is True
        assert project.repo.path_with_namespace == "acme/apollo"

    def test_refuses_to_link_a_repo_twice(self, user_client, mocked_responses, repo):
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fapollo", json=PROJECT_PAYLOAD
        )
        mocked_responses.add(responses.GET, f"{API}/projects/555", json=PROJECT_PAYLOAD)

        with pytest.raises(RepoValidationError, match="already linked"):
            register_project(
                name="Apollo II", user_client=user_client, repo_reference="acme/apollo"
            )

    def test_registration_is_atomic_when_the_repo_step_fails(
        self, user_client, mocked_responses
    ):
        """A half-registered project with no repo would violate the core invariant."""
        mocked_responses.add(
            responses.POST, f"{API}/projects", json={"message": "boom"}, status=400
        )

        with pytest.raises(RepoValidationError):
            register_project(name="Apollo", user_client=user_client)

        assert Project.objects.count() == 0
        assert GitLabRepo.objects.count() == 0

    def test_slug_collisions_get_a_suffix(self, user_client, mocked_responses, project):
        payload = {**PROJECT_PAYLOAD, "id": 777, "path_with_namespace": "acme/apollo-2"}
        mocked_responses.add(responses.POST, f"{API}/projects", json=payload, status=201)

        second = register_project(name="Apollo!", user_client=user_client)

        assert second.slug == "apollo-2"


@pytest.mark.django_db
class TestEndpoints:
    def test_validate_repo_returns_a_readable_failure(
        self, api_client, mocked_responses, admin_user
    ):
        from accounts.models import GitLabOAuthToken

        GitLabOAuthToken.objects.create(user=admin_user, access_token="at", refresh_token="rt")
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fghost", json={"message": "404"}, status=404
        )

        response = api_client.post(
            "/api/projects/validate-repo/", {"repo_reference": "acme/ghost"}
        )

        assert response.status_code == 200
        assert response.json()["valid"] is False
        assert "not visible" in response.json()["detail"]

    def test_registration_rejects_a_duplicate_name(self, api_client, project):
        response = api_client.post("/api/projects/", {"name": "Apollo"})

        assert response.status_code == 400
        assert "already exists" in str(response.json())

    def test_registration_requires_a_gitlab_connection(self, api_client):
        response = api_client.post("/api/projects/", {"name": "Brand New"})

        assert response.status_code == 401
        assert response.json()["code"] == "gitlab_reauthorize_required"
