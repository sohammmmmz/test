"""Tests for committing documents onto the documentation branch."""

import base64
import json

import pytest
import responses

from projects.documents import (
    DocumentUploadError,
    commit_documents,
    ensure_documentation_branch,
    find_documents_in_repo,
    prepare_file,
    upload_document,
)
from projects.models import Document, DocumentKind

API = "https://gitlab.example.com/api/v4"
COMMITS_URL = f"{API}/projects/555/repository/commits"
BRANCH_URL = f"{API}/projects/555/repository/branches/documentation"

pytestmark = pytest.mark.django_db


def _commit_body(mocked_responses, index=-1):
    return json.loads(mocked_responses.calls[index].request.body)


class TestPrepareFile:
    def test_markdown_is_committed_as_utf8_text(self):
        prepared = prepare_file("brd.md", b"# Requirements", DocumentKind.BRD)

        assert prepared.encoding == "text"
        assert prepared.content == "# Requirements"
        assert prepared.path == "docs/BRD.md"

    def test_binary_is_base64_encoded(self):
        raw = b"%PDF-1.7\x00\x01binary"
        prepared = prepare_file("requirements.pdf", raw, DocumentKind.BRD)

        assert prepared.encoding == "base64"
        assert base64.b64decode(prepared.content) == raw
        assert prepared.path == "docs/BRD.pdf"

    def test_mislabelled_binary_falls_back_to_base64(self):
        """A .md that is not valid UTF-8 must not blow up the commit."""
        prepared = prepare_file("brd.md", b"\xff\xfe\x00bad", DocumentKind.BRD)

        assert prepared.encoding == "base64"

    def test_technical_documents_get_a_predictable_name(self):
        assert prepare_file("Design v3 FINAL.docx", b"x", DocumentKind.TECHNICAL).path == (
            "docs/TECHNICAL.docx"
        )

    def test_rejects_oversized_uploads(self, settings):
        """GitLab throttles requests over 20MB to 3 per 30 seconds."""
        settings.MAX_DOCUMENT_UPLOAD_BYTES = 1024

        with pytest.raises(DocumentUploadError, match="over the"):
            prepare_file("big.pdf", b"x" * 2048, DocumentKind.BRD)

    def test_rejects_empty_files(self):
        with pytest.raises(DocumentUploadError, match="empty"):
            prepare_file("brd.pdf", b"", DocumentKind.BRD)

    def test_filename_cannot_escape_the_docs_directory(self):
        prepared = prepare_file("../../etc/passwd", b"x", DocumentKind.BRD)

        assert prepared.path.startswith("docs/")
        assert ".." not in prepared.path


class TestCommitDocuments:
    def test_creates_the_branch_atomically_when_missing(self, repo, mocked_responses):
        """start_branch creates the branch as part of the same commit, so there
        is no window where an empty documentation branch exists."""
        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "abc123"}, status=201)

        commit_documents(repo, [(DocumentKind.BRD, prepare_file("b.md", b"x", "brd"))])

        body = _commit_body(mocked_responses)
        assert body["branch"] == "documentation"
        assert body["start_branch"] == "main"
        assert [a["action"] for a in body["actions"]] == ["create", "create"]

    def test_omits_start_branch_when_the_branch_exists(self, repo, mocked_responses):
        """Sending start_branch for an existing branch makes GitLab reject it."""
        mocked_responses.add(responses.GET, BRANCH_URL, json={"name": "documentation"})
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/files/docs%2FBRD.md",
            json={"message": "404"}, status=404,
        )
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "abc"}, status=201)

        commit_documents(repo, [(DocumentKind.BRD, prepare_file("b.md", b"x", "brd"))])

        assert "start_branch" not in _commit_body(mocked_responses)

    def test_uses_update_when_the_file_already_exists(self, repo, mocked_responses):
        """`create` fails on an existing path and `update` fails on a missing one."""
        mocked_responses.add(responses.GET, BRANCH_URL, json={"name": "documentation"})
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/files/docs%2FBRD.md",
            json={"file_path": "docs/BRD.md"},
        )
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "abc"}, status=201)

        commit_documents(repo, [(DocumentKind.BRD, prepare_file("b.md", b"x", "brd"))])

        assert _commit_body(mocked_responses)["actions"][0]["action"] == "update"

    def test_marks_the_repo_as_having_the_branch(self, repo, mocked_responses):
        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "abc"}, status=201)

        commit_documents(repo, [(DocumentKind.BRD, prepare_file("b.md", b"x", "brd"))])

        repo.refresh_from_db()
        assert repo.documentation_branch_ready is True

    def test_rejects_an_empty_file_list(self, repo):
        with pytest.raises(DocumentUploadError, match="No documents"):
            commit_documents(repo, [])


class TestEnsureDocumentationBranch:
    def test_reports_an_existing_branch_without_committing(self, repo, mocked_responses):
        mocked_responses.add(responses.GET, BRANCH_URL, json={"name": "documentation"})

        assert ensure_documentation_branch(repo) is True
        assert len(mocked_responses.calls) == 1

    def test_creates_the_branch_from_the_default_branch(self, repo, mocked_responses):
        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "abc"}, status=201)

        assert ensure_documentation_branch(repo) is False
        assert _commit_body(mocked_responses)["start_branch"] == "main"


class TestUploadDocument:
    def test_records_the_document_after_committing(self, repo, mocked_responses, admin_user):
        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "sha1"}, status=201)

        document = upload_document(
            repo, kind=DocumentKind.BRD, filename="brd.pdf",
            raw=b"%PDF-1.7 content", uploaded_by=admin_user,
        )

        assert document.repo_path == "docs/BRD.pdf"
        assert document.committed_sha == "sha1"
        assert document.uploaded_by == admin_user

    def test_reuploading_identical_content_skips_the_commit(self, repo, mocked_responses):
        """Avoids a no-op commit every time someone re-uploads the same file."""
        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "sha1"}, status=201)
        upload_document(repo, kind=DocumentKind.BRD, filename="brd.pdf", raw=b"same")

        calls_before = len(mocked_responses.calls)
        upload_document(repo, kind=DocumentKind.BRD, filename="brd.pdf", raw=b"same")

        assert len(mocked_responses.calls) == calls_before
        assert Document.objects.count() == 1

    def test_new_content_clears_the_previous_summary(self, repo, mocked_responses):
        """A stale summary would feed the wrong business context into scoring."""
        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "s1"}, status=201)
        doc = upload_document(repo, kind=DocumentKind.BRD, filename="brd.md", raw=b"v1")
        Document.objects.filter(pk=doc.pk).update(
            summary="old summary", summary_model_version="gemini-3.6-flash"
        )

        mocked_responses.add(responses.GET, BRANCH_URL, json={"name": "documentation"})
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/files/docs%2FBRD.md",
            json={"file_path": "docs/BRD.md"},
        )
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "s2"}, status=201)
        updated = upload_document(repo, kind=DocumentKind.BRD, filename="brd.md", raw=b"v2")

        assert updated.summary == ""
        assert updated.committed_sha == "s2"


class TestFindDocumentsInRepo:
    def test_detects_documents_committed_by_hand(self, repo, mocked_responses):
        """Compliance should reflect the repository, not only this app's uploads."""
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[
                {"type": "blob", "name": "BRD.pdf", "path": "docs/BRD.pdf"},
                {"type": "blob", "name": "TECHNICAL.md", "path": "docs/TECHNICAL.md"},
                {"type": "blob", "name": "notes.txt", "path": "docs/notes.txt"},
                {"type": "tree", "name": "archive", "path": "docs/archive"},
            ],
        )

        found = find_documents_in_repo(repo)

        assert found == {"brd": "docs/BRD.pdf", "technical": "docs/TECHNICAL.md"}

    def test_missing_branch_yields_nothing_rather_than_erroring(self, repo, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json={"message": "404 Tree Not Found"}, status=404,
        )

        assert find_documents_in_repo(repo) == {}


class TestUploadEndpoint:
    def test_uploads_through_the_api(self, api_client, repo, mocked_responses):
        from django.core.files.uploadedfile import SimpleUploadedFile

        mocked_responses.add(responses.GET, BRANCH_URL, json={"message": "404"}, status=404)
        mocked_responses.add(responses.POST, COMMITS_URL, json={"id": "sha1"}, status=201)

        response = api_client.post(
            f"/api/projects/{repo.project.pk}/documents/",
            {"kind": "brd", "file": SimpleUploadedFile("brd.pdf", b"%PDF-1.7 x")},
            format="multipart",
        )

        assert response.status_code == 201
        assert response.json()["repo_path"] == "docs/BRD.pdf"

    def test_oversized_upload_returns_a_readable_error(
        self, api_client, repo, settings
    ):
        from django.core.files.uploadedfile import SimpleUploadedFile

        settings.MAX_DOCUMENT_UPLOAD_BYTES = 10

        response = api_client.post(
            f"/api/projects/{repo.project.pk}/documents/",
            {"kind": "brd", "file": SimpleUploadedFile("brd.pdf", b"x" * 100)},
            format="multipart",
        )

        assert response.status_code == 400
        assert "limit" in response.json()["detail"]
