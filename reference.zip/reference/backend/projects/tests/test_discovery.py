"""Repository discovery and the service-token failure modes.

Namespace is deliberately not a constraint anywhere here: a repository is
trackable if the sync token can read it, whether it sits in a group, the
admin's own namespace, or a teammate's.
"""

import json

import pytest
import responses

from gitlab_integration.client import GitLabClient
from projects.services import (
    RepoValidationError,
    create_repo_for_project,
    resolve_repo_reference,
    search_accessible_repos,
    validate_repo_reference,
)

API = "https://gitlab.example.com/api/v4"

pytestmark = pytest.mark.django_db


def repo_payload(pid, path, namespace):
    return {
        "id": pid,
        "name": path.split("/")[-1],
        "path_with_namespace": path,
        "web_url": f"https://gitlab.example.com/{path}",
        "default_branch": "main",
        "visibility": "private",
        "last_activity_at": "2026-07-20T10:00:00Z",
        "namespace": {"id": 1, "full_path": namespace},
    }


@pytest.fixture
def user_client():
    return GitLabClient(token="user-tok", api_url=API, token_kind="user", max_retries=0)


class TestSearchAccessibleRepos:
    def test_returns_repos_from_every_namespace(self, mocked_responses):
        """Personal namespaces and teammates' namespaces count too."""
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json=[
                repo_payload(1, "pj7374/head-count-interface", "pj7374"),
                repo_payload(2, "acme/apollo", "acme"),
                repo_payload(3, "teammate/side-tool", "teammate"),
            ],
        )

        repos = search_accessible_repos(GitLabClient(token="t", api_url=API))

        assert [r["path_with_namespace"] for r in repos] == [
            "pj7374/head-count-interface",
            "acme/apollo",
            "teammate/side-tool",
        ]

    def test_asks_gitlab_for_everything_the_token_can_reach(self, mocked_responses):
        mocked_responses.add(responses.GET, f"{API}/projects", json=[])

        search_accessible_repos(GitLabClient(token="t", api_url=API))

        params = mocked_responses.calls[0].request.params
        assert params["membership"] == "True"
        assert params["min_access_level"] == "20"
        # No namespace or group filter is applied.
        assert "namespace_id" not in params

    def test_search_is_delegated_to_gitlab(self, mocked_responses):
        """Filtering locally would mean pulling the whole account per keystroke."""
        mocked_responses.add(responses.GET, f"{API}/projects", json=[])

        search_accessible_repos(GitLabClient(token="t", api_url=API), query="head-count")

        params = mocked_responses.calls[0].request.params
        assert params["search"] == "head-count"
        assert params["search_namespaces"] == "True"

    def test_uses_a_single_bounded_request(self, mocked_responses):
        """Runs on every keystroke, so it must never walk pages."""
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json=[repo_payload(i, f"ns/p{i}", "ns") for i in range(15)],
        )

        search_accessible_repos(GitLabClient(token="t", api_url=API), query="p", limit=15)

        assert len(mocked_responses.calls) == 1
        assert mocked_responses.calls[0].request.params["per_page"] == "15"


class TestResolveRepoReference:
    def test_a_pasted_url_resolves_directly(self, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/pj7374%2Fhead-count-interface",
            json=repo_payload(1, "pj7374/head-count-interface", "pj7374"),
        )

        found = resolve_repo_reference(
            GitLabClient(token="t", api_url=API),
            "https://gitlab.example.com/pj7374/head-count-interface",
        )

        assert found["path_with_namespace"] == "pj7374/head-count-interface"

    def test_free_text_is_not_a_reference(self, mocked_responses):
        """"head-count" has no namespace, so it is a search term, not a path."""
        assert resolve_repo_reference(GitLabClient(token="t", api_url=API), "head-count") is None
        assert len(mocked_responses.calls) == 0

    def test_an_unreachable_path_returns_none_rather_than_raising(self, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/ns%2Fnope", json={"message": "404"}, status=404
        )

        assert resolve_repo_reference(GitLabClient(token="t", api_url=API), "ns/nope") is None


class TestServiceTokenFailureModes:
    """Each needs a different fix, so each gets a different message."""

    def test_missing_token_says_so_instead_of_blaming_permissions(
        self, user_client, mocked_responses, settings
    ):
        settings.GITLAB_SERVICE_TOKEN = ""
        mocked_responses.add(
            responses.GET, f"{API}/projects/pj7374%2Fhead-count-interface",
            json=repo_payload(1, "pj7374/head-count-interface", "pj7374"),
        )

        with pytest.raises(RepoValidationError, match="GITLAB_SERVICE_TOKEN is not set"):
            validate_repo_reference("pj7374/head-count-interface", user_client)

    def test_invalid_token_is_reported_as_invalid(self, user_client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/pj7374%2Fhead-count-interface",
            json=repo_payload(1, "pj7374/head-count-interface", "pj7374"),
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/1", json={"message": "401"}, status=401
        )

        with pytest.raises(RepoValidationError, match="invalid, revoked, or expired"):
            validate_repo_reference("pj7374/head-count-interface", user_client)

    def test_genuine_access_gap_offers_both_remedies(self, user_client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/pj7374%2Fhead-count-interface",
            json=repo_payload(1, "pj7374/head-count-interface", "pj7374"),
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/1", json={"message": "404"}, status=404
        )

        with pytest.raises(RepoValidationError) as exc:
            validate_repo_reference("pj7374/head-count-interface", user_client)

        message = str(exc.value)
        assert "as a Reporter" in message
        assert "token from your own account" in message

    def test_a_personal_namespace_repo_validates_normally(self, user_client, mocked_responses):
        """Nothing about validation requires a group."""
        payload = repo_payload(1, "pj7374/head-count-interface", "pj7374")
        mocked_responses.add(
            responses.GET, f"{API}/projects/pj7374%2Fhead-count-interface", json=payload
        )
        mocked_responses.add(responses.GET, f"{API}/projects/1", json=payload)

        validation = validate_repo_reference("pj7374/head-count-interface", user_client)

        assert validation.is_usable
        assert validation.namespace_path == "pj7374"


class TestCreateWithoutAGroup:
    def test_falls_back_to_the_token_owners_namespace(self, mocked_responses, settings):
        """GitLab puts the project in the token owner's namespace when none is
        given, so a group is a convenience rather than a requirement."""
        settings.GITLAB_GROUP_ID = ""
        mocked_responses.add(
            responses.POST, f"{API}/projects",
            json=repo_payload(9, "pj7374/apollo", "pj7374"), status=201,
        )

        create_repo_for_project("Apollo")

        body = json.loads(mocked_responses.calls[0].request.body)
        assert "namespace_id" not in body
        assert body["initialize_with_readme"] is True

    def test_uses_the_group_when_one_is_configured(self, mocked_responses, settings):
        settings.GITLAB_GROUP_ID = "42"
        mocked_responses.add(
            responses.POST, f"{API}/projects",
            json=repo_payload(9, "acme/apollo", "acme"), status=201,
        )

        create_repo_for_project("Apollo")

        assert json.loads(mocked_responses.calls[0].request.body)["namespace_id"] == "42"


class TestAvailableReposEndpoint:
    def test_lists_repos_and_flags_ones_already_linked(
        self, api_client, mocked_responses, repo
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json=[
                repo_payload(555, "acme/apollo", "acme"),
                repo_payload(1, "pj7374/head-count-interface", "pj7374"),
            ],
        )

        data = api_client.get("/api/projects/available-repos/").json()

        assert data["count"] == 2
        by_path = {r["path_with_namespace"]: r for r in data["repos"]}
        assert by_path["acme/apollo"]["linked_to"] == repo.project.name
        assert by_path["pj7374/head-count-interface"]["linked_to"] is None

    def test_a_short_query_skips_the_round_trip(self, api_client, mocked_responses):
        """Two characters match most of an account, so the call is not worth making."""
        data = api_client.get("/api/projects/available-repos/?search=he").json()

        assert data["code"] == "query_too_short"
        assert data["repos"] == []
        assert len(mocked_responses.calls) == 0

    def test_a_search_delegates_filtering_to_gitlab(self, api_client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json=[repo_payload(1, "pj7374/head-count-interface", "pj7374")],
        )

        data = api_client.get("/api/projects/available-repos/?search=head-count").json()

        assert data["count"] == 1
        assert mocked_responses.calls[0].request.params["search"] == "head-count"

    def test_a_pasted_url_is_surfaced_first_and_flagged(self, api_client, mocked_responses):
        """Waiting for a fuzzy search to maybe surface a link you already have
        is the wrong behaviour."""
        target = repo_payload(1, "pj7374/head-count-interface", "pj7374")
        mocked_responses.add(
            responses.GET, f"{API}/projects/pj7374%2Fhead-count-interface", json=target
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json=[repo_payload(2, "other/thing", "other"), target],
        )

        data = api_client.get(
            "/api/projects/available-repos/"
            "?search=https://gitlab.example.com/pj7374/head-count-interface"
        ).json()

        assert data["matched_directly"] is True
        assert data["repos"][0]["path_with_namespace"] == "pj7374/head-count-interface"
        # Present once, not duplicated by the search results.
        paths = [r["path_with_namespace"] for r in data["repos"]]
        assert paths.count("pj7374/head-count-interface") == 1

    def test_an_empty_query_returns_recent_repos_in_one_request(
        self, api_client, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json=[repo_payload(1, "ns/recent", "ns")],
        )

        data = api_client.get("/api/projects/available-repos/").json()

        assert data["count"] == 1
        assert data["matched_directly"] is False
        assert len(mocked_responses.calls) == 1, "opening the picker costs one call"

    def test_missing_service_token_returns_a_readable_notice(self, api_client, settings):
        settings.GITLAB_SERVICE_TOKEN = ""

        data = api_client.get("/api/projects/available-repos/").json()

        assert data["code"] == "service_token_missing"
        assert data["repos"] == []

    def test_invalid_service_token_returns_a_readable_notice(
        self, api_client, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects", json={"message": "401"}, status=401
        )

        data = api_client.get("/api/projects/available-repos/").json()

        assert data["code"] == "service_token_invalid"
