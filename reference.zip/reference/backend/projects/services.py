"""Project registration: validating or creating the mandatory GitLab repo.

A project without a repository is not a valid project, so registration has
exactly two paths — link one the admin already has, or create one — and both
end with a repo that has an initialized default branch.

Validation runs twice on purpose. First as the signed-in admin, because
"is this repo accessible to *me*?" is the question they actually asked. Then as
the service account, because that is the identity that will do the nightly
syncing: a repo the admin can see but the service account cannot would register
happily and then silently never sync.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from django.conf import settings
from django.db import transaction
from django.utils import timezone
from django.utils.text import slugify

from gitlab_integration.client import GitLabClient
from gitlab_integration.exceptions import (
    GitLabAuthError,
    GitLabError,
    GitLabForbidden,
    GitLabInsufficientScope,
    GitLabNotFound,
    GitLabValidationError,
)

from .models import GitLabRepo, Project
from .repo_url import InvalidRepoReference, parse_repo_reference

logger = logging.getLogger(__name__)

# Access levels that can actually read repository content.
MIN_SERVICE_ACCESS_LEVEL = 20  # Reporter


class RepoValidationError(GitLabError):
    """The repository cannot be used for a project, with a reason for the admin."""


@dataclass
class RepoValidation:
    """Outcome of checking a repository before linking it."""

    path_with_namespace: str
    gitlab_project_id: int
    name: str
    web_url: str
    ssh_url_to_repo: str
    http_url_to_repo: str
    default_branch: str
    visibility: str
    namespace_id: int | None
    namespace_path: str
    accessible_to_user: bool
    accessible_to_service: bool
    already_linked_to: str | None
    payload: dict

    @property
    def is_usable(self) -> bool:
        return (
            self.accessible_to_user
            and self.accessible_to_service
            and self.already_linked_to is None
        )


def _repo_fields(payload: dict) -> dict:
    namespace = payload.get("namespace") or {}
    return {
        "gitlab_project_id": payload["id"],
        "path_with_namespace": payload["path_with_namespace"],
        "name": payload.get("name", ""),
        "web_url": payload.get("web_url", ""),
        "ssh_url_to_repo": payload.get("ssh_url_to_repo", "") or "",
        "http_url_to_repo": payload.get("http_url_to_repo", "") or "",
        # A brand-new empty project reports default_branch as null.
        "default_branch": payload.get("default_branch") or settings.GITLAB_DEFAULT_BRANCH,
        "visibility": payload.get("visibility", "private"),
        "namespace_id": namespace.get("id"),
        "namespace_path": namespace.get("full_path", "") or "",
    }


def validate_repo_reference(reference: str, user_client: GitLabClient) -> RepoValidation:
    """Check a repository is real, visible to the admin, and usable by the sync.

    Raises :class:`RepoValidationError` with an actionable message rather than
    returning an unusable result, except for the "already linked" case which is
    reported on the returned object so the caller can name the other project.
    """
    try:
        path = parse_repo_reference(reference, gitlab_url=settings.GITLAB_URL)
    except InvalidRepoReference as exc:
        raise RepoValidationError(str(exc)) from exc

    # 1. As the admin. GitLab returns 404 rather than 403 for projects you
    #    cannot see, so both mean "not available to you" here.
    try:
        payload = user_client.get_project(path)
    except (GitLabNotFound, GitLabForbidden) as exc:
        raise RepoValidationError(
            f"'{path}' does not exist or is not visible to your GitLab account. "
            "Check the path and that you have at least Reporter access."
        ) from exc

    fields = _repo_fields(payload)

    # 2. As the service credential, which is what actually runs the syncing.
    #    A repo this token cannot read would register and then never sync, so
    #    the failure modes are separated: they need very different fixes and
    #    lumping them together sends people hunting for a permissions problem
    #    that may not exist.
    if not settings.GITLAB_SERVICE_TOKEN:
        raise RepoValidationError(
            "GITLAB_SERVICE_TOKEN is not set, so nothing can sync yet. Create a "
            "Personal Access Token with the 'api' scope at "
            f"{settings.GITLAB_URL}/-/user_settings/personal_access_tokens and put "
            "it in your .env as GITLAB_SERVICE_TOKEN. Using your own token is the "
            "simplest option: every repository you can access becomes syncable "
            "without adding anyone to anything."
        )

    try:
        GitLabClient.for_service().get_project(fields["gitlab_project_id"])
    except GitLabInsufficientScope as exc:
        raise RepoValidationError(
            "GITLAB_SERVICE_TOKEN is valid but is missing the 'api' scope. Scopes "
            "cannot be added to an existing token — create a new personal access "
            "token with 'api' ticked and replace the value in your .env."
        ) from exc
    except GitLabAuthError as exc:
        raise RepoValidationError(
            "GITLAB_SERVICE_TOKEN was rejected by GitLab — it is invalid, revoked, "
            "or expired. GitLab forces an expiry date on personal access tokens, "
            "so this is worth checking first."
        ) from exc
    except (GitLabNotFound, GitLabForbidden) as exc:
        raise RepoValidationError(
            f"You can see '{path}', but GITLAB_SERVICE_TOKEN cannot, so this "
            "project would register and then never sync. Either add that token's "
            f"account to the project as a Reporter (Manage → Members on {path}), "
            "or set GITLAB_SERVICE_TOKEN to a token from your own account so "
            "everything you can access is syncable automatically."
        ) from exc
    except GitLabError as exc:
        logger.warning("Service-token access check failed for %s", path, exc_info=True)
        raise RepoValidationError(
            f"Could not verify sync access to '{path}': {exc}"
        ) from exc

    existing = GitLabRepo.objects.filter(
        gitlab_project_id=fields["gitlab_project_id"]
    ).select_related("project").first()

    return RepoValidation(
        **fields,
        accessible_to_user=True,
        accessible_to_service=True,
        already_linked_to=existing.project.name if existing else None,
        payload=payload,
    )


# Enough characters for GitLab's search to be selective; below this a query
# matches most of an account and the round trip is wasted.
MIN_SEARCH_LENGTH = 3


def search_accessible_repos(
    client: GitLabClient, *, query: str = "", limit: int = 15
) -> list[dict]:
    """Repositories matching ``query``, across every namespace.

    Deliberately a single request with ``per_page=limit`` rather than a paged
    walk: this runs on every keystroke, so GitLab does the filtering and the
    response size is bounded. Enumerating an entire account and filtering
    locally is what made the picker slow to open.

    Namespace is never a filter — a repository is trackable whether it sits in
    a group, your own namespace, or a teammate's.
    """
    params: dict = {
        "membership": True,
        "min_access_level": MIN_SERVICE_ACCESS_LEVEL,
        "order_by": "last_activity_at",
        "sort": "desc",
        "simple": True,
        "archived": False,
        "per_page": limit,
    }
    if query:
        params["search"] = query
        # Lets "acme/apollo" match on the namespace as well as the project name.
        params["search_namespaces"] = True

    result = client.request("GET", "/projects", params=params)
    return result if isinstance(result, list) else []


def resolve_repo_reference(client: GitLabClient, reference: str) -> dict | None:
    """Interpret text as a direct repo path or URL, or return None.

    Lets a pasted link resolve to its project immediately instead of waiting
    for a fuzzy search to maybe surface it.
    """
    try:
        path = parse_repo_reference(reference, gitlab_url=settings.GITLAB_URL)
    except InvalidRepoReference:
        return None

    try:
        return client.get_project(path)
    except (GitLabNotFound, GitLabForbidden):
        return None
    except GitLabError:
        logger.debug("Direct lookup of %r failed", reference, exc_info=True)
        return None


def create_repo_for_project(
    name: str, *, description: str = "", namespace_id: int | str | None = None
) -> dict:
    """Create a repository.

    Placed in ``GITLAB_GROUP_ID`` when one is configured, otherwise in the
    service token owner's own namespace — GitLab defaults there when no
    namespace is given. A group is a convenience, not a requirement.
    """
    namespace = namespace_id or settings.GITLAB_GROUP_ID or None
    client = GitLabClient.for_service()
    path = slugify(name)[:80] or "project"

    try:
        return client.create_project(
            name, path=path, namespace_id=namespace, description=description
        )
    except GitLabValidationError as exc:
        # The most common cause by far is a name/path collision in the target
        # namespace.
        where = f"group {namespace}" if namespace else "your personal namespace"
        raise RepoValidationError(
            f"GitLab rejected the new repository '{path}': {exc.message}. "
            f"A project with that path may already exist in {where}."
        ) from exc


def _unique_slug(name: str) -> str:
    base = slugify(name)[:200] or "project"
    slug, n = base, 1
    while Project.objects.filter(slug=slug).exists():
        n += 1
        suffix = f"-{n}"
        slug = f"{base[: 200 - len(suffix)]}{suffix}"
    return slug


@transaction.atomic
def register_project(
    *,
    name: str,
    user_client: GitLabClient,
    description: str = "",
    repo_reference: str | None = None,
    owner=None,
    status: str | None = None,
    started_on=None,
    target_end_on=None,
) -> Project:
    """Create a project and attach its mandatory repository.

    Either links the supplied repository after validating it, or creates a new
    one when none was given.
    """
    if repo_reference:
        validation = validate_repo_reference(repo_reference, user_client)
        if validation.already_linked_to:
            raise RepoValidationError(
                f"'{validation.path_with_namespace}' is already linked to the project "
                f"'{validation.already_linked_to}'. A repository backs exactly one project."
            )
        repo_fields = _repo_fields(validation.payload)
        created_by_app = False
    else:
        payload = create_repo_for_project(name, description=description)
        repo_fields = _repo_fields(payload)
        created_by_app = True

    project = Project.objects.create(
        name=name,
        slug=_unique_slug(name),
        description=description,
        owner=owner,
        status=status or Project._meta.get_field("status").default,
        started_on=started_on,
        target_end_on=target_end_on,
    )

    GitLabRepo.objects.create(
        project=project,
        created_by_app=created_by_app,
        gitlab_created_at=timezone.now() if created_by_app else None,
        **repo_fields,
    )

    logger.info(
        "Registered project %s -> %s (%s)",
        project.name,
        repo_fields["path_with_namespace"],
        "created" if created_by_app else "linked",
    )
    return project
