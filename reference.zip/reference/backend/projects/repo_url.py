"""Parsing whatever form of GitLab repo reference an admin pastes in.

People paste browser URLs, clone URLs, SSH remotes, or just the namespace path.
All of them have to reduce to the ``namespace/project`` form the API takes as a
URL-encoded ``:id``.
"""

from __future__ import annotations

import re
from urllib.parse import urlparse

# Trailing GitLab UI paths that get copied along with a repo URL.
_UI_SUFFIXES = re.compile(
    r"/-/(tree|blob|commits?|merge_requests|issues|milestones|settings|branches|pipelines).*$"
)

SSH_RE = re.compile(r"^(?:ssh://)?(?:git@)([^:/]+)[:/](?P<path>.+?)(?:\.git)?/?$")


class InvalidRepoReference(ValueError):
    """The supplied text is not a usable GitLab project reference."""


def parse_repo_reference(reference: str, *, gitlab_url: str | None = None) -> str:
    """Reduce a repo reference to ``namespace/project``.

    Accepts browser URLs, HTTPS clone URLs, SSH remotes and bare paths.
    """
    if not reference or not reference.strip():
        raise InvalidRepoReference("No repository reference was provided.")

    text = reference.strip()

    ssh_match = SSH_RE.match(text)
    if ssh_match:
        path = ssh_match.group("path")
    elif "://" in text:
        parsed = urlparse(text)
        if not parsed.netloc:
            raise InvalidRepoReference(f"Could not parse {reference!r} as a URL.")
        if gitlab_url:
            expected = urlparse(gitlab_url).netloc
            if expected and parsed.netloc.lower() != expected.lower():
                raise InvalidRepoReference(
                    f"{parsed.netloc} is not the configured GitLab host ({expected})."
                )
        path = parsed.path
    else:
        path = text

    path = _UI_SUFFIXES.sub("", path)
    path = path.strip("/")
    if path.endswith(".git"):
        path = path[: -len(".git")]
    # A URL like /acme/apollo/-/tree/main leaves a dangling "/-" segment.
    path = path.removesuffix("/-")

    if not path or "/" not in path:
        raise InvalidRepoReference(
            f"{reference!r} does not look like a project path. "
            "Expected something like 'group/project'."
        )

    if any(segment == "" for segment in path.split("/")):
        raise InvalidRepoReference(f"{reference!r} contains an empty path segment.")

    return path
