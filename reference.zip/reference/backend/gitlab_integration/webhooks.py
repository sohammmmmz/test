"""Webhook signature verification and registration.

GitLab offers two authentication schemes for webhooks. The signing token
produces an HMAC-SHA256 signature over the request body, which proves both the
sender and that the payload was not altered. The legacy secret token is simply
echoed back in a header as plaintext, which proves neither if the transport is
ever compromised. The signing token is preferred here, with the plaintext token
accepted only as a fallback for hooks that have not been migrated yet.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging

from django.conf import settings
from django.utils import timezone

from .client import GitLabClient
from .exceptions import GitLabError
from .models import GroupWebhook

logger = logging.getLogger(__name__)

SIGNATURE_HEADERS = (
    "HTTP_WEBHOOK_SIGNATURE",
    "HTTP_X_GITLAB_SIGNATURE_256",
    "HTTP_X_GITLAB_SIGNATURE",
)
TOKEN_HEADER = "HTTP_X_GITLAB_TOKEN"
EVENT_HEADER = "HTTP_X_GITLAB_EVENT"
UUID_HEADER = "HTTP_X_GITLAB_EVENT_UUID"


def compute_signature(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def _presented_signature(meta) -> str | None:
    for header in SIGNATURE_HEADERS:
        value = meta.get(header)
        if value:
            # Some senders prefix the algorithm, e.g. "sha256=abc123".
            return value.split("=", 1)[-1].strip() if "=" in value else value.strip()
    return None


def verify_request(body: bytes, meta) -> tuple[bool, str]:
    """Verify a webhook delivery. Returns ``(verified, reason)``.

    Rejects unsigned deliveries when a signing token is configured: accepting
    them would make the endpoint an unauthenticated write path into the
    activity data.
    """
    signing_token = settings.GITLAB_WEBHOOK_SIGNING_TOKEN
    secret_token = settings.GITLAB_WEBHOOK_SECRET_TOKEN

    if not signing_token and not secret_token:
        return False, "No webhook token is configured; refusing to trust the delivery."

    if signing_token:
        presented = _presented_signature(meta)
        if presented:
            expected = compute_signature(body, signing_token)
            if hmac.compare_digest(presented, expected):
                return True, "signature"
            return False, "HMAC signature did not match."

    if secret_token:
        presented_token = meta.get(TOKEN_HEADER, "")
        if presented_token and hmac.compare_digest(presented_token, secret_token):
            return True, "secret_token"
        return False, "Secret token did not match."

    return False, "No signature header was present on a signed-webhook endpoint."


def dedupe_key(body: bytes, meta) -> str:
    """Stable key for a delivery, so GitLab's retries do not double-process.

    Prefers the event UUID; falls back to hashing the body for older instances
    that do not send one.
    """
    uuid = meta.get(UUID_HEADER)
    if uuid:
        return hashlib.sha256(f"uuid:{uuid}".encode()).hexdigest()
    return hashlib.sha256(body).hexdigest()


def extract_project_id(payload: dict) -> int | None:
    project = payload.get("project") or {}
    if project.get("id"):
        return project["id"]
    if payload.get("project_id"):
        return payload["project_id"]
    attrs = payload.get("object_attributes") or {}
    return attrs.get("target_project_id") or attrs.get("project_id")


def parse_payload(body: bytes) -> dict:
    try:
        data = json.loads(body or b"{}")
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def ensure_group_webhook(*, client: GitLabClient | None = None) -> GroupWebhook | None:
    """Register the group-level webhook, or update it if the URL changed.

    Registered once at the group rather than per project: one hook covers every
    project and subgroup, there is a single secret to rotate, and repositories
    created later are covered the moment they exist.
    """
    group_id = settings.GITLAB_GROUP_ID
    url = settings.GITLAB_WEBHOOK_URL
    token = settings.GITLAB_WEBHOOK_SIGNING_TOKEN or settings.GITLAB_WEBHOOK_SECRET_TOKEN

    if not (group_id and url and token):
        logger.info(
            "Skipping webhook registration: GITLAB_GROUP_ID, GITLAB_WEBHOOK_URL and a "
            "webhook token must all be set."
        )
        return None

    client = client or GitLabClient.for_service()
    record, _ = GroupWebhook.objects.get_or_create(
        group_id=str(group_id), defaults={"url": url}
    )
    fingerprint = hashlib.sha256(token.encode()).hexdigest()[:32]

    try:
        existing = next(
            (h for h in client.list_group_hooks(group_id) if h.get("url") == url), None
        )
        if existing:
            client.update_group_hook(
                group_id, existing["id"], url=url, token=token,
                push_events=True, merge_requests_events=True, issues_events=True,
            )
            record.gitlab_hook_id = existing["id"]
        else:
            created = client.create_group_hook(group_id, url=url, token=token)
            record.gitlab_hook_id = created.get("id")
    except GitLabError as exc:
        record.last_error = str(exc)
        record.save()
        logger.warning("Group webhook registration failed: %s", exc)
        return record

    record.url = url
    record.signing_token_fingerprint = fingerprint
    record.is_active = True
    record.last_error = ""
    record.last_registered_at = timezone.now()
    record.save()
    return record
