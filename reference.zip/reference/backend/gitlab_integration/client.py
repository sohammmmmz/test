"""GitLab REST API v4 client.

Two auth modes, deliberately separate:

* **service** — a Group Access Token used for all scheduled syncing, repo
  creation and webhook management. GitLab OAuth access tokens live only two
  hours and refreshing rotates the refresh token, so nightly work cannot depend
  on any individual staying logged in.
* **user** — a person's OAuth token, used only where acting *as them* is the
  point, i.e. the "is this repo accessible to me?" check at registration.
"""

from __future__ import annotations

import logging
import random
import time
from collections.abc import Iterator
from typing import Any
from urllib.parse import quote

import requests
from django.conf import settings

from .exceptions import (
    GitLabAuthError,
    GitLabConflict,
    GitLabError,
    GitLabForbidden,
    GitLabInsufficientScope,
    GitLabNotFound,
    GitLabRateLimited,
    GitLabServerError,
    GitLabValidationError,
)

logger = logging.getLogger(__name__)

RETRYABLE_STATUSES = {429, 500, 502, 503, 504}


def encode_path(path: str) -> str:
    """URL-encode a ``namespace/project`` path for use as an :id path segment."""
    return quote(str(path).strip("/"), safe="")


class GitLabClient:
    """Thin, typed wrapper over the GitLab REST API."""

    def __init__(
        self,
        token: str | None = None,
        *,
        api_url: str | None = None,
        token_kind: str = "service",
        timeout: int | None = None,
        max_retries: int | None = None,
        session: requests.Session | None = None,
    ):
        self.api_url = (api_url or settings.GITLAB_API_URL).rstrip("/")
        self.token = token if token is not None else settings.GITLAB_SERVICE_TOKEN
        self.token_kind = token_kind
        self.timeout = timeout or settings.GITLAB_TIMEOUT
        self.max_retries = max_retries if max_retries is not None else settings.GITLAB_MAX_RETRIES
        self.per_page = settings.GITLAB_PER_PAGE
        self.session = session or requests.Session()

    # -- construction ------------------------------------------------------

    @classmethod
    def for_service(cls, **kwargs) -> GitLabClient:
        if not settings.GITLAB_SERVICE_TOKEN:
            raise GitLabError(
                "GITLAB_SERVICE_TOKEN is not configured. Scheduled syncing, repo "
                "creation and webhook registration all require the service credential."
            )
        return cls(settings.GITLAB_SERVICE_TOKEN, token_kind="service", **kwargs)

    @classmethod
    def for_user(cls, access_token: str, **kwargs) -> GitLabClient:
        return cls(access_token, token_kind="user", **kwargs)

    # -- transport ---------------------------------------------------------

    @property
    def _headers(self) -> dict[str, str]:
        # Group/personal access tokens use PRIVATE-TOKEN; OAuth tokens use
        # Authorization: Bearer. Sending the wrong one yields a confusing 401.
        if self.token_kind == "user":
            return {"Authorization": f"Bearer {self.token}"}
        return {"PRIVATE-TOKEN": self.token}

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: Any = None,
        raw_response: bool = False,
    ):
        url = path if path.startswith("http") else f"{self.api_url}/{path.lstrip('/')}"
        attempt = 0

        while True:
            attempt += 1
            try:
                response = self.session.request(
                    method,
                    url,
                    headers=self._headers,
                    params=params,
                    json=json,
                    timeout=self.timeout,
                )
            except requests.Timeout as exc:
                if attempt > self.max_retries:
                    raise GitLabServerError(f"Timed out calling {method} {url}") from exc
                self._sleep_backoff(attempt)
                continue
            except requests.RequestException as exc:
                if attempt > self.max_retries:
                    raise GitLabError(f"Network error calling {method} {url}: {exc}") from exc
                self._sleep_backoff(attempt)
                continue

            if response.status_code in RETRYABLE_STATUSES and attempt <= self.max_retries:
                self._sleep_backoff(attempt, response)
                continue

            if response.status_code >= 400:
                self._raise_for_status(response, method, url)

            return response if raw_response else self._decode(response)

    def _sleep_backoff(self, attempt: int, response: requests.Response | None = None):
        """Honour Retry-After when GitLab sends it, else exponential backoff.

        Jitter avoids a fleet-wide nightly sync retrying in lockstep.
        """
        delay: float | None = None
        if response is not None:
            header = response.headers.get("Retry-After") or response.headers.get(
                "RateLimit-Reset-After"
            )
            if header:
                try:
                    delay = float(header)
                except ValueError:
                    delay = None
        if delay is None:
            delay = min(2 ** (attempt - 1), 30) + random.uniform(0, 0.5)
        logger.warning("GitLab retry in %.1fs (attempt %s)", delay, attempt)
        time.sleep(delay)

    @staticmethod
    def _decode(response: requests.Response):
        if response.status_code == 204 or not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.content

    def _raise_for_status(self, response: requests.Response, method: str, url: str):
        try:
            payload = response.json()
            detail = payload.get("message") or payload.get("error") or payload
        except ValueError:
            payload, detail = None, response.text[:500]

        status = response.status_code
        message = f"{method} {url}: {detail}"

        if status == 401:
            raise GitLabAuthError(message, status_code=status, payload=payload)
        if status == 403:
            # GitLab reports a missing token scope as a 403 carrying
            # "insufficient_scope", which needs a new token rather than new
            # permissions — worth separating so the message can say so.
            haystack = f"{detail} {response.headers.get('WWW-Authenticate', '')}".lower()
            if "insufficient_scope" in haystack:
                raise GitLabInsufficientScope(message, status_code=status, payload=payload)
            raise GitLabForbidden(message, status_code=status, payload=payload)
        if status == 404:
            raise GitLabNotFound(message, status_code=status, payload=payload)
        if status == 409:
            raise GitLabConflict(message, status_code=status, payload=payload)
        if status == 429:
            retry_after = response.headers.get("Retry-After")
            raise GitLabRateLimited(
                message,
                retry_after=float(retry_after) if retry_after else None,
                status_code=status,
                payload=payload,
            )
        if status in (400, 422):
            raise GitLabValidationError(message, status_code=status, payload=payload)
        if status >= 500:
            raise GitLabServerError(message, status_code=status, payload=payload)
        raise GitLabError(message, status_code=status, payload=payload)

    # -- pagination --------------------------------------------------------

    def paginate(
        self,
        path: str,
        *,
        params: dict | None = None,
        per_page: int | None = None,
        max_pages: int = 1000,
    ) -> Iterator[dict]:
        """Yield every item across pages.

        The Commits API deliberately omits ``x-total`` and ``x-total-pages`` for
        performance, so total counts are simply unavailable and progress cannot
        be pre-computed. Rather than special-casing endpoints, this walks pages
        until one comes back short or empty, which is correct everywhere.
        """
        params = dict(params or {})
        params["per_page"] = per_page or self.per_page
        page = 1

        while page <= max_pages:
            params["page"] = page
            response = self.request("GET", path, params=params, raw_response=True)
            items = self._decode(response) or []

            if not isinstance(items, list):
                raise GitLabError(f"Expected a list from {path}, got {type(items).__name__}")
            yield from items

            if len(items) < params["per_page"]:
                return

            # Prefer the server's own next-page pointer when present.
            next_page = response.headers.get("x-next-page")
            if next_page:
                try:
                    page = int(next_page)
                    continue
                except ValueError:
                    pass
            elif "x-page" in response.headers:
                # The header exists and is empty: GitLab is telling us this was
                # the last page.
                return
            page += 1

        logger.warning("paginate(%s) hit max_pages=%s; results may be truncated", path, max_pages)

    def get_list(self, path: str, **kwargs) -> list[dict]:
        return list(self.paginate(path, **kwargs))

    # -- users -------------------------------------------------------------

    def get_current_user(self) -> dict:
        return self.request("GET", "/user")

    # -- projects ----------------------------------------------------------

    def get_project(self, project: str | int, *, statistics: bool = False) -> dict:
        """Fetch a project by numeric id or ``namespace/path``."""
        ident = project if isinstance(project, int) else encode_path(project)
        return self.request("GET", f"/projects/{ident}", params={"statistics": statistics})

    def create_project(
        self,
        name: str,
        *,
        path: str | None = None,
        namespace_id: int | str | None = None,
        description: str = "",
        visibility: str | None = None,
        default_branch: str | None = None,
    ) -> dict:
        """Create a repository, initialized so it has a usable default branch.

        ``initialize_with_readme`` is not optional here: without it GitLab
        creates a project with no branches at all, and the very next step —
        committing the BRD onto a documentation branch started from the default
        branch — would have nothing to branch from. ``default_branch`` must also
        be a bare name; passing a full ref like ``refs/heads/main`` silently
        skips initialization altogether.
        """
        branch = default_branch or settings.GITLAB_DEFAULT_BRANCH
        if branch.startswith("refs/"):
            raise GitLabValidationError(
                f"default_branch must be a bare branch name, not a full ref: {branch!r}"
            )

        body = {
            "name": name,
            "description": description,
            "visibility": visibility or settings.GITLAB_DEFAULT_VISIBILITY,
            "initialize_with_readme": True,
            "default_branch": branch,
        }
        if path:
            body["path"] = path
        if namespace_id:
            body["namespace_id"] = namespace_id
        return self.request("POST", "/projects", json=body)

    # -- commits -----------------------------------------------------------

    def list_commits(
        self,
        project: str | int,
        *,
        since=None,
        until=None,
        ref_name: str | None = None,
        all_branches: bool = True,
        with_stats: bool = True,
        author: str | None = None,
    ) -> Iterator[dict]:
        """Iterate commits.

        ``all_branches`` defaults to True and maps to GitLab's ``all=true``.
        This matters more than it looks: without it the endpoint returns only
        the default branch, so a team working on feature branches appears to
        have committed nothing. ``all=true`` also causes GitLab to ignore
        ``ref_name``, so the two are mutually exclusive.
        """
        ident = project if isinstance(project, int) else encode_path(project)
        params: dict[str, Any] = {"with_stats": with_stats}

        if all_branches:
            params["all"] = True
            if ref_name:
                logger.debug("ref_name=%r ignored because all=true", ref_name)
        elif ref_name:
            params["ref_name"] = ref_name

        if since is not None:
            params["since"] = _iso(since)
        if until is not None:
            params["until"] = _iso(until)
        if author:
            params["author"] = author

        return self.paginate(f"/projects/{ident}/repository/commits", params=params)

    def get_commit_diff(self, project: str | int, sha: str) -> list[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        return self.get_list(f"/projects/{ident}/repository/commits/{sha}/diff")

    def get_commit_refs(self, project: str | int, sha: str) -> list[dict]:
        """Branches and tags containing a commit."""
        ident = project if isinstance(project, int) else encode_path(project)
        return self.get_list(
            f"/projects/{ident}/repository/commits/{sha}/refs", params={"type": "branch"}
        )

    def create_commit(
        self,
        project: str | int,
        *,
        branch: str,
        commit_message: str,
        actions: list[dict],
        start_branch: str | None = None,
        start_sha: str | None = None,
        author_name: str | None = None,
        author_email: str | None = None,
    ) -> dict:
        """Create a commit containing several file actions.

        Passing ``start_branch`` for a branch that does not exist creates it as
        part of the same commit, so "create the documentation branch if missing,
        then add the BRD" is one atomic call rather than a branch-then-commit
        sequence that can half-fail.
        """
        if start_branch and start_sha:
            raise GitLabValidationError("start_branch and start_sha are mutually exclusive")

        ident = project if isinstance(project, int) else encode_path(project)
        body: dict[str, Any] = {
            "branch": branch,
            "commit_message": commit_message,
            "actions": actions,
        }
        if start_branch:
            body["start_branch"] = start_branch
        if start_sha:
            body["start_sha"] = start_sha
        if author_name:
            body["author_name"] = author_name
        if author_email:
            body["author_email"] = author_email

        return self.request("POST", f"/projects/{ident}/repository/commits", json=body)

    # -- branches / files --------------------------------------------------

    def list_branches(self, project: str | int) -> Iterator[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        return self.paginate(f"/projects/{ident}/repository/branches")

    def get_branch(self, project: str | int, branch: str) -> dict:
        ident = project if isinstance(project, int) else encode_path(project)
        return self.request("GET", f"/projects/{ident}/repository/branches/{encode_path(branch)}")

    def branch_exists(self, project: str | int, branch: str) -> bool:
        try:
            self.get_branch(project, branch)
            return True
        except GitLabNotFound:
            return False

    def get_file(self, project: str | int, file_path: str, ref: str) -> dict:
        ident = project if isinstance(project, int) else encode_path(project)
        return self.request(
            "GET",
            f"/projects/{ident}/repository/files/{encode_path(file_path)}",
            params={"ref": ref},
        )

    def file_exists(self, project: str | int, file_path: str, ref: str) -> bool:
        try:
            self.get_file(project, file_path, ref)
            return True
        except GitLabNotFound:
            return False

    def list_tree(
        self, project: str | int, *, ref: str, path: str = "", recursive: bool = True
    ) -> Iterator[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        return self.paginate(
            f"/projects/{ident}/repository/tree",
            params={"ref": ref, "path": path, "recursive": recursive},
        )

    # -- planning ----------------------------------------------------------

    def list_milestones(self, project: str | int, *, state: str | None = None) -> Iterator[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        params = {"state": state} if state else None
        return self.paginate(f"/projects/{ident}/milestones", params=params)

    def create_milestone(
        self,
        project: str | int,
        *,
        title: str,
        description: str = "",
        due_date=None,
        start_date=None,
    ) -> dict:
        """Create a milestone — the app authoring a timeline into GitLab.

        Milestones are the project's timeline, so writing them here rather than
        only reading them means the plan can be authored in one place and GitLab
        stays the source of truth.
        """
        ident = project if isinstance(project, int) else encode_path(project)
        body: dict[str, Any] = {"title": title, "description": description}
        if due_date:
            body["due_date"] = _date(due_date)
        if start_date:
            body["start_date"] = _date(start_date)
        return self.request("POST", f"/projects/{ident}/milestones", json=body)

    def update_milestone(self, project: str | int, milestone_id: int, **fields) -> dict:
        ident = project if isinstance(project, int) else encode_path(project)
        body = {k: (_date(v) if k.endswith("_date") and v else v) for k, v in fields.items()}
        return self.request(
            "PUT", f"/projects/{ident}/milestones/{milestone_id}", json=body
        )

    def create_issue(
        self,
        project: str | int,
        *,
        title: str,
        description: str = "",
        milestone_id: int | None = None,
        assignee_ids: list[int] | None = None,
        due_date=None,
        labels: list[str] | None = None,
    ) -> dict:
        """Create an issue, so tasks under a milestone can be authored here too."""
        ident = project if isinstance(project, int) else encode_path(project)
        body: dict[str, Any] = {"title": title, "description": description}
        if milestone_id:
            body["milestone_id"] = milestone_id
        if assignee_ids:
            body["assignee_ids"] = assignee_ids
        if due_date:
            body["due_date"] = _date(due_date)
        if labels:
            body["labels"] = ",".join(labels)
        return self.request("POST", f"/projects/{ident}/issues", json=body)

    def list_issues(self, project: str | int, *, updated_after=None) -> Iterator[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        params: dict[str, Any] = {"scope": "all"}
        if updated_after is not None:
            params["updated_after"] = _iso(updated_after)
        return self.paginate(f"/projects/{ident}/issues", params=params)

    def list_merge_requests(self, project: str | int, *, updated_after=None) -> Iterator[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        params: dict[str, Any] = {"scope": "all", "state": "all"}
        if updated_after is not None:
            params["updated_after"] = _iso(updated_after)
        return self.paginate(f"/projects/{ident}/merge_requests", params=params)

    def list_merge_request_notes(self, project: str | int, iid: int) -> Iterator[dict]:
        ident = project if isinstance(project, int) else encode_path(project)
        return self.paginate(f"/projects/{ident}/merge_requests/{iid}/notes")

    def list_members(self, project: str | int, *, include_inherited: bool = True):
        """Project members.

        ``/members/all`` includes members inherited from parent groups, which is
        how most teams actually grant access — checking only direct members
        would report a properly-staffed project as having none.
        """
        ident = project if isinstance(project, int) else encode_path(project)
        suffix = "members/all" if include_inherited else "members"
        return self.paginate(f"/projects/{ident}/{suffix}")

    # -- groups / webhooks -------------------------------------------------

    def get_group(self, group: str | int) -> dict:
        ident = group if isinstance(group, int) else encode_path(group)
        return self.request("GET", f"/groups/{ident}")

    def list_group_hooks(self, group: str | int) -> list[dict]:
        ident = group if isinstance(group, int) else encode_path(group)
        return self.get_list(f"/groups/{ident}/hooks")

    def create_group_hook(self, group: str | int, *, url: str, token: str, **events) -> dict:
        ident = group if isinstance(group, int) else encode_path(group)
        body = {
            "url": url,
            "push_events": events.get("push_events", True),
            "merge_requests_events": events.get("merge_requests_events", True),
            "issues_events": events.get("issues_events", True),
            "tag_push_events": events.get("tag_push_events", False),
            "enable_ssl_verification": events.get("enable_ssl_verification", True),
            # The signing token yields an HMAC-SHA256 signature header, unlike
            # the legacy secret token which is sent as plaintext.
            "token": token,
        }
        return self.request("POST", f"/groups/{ident}/hooks", json=body)

    def update_group_hook(self, group: str | int, hook_id: int, **fields) -> dict:
        ident = group if isinstance(group, int) else encode_path(group)
        return self.request("PUT", f"/groups/{ident}/hooks/{hook_id}", json=fields)

    def delete_group_hook(self, group: str | int, hook_id: int) -> None:
        ident = group if isinstance(group, int) else encode_path(group)
        self.request("DELETE", f"/groups/{ident}/hooks/{hook_id}")


def _iso(value) -> str:
    """Render a datetime/date/string as ISO 8601 for GitLab query params."""
    if isinstance(value, str):
        return value
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def _date(value) -> str:
    """Render a date as YYYY-MM-DD, which is what GitLab's date fields expect."""
    if isinstance(value, str):
        return value[:10]
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d")
    return str(value)
