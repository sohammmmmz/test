from django.urls import path

from sync.views import GitLabWebhookView

urlpatterns = [
    # Deliberately unauthenticated: GitLab proves itself with an HMAC signature
    # over the request body rather than a session cookie.
    path("webhook", GitLabWebhookView.as_view(), name="gitlab-webhook"),
]
