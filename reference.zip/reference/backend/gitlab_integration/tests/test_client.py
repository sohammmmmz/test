"""Tests for the GitLab client transport, pagination and request shaping."""

import pytest
import responses

from gitlab_integration.client import GitLabClient, encode_path
from gitlab_integration.exceptions import (
    GitLabAuthError,
    GitLabForbidden,
    GitLabNotFound,
    GitLabServerError,
    GitLabValidationError,
)

API = "https://gitlab.example.com/api/v4"


@pytest.fixture
def client():
    return GitLabClient(token="tok", api_url=API, max_retries=0)


def test_encode_path_escapes_slashes():
    assert encode_path("acme/sub/apollo") == "acme%2Fsub%2Fapollo"
    assert encode_path("/acme/apollo/") == "acme%2Fapollo"


def test_service_token_uses_private_token_header(client, mocked_responses):
    mocked_responses.add(responses.GET, f"{API}/user", json={"id": 1}, status=200)
    client.get_current_user()
    assert mocked_responses.calls[0].request.headers["PRIVATE-TOKEN"] == "tok"
    assert "Authorization" not in mocked_responses.calls[0].request.headers


def test_user_token_uses_bearer_header(mocked_responses):
    user_client = GitLabClient(token="oauth-tok", api_url=API, token_kind="user")
    mocked_responses.add(responses.GET, f"{API}/user", json={"id": 1}, status=200)
    user_client.get_current_user()
    assert mocked_responses.calls[0].request.headers["Authorization"] == "Bearer oauth-tok"


@pytest.mark.parametrize(
    "status,exc",
    [
        (401, GitLabAuthError),
        (403, GitLabForbidden),
        (404, GitLabNotFound),
        (400, GitLabValidationError),
        (500, GitLabServerError),
    ],
)
def test_error_statuses_map_to_typed_exceptions(client, mocked_responses, status, exc):
    mocked_responses.add(
        responses.GET, f"{API}/projects/1", json={"message": "nope"}, status=status
    )
    with pytest.raises(exc):
        client.get_project(1)


class TestPagination:
    """The Commits API omits x-total/x-total-pages, so paging cannot rely on
    counts and must walk until a page comes back short."""

    def test_walks_until_short_page_without_total_headers(self, client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/1/repository/commits",
            json=[{"id": f"sha{i}"} for i in range(100)], status=200,
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/1/repository/commits",
            json=[{"id": "sha100"}], status=200,
        )

        items = list(client.paginate("/projects/1/repository/commits"))

        assert len(items) == 101
        assert len(mocked_responses.calls) == 2

    def test_stops_on_empty_page(self, client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/x", json=[{"id": i} for i in range(100)], status=200
        )
        mocked_responses.add(responses.GET, f"{API}/x", json=[], status=200)

        assert len(list(client.paginate("/x"))) == 100

    def test_follows_x_next_page_header(self, client, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/x",
            json=[{"id": i} for i in range(100)],
            status=200, headers={"x-next-page": "7"},
        )
        mocked_responses.add(responses.GET, f"{API}/x", json=[], status=200)

        list(client.paginate("/x"))

        assert mocked_responses.calls[1].request.params["page"] == "7"

    def test_empty_x_page_header_ends_iteration(self, client, mocked_responses):
        """GitLab signals the final page with an empty x-next-page."""
        mocked_responses.add(
            responses.GET, f"{API}/x",
            json=[{"id": i} for i in range(100)],
            status=200, headers={"x-page": "1", "x-next-page": ""},
        )

        assert len(list(client.paginate("/x"))) == 100
        assert len(mocked_responses.calls) == 1


class TestListCommits:
    def test_defaults_to_all_branches(self, client, mocked_responses):
        """Without all=true GitLab returns only the default branch, which makes
        a team working on feature branches look inactive."""
        mocked_responses.add(responses.GET, f"{API}/projects/1/repository/commits", json=[])

        list(client.list_commits(1))

        params = mocked_responses.calls[0].request.params
        assert params["all"] == "True"
        assert "ref_name" not in params

    def test_ref_name_is_dropped_when_all_is_set(self, client, mocked_responses):
        """all=true makes GitLab ignore ref_name; sending both is misleading."""
        mocked_responses.add(responses.GET, f"{API}/projects/1/repository/commits", json=[])

        list(client.list_commits(1, ref_name="feature/x"))

        assert "ref_name" not in mocked_responses.calls[0].request.params

    def test_ref_name_is_sent_when_all_is_disabled(self, client, mocked_responses):
        mocked_responses.add(responses.GET, f"{API}/projects/1/repository/commits", json=[])

        list(client.list_commits(1, ref_name="feature/x", all_branches=False))

        params = mocked_responses.calls[0].request.params
        assert params["ref_name"] == "feature/x"
        assert "all" not in params

    def test_since_until_are_iso_formatted(self, client, mocked_responses):
        from datetime import UTC, datetime

        mocked_responses.add(responses.GET, f"{API}/projects/1/repository/commits", json=[])

        list(client.list_commits(1, since=datetime(2026, 7, 1, tzinfo=UTC)))

        assert mocked_responses.calls[0].request.params["since"].startswith("2026-07-01T")


class TestCreateProject:
    def test_initializes_repo_so_a_default_branch_exists(self, client, mocked_responses):
        """An uninitialized project has no branches at all, which would break
        the very next step of committing docs onto a documentation branch."""
        mocked_responses.add(responses.POST, f"{API}/projects", json={"id": 9}, status=201)

        client.create_project("Apollo", namespace_id=42)

        body = mocked_responses.calls[0].request.body
        import json as _json

        payload = _json.loads(body)
        assert payload["initialize_with_readme"] is True
        assert payload["default_branch"] == "main"
        assert payload["namespace_id"] == 42

    def test_rejects_full_ref_as_default_branch(self, client):
        """A full ref silently skips initialization on GitLab's side."""
        with pytest.raises(GitLabValidationError, match="bare branch name"):
            client.create_project("Apollo", default_branch="refs/heads/main")


class TestCreateCommit:
    def test_start_branch_creates_branch_atomically(self, client, mocked_responses):
        import json as _json

        mocked_responses.add(
            responses.POST, f"{API}/projects/1/repository/commits", json={"id": "abc"}, status=201
        )

        client.create_commit(
            1,
            branch="documentation",
            commit_message="Add BRD",
            actions=[{"action": "create", "file_path": "docs/BRD.pdf", "content": "x"}],
            start_branch="main",
        )

        payload = _json.loads(mocked_responses.calls[0].request.body)
        assert payload["branch"] == "documentation"
        assert payload["start_branch"] == "main"

    def test_start_branch_and_start_sha_are_mutually_exclusive(self, client):
        with pytest.raises(GitLabValidationError):
            client.create_commit(
                1, branch="b", commit_message="m", actions=[],
                start_branch="main", start_sha="abc123",
            )


class TestMembers:
    def test_uses_members_all_to_include_inherited(self, client, mocked_responses):
        """Most teams grant access at the group level; checking only direct
        members would report a staffed project as having none."""
        mocked_responses.add(responses.GET, f"{API}/projects/1/members/all", json=[])

        list(client.list_members(1))

        assert "/members/all" in mocked_responses.calls[0].request.url


class TestRetries:
    def test_retries_retryable_status_then_succeeds(self, mocked_responses, monkeypatch):
        monkeypatch.setattr("gitlab_integration.client.time.sleep", lambda _s: None)
        c = GitLabClient(token="t", api_url=API, max_retries=2)
        mocked_responses.add(responses.GET, f"{API}/projects/1", json={}, status=502)
        mocked_responses.add(responses.GET, f"{API}/projects/1", json={"id": 1}, status=200)

        assert c.get_project(1)["id"] == 1
        assert len(mocked_responses.calls) == 2

    def test_gives_up_after_max_retries(self, mocked_responses, monkeypatch):
        monkeypatch.setattr("gitlab_integration.client.time.sleep", lambda _s: None)
        c = GitLabClient(token="t", api_url=API, max_retries=1)
        for _ in range(3):
            mocked_responses.add(responses.GET, f"{API}/projects/1", json={}, status=503)

        with pytest.raises(GitLabServerError):
            c.get_project(1)

    def test_honours_retry_after_header(self, mocked_responses, monkeypatch):
        slept = []
        monkeypatch.setattr("gitlab_integration.client.time.sleep", slept.append)
        c = GitLabClient(token="t", api_url=API, max_retries=1)
        mocked_responses.add(
            responses.GET, f"{API}/projects/1", json={}, status=429,
            headers={"Retry-After": "3"},
        )
        mocked_responses.add(responses.GET, f"{API}/projects/1", json={"id": 1}, status=200)

        c.get_project(1)

        assert slept == [3.0]


def test_branch_exists_maps_404_to_false(client, mocked_responses):
    mocked_responses.add(
        responses.GET, f"{API}/projects/1/repository/branches/documentation",
        json={"message": "404"}, status=404,
    )
    assert client.branch_exists(1, "documentation") is False
