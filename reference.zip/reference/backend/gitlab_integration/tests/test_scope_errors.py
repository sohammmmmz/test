"""A missing token scope must not be reported as a permissions problem.

GitLab answers both with a 403, but the fixes are opposite: a scope problem
needs a *new token*, and no amount of adding the account to projects will help.
"""

import pytest
import responses

from gitlab_integration.client import GitLabClient
from gitlab_integration.exceptions import GitLabForbidden, GitLabInsufficientScope

API = "https://gitlab.example.com/api/v4"


@pytest.fixture
def client():
    return GitLabClient(token="tok", api_url=API, max_retries=0)


def test_insufficient_scope_in_the_body_is_recognised(client, mocked_responses):
    mocked_responses.add(
        responses.GET, f"{API}/projects/1",
        json={"error": "insufficient_scope"}, status=403,
    )

    with pytest.raises(GitLabInsufficientScope):
        client.get_project(1)


def test_insufficient_scope_in_the_www_authenticate_header_is_recognised(
    client, mocked_responses
):
    """GitLab signals it there rather than in the body on some endpoints."""
    mocked_responses.add(
        responses.GET, f"{API}/projects/1",
        json={"message": "403 Forbidden"}, status=403,
        headers={
            "WWW-Authenticate": 'Bearer error="insufficient_scope", scope="api"'
        },
    )

    with pytest.raises(GitLabInsufficientScope):
        client.get_project(1)


def test_an_ordinary_403_is_not_mistaken_for_a_scope_problem(client, mocked_responses):
    mocked_responses.add(
        responses.GET, f"{API}/projects/1",
        json={"message": "403 Forbidden - You are not a member"}, status=403,
    )

    with pytest.raises(GitLabForbidden) as exc:
        client.get_project(1)

    assert not isinstance(exc.value, GitLabInsufficientScope)


def test_scope_errors_remain_a_kind_of_forbidden(client, mocked_responses):
    """Existing `except GitLabForbidden` handlers must keep working."""
    mocked_responses.add(
        responses.GET, f"{API}/projects/1",
        json={"error": "insufficient_scope"}, status=403,
    )

    with pytest.raises(GitLabForbidden):
        client.get_project(1)


@pytest.mark.django_db
class TestSurfacedMessages:
    def test_available_repos_explains_the_scope_problem(self, api_client, mocked_responses):
        """This is the exact response the repo picker showed as a raw 403."""
        mocked_responses.add(
            responses.GET, f"{API}/projects",
            json={"error": "insufficient_scope"}, status=403,
        )

        data = api_client.get("/api/projects/available-repos/").json()

        assert data["code"] == "service_token_scope"
        assert "'api' scope" in data["detail"]
        assert "create a new one" in data["detail"].lower()

    def test_validation_explains_the_scope_problem(self, api_client, admin_user, mocked_responses):
        from accounts.models import GitLabOAuthToken

        GitLabOAuthToken.objects.create(user=admin_user, access_token="at", refresh_token="rt")
        mocked_responses.add(
            responses.GET, f"{API}/projects/acme%2Fapollo",
            json={"id": 555, "path_with_namespace": "acme/apollo", "namespace": {}},
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555",
            json={"error": "insufficient_scope"}, status=403,
        )

        response = api_client.post(
            "/api/projects/validate-repo/", {"repo_reference": "acme/apollo"}
        )

        assert response.json()["valid"] is False
        assert "'api' scope" in response.json()["detail"]
