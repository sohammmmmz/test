"""GitLab integration state.

Only the group-level webhook registration is persisted here; per-user OAuth
tokens live in ``accounts`` and received deliveries live in ``sync``.
"""

from django.db import models

from common.models import TimeStampedModel


class GroupWebhook(TimeStampedModel):
    """The single group-level webhook covering every project and subgroup.

    Registered once at the group rather than per project: one hook, one secret
    to rotate, and new repositories are covered the moment they are created.
    """

    group_id = models.CharField(max_length=64, unique=True)
    gitlab_hook_id = models.BigIntegerField(null=True, blank=True)
    url = models.URLField()
    # Stored so rotation can be detected; never returned by the API.
    signing_token_fingerprint = models.CharField(max_length=64, blank=True)

    push_events = models.BooleanField(default=True)
    merge_requests_events = models.BooleanField(default=True)
    issues_events = models.BooleanField(default=True)
    tag_push_events = models.BooleanField(default=False)

    is_active = models.BooleanField(default=True)
    last_registered_at = models.DateTimeField(null=True, blank=True)
    last_error = models.TextField(blank=True)

    def __str__(self):
        return f"group webhook {self.group_id} -> {self.url}"
