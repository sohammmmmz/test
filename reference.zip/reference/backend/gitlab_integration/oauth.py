"""GitLab OAuth 2.0 authorization-code flow.

Scope of this module: signing people in, and giving us a token to act *as them*
for the one check that genuinely requires it — whether a repository they are
registering is visible to their own account. Everything scheduled runs on the
service credential instead.

The refresh path is the subtle part. GitLab access tokens live two hours, and
exchanging a refresh token invalidates both the old access token *and* the old
refresh token. If the process dies between "GitLab issued a new pair" and "the
new pair is committed", that user's connection is permanently orphaned — the
stored refresh token is already dead and there is nothing to retry with. So the
refresh is serialized with a row lock and the write is the last thing that
happens.
"""

from __future__ import annotations

import logging
import secrets
from datetime import timedelta

import requests
from django.conf import settings
from django.db import transaction
from django.utils import timezone

from accounts.models import GitLabOAuthToken, OAuthState, User

from .client import GitLabClient
from .exceptions import GitLabAuthError, GitLabError

logger = logging.getLogger(__name__)

STATE_TTL_SECONDS = 600
MAX_REFRESH_FAILURES = 3


def build_authorize_url(redirect_to: str = "") -> tuple[str, OAuthState]:
    """Create a CSRF state and return the GitLab authorization URL."""
    if not settings.GITLAB_OAUTH_CLIENT_ID:
        raise GitLabError("GITLAB_OAUTH_CLIENT_ID is not configured.")

    state = OAuthState.objects.create(
        state=secrets.token_urlsafe(32),
        redirect_to=redirect_to or "",
        expires_at=timezone.now() + timedelta(seconds=STATE_TTL_SECONDS),
    )

    from urllib.parse import urlencode

    query = urlencode(
        {
            "client_id": settings.GITLAB_OAUTH_CLIENT_ID,
            "redirect_uri": settings.GITLAB_OAUTH_REDIRECT_URI,
            "response_type": "code",
            "state": state.state,
            "scope": settings.GITLAB_OAUTH_SCOPES,
        }
    )
    return f"{settings.GITLAB_URL}/oauth/authorize?{query}", state


def consume_state(raw_state: str) -> OAuthState:
    """Validate and single-use a state value."""
    try:
        state = OAuthState.objects.get(state=raw_state)
    except OAuthState.DoesNotExist as exc:
        raise GitLabAuthError("Unknown OAuth state; the login attempt is not recognised.") from exc

    if not state.is_usable:
        raise GitLabAuthError("This OAuth state has expired or already been used.")

    state.consumed_at = timezone.now()
    state.save(update_fields=["consumed_at", "updated_at"])
    return state


def _token_request(payload: dict) -> dict:
    response = requests.post(
        f"{settings.GITLAB_URL}/oauth/token",
        data=payload,
        timeout=settings.GITLAB_TIMEOUT,
        headers={"Accept": "application/json"},
    )
    if response.status_code >= 400:
        try:
            detail = response.json()
        except ValueError:
            detail = response.text[:500]
        raise GitLabAuthError(
            f"Token endpoint returned {response.status_code}: {detail}",
            status_code=response.status_code,
            payload=detail if isinstance(detail, dict) else None,
        )
    return response.json()


def exchange_code_for_token(code: str) -> dict:
    return _token_request(
        {
            "client_id": settings.GITLAB_OAUTH_CLIENT_ID,
            "client_secret": settings.GITLAB_OAUTH_CLIENT_SECRET,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": settings.GITLAB_OAUTH_REDIRECT_URI,
        }
    )


def _expires_at(token_payload: dict):
    expires_in = token_payload.get("expires_in")
    if not expires_in:
        return None
    return timezone.now() + timedelta(seconds=int(expires_in))


@transaction.atomic
def upsert_user_from_token(token_payload: dict) -> tuple[User, GitLabOAuthToken]:
    """Create or update the local user from a fresh token, and store it.

    Every user of this tool is an admin, so ``is_staff`` is set on creation.
    """
    gitlab_user = GitLabClient.for_user(token_payload["access_token"]).get_current_user()

    user, created = User.objects.update_or_create(
        gitlab_user_id=gitlab_user["id"],
        defaults={
            "username": gitlab_user.get("username") or f"gl-{gitlab_user['id']}",
            "email": gitlab_user.get("email") or f"{gitlab_user['id']}@users.noreply.gitlab.com",
            "first_name": (gitlab_user.get("name") or "").split(" ")[0][:150],
            "gitlab_username": gitlab_user.get("username", ""),
            "gitlab_avatar_url": gitlab_user.get("avatar_url") or "",
            "gitlab_web_url": gitlab_user.get("web_url") or "",
            "last_login_at": timezone.now(),
        },
    )
    if created:
        user.is_staff = True
        user.set_unusable_password()
        user.save(update_fields=["is_staff", "password"])

    token, _ = GitLabOAuthToken.objects.update_or_create(
        user=user,
        defaults={
            "access_token": token_payload["access_token"],
            "refresh_token": token_payload.get("refresh_token", ""),
            "token_type": token_payload.get("token_type", "Bearer"),
            "scope": token_payload.get("scope", ""),
            "expires_at": _expires_at(token_payload),
            "is_revoked": False,
            "refresh_failure_count": 0,
            "last_refreshed_at": timezone.now(),
        },
    )
    return user, token


def _record_refresh_failure(token_pk: int) -> None:
    """Persist a failed refresh in its own transaction.

    Deliberately separate from the refresh transaction: raising out of that
    block would roll back the very row that records the failure, so the counter
    would never advance and a permanently dead token would be retried forever.
    """
    with transaction.atomic():
        locked = GitLabOAuthToken.objects.select_for_update().get(pk=token_pk)
        locked.refresh_failure_count += 1
        # GitLab invalidates the old refresh token as soon as it issues a new
        # pair, whether or not we received it. Repeated failures therefore mean
        # this token is dead rather than temporarily unlucky.
        if locked.refresh_failure_count >= MAX_REFRESH_FAILURES:
            locked.is_revoked = True
        locked.save(update_fields=["refresh_failure_count", "is_revoked", "updated_at"])


def refresh_user_token(token: GitLabOAuthToken) -> GitLabOAuthToken:
    """Exchange the refresh token for a new pair.

    Serialized on the token row: two concurrent requests both refreshing would
    otherwise race, and the loser would persist a refresh token GitLab has
    already invalidated.
    """
    refresh_error: GitLabAuthError | None = None

    with transaction.atomic():
        locked = GitLabOAuthToken.objects.select_for_update().get(pk=token.pk)

        # Another request may have refreshed while we waited for the lock.
        if not locked.is_expired():
            return locked

        if locked.is_revoked or not locked.refresh_token:
            raise GitLabAuthError(
                f"{locked.user} must re-authorize with GitLab: no usable refresh token."
            )

        try:
            payload = _token_request(
                {
                    "client_id": settings.GITLAB_OAUTH_CLIENT_ID,
                    "client_secret": settings.GITLAB_OAUTH_CLIENT_SECRET,
                    "refresh_token": locked.refresh_token,
                    "grant_type": "refresh_token",
                    "redirect_uri": settings.GITLAB_OAUTH_REDIRECT_URI,
                }
            )
        except GitLabAuthError as exc:
            refresh_error = exc
        else:
            locked.access_token = payload["access_token"]
            # A rotation that omits a new refresh token would leave the old, now
            # invalid, one in place — keep whatever GitLab returned.
            locked.refresh_token = payload.get("refresh_token", locked.refresh_token)
            locked.expires_at = _expires_at(payload)
            locked.scope = payload.get("scope", locked.scope)
            locked.is_revoked = False
            locked.refresh_failure_count = 0
            locked.last_refreshed_at = timezone.now()
            locked.save()
            return locked

    _record_refresh_failure(token.pk)
    raise refresh_error


def get_user_client(user: User) -> GitLabClient:
    """A GitLab client acting as ``user``, refreshing the token if needed."""
    try:
        token = user.gitlab_token
    except GitLabOAuthToken.DoesNotExist as exc:
        raise GitLabAuthError(f"{user} has not connected a GitLab account.") from exc

    if token.is_revoked:
        raise GitLabAuthError(f"{user} must re-authorize with GitLab.")
    if token.is_expired():
        token = refresh_user_token(token)

    return GitLabClient.for_user(token.access_token)


def revoke_user_token(user: User) -> None:
    token = GitLabOAuthToken.objects.filter(user=user).first()
    if not token:
        return
    try:
        requests.post(
            f"{settings.GITLAB_URL}/oauth/revoke",
            data={
                "client_id": settings.GITLAB_OAUTH_CLIENT_ID,
                "client_secret": settings.GITLAB_OAUTH_CLIENT_SECRET,
                "token": token.access_token,
            },
            timeout=settings.GITLAB_TIMEOUT,
        )
    except requests.RequestException:
        # Best effort: the local record is what governs our own access.
        logger.warning("Could not revoke GitLab token for %s upstream", user, exc_info=True)

    token.is_revoked = True
    token.save(update_fields=["is_revoked", "updated_at"])
