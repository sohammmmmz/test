"""Typed GitLab API failures.

Callers need to distinguish "the repo does not exist" from "you cannot see it"
from "GitLab is having a bad day" — during project registration those three
produce very different messages for the admin.
"""


class GitLabError(Exception):
    """Base class for every GitLab API failure."""

    def __init__(self, message: str, status_code: int | None = None, payload=None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.payload = payload

    def __str__(self):
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class GitLabAuthError(GitLabError):
    """401 — the token is invalid, expired, or revoked."""


class GitLabForbidden(GitLabError):
    """403 — authenticated but not permitted.

    Distinct from :class:`GitLabNotFound` even though GitLab often returns 404
    for resources you cannot see, precisely to avoid leaking their existence.
    """


class GitLabInsufficientScope(GitLabForbidden):
    """403 ``insufficient_scope`` — the token is valid but lacks the scope.

    Distinct from a plain 403 because the fix is completely different: the
    token is not missing *membership*, it is missing a *scope*, and no amount
    of adding the account to projects will help.
    """


class GitLabNotFound(GitLabError):
    """404 — no such resource, or it is invisible to this token."""


class GitLabConflict(GitLabError):
    """409 / 400 on create — the resource already exists."""


class GitLabRateLimited(GitLabError):
    """429 — too many requests. Carries the server's Retry-After when given."""

    def __init__(self, message: str, retry_after: float | None = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class GitLabServerError(GitLabError):
    """5xx — retryable."""


class GitLabValidationError(GitLabError):
    """400 / 422 — GitLab rejected the request body."""
