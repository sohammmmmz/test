from django.urls import path

from . import views

urlpatterns = [
    path("<int:project_id>/graph", views.vault_graph, name="vault-graph"),
    path("<int:project_id>/snapshots", views.vault_snapshots, name="vault-snapshots"),
    path("<int:project_id>/regenerate", views.regenerate, name="vault-regenerate"),
    path("<int:project_id>/node/<str:slug>", views.vault_node, name="vault-node"),
]

urlpatterns += [
    path("<int:project_id>/code", views.code_map, name="vault-code-map"),
    path("<int:project_id>/reindex", views.reindex_code, name="vault-reindex-code"),
    path("<int:project_id>/code-graph", views.code_graph, name="vault-code-graph"),
]
