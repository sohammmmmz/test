"""Generating the project vault from synced state.

Produces one markdown file per entity — the project, its milestones, tasks,
people, code modules, documents and daily activity — linked with wikilinks.
The result is browsable in Obsidian, diffable in git, and directly usable as
LLM context, since markdown is what a model consumes best.

Modules are inferred by clustering the paths that commits touch. That is a
heuristic, not a code parse: it answers "which parts of the codebase is work
landing in" without needing a language-aware analyser for every stack the team
uses.
"""

from __future__ import annotations

import logging
from collections import Counter, defaultdict
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from activity.models import Branch, Commit, Issue, Milestone, ProjectMember
from projects.models import Document, Project
from team.models import Assignment, active_assignments_q

from .code_models import CodeFile
from .markdown import (
    content_hash,
    extract_frontmatter_links,
    extract_wikilinks,
    render_markdown,
    slugify_node,
    tree_hash,
    wikilink,
)
from .models import EdgeType, NodeType, VaultEdge, VaultNode, VaultSnapshot

logger = logging.getLogger(__name__)

VAULT_ROOT = "vault"
ACTIVITY_WINDOW_DAYS = 30
MAX_MODULE_DEPTH = 2


class NodeDraft:
    """An in-memory node before it is persisted."""

    __slots__ = (
        "node_type", "path", "slug", "title", "frontmatter", "body",
        "source_model", "source_id",
    )

    def __init__(
        self, node_type, path, slug, title, frontmatter, body,
        source_model="", source_id=None,
    ):
        self.node_type = node_type
        self.path = path
        self.slug = slug
        self.title = title
        self.frontmatter = frontmatter
        self.body = body
        self.source_model = source_model
        self.source_id = source_id

    @property
    def content_hash(self) -> str:
        return content_hash(self.frontmatter, self.body)

    def render(self) -> str:
        return render_markdown(self.frontmatter, self.body)


# ---------------------------------------------------------------------------
# Node builders
# ---------------------------------------------------------------------------


def _person_slug(employee) -> str:
    return slugify_node(employee.full_name)


def _milestone_slug(milestone) -> str:
    return slugify_node(milestone.title)


def _task_slug(issue) -> str:
    return slugify_node(f"ISSUE-{issue.iid}-{issue.title}"[:90])


def _module_slug(path: str) -> str:
    return slugify_node(path.replace("/", "-"))


def _fmt_date(value) -> str | None:
    return value.isoformat() if value else None


def build_project_node(project: Project, context: dict) -> NodeDraft:
    repo = getattr(project, "repo", None)
    frontmatter = {
        "type": "project",
        "slug": project.slug,
        "status": project.status,
        "health": project.health_state,
        "health_score": project.health_score,
        "repo": repo.path_with_namespace if repo else None,
        "started_on": _fmt_date(project.started_on),
        "target_end_on": _fmt_date(project.target_end_on),
        "owner": wikilink(_person_slug(project.owner)) if project.owner else None,
        "generated_at": timezone.now().isoformat(),
    }

    lines = [f"# {project.name}", ""]
    if project.description:
        lines += [project.description, ""]

    if context["milestones"]:
        lines.append("## Milestones")
        for milestone in context["milestones"]:
            due = f" — due {milestone.due_date}" if milestone.due_date else ""
            lines.append(f"- {wikilink(_milestone_slug(milestone))} ({milestone.state}){due}")
        lines.append("")

    if context["people"]:
        lines.append("## Team")
        for employee, role, allocation in context["people"]:
            lines.append(f"- {wikilink(_person_slug(employee))} — {role} ({allocation}%)")
        lines.append("")

    if context["modules"]:
        lines.append("## Modules")
        for path, count in context["modules"]:
            lines.append(f"- {wikilink(_module_slug(path))} — {count} commit(s)")
        lines.append("")

    if context["documents"]:
        lines.append("## Documents")
        for document in context["documents"]:
            lines.append(
                f"- {wikilink(slugify_node(document.get_kind_display()))} "
                f"(`{document.repo_path}`)"
            )
        lines.append("")

    open_tasks = [i for i in context["issues"] if i.state == "opened"]
    if open_tasks:
        lines.append("## Open tasks")
        for issue in open_tasks[:50]:
            lines.append(f"- {wikilink(_task_slug(issue))}")
        lines.append("")

    return NodeDraft(
        NodeType.PROJECT, f"{VAULT_ROOT}/Project.md", slugify_node(project.name),
        project.name, frontmatter, "\n".join(lines), "projects.Project", project.pk,
    )


def build_milestone_node(milestone: Milestone, issues: list[Issue]) -> NodeDraft:
    slug = _milestone_slug(milestone)
    closed = [i for i in issues if i.state == "closed"]
    frontmatter = {
        "type": "milestone",
        "gitlab_id": milestone.gitlab_id,
        "state": milestone.state,
        "start_date": _fmt_date(milestone.start_date),
        "due_date": _fmt_date(milestone.due_date),
        "expired": milestone.expired,
        "progress": f"{len(closed)}/{len(issues)}",
        "url": milestone.web_url or None,
    }

    lines = [f"# {milestone.title}", ""]
    if milestone.description:
        lines += [milestone.description, ""]
    if milestone.due_date:
        remaining = (milestone.due_date - timezone.localdate()).days
        state = (
            f"{remaining} day(s) remaining" if remaining >= 0
            else f"{-remaining} day(s) overdue"
        )
        lines += [f"Due {milestone.due_date} — {state}.", ""]
    if issues:
        lines.append("## Tasks")
        for issue in issues:
            mark = "x" if issue.state == "closed" else " "
            lines.append(f"- [{mark}] {wikilink(_task_slug(issue))}")
        lines.append("")

    return NodeDraft(
        NodeType.MILESTONE, f"{VAULT_ROOT}/milestones/{slug}.md", slug,
        milestone.title, frontmatter, "\n".join(lines), "activity.Milestone", milestone.pk,
    )


def build_task_node(issue: Issue, commits: list[Commit], modules: list[str]) -> NodeDraft:
    slug = _task_slug(issue)
    assignees = list(issue.assignees.all())
    frontmatter = {
        "type": "task",
        "gitlab_iid": issue.iid,
        "state": issue.state,
        "labels": issue.labels or [],
        "assignees": [wikilink(_person_slug(a)) for a in assignees] or None,
        "milestone": wikilink(_milestone_slug(issue.milestone)) if issue.milestone else None,
        "due_date": _fmt_date(issue.due_date),
        "url": issue.web_url or None,
    }

    lines = [f"# #{issue.iid} {issue.title}", ""]
    if issue.description:
        lines += [issue.description.strip()[:4000], ""]
    if modules:
        lines += ["Touches " + ", ".join(wikilink(_module_slug(m)) for m in modules), ""]
    if commits:
        lines.append("## Linked commits")
        for commit in commits[:40]:
            author = (
                wikilink(_person_slug(commit.author_employee))
                if commit.author_employee
                else commit.author_name or "unknown"
            )
            lines.append(
                f"- `{commit.short_id or commit.sha[:8]}` {commit.title[:90]} — {author}"
            )
        lines.append("")

    return NodeDraft(
        NodeType.TASK, f"{VAULT_ROOT}/tasks/{slug}.md", slug,
        f"#{issue.iid} {issue.title}", frontmatter, "\n".join(lines),
        "activity.Issue", issue.pk,
    )


def build_person_node(employee, project: Project, stats: dict) -> NodeDraft:
    slug = _person_slug(employee)
    frontmatter = {
        "type": "person",
        "email": employee.official_email,
        "employment_type": employee.employment_type,
        "gitlab_username": employee.gitlab_username or None,
        "role_on_project": stats.get("role"),
        "allocation_percent": stats.get("allocation"),
        "commits_30d": stats.get("commits", 0),
        "last_commit_at": stats.get("last_commit_at"),
    }

    lines = [f"# {employee.full_name}", ""]
    lines.append(f"Works on {wikilink(slugify_node(project.name))}.")
    lines.append("")

    if stats.get("issues"):
        lines.append("## Assigned tasks")
        for issue in stats["issues"]:
            lines.append(f"- {wikilink(_task_slug(issue))} ({issue.state})")
        lines.append("")

    if stats.get("branches"):
        lines.append("## Branches")
        for branch in stats["branches"]:
            lines.append(f"- `{branch.name}` — last commit {branch.last_commit_at:%Y-%m-%d}")
        lines.append("")

    if stats.get("commits", 0) == 0 and stats.get("allocation"):
        # Worth stating plainly in the vault, since this is the gap the
        # utilization view exists to surface.
        lines += [
            f"> Allocated {stats['allocation']}% but no commits in the last "
            f"{ACTIVITY_WINDOW_DAYS} days.",
            "",
        ]

    return NodeDraft(
        NodeType.PERSON, f"{VAULT_ROOT}/people/{slug}.md", slug,
        employee.full_name, frontmatter, "\n".join(lines), "team.Employee", employee.pk,
    )


def build_module_node(
    path: str, commits: list[Commit], project: Project, code_files=None
) -> NodeDraft:
    """A code area, described by what is in it and who works on it.

    When the codebase has been indexed the description comes from the actual
    files, classes and functions found there; otherwise it falls back to commit
    paths alone, which says where work lands but not what lives there.
    """
    slug = _module_slug(path)
    contributors = Counter(
        c.author_employee.full_name for c in commits if c.author_employee
    )
    last = max((c.authored_date for c in commits), default=None)
    files = list(code_files or [])

    symbol_total = sum(len(f.cached_symbols) for f in files)
    frontmatter = {
        "type": "module",
        "path": path,
        "commit_count": len(commits),
        "file_count": len(files) or None,
        "symbol_count": symbol_total or None,
        "languages": sorted({f.language for f in files if f.language}) or None,
        "last_commit_at": last.isoformat() if last else None,
        "contributors": [wikilink(slugify_node(n)) for n, _ in contributors.most_common(10)]
        or None,
    }

    lines = [
        f"# {path}",
        "",
        f"Code area within {wikilink(slugify_node(project.name))}"
        + (
            f", holding {len(files)} indexed file(s) and {symbol_total} symbol(s)."
            if files
            else ", inferred from commit paths."
        ),
        "",
    ]

    if files:
        lines.append("## Files")
        for code_file in files[:40]:
            summary = f" — {code_file.summary}" if code_file.summary else ""
            lines.append(f"- `{code_file.path}`{summary}")
        lines.append("")

        named = [
            (f, s) for f in files for s in f.cached_symbols if s.kind in ("class", "interface")
        ]
        if named:
            lines.append("## Classes and interfaces")
            for code_file, symbol in named[:40]:
                detail = f" — {symbol.summary}" if symbol.summary else ""
                lines.append(f"- **{symbol.name}** (`{code_file.path}`){detail}")
            lines.append("")

    if contributors:
        lines.append("## Contributors")
        for name, count in contributors.most_common(10):
            lines.append(f"- {wikilink(slugify_node(name))} — {count} commit(s)")
        lines.append("")

    return NodeDraft(
        NodeType.MODULE, f"{VAULT_ROOT}/modules/{slug}.md", slug, path, frontmatter,
        "\n".join(lines),
    )


def build_document_node(document: Document, project: Project) -> NodeDraft:
    slug = slugify_node(document.get_kind_display())
    frontmatter = {
        "type": "document",
        "kind": document.kind,
        "repo_path": document.repo_path,
        "filename": document.filename,
        "committed_at": document.committed_at.isoformat() if document.committed_at else None,
        "summary_model": document.summary_model_version or None,
    }

    lines = [
        f"# {document.get_kind_display()}",
        "",
        f"Source: `{document.repo_path}` on the "
        f"`{settings.DOCUMENTATION_BRANCH}` branch.",
        "",
        f"Documents {wikilink(slugify_node(project.name))}.",
        "",
    ]
    if document.summary:
        lines += ["## Summary", "", document.summary, ""]
    else:
        lines += ["_No summary extracted yet._", ""]

    return NodeDraft(
        NodeType.DOCUMENT, f"{VAULT_ROOT}/docs/{slug}.md", slug,
        document.get_kind_display(), frontmatter, "\n".join(lines),
        "projects.Document", document.pk,
    )


def build_activity_node(day, commits: list[Commit], project: Project) -> NodeDraft:
    slug = day.isoformat()
    by_author: dict[str, list[Commit]] = defaultdict(list)
    for commit in commits:
        name = commit.author_employee.full_name if commit.author_employee else (
            commit.author_name or "Unattributed"
        )
        by_author[name].append(commit)

    frontmatter = {
        "type": "activity",
        "date": slug,
        "commit_count": len(commits),
        "contributors": [
            wikilink(slugify_node(n)) for n in sorted(by_author) if n != "Unattributed"
        ] or None,
    }

    lines = [f"# {slug}", "", f"Activity on {wikilink(slugify_node(project.name))}.", ""]
    for name in sorted(by_author):
        lines.append(f"## {name}")
        for commit in by_author[name][:30]:
            lines.append(f"- `{commit.short_id or commit.sha[:8]}` {commit.title[:100]}")
        lines.append("")

    return NodeDraft(
        NodeType.ACTIVITY, f"{VAULT_ROOT}/activity/{slug}.md", f"activity-{slug}",
        slug, frontmatter, "\n".join(lines),
    )


# ---------------------------------------------------------------------------
# Assembly
# ---------------------------------------------------------------------------


def _module_for_path(file_path: str) -> str:
    """Reduce a file path to a module key: its leading directories.

    The filename is dropped first — keeping it would make every shallow path
    its own module and the clustering would group nothing.
    """
    parts = [p for p in (file_path or "").split("/") if p]
    directories = parts[:-1]
    if not directories:
        return "(root)"
    return "/".join(directories[:MAX_MODULE_DEPTH])


def _module_commits(commits: list[Commit]) -> dict[str, list[Commit]]:
    """Group commits by inferred module, using the file paths they touched.

    Only commits whose diffs have been fetched carry ``changed_paths``; the
    rest contribute nothing rather than being clustered incorrectly.
    """
    modules: dict[str, list[Commit]] = defaultdict(list)
    for commit in commits:
        for path in {_module_for_path(p) for p in (commit.changed_paths or [])}:
            modules[path].append(commit)
    return modules


def collect_context(project: Project) -> dict:
    """Gather everything the node builders need, in a bounded set of queries."""
    repo = getattr(project, "repo", None)
    window_start = timezone.now() - timedelta(days=ACTIVITY_WINDOW_DAYS)

    if repo is None:
        return {
            "repo": None, "milestones": [], "issues": [], "commits": [],
            "people": [], "documents": [], "modules": [], "branches": [],
            "code_by_module": {}, "code_file_count": 0,
        }

    milestones = list(Milestone.objects.filter(repo=repo).order_by("due_date", "title"))
    issues = list(
        Issue.objects.filter(repo=repo)
        .select_related("milestone")
        .prefetch_related("assignees")
        .order_by("-gitlab_updated_at")[:500]
    )
    commits = list(
        Commit.objects.filter(repo=repo, authored_date__gte=window_start)
        .select_related("author_employee")
        .order_by("-authored_date")[:2000]
    )
    branches = list(
        Branch.objects.filter(repo=repo, is_present=True)
        .select_related("last_commit_author")
        .order_by("-last_commit_at")
    )
    documents = list(Document.objects.filter(project=project))

    assignments = list(
        Assignment.objects.filter(project=project)
        .filter(active_assignments_q())
        .select_related("employee")
    )
    people = [(a.employee, a.get_role_display(), a.allocation_percent) for a in assignments]

    # Members who commit but were never assigned in this app still belong in
    # the vault — otherwise the graph disagrees with reality.
    assigned_ids = {a.employee_id for a in assignments}
    for member in ProjectMember.objects.filter(repo=repo).select_related("employee"):
        if member.employee_id and member.employee_id not in assigned_ids:
            assigned_ids.add(member.employee_id)
            people.append((member.employee, member.access_level_display, 0))

    # The owner and anyone holding an issue are involved by definition, even
    # without an assignment row or GitLab membership. Omitting them would leave
    # the graph linking to people who have no note, turning a real relationship
    # into an unresolved link.
    if project.owner_id and project.owner_id not in assigned_ids:
        assigned_ids.add(project.owner_id)
        people.append((project.owner, "Owner", 0))

    for issue in issues:
        for assignee in issue.assignees.all():
            if assignee.pk not in assigned_ids:
                assigned_ids.add(assignee.pk)
                people.append((assignee, "Assignee", 0))

    module_counts = Counter(
        {path: len(group) for path, group in _module_commits(commits).items()}
    )

    # Indexed code contributes modules of its own — a package nobody has
    # touched recently still exists and still belongs on the map.
    code_by_module: dict[str, list] = defaultdict(list)
    code_files = list(
        CodeFile.objects.filter(project=project, is_present=True).prefetch_related("symbols")
    )
    for code_file in code_files:
        code_file.cached_symbols = list(code_file.symbols.all())
        code_by_module[code_file.module or "(root)"].append(code_file)
        module_counts.setdefault(code_file.module or "(root)", 0)

    return {
        "code_by_module": code_by_module,
        "code_file_count": len(code_files),
        "repo": repo,
        "milestones": milestones,
        "issues": issues,
        "commits": commits,
        "branches": branches,
        "documents": documents,
        "people": people,
        "modules": module_counts.most_common(60),
    }


def build_nodes(project: Project) -> list[NodeDraft]:
    """Build every node for a project's vault."""
    context = collect_context(project)
    drafts = [build_project_node(project, context)]

    issues_by_milestone: dict[int, list[Issue]] = defaultdict(list)
    for issue in context["issues"]:
        if issue.milestone_id:
            issues_by_milestone[issue.milestone_id].append(issue)

    for milestone in context["milestones"]:
        drafts.append(build_milestone_node(milestone, issues_by_milestone.get(milestone.pk, [])))

    commits_by_issue: dict[int, list[Commit]] = defaultdict(list)
    for commit in context["commits"]:
        for iid in commit.referenced_issue_iids or []:
            commits_by_issue[iid].append(commit)

    for issue in context["issues"]:
        linked = commits_by_issue.get(issue.iid, [])
        touched = sorted(
            {_module_for_path(p) for c in linked for p in (c.changed_paths or [])}
        )
        drafts.append(build_task_node(issue, linked, touched[:10]))

    commits_by_employee: dict[int, list[Commit]] = defaultdict(list)
    for commit in context["commits"]:
        if commit.author_employee_id:
            commits_by_employee[commit.author_employee_id].append(commit)

    issues_by_employee: dict[int, list[Issue]] = defaultdict(list)
    for issue in context["issues"]:
        for assignee in issue.assignees.all():
            issues_by_employee[assignee.pk].append(issue)

    branches_by_employee: dict[int, list[Branch]] = defaultdict(list)
    for branch in context["branches"]:
        if branch.last_commit_author_id and branch.last_commit_at:
            branches_by_employee[branch.last_commit_author_id].append(branch)

    for employee, role, allocation in context["people"]:
        person_commits = commits_by_employee.get(employee.pk, [])
        drafts.append(
            build_person_node(
                employee,
                project,
                {
                    "role": role,
                    "allocation": allocation,
                    "commits": len(person_commits),
                    "last_commit_at": (
                        person_commits[0].authored_date.isoformat() if person_commits else None
                    ),
                    "issues": issues_by_employee.get(employee.pk, [])[:30],
                    "branches": branches_by_employee.get(employee.pk, [])[:20],
                },
            )
        )

    module_commits = _module_commits(context["commits"])
    code_by_module = context.get("code_by_module", {})
    for path, _count in context["modules"]:
        drafts.append(
            build_module_node(
                path, module_commits.get(path, []), project, code_by_module.get(path, [])
            )
        )

    for document in context["documents"]:
        drafts.append(build_document_node(document, project))

    commits_by_day: dict[object, list[Commit]] = defaultdict(list)
    for commit in context["commits"]:
        commits_by_day[timezone.localtime(commit.authored_date).date()].append(commit)
    for day in sorted(commits_by_day, reverse=True)[:ACTIVITY_WINDOW_DAYS]:
        drafts.append(build_activity_node(day, commits_by_day[day], project))

    return _deduplicate(drafts)


def _deduplicate(drafts: list[NodeDraft]) -> list[NodeDraft]:
    """Two entities can slugify to the same name; keep the first and warn."""
    seen: dict[str, NodeDraft] = {}
    for draft in drafts:
        if draft.slug in seen:
            logger.warning(
                "Vault slug collision on %r (%s vs %s); keeping the first",
                draft.slug, seen[draft.slug].path, draft.path,
            )
            continue
        seen[draft.slug] = draft
    return list(seen.values())


# ---------------------------------------------------------------------------
# Persistence and mirroring
# ---------------------------------------------------------------------------


@transaction.atomic
def persist_nodes(project: Project, drafts: list[NodeDraft]) -> tuple[list[VaultNode], int, int]:
    """Upsert nodes and rebuild the edge table. Returns (nodes, edges, dangling)."""
    VaultNode.objects.filter(project=project).update(is_current=False)

    nodes: dict[str, VaultNode] = {}
    for draft in drafts:
        node, _created = VaultNode.objects.update_or_create(
            project=project,
            slug=draft.slug,
            defaults={
                "node_type": draft.node_type,
                "path": draft.path,
                "title": draft.title,
                "frontmatter": draft.frontmatter,
                "body": draft.body,
                "content_hash": draft.content_hash,
                "source_model": draft.source_model,
                "source_id": draft.source_id,
                "is_current": True,
            },
        )
        nodes[draft.slug] = node

    # Nodes that no longer exist upstream are removed along with their edges.
    VaultNode.objects.filter(project=project, is_current=False).delete()
    VaultEdge.objects.filter(project=project).delete()

    edges: list[VaultEdge] = []
    for draft in drafts:
        from_node = nodes[draft.slug]

        for key, target in extract_frontmatter_links(draft.frontmatter):
            edges.append(
                VaultEdge(
                    project=project, from_node=from_node, to_node=nodes.get(target),
                    to_slug=target, edge_type=_edge_type_for(key),
                    source=VaultEdge.Source.FRONTMATTER, label=key,
                )
            )

        frontmatter_targets = {t for _k, t in extract_frontmatter_links(draft.frontmatter)}
        for target in extract_wikilinks(draft.body):
            if target in frontmatter_targets:
                continue  # Already captured with a more meaningful label.
            edges.append(
                VaultEdge(
                    project=project, from_node=from_node, to_node=nodes.get(target),
                    to_slug=target, edge_type=EdgeType.REFERENCES,
                    source=VaultEdge.Source.BODY,
                )
            )

    VaultEdge.objects.bulk_create(edges, batch_size=1000)
    dangling = sum(1 for e in edges if e.to_node_id is None)
    return list(nodes.values()), len(edges), dangling


_EDGE_TYPE_BY_KEY = {
    "assignees": EdgeType.ASSIGNED_TO,
    "assignee": EdgeType.ASSIGNED_TO,
    "owner": EdgeType.ASSIGNED_TO,
    "milestone": EdgeType.BELONGS_TO,
    "contributors": EdgeType.AUTHORED,
    "modules": EdgeType.TOUCHES,
}


def _edge_type_for(key: str) -> str:
    return _EDGE_TYPE_BY_KEY.get(key, EdgeType.REFERENCES)


def snapshot_hashes(project: Project) -> dict[str, str]:
    """Current on-record content hash per path.

    Must be captured *before* ``persist_nodes`` writes the new generation,
    otherwise change detection compares the new content against itself, finds
    no difference, and the mirror silently stops updating after its first commit.
    """
    return dict(
        VaultNode.objects.filter(project=project).values_list("path", "content_hash")
    )


def mirror_to_repo(
    project: Project,
    drafts: list[NodeDraft],
    *,
    previous: dict[str, str] | None = None,
    client=None,
) -> tuple[str, list[str]]:
    """Commit changed vault files to the documentation branch.

    Only files whose content actually changed are committed, so the branch does
    not collect a commit every night saying nothing happened. Returns
    ``(commit_sha, changed_paths)``; the sha is empty when nothing changed.
    """
    from gitlab_integration.client import GitLabClient
    from gitlab_integration.exceptions import GitLabError

    repo = getattr(project, "repo", None)
    if repo is None:
        return "", []

    client = client or GitLabClient.for_service()
    branch = settings.DOCUMENTATION_BRANCH
    branch_exists = client.branch_exists(repo.gitlab_project_id, branch)

    # What the branch currently holds, so unchanged files can be skipped.
    existing_paths: set[str] = set()
    if branch_exists:
        try:
            existing_paths = {
                entry["path"]
                for entry in client.list_tree(
                    repo.gitlab_project_id, ref=branch, path=VAULT_ROOT
                )
                if entry.get("type") == "blob"
            }
        except GitLabError:
            logger.warning("Could not list %s on %s", VAULT_ROOT, repo.path_with_namespace)

    previous = previous if previous is not None else snapshot_hashes(project)

    actions, changed = [], []
    for draft in drafts:
        rendered = draft.render()
        unchanged = (
            draft.path in existing_paths and previous.get(draft.path) == draft.content_hash
        )
        if unchanged:
            continue
        actions.append(
            {
                "action": "update" if draft.path in existing_paths else "create",
                "file_path": draft.path,
                "content": rendered,
                "encoding": "text",
            }
        )
        changed.append(draft.path)

    # Files the vault no longer generates are deleted so the branch matches state.
    generated = {d.path for d in drafts}
    for path in sorted(existing_paths - generated):
        actions.append({"action": "delete", "file_path": path})
        changed.append(path)

    if not actions:
        return "", []

    result = client.create_commit(
        repo.gitlab_project_id,
        branch=branch,
        commit_message=f"Update project vault ({len(actions)} file(s))",
        actions=actions,
        start_branch=repo.default_branch if not branch_exists else None,
    )
    return (result or {}).get("id", ""), changed


def regenerate_vault(
    project: Project, *, sync_run=None, mirror: bool = True, client=None
) -> VaultSnapshot:
    """Rebuild the vault, persist it, and mirror changes to the repository."""
    drafts = build_nodes(project)
    # Captured before persisting, so the mirror can tell what actually changed.
    previous = snapshot_hashes(project)

    nodes, edge_count, dangling = persist_nodes(project, drafts)
    digest = tree_hash([d.content_hash for d in drafts])

    commit_sha, changed = "", []
    if mirror:
        try:
            commit_sha, changed = mirror_to_repo(
                project, drafts, previous=previous, client=client
            )
        except Exception as exc:  # noqa: BLE001 - the DB copy is still valid
            logger.exception("Vault mirror failed for %s", project.name)
            changed = [f"mirror failed: {exc}"]

    return VaultSnapshot.objects.create(
        project=project,
        sync_run=sync_run,
        node_count=len(nodes),
        edge_count=edge_count,
        dangling_edge_count=dangling,
        tree_hash=digest,
        changed_paths=changed[:200],
        commit_sha=commit_sha,
        committed_at=timezone.now() if commit_sha else None,
    )
