"""Markdown serialisation and wikilink parsing for the vault.

Files follow the Obsidian convention: a YAML frontmatter block delimited by
``---``, then a markdown body, with ``[[wikilinks]]`` forming the graph. The
links are extracted from both the frontmatter and the body, because the most
meaningful relationships (assignee, milestone) live in structured fields while
incidental ones appear in prose.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata

import yaml

WIKILINK_RE = re.compile(r"\[\[([^\[\]|#]+)(?:#[^\[\]|]*)?(?:\|([^\[\]]*))?\]\]")
FRONTMATTER_RE = re.compile(r"\A---\r?\n(.*?)\r?\n---\r?\n?(.*)\Z", re.DOTALL)

# Characters Obsidian and most filesystems disallow in a note name.
_UNSAFE = re.compile(r'[<>:"/\\|?*\[\]#^]')


def slugify_node(value: str, max_length: int = 80) -> str:
    """Turn arbitrary text into a safe, stable wikilink target.

    Not Django's slugify: vault names keep their capitalisation and spaces
    become hyphens, so ``[[M1-Auth-MVP]]`` stays readable in Obsidian rather
    than collapsing to ``m1-auth-mvp``.
    """
    normalized = unicodedata.normalize("NFKD", str(value))
    cleaned = _UNSAFE.sub("", normalized)
    cleaned = re.sub(r"\s+", "-", cleaned.strip())
    cleaned = re.sub(r"-{2,}", "-", cleaned).strip("-.")
    if len(cleaned) > max_length:
        # Keep a hash suffix so two long titles do not collide after truncation.
        digest = hashlib.sha1(normalized.encode()).hexdigest()[:6]
        cleaned = f"{cleaned[: max_length - 7].rstrip('-')}-{digest}"
    return cleaned or "untitled"


def wikilink(target: str, alias: str | None = None) -> str:
    return f"[[{target}|{alias}]]" if alias else f"[[{target}]]"


def to_plain(value):
    """Reduce a value to something ``yaml.safe_dump`` can represent.

    Frontmatter is assembled from ORM fields, so it arrives holding Django
    ``TextChoices`` members, ``Decimal``s and date objects. ``safe_dump``
    refuses all of those, and the failure surfaces only when a particular field
    happens to be populated — so normalise here rather than at every call site.
    """
    import datetime
    import decimal
    import enum

    if value is None or isinstance(value, (bool, int, float, str)):
        # TextChoices members subclass str, so unwrap to the plain value.
        return str(value) if isinstance(value, enum.Enum) else value
    if isinstance(value, enum.Enum):
        return to_plain(value.value)
    if isinstance(value, decimal.Decimal):
        return float(value)
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(k): to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [to_plain(v) for v in value]
    return str(value)


def render_markdown(frontmatter: dict, body: str) -> str:
    """Serialise a node to its on-disk representation."""
    if not frontmatter:
        return (body or "").rstrip() + "\n"

    dumped = yaml.safe_dump(
        to_plain(frontmatter), sort_keys=False, allow_unicode=True, default_flow_style=False
    ).rstrip()
    return f"---\n{dumped}\n---\n\n{(body or '').rstrip()}\n"


def parse_markdown(content: str) -> tuple[dict, str]:
    """Split a file into (frontmatter, body). Malformed YAML yields an empty dict."""
    match = FRONTMATTER_RE.match(content or "")
    if not match:
        return {}, content or ""

    raw, body = match.groups()
    try:
        frontmatter = yaml.safe_load(raw) or {}
    except yaml.YAMLError:
        return {}, content
    if not isinstance(frontmatter, dict):
        return {}, content
    return frontmatter, body


def extract_wikilinks(text: str) -> list[str]:
    """Wikilink targets in a string, in order, de-duplicated.

    Handles ``[[Note]]``, ``[[Note|alias]]`` and ``[[Note#heading]]``.
    """
    seen, targets = set(), []
    for match in WIKILINK_RE.finditer(text or ""):
        target = match.group(1).strip()
        if target and target not in seen:
            seen.add(target)
            targets.append(target)
    return targets


def extract_frontmatter_links(frontmatter: dict) -> list[tuple[str, str]]:
    """``(key, target)`` pairs for every wikilink in the frontmatter.

    Recurses into lists so ``assignees: [[[a]], [[b]]]`` works, but not into
    nested dicts — a key path is what makes the resulting edge label useful.
    """
    links: list[tuple[str, str]] = []

    for key, value in (frontmatter or {}).items():
        if isinstance(value, str):
            links.extend((key, t) for t in extract_wikilinks(value))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, str):
                    links.extend((key, t) for t in extract_wikilinks(item))

    return links


def content_hash(frontmatter: dict, body: str) -> str:
    """Hash of the rendered file; the vault's change detector."""
    return hashlib.sha256(render_markdown(frontmatter, body).encode("utf-8")).hexdigest()


def tree_hash(node_hashes: list[str]) -> str:
    """Hash over every node hash, identifying the vault as a whole."""
    hasher = hashlib.sha256()
    for value in sorted(node_hashes):
        hasher.update(value.encode())
    return hasher.hexdigest()
