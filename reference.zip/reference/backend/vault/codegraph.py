"""Turning indexed code into a connected knowledge graph.

The indexer records what each file declares and what it imports, but those are
strings — ``"./utils"``, ``"@/lib/api"``, ``"myapp.services.billing"``. This
module resolves them against the set of files that actually exist, producing
edges. That resolution is the whole value: an unresolved import list is a
property of one file, while a resolved one is a graph you can traverse to ask
what a change reaches.

Resolution is heuristic and deliberately conservative. An import that cannot be
matched to a file in this repository is dropped rather than guessed at — a
wrong edge is worse than a missing one, because it makes the graph assert a
relationship that does not exist.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field

from .code_models import CodeFile, CodeSymbol
from .layout import detect_layout

logger = logging.getLogger(__name__)

# Extensions tried when an import omits one, in the order a bundler would.
CANDIDATE_SUFFIXES = [
    ".ts", ".tsx", ".js", ".jsx", ".mjs", ".py", ".go", ".rb", ".php", ".java",
    ".rs", ".kt", ".vue", ".svelte",
]
INDEX_NAMES = ["index", "__init__", "mod", "main"]

# Common path aliases. "@/x" almost always means one of these roots.
ALIAS_ROOTS = ["src", "app", "lib", "frontend/src", "backend", "packages"]


@dataclass
class GraphNode:
    id: str
    label: str
    kind: str  # file | symbol | module | component
    component: str = ""
    module: str = ""
    language: str = ""
    summary: str = ""
    symbol_count: int = 0
    parent: str = ""


@dataclass
class GraphEdge:
    source: str
    target: str
    kind: str  # imports | calls | contains | defines


@dataclass
class CodeGraph:
    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)
    archetype: str = "unknown"
    components: list[dict] = field(default_factory=list)
    stacks: list[str] = field(default_factory=list)
    unresolved_imports: int = 0
    truncated: bool = False


def _normalise(path: str) -> str:
    """Collapse ``.`` and ``..`` segments in a path."""
    out: list[str] = []
    for part in path.split("/"):
        if part in ("", "."):
            continue
        if part == "..":
            if out:
                out.pop()
            continue
        out.append(part)
    return "/".join(out)


def _candidates(reference: str, from_path: str) -> list[str]:
    """Paths an import string might refer to, best guess first."""
    reference = reference.strip().strip("'\"")
    if not reference:
        return []

    from_dir = from_path.rsplit("/", 1)[0] if "/" in from_path else ""
    bases: list[str] = []

    if reference.startswith("."):
        bases.append(_normalise(f"{from_dir}/{reference}"))
    elif reference.startswith("@/") or reference.startswith("~/"):
        stem = reference[2:]
        bases.extend(_normalise(f"{root}/{stem}") for root in ALIAS_ROOTS)
        bases.append(_normalise(stem))
    elif "/" in reference:
        bases.append(_normalise(reference))
        bases.extend(_normalise(f"{root}/{reference}") for root in ALIAS_ROOTS)
    else:
        # A dotted module path ("app.services.billing") or a bare name.
        dotted = reference.replace(".", "/")
        bases.append(_normalise(dotted))
        bases.extend(_normalise(f"{root}/{dotted}") for root in ALIAS_ROOTS)
        if from_dir:
            bases.append(_normalise(f"{from_dir}/{dotted}"))

    paths: list[str] = []
    for base in bases:
        if not base:
            continue
        paths.append(base)
        paths.extend(f"{base}{suffix}" for suffix in CANDIDATE_SUFFIXES)
        for index in INDEX_NAMES:
            paths.extend(f"{base}/{index}{suffix}" for suffix in CANDIDATE_SUFFIXES)
    return paths


def resolve_import(reference: str, from_path: str, known_paths: set[str]) -> str | None:
    """Match an import string to a file in the repository, or return None.

    Falls back to a unique basename match, which catches Java-style packages
    and Go imports whose on-disk layout does not mirror the import path. A
    non-unique basename is left unresolved rather than guessed.
    """
    for candidate in _candidates(reference, from_path):
        if candidate in known_paths:
            return candidate

    stem = reference.replace("\\", "/").rstrip("/").split("/")[-1].split(".")[-1]
    if len(stem) < 3:
        return None
    matches = [
        p for p in known_paths if p.rsplit("/", 1)[-1].rsplit(".", 1)[0] == stem
    ]
    return matches[0] if len(matches) == 1 else None


def build_code_graph(
    project,
    *,
    include_symbols: bool = True,
    max_nodes: int = 1200,
) -> CodeGraph:
    """Assemble the knowledge graph for a project's indexed codebase."""
    files = list(
        CodeFile.objects.filter(project=project, is_present=True).prefetch_related("symbols")
    )
    if not files:
        return CodeGraph()

    languages = {f.path: f.language for f in files}
    layout = detect_layout(list(languages), languages)

    graph = CodeGraph(
        archetype=layout.archetype,
        stacks=layout.stacks,
        components=[
            {
                "name": c.name,
                "root": c.root,
                "side": c.side,
                "stacks": c.stacks,
                "file_count": c.file_count,
            }
            for c in layout.components
        ],
    )

    known_paths = set(languages)
    component_of: dict[str, str] = {}

    # Component nodes anchor each side of the repository, so a monorepo reads
    # as two connected clusters rather than one undifferentiated mass.
    for component in layout.components:
        node_id = f"component:{component.root or 'root'}"
        graph.nodes.append(
            GraphNode(
                id=node_id,
                label=component.name,
                kind="component",
                component=component.name,
                summary=f"{component.side} · {', '.join(component.stacks) or 'no marker'}",
                symbol_count=component.file_count,
            )
        )

    # Module nodes group files the way the vault does.
    modules: dict[str, list[CodeFile]] = defaultdict(list)
    for code_file in files:
        modules[code_file.module or "(root)"].append(code_file)

    for module, module_files in modules.items():
        component = layout.component_for(module_files[0].path)
        component_name = component.name if component else "root"
        module_id = f"module:{module}"
        graph.nodes.append(
            GraphNode(
                id=module_id,
                label=module,
                kind="module",
                component=component_name,
                symbol_count=sum(len(f.symbols.all()) for f in module_files),
            )
        )
        graph.edges.append(
            GraphEdge(
                source=f"component:{component.root or 'root'}" if component else "component:root",
                target=module_id,
                kind="contains",
            )
        )
        for code_file in module_files:
            component_of[code_file.path] = component_name

    for code_file in files:
        file_id = f"file:{code_file.path}"
        symbols = list(code_file.symbols.all())
        graph.nodes.append(
            GraphNode(
                id=file_id,
                label=code_file.path.rsplit("/", 1)[-1],
                kind="file",
                component=component_of.get(code_file.path, "root"),
                module=code_file.module,
                language=code_file.language,
                summary=code_file.summary,
                symbol_count=len(symbols),
            )
        )
        graph.edges.append(
            GraphEdge(
                source=f"module:{code_file.module or '(root)'}",
                target=file_id,
                kind="contains",
            )
        )

    # Import edges: the connective tissue between files.
    for code_file in files:
        source_id = f"file:{code_file.path}"
        seen: set[str] = set()
        for reference in code_file.imports or []:
            target = resolve_import(reference, code_file.path, known_paths)
            if target is None:
                graph.unresolved_imports += 1
                continue
            if target == code_file.path or target in seen:
                continue
            seen.add(target)
            graph.edges.append(
                GraphEdge(source=source_id, target=f"file:{target}", kind="imports")
            )

    if include_symbols:
        # Only declarations worth navigating to. Including every method would
        # swamp the graph without telling you anything the file node does not.
        notable = {"class", "interface", "component", "type"}
        symbol_ids: dict[str, str] = {}

        for code_file in files:
            for symbol in code_file.symbols.all():
                if symbol.kind not in notable and symbol.parent_name:
                    continue
                symbol_id = f"symbol:{code_file.path}:{symbol.qualified_name}"
                symbol_ids.setdefault(symbol.name, symbol_id)
                graph.nodes.append(
                    GraphNode(
                        id=symbol_id,
                        label=symbol.qualified_name,
                        kind="symbol",
                        component=component_of.get(code_file.path, "root"),
                        module=code_file.module,
                        language=code_file.language,
                        summary=symbol.summary,
                        parent=code_file.path,
                    )
                )
                graph.edges.append(
                    GraphEdge(
                        source=f"file:{code_file.path}", target=symbol_id, kind="defines"
                    )
                )

        # Call edges, resolved by unique symbol name. Ambiguous names are
        # skipped rather than wired to an arbitrary match.
        name_counts: dict[str, int] = defaultdict(int)
        for symbol in CodeSymbol.objects.filter(project=project):
            name_counts[symbol.name] += 1

        for code_file in files:
            for symbol in code_file.symbols.all():
                origin = symbol_ids.get(symbol.name)
                if origin is None:
                    continue
                for called in symbol.calls or []:
                    if name_counts.get(called, 0) != 1:
                        continue
                    target = symbol_ids.get(called)
                    if target and target != origin:
                        graph.edges.append(
                            GraphEdge(source=origin, target=target, kind="calls")
                        )

    if len(graph.nodes) > max_nodes:
        # Keep the structural layers whole and drop the most numerous leaves,
        # so a huge repository still renders as a readable shape.
        keep_order = {"component": 0, "module": 1, "file": 2, "symbol": 3}
        graph.nodes.sort(key=lambda n: (keep_order.get(n.kind, 9), -n.symbol_count))
        graph.nodes = graph.nodes[:max_nodes]
        kept = {n.id for n in graph.nodes}
        graph.edges = [
            e for e in graph.edges if e.source in kept and e.target in kept
        ]
        graph.truncated = True

    return graph
