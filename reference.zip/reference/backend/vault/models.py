"""Obsidian-style markdown vault mirrored from the documentation branch.

The vault is the canonical human-readable representation of project state: one
markdown file per entity, linked with ``[[wikilinks]]``. It lives at ``vault/``
on the documentation branch (clonable and openable directly in Obsidian, with
git history recording how project state evolved) and is mirrored here so graph
rendering and scoring do not have to hit the GitLab API.

Edges are a parsed table in Postgres rather than a graph database: at a few
thousand nodes per project, recursive CTEs cover every traversal this needs.
"""

from django.db import models

from common.models import TimeStampedModel


class NodeType(models.TextChoices):
    PROJECT = "project", "Project"
    MILESTONE = "milestone", "Milestone"
    TASK = "task", "Task"
    PERSON = "person", "Person"
    MODULE = "module", "Module"
    DOCUMENT = "document", "Document"
    ACTIVITY = "activity", "Activity rollup"


class VaultNode(TimeStampedModel):
    """One markdown file in a project's vault."""

    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="vault_nodes"
    )
    node_type = models.CharField(max_length=32, choices=NodeType.choices, db_index=True)
    # Vault-relative path, e.g. "tasks/ISSUE-123-Login-endpoint.md".
    path = models.CharField(max_length=512)
    # The wikilink target, i.e. the filename without extension.
    slug = models.CharField(max_length=255, db_index=True)
    title = models.CharField(max_length=512)

    frontmatter = models.JSONField(default=dict, blank=True)
    body = models.TextField(blank=True)
    content_hash = models.CharField(max_length=64, db_index=True)

    # Backlinks to the domain rows this node was generated from, so the graph
    # can deep-link into the app.
    source_model = models.CharField(max_length=64, blank=True)
    source_id = models.BigIntegerField(null=True, blank=True)

    # Cleared when a regeneration no longer produces this node.
    is_current = models.BooleanField(default=True, db_index=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["project", "path"], name="uniq_vault_node_path"),
            models.UniqueConstraint(fields=["project", "slug"], name="uniq_vault_node_slug"),
        ]
        ordering = ["project", "node_type", "path"]

    def __str__(self):
        return f"{self.project.slug}/{self.path}"

    def to_markdown(self) -> str:
        """Serialise frontmatter + body into the on-disk file contents."""
        from vault.markdown import render_markdown

        return render_markdown(self.frontmatter, self.body)


class EdgeType(models.TextChoices):
    ASSIGNED_TO = "assigned_to", "Assigned to"
    BELONGS_TO = "belongs_to", "Belongs to"
    TOUCHES = "touches", "Touches"
    ADVANCES = "advances", "Advances"
    AUTHORED = "authored", "Authored"
    DOCUMENTS = "documents", "Documents"
    REFERENCES = "references", "References"


class VaultEdge(TimeStampedModel):
    """A ``[[wikilink]]`` parsed out of a vault node.

    ``to_node`` is nullable: a link to a page that does not exist yet is kept
    rather than dropped, because in Obsidian those dangling links are exactly
    how gaps show up — an unlinked task, a module with no owner.
    """

    class Source(models.TextChoices):
        FRONTMATTER = "frontmatter", "Frontmatter"
        BODY = "body", "Body"

    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="vault_edges"
    )
    from_node = models.ForeignKey(
        VaultNode, on_delete=models.CASCADE, related_name="outgoing_edges"
    )
    to_node = models.ForeignKey(
        VaultNode, null=True, blank=True, on_delete=models.CASCADE,
        related_name="incoming_edges",
    )
    to_slug = models.CharField(max_length=255, db_index=True)
    edge_type = models.CharField(
        max_length=32, choices=EdgeType.choices, default=EdgeType.REFERENCES
    )
    source = models.CharField(max_length=16, choices=Source.choices, default=Source.BODY)
    # Frontmatter key or body context the link came from.
    label = models.CharField(max_length=255, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["project", "from_node"]),
            models.Index(fields=["project", "to_slug"]),
        ]
        ordering = ["from_node", "to_slug"]

    def __str__(self):
        return f"{self.from_node.slug} -[{self.edge_type}]-> {self.to_slug}"

    @property
    def is_dangling(self) -> bool:
        return self.to_node_id is None


class VaultSnapshot(TimeStampedModel):
    """Record of a vault generation and its mirror commit.

    ``commit_sha`` is empty when generation produced no change — the mirror only
    commits when content actually differs, so the documentation branch does not
    accumulate a commit per night saying nothing happened.
    """

    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="vault_snapshots"
    )
    sync_run = models.ForeignKey(
        "sync.SyncRun", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="vault_snapshots",
    )
    node_count = models.PositiveIntegerField(default=0)
    edge_count = models.PositiveIntegerField(default=0)
    dangling_edge_count = models.PositiveIntegerField(default=0)
    # Hash over every node's content hash; the change detector.
    tree_hash = models.CharField(max_length=64, db_index=True)
    changed_paths = models.JSONField(default=list, blank=True)
    commit_sha = models.CharField(max_length=64, blank=True)
    committed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        state = self.commit_sha[:8] if self.commit_sha else "no-change"
        return f"vault snapshot {self.project.slug} {state}"


# Code structure lives in its own module for readability but must be imported
# here so Django discovers the models.
from .code_models import (  # noqa: E402,F401
    CodeFile,
    CodeIndexRun,
    CodeSymbol,
    IndexStatus,
    SymbolKind,
)
