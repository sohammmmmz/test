"""Tests for markdown serialisation, wikilink parsing and vault generation."""

from datetime import date

import pytest
import responses
from django.utils import timezone

from activity.models import Commit, Issue, Milestone
from vault.generator import build_nodes, persist_nodes, regenerate_vault
from vault.markdown import (
    content_hash,
    extract_frontmatter_links,
    extract_wikilinks,
    parse_markdown,
    render_markdown,
    slugify_node,
    wikilink,
)
from vault.models import EdgeType, NodeType, VaultEdge, VaultNode

API = "https://gitlab.example.com/api/v4"

pytestmark = pytest.mark.django_db


class TestSlugify:
    @pytest.mark.parametrize(
        "value,expected",
        [
            ("M1 Auth MVP", "M1-Auth-MVP"),
            ("Riya Sharma", "Riya-Sharma"),
            ("api/auth", "apiauth"),
            ("Fix: the [thing]", "Fix-the-thing"),
            ("  spaced   out  ", "spaced-out"),
        ],
    )
    def test_produces_obsidian_safe_names(self, value, expected):
        assert slugify_node(value) == expected

    def test_preserves_capitalisation(self):
        """Unlike Django's slugify — vault names are read by humans in Obsidian."""
        assert slugify_node("Login Endpoint") == "Login-Endpoint"

    def test_long_names_get_a_stable_hash_suffix(self):
        long_name = "x" * 200
        first, second = slugify_node(long_name), slugify_node(long_name)

        assert first == second
        assert len(first) <= 80

    def test_different_long_names_do_not_collide(self):
        assert slugify_node("a" * 100 + "one") != slugify_node("a" * 100 + "two")

    def test_empty_input_is_still_usable(self):
        assert slugify_node("") == "untitled"


class TestMarkdownRoundTrip:
    def test_frontmatter_survives_a_round_trip(self):
        frontmatter = {"type": "task", "gitlab_iid": 123, "labels": ["a", "b"]}
        body = "# Title\n\nSome text."

        parsed_fm, parsed_body = parse_markdown(render_markdown(frontmatter, body))

        assert parsed_fm == frontmatter
        assert parsed_body.strip() == body

    def test_a_file_without_frontmatter_parses_as_body(self):
        frontmatter, body = parse_markdown("# Just a heading\n")

        assert frontmatter == {}
        assert body == "# Just a heading\n"

    def test_malformed_yaml_does_not_raise(self):
        frontmatter, _body = parse_markdown("---\n: : :\nbad\n---\nbody")

        assert frontmatter == {}

    def test_content_hash_is_stable_and_sensitive(self):
        a = content_hash({"type": "task"}, "body")
        b = content_hash({"type": "task"}, "body")
        c = content_hash({"type": "task"}, "different")

        assert a == b
        assert a != c


class TestWikilinks:
    @pytest.mark.parametrize(
        "text,expected",
        [
            ("See [[Riya-Sharma]]", ["Riya-Sharma"]),
            ("[[Note|display text]]", ["Note"]),
            ("[[Note#heading]]", ["Note"]),
            ("[[A]] and [[B]] and [[A]]", ["A", "B"]),
            ("no links", []),
            ("[not a link]", []),
        ],
    )
    def test_extracts_targets(self, text, expected):
        assert extract_wikilinks(text) == expected

    def test_extracts_from_frontmatter_including_lists(self):
        frontmatter = {
            "assignees": [wikilink("Riya-Sharma"), wikilink("Dev-Two")],
            "milestone": wikilink("M1"),
            "state": "opened",
        }

        links = extract_frontmatter_links(frontmatter)

        assert ("assignees", "Riya-Sharma") in links
        assert ("assignees", "Dev-Two") in links
        assert ("milestone", "M1") in links
        assert len(links) == 3


@pytest.fixture
def populated_project(project, repo, employee):
    from team.models import Assignment

    milestone = Milestone.objects.create(
        repo=repo, gitlab_id=1, title="M1 Auth", state="active", due_date=date(2026, 9, 1)
    )
    issue = Issue.objects.create(
        repo=repo, iid=123, title="Login endpoint", state="opened",
        milestone=milestone, description="Build it.",
    )
    issue.assignees.add(employee)
    Commit.objects.create(
        repo=repo, sha="a" * 40, short_id="aaaaaaaa", title="feat: login #123",
        message="feat: login #123", author_email="riya@company.com",
        author_employee=employee, authored_date=timezone.now(),
        referenced_issue_iids=[123], changed_paths=["api/auth/login.py"],
    )
    Assignment.objects.create(employee=employee, project=project, allocation_percent=60)
    return project


class TestBuildNodes:
    def test_produces_a_node_per_entity(self, populated_project):
        drafts = build_nodes(populated_project)
        by_type = {}
        for draft in drafts:
            by_type.setdefault(draft.node_type, []).append(draft)

        assert len(by_type[NodeType.PROJECT]) == 1
        assert len(by_type[NodeType.MILESTONE]) == 1
        assert len(by_type[NodeType.TASK]) == 1
        assert len(by_type[NodeType.PERSON]) == 1
        assert NodeType.MODULE in by_type, "modules come from commit paths"

    def test_task_node_links_assignee_and_milestone(self, populated_project):
        task = next(d for d in build_nodes(populated_project) if d.node_type == NodeType.TASK)

        assert task.frontmatter["assignees"] == ["[[Riya-Sharma]]"]
        assert task.frontmatter["milestone"] == "[[M1-Auth]]"
        assert task.frontmatter["gitlab_iid"] == 123

    def test_module_is_inferred_from_commit_paths(self, populated_project):
        modules = [d for d in build_nodes(populated_project) if d.node_type == NodeType.MODULE]

        assert [m.title for m in modules] == ["api/auth"]

    def test_person_node_flags_allocation_without_activity(self, project, repo, employee):
        """The gap between assigned and observed is the point of the tool."""
        from team.models import Assignment

        Assignment.objects.create(employee=employee, project=project, allocation_percent=80)

        person = next(d for d in build_nodes(project) if d.node_type == NodeType.PERSON)

        assert "Allocated 80% but no commits" in person.body

    def test_slug_collisions_keep_only_the_first(self, project, repo):
        Milestone.objects.create(repo=repo, gitlab_id=1, title="M1", state="active")
        Milestone.objects.create(repo=repo, gitlab_id=2, title="M1", state="active")

        milestones = [d for d in build_nodes(project) if d.node_type == NodeType.MILESTONE]

        assert len(milestones) == 1


class TestPersistNodes:
    def test_creates_nodes_and_edges(self, populated_project):
        drafts = build_nodes(populated_project)

        nodes, edge_count, dangling = persist_nodes(populated_project, drafts)

        assert len(nodes) == len(drafts)
        assert edge_count > 0
        assert dangling == 0, "every generated link should resolve"

    def test_edges_are_typed_from_their_frontmatter_key(self, populated_project):
        persist_nodes(populated_project, build_nodes(populated_project))

        assignee_edge = VaultEdge.objects.filter(edge_type=EdgeType.ASSIGNED_TO).first()
        milestone_edge = VaultEdge.objects.filter(edge_type=EdgeType.BELONGS_TO).first()

        assert assignee_edge.to_slug == "Riya-Sharma"
        assert milestone_edge.to_slug == "M1-Auth"

    def test_regeneration_removes_nodes_that_no_longer_exist(self, populated_project):
        persist_nodes(populated_project, build_nodes(populated_project))
        before = VaultNode.objects.count()

        Milestone.objects.all().delete()
        Issue.objects.all().delete()
        persist_nodes(populated_project, build_nodes(populated_project))

        assert VaultNode.objects.count() < before
        assert not VaultNode.objects.filter(slug="M1-Auth").exists()

    def test_regeneration_is_stable_when_nothing_changed(self, populated_project):
        drafts = build_nodes(populated_project)
        persist_nodes(populated_project, drafts)
        first = {n.slug: n.content_hash for n in VaultNode.objects.all()}

        persist_nodes(populated_project, build_nodes(populated_project))
        second = {n.slug: n.content_hash for n in VaultNode.objects.all()}

        # The project node embeds a generation timestamp, so exclude it.
        first.pop(populated_project.slug.replace("-", "-"), None)
        assert set(first) == set(second)

    def test_dangling_links_are_kept_not_dropped(self, populated_project):
        """An unresolved link is how a gap announces itself in Obsidian."""
        drafts = build_nodes(populated_project)
        drafts[0].body += "\n\nBlocked on [[Nonexistent-Note]]."

        _nodes, _edges, dangling = persist_nodes(populated_project, drafts)

        assert dangling == 1
        assert VaultEdge.objects.filter(to_slug="Nonexistent-Note", to_node=None).exists()


class TestRegenerateAndMirror:
    def test_commits_the_vault_to_the_documentation_branch(
        self, populated_project, mocked_responses
    ):
        import json

        mocked_responses.add(
            responses.GET,
            f"{API}/projects/555/repository/branches/documentation",
            json={"message": "404"}, status=404,
        )
        mocked_responses.add(
            responses.POST, f"{API}/projects/555/repository/commits",
            json={"id": "vaultsha"}, status=201,
        )

        snapshot = regenerate_vault(populated_project)

        assert snapshot.commit_sha == "vaultsha"
        body = json.loads(mocked_responses.calls[-1].request.body)
        assert body["start_branch"] == "main"
        assert all(a["file_path"].startswith("vault/") for a in body["actions"])

    def test_unchanged_files_are_not_recommitted(self, populated_project, mocked_responses):
        """Otherwise the branch collects a commit every night saying nothing."""
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches/documentation",
            json={"message": "404"}, status=404,
        )
        mocked_responses.add(
            responses.POST, f"{API}/projects/555/repository/commits",
            json={"id": "sha1"}, status=201,
        )
        regenerate_vault(populated_project)

        # Second pass: the branch now exists and holds exactly what we generated.
        paths = list(VaultNode.objects.values_list("path", flat=True))
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches/documentation",
            json={"name": "documentation"},
        )
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[{"type": "blob", "path": p} for p in paths],
        )

        second = regenerate_vault(populated_project)

        # Only the project node changes, because it embeds a generated_at stamp.
        assert second.changed_paths == ["vault/Project.md"]

    def test_a_mirror_failure_still_leaves_a_valid_database_copy(
        self, populated_project, mocked_responses
    ):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/branches/documentation",
            json={"message": "500"}, status=500,
        )

        snapshot = regenerate_vault(populated_project)

        assert snapshot.node_count > 0
        assert snapshot.commit_sha == ""
        assert VaultNode.objects.count() == snapshot.node_count

    def test_mirror_can_be_skipped(self, populated_project):
        snapshot = regenerate_vault(populated_project, mirror=False)

        assert snapshot.commit_sha == ""
        assert snapshot.node_count > 0


class TestGraphEndpoints:
    def test_graph_returns_nodes_and_edges(self, api_client, populated_project):
        regenerate_vault(populated_project, mirror=False)

        data = api_client.get(f"/api/vault/{populated_project.pk}/graph").json()

        assert data["stats"]["node_count"] > 0
        assert any(n["type"] == "task" for n in data["nodes"])

    def test_graph_surfaces_dangling_links_as_placeholder_nodes(
        self, api_client, populated_project
    ):
        drafts = build_nodes(populated_project)
        drafts[0].body += "\n[[Missing-Thing]]"
        persist_nodes(populated_project, drafts)

        data = api_client.get(f"/api/vault/{populated_project.pk}/graph").json()

        placeholder = next(n for n in data["nodes"] if n["id"] == "Missing-Thing")
        assert placeholder["exists"] is False

    def test_node_endpoint_returns_markdown_and_backlinks(
        self, api_client, populated_project
    ):
        regenerate_vault(populated_project, mirror=False)

        data = api_client.get(
            f"/api/vault/{populated_project.pk}/node/Riya-Sharma"
        ).json()

        assert data["markdown"].startswith("---")
        assert any(b["type"] == "assigned_to" for b in data["backlinks"])
