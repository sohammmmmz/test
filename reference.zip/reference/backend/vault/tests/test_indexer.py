"""Codebase indexing.

Cost control and partial-failure tolerance are the load-bearing behaviours: a
repository has far more files than a nightly diff, and one unparseable file
must not abandon the run.
"""

import base64
import json

import pytest
import responses

from scoring.gemini import TextResponse
from vault.code_models import CodeFile, CodeSymbol, IndexStatus
from vault.indexer import (
    discover_files,
    index_project_code,
    is_skippable,
    language_for,
    module_for,
    parse_extraction,
)

API = "https://gitlab.example.com/api/v4"

pytestmark = pytest.mark.django_db


class FakeScorer:
    """Returns a fixed extraction, and records what it was asked."""

    model = "fake-index-1"

    def __init__(self, payload=None, fail=False):
        self.payload = payload
        self.fail = fail
        self.prompts = []

    def generate_json(self, prompt):
        self.prompts.append(prompt)
        if self.fail:
            return TextResponse("", self.model, error="model unavailable")
        return TextResponse(
            json.dumps(self.payload or {"files": []}),
            self.model,
            input_tokens=500,
            output_tokens=120,
        )


class TestFileSelection:
    @pytest.mark.parametrize(
        "path,language",
        [
            ("src/auth.py", "python"),
            ("web/App.tsx", "typescript"),
            ("cmd/main.go", "go"),
            ("README.md", None),
            ("package-lock.json", None),
            ("logo.svg", None),
        ],
    )
    def test_only_source_files_are_indexable(self, path, language):
        assert language_for(path) == language

    @pytest.mark.parametrize(
        "path",
        [
            "node_modules/react/index.js",
            "backend/app/migrations/0001_initial.py",
            "frontend/dist/bundle.js",
            "vendor/lib/thing.go",
            ".venv/lib/mod.py",
            "src/app.min.js",
        ],
    )
    def test_generated_and_vendored_trees_are_skipped(self, path):
        assert is_skippable(path) is True

    def test_real_source_is_not_skipped(self):
        assert is_skippable("backend/accounts/views.py") is False

    @pytest.mark.parametrize(
        "path,module",
        [
            ("backend/accounts/views.py", "backend/accounts"),
            # The filename must not become part of the module, or every
            # shallow path would be its own group.
            ("src/auth.py", "src"),
            ("a/b/c/d/e.py", "a/b"),
            ("main.py", "(root)"),
        ],
    )
    def test_module_is_the_leading_directories(self, path, module):
        assert module_for(path) == module


class TestDiscovery:
    def test_lists_only_indexable_blobs(self, repo, mocked_responses):
        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[
                {"type": "blob", "path": "src/auth.py", "id": "blob1"},
                {"type": "blob", "path": "node_modules/x/i.js", "id": "blob2"},
                {"type": "blob", "path": "README.md", "id": "blob3"},
                {"type": "tree", "path": "src", "id": "tree1"},
            ],
        )

        from gitlab_integration.client import GitLabClient

        found = discover_files(repo, GitLabClient(token="t", api_url=API), "main")

        assert [f.path for f in found] == ["src/auth.py"]
        assert found[0].blob_id == "blob1"
        assert found[0].module == "src"


class TestParseExtraction:
    def test_parses_plain_json(self):
        files = parse_extraction('{"files": [{"path": "a.py", "symbols": []}]}')

        assert files[0]["path"] == "a.py"

    def test_tolerates_markdown_fences(self):
        assert parse_extraction('```json\n{"files": []}\n```') == []

    def test_unparseable_output_raises(self):
        with pytest.raises(ValueError):
            parse_extraction("I could not read those files.")


def _stub_tree_and_file(mocked_responses, path="src/auth.py", blob="blob1", content=b"code"):
    mocked_responses.add(
        responses.GET, f"{API}/projects/555/repository/tree",
        json=[{"type": "blob", "path": path, "id": blob}],
    )
    mocked_responses.add(
        responses.GET,
        f"{API}/projects/555/repository/files/{path.replace('/', '%2F')}",
        json={"content": base64.b64encode(content).decode()},
    )


EXTRACTION = {
    "files": [
        {
            "path": "src/auth.py",
            "summary": "Session handling.",
            "imports": ["django.contrib.auth"],
            "symbols": [
                {
                    "name": "SessionManager",
                    "kind": "class",
                    "parent": "",
                    "signature": "class SessionManager:",
                    "summary": "Owns session lifecycle.",
                    "line": 10,
                    "calls": [],
                },
                {
                    "name": "login",
                    "kind": "method",
                    "parent": "SessionManager",
                    "signature": "def login(self, user):",
                    "summary": "Starts a session.",
                    "line": 18,
                    "calls": ["issue_token"],
                },
            ],
        }
    ]
}


class TestIndexProjectCode:
    def test_records_files_and_symbols(self, project, repo, mocked_responses):
        _stub_tree_and_file(mocked_responses)
        scorer = FakeScorer(EXTRACTION)

        run = index_project_code(project, scorer=scorer)

        assert run.status == IndexStatus.COMPLETED
        assert run.files_indexed == 1
        assert run.symbols_extracted == 2

        code_file = CodeFile.objects.get(path="src/auth.py")
        assert code_file.summary == "Session handling."
        assert code_file.imports == ["django.contrib.auth"]

        method = CodeSymbol.objects.get(name="login")
        assert method.parent_name == "SessionManager"
        assert method.calls == ["issue_token"]

    def test_unchanged_files_are_not_re_sent(self, project, repo, mocked_responses):
        """Re-sending unchanged content is the single biggest avoidable cost."""
        _stub_tree_and_file(mocked_responses)
        first = FakeScorer(EXTRACTION)
        index_project_code(project, scorer=first)

        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree",
            json=[{"type": "blob", "path": "src/auth.py", "id": "blob1"}],
        )
        second = FakeScorer(EXTRACTION)
        run = index_project_code(project, scorer=second)

        assert run.files_unchanged == 1
        assert run.files_indexed == 0
        assert second.prompts == [], "nothing should have been sent to the model"

    def test_changed_content_is_re_indexed(self, project, repo, mocked_responses):
        _stub_tree_and_file(mocked_responses)
        index_project_code(project, scorer=FakeScorer(EXTRACTION))

        # A new blob id means the content changed.
        _stub_tree_and_file(mocked_responses, blob="blob2", content=b"new code")
        scorer = FakeScorer(EXTRACTION)
        run = index_project_code(project, scorer=scorer)

        assert run.files_indexed == 1
        assert len(scorer.prompts) == 1

    def test_force_ignores_the_blob_cache(self, project, repo, mocked_responses):
        _stub_tree_and_file(mocked_responses)
        index_project_code(project, scorer=FakeScorer(EXTRACTION))

        _stub_tree_and_file(mocked_responses)
        run = index_project_code(project, scorer=FakeScorer(EXTRACTION), force=True)

        assert run.files_indexed == 1
        assert run.files_unchanged == 0

    def test_a_model_failure_is_recorded_and_the_run_continues(
        self, project, repo, mocked_responses
    ):
        _stub_tree_and_file(mocked_responses)

        run = index_project_code(project, scorer=FakeScorer(fail=True))

        assert run.status == IndexStatus.PARTIAL
        assert run.errors[0]["stage"] == "extract"
        assert CodeSymbol.objects.count() == 0

    def test_symbols_are_replaced_not_accumulated(self, project, repo, mocked_responses):
        """A symbol deleted from the file must not linger as a phantom."""
        _stub_tree_and_file(mocked_responses)
        index_project_code(project, scorer=FakeScorer(EXTRACTION))

        reduced = {
            "files": [
                {**EXTRACTION["files"][0], "symbols": EXTRACTION["files"][0]["symbols"][:1]}
            ]
        }
        _stub_tree_and_file(mocked_responses, blob="blob2")
        index_project_code(project, scorer=FakeScorer(reduced), force=True)

        assert CodeSymbol.objects.count() == 1
        assert not CodeSymbol.objects.filter(name="login").exists()

    def test_deleted_files_are_flagged_not_removed(self, project, repo, mocked_responses):
        _stub_tree_and_file(mocked_responses)
        index_project_code(project, scorer=FakeScorer(EXTRACTION))

        mocked_responses.add(
            responses.GET, f"{API}/projects/555/repository/tree", json=[]
        )
        index_project_code(project, scorer=FakeScorer())

        assert CodeFile.objects.get(path="src/auth.py").is_present is False

    def test_a_project_without_a_repo_fails_visibly(self, db):
        from projects.models import Project

        orphan = Project.objects.create(name="Orphan Index", slug="orphan-index")

        run = index_project_code(orphan, scorer=FakeScorer())

        assert run.status == IndexStatus.FAILED
        assert "no repository" in run.errors[0]["message"]

    def test_without_an_api_key_files_are_mapped_but_not_analysed(
        self, project, repo, mocked_responses
    ):
        """Degrades to a file map rather than inventing structure."""
        from scoring.gemini import StubScorer

        _stub_tree_and_file(mocked_responses)

        run = index_project_code(project, scorer=StubScorer())

        assert run.files_indexed == 1
        assert run.symbols_extracted == 0
        assert CodeFile.objects.filter(path="src/auth.py").exists()


class TestCodeMapEndpoint:
    def test_groups_files_by_module(self, api_client, project, repo, mocked_responses):
        _stub_tree_and_file(mocked_responses)
        index_project_code(project, scorer=FakeScorer(EXTRACTION))

        data = api_client.get(f"/api/vault/{project.pk}/code").json()

        assert data["indexed"] is True
        assert data["file_count"] == 1
        assert data["modules"][0]["symbol_count"] == 2
        assert data["latest_run"]["model_version"] == "fake-index-1"

    def test_reports_an_unindexed_project_plainly(self, api_client, project, repo):
        data = api_client.get(f"/api/vault/{project.pk}/code").json()

        assert data["indexed"] is False
        assert data["modules"] == []


class TestVaultUsesIndexedCode:
    def test_module_nodes_describe_real_files_and_classes(
        self, project, repo, mocked_responses
    ):
        from vault.generator import build_nodes

        _stub_tree_and_file(mocked_responses)
        index_project_code(project, scorer=FakeScorer(EXTRACTION))

        modules = [d for d in build_nodes(project) if d.node_type == "module"]

        assert modules, "indexed code should produce a module node"
        body = modules[0].body
        assert "src/auth.py" in body
        assert "SessionManager" in body
