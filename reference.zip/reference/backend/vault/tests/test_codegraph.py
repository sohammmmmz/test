"""Layout detection and code-graph construction.

The load-bearing behaviour is import resolution: an unresolved import list is a
property of one file, while a resolved one is a graph you can traverse. A wrong
edge is worse than a missing one, so ambiguity must resolve to nothing.
"""

import pytest

from vault.code_models import CodeFile, CodeSymbol
from vault.codegraph import build_code_graph, resolve_import
from vault.layout import detect_layout

pytestmark = pytest.mark.django_db


class TestLayoutDetection:
    def test_detects_a_django_backend(self):
        layout = detect_layout(
            ["manage.py", "requirements.txt", "app/views.py"],
            {"app/views.py": "python"},
        )

        assert layout.archetype == "backend"
        assert "django" in layout.stacks

    def test_detects_a_next_frontend(self):
        layout = detect_layout(
            ["package.json", "next.config.mjs", "src/app/page.tsx"],
            {"src/app/page.tsx": "typescript"},
        )

        assert layout.archetype == "frontend"
        assert "nextjs" in layout.stacks

    def test_detects_a_monorepo_and_separates_the_sides(self):
        """The frontend/backend split is the most useful boundary in the repo;
        flattening it loses exactly the structure worth seeing."""
        layout = detect_layout(
            [
                "backend/manage.py",
                "backend/requirements.txt",
                "backend/app/views.py",
                "frontend/package.json",
                "frontend/next.config.mjs",
                "frontend/src/page.tsx",
            ],
            {"backend/app/views.py": "python", "frontend/src/page.tsx": "typescript"},
        )

        assert layout.is_monorepo
        assert {c.side for c in layout.components} == {"backend", "frontend"}

    def test_falls_back_to_directory_names_without_markers(self):
        layout = detect_layout(
            ["client/main.ts", "server/main.go"],
            {"client/main.ts": "typescript", "server/main.go": "go"},
        )

        assert {c.side for c in layout.components} == {"frontend", "backend"}

    def test_falls_back_to_languages_with_no_structure_at_all(self):
        layout = detect_layout(["main.py", "util.py"], {"main.py": "python"})

        assert layout.archetype == "backend"

    def test_deepest_component_wins(self):
        """A file under backend/api belongs to the api service, not the root."""
        layout = detect_layout(
            ["package.json", "backend/go.mod", "backend/main.go"],
            {"backend/main.go": "go"},
        )

        component = layout.component_for("backend/main.go")
        assert component.root == "backend"


class TestResolveImport:
    KNOWN = {
        "src/lib/api.ts",
        "src/app/page.tsx",
        "src/components/Button.tsx",
        "backend/app/services/billing.py",
        "backend/app/views.py",
        "src/utils/index.ts",
    }

    @pytest.mark.parametrize(
        "reference,from_path,expected",
        [
            ("./api", "src/lib/page.ts", "src/lib/api.ts"),
            ("../lib/api", "src/app/page.tsx", "src/lib/api.ts"),
            ("@/lib/api", "src/app/page.tsx", "src/lib/api.ts"),
            ("@/components/Button", "src/app/page.tsx", "src/components/Button.tsx"),
            ("app.services.billing", "backend/app/views.py", "backend/app/services/billing.py"),
            # A directory import lands on its index file.
            ("../utils", "src/app/page.tsx", "src/utils/index.ts"),
        ],
    )
    def test_resolves_the_forms_real_code_uses(self, reference, from_path, expected):
        assert resolve_import(reference, from_path, self.KNOWN) == expected

    def test_a_relative_import_is_resolved_against_its_own_directory(self):
        """"./utils" from src/app means src/app/utils, which does not exist —
        so it must resolve to nothing rather than to a same-named file
        elsewhere in the tree."""
        assert resolve_import("./utils", "src/app/page.tsx", self.KNOWN) is None

    def test_external_packages_do_not_resolve(self):
        """A wrong edge asserts a relationship that does not exist."""
        assert resolve_import("react", "src/app/page.tsx", self.KNOWN) is None
        assert resolve_import("django.db", "backend/app/views.py", self.KNOWN) is None

    def test_an_ambiguous_basename_resolves_to_nothing(self):
        known = {"a/thing.py", "b/thing.py"}

        assert resolve_import("thing", "c/other.py", known) is None

    def test_a_unique_basename_resolves(self):
        assert resolve_import("billing", "x/y.py", self.KNOWN) == (
            "backend/app/services/billing.py"
        )


def _add_file(project, path, module, language="python", imports=None, symbols=()):
    code_file = CodeFile.objects.create(
        project=project, path=path, module=module, language=language,
        imports=list(imports or []), is_present=True,
    )
    for name, kind, calls in symbols:
        CodeSymbol.objects.create(
            file=code_file, project=project, name=name, kind=kind, calls=list(calls)
        )
    return code_file


class TestBuildCodeGraph:
    def test_an_unindexed_project_yields_an_empty_graph(self, project, repo):
        graph = build_code_graph(project)

        assert graph.nodes == []

    def test_layers_components_modules_and_files(self, project, repo):
        _add_file(project, "backend/manage.py", "backend")
        _add_file(project, "backend/app/views.py", "backend/app")
        _add_file(project, "frontend/src/page.tsx", "frontend/src", "typescript")

        graph = build_code_graph(project)

        kinds = {n.kind for n in graph.nodes}
        assert {"component", "module", "file"} <= kinds
        assert any(e.kind == "contains" for e in graph.edges)

    def test_import_edges_connect_files(self, project, repo):
        _add_file(project, "src/lib/api.ts", "src/lib", "typescript")
        _add_file(
            project, "src/app/page.tsx", "src/app", "typescript",
            imports=["@/lib/api", "react"],
        )

        graph = build_code_graph(project)

        import_edges = [e for e in graph.edges if e.kind == "imports"]
        assert len(import_edges) == 1
        assert import_edges[0].source == "file:src/app/page.tsx"
        assert import_edges[0].target == "file:src/lib/api.ts"
        assert graph.unresolved_imports == 1, "react is external and must stay unresolved"

    def test_symbol_nodes_and_call_edges(self, project, repo):
        _add_file(
            project, "src/auth.py", "src",
            symbols=[("SessionManager", "class", ["issue_token"])],
        )
        _add_file(
            project, "src/tokens.py", "src",
            symbols=[("issue_token", "function", [])],
        )

        graph = build_code_graph(project)

        assert any(n.kind == "symbol" and n.label == "SessionManager" for n in graph.nodes)
        assert any(e.kind == "calls" for e in graph.edges)

    def test_symbols_can_be_excluded_for_a_structural_view(self, project, repo):
        _add_file(project, "src/auth.py", "src", symbols=[("A", "class", [])])

        graph = build_code_graph(project, include_symbols=False)

        assert not any(n.kind == "symbol" for n in graph.nodes)

    def test_a_large_graph_truncates_leaves_not_structure(self, project, repo):
        for i in range(60):
            _add_file(project, f"src/mod{i}.py", "src")

        graph = build_code_graph(project, max_nodes=20)

        assert graph.truncated is True
        assert len(graph.nodes) == 20
        # Components and modules survive; files are what get dropped.
        assert any(n.kind == "component" for n in graph.nodes)
        assert any(n.kind == "module" for n in graph.nodes)

    def test_truncation_drops_dangling_edges(self, project, repo):
        for i in range(40):
            _add_file(project, f"src/m{i}.py", "src", imports=[f"./m{(i + 1) % 40}"])

        graph = build_code_graph(project, max_nodes=15)

        ids = {n.id for n in graph.nodes}
        assert all(e.source in ids and e.target in ids for e in graph.edges)


class TestCodeGraphEndpoint:
    def test_returns_the_graph_with_archetype(self, api_client, project, repo):
        _add_file(project, "backend/manage.py", "backend")
        _add_file(project, "backend/app/views.py", "backend/app")

        data = api_client.get(f"/api/vault/{project.pk}/code-graph").json()

        assert data["archetype"] in ("backend", "multi-package")
        assert data["stats"]["node_count"] > 0
        assert data["components"]

    def test_reports_an_unindexed_project_as_empty(self, api_client, project, repo):
        data = api_client.get(f"/api/vault/{project.pk}/code-graph").json()

        assert data["nodes"] == []
        assert data["stats"]["node_count"] == 0


class TestProjectDeletion:
    def test_removes_the_project_and_its_derived_records(
        self, api_client, project, repo, employee
    ):
        from django.utils import timezone

        from activity.models import Commit

        Commit.objects.create(
            repo=repo, sha="a" * 40, authored_date=timezone.now(), author_employee=employee
        )
        _add_file(project, "src/a.py", "src", symbols=[("A", "class", [])])

        response = api_client.delete(f"/api/projects/{project.pk}/")

        assert response.status_code == 200
        body = response.json()
        assert body["removed"]["commits"] == 1
        assert body["removed"]["code_files"] == 1

        from projects.models import Project

        assert not Project.objects.filter(pk=project.pk).exists()
        assert Commit.objects.count() == 0
        assert CodeFile.objects.count() == 0

    def test_the_employee_survives_the_project(self, api_client, project, repo, employee):
        """People outlive projects; deleting one must not delete the roster."""
        from team.models import Assignment, Employee

        Assignment.objects.create(employee=employee, project=project, allocation_percent=50)

        api_client.delete(f"/api/projects/{project.pk}/")

        assert Employee.objects.filter(pk=employee.pk).exists()
        assert Assignment.objects.count() == 0

    def test_the_response_says_the_repository_was_kept(self, api_client, project, repo):
        body = api_client.delete(f"/api/projects/{project.pk}/").json()

        assert body["repository_kept"] == "acme/apollo"
        assert "was not touched" in body["detail"]


class TestProjectMembersEndpoint:
    def test_lists_members_and_flags_unlinked_ones(self, api_client, project, repo, employee):
        from activity.models import ProjectMember

        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=1001, username="riya", name="Riya Sharma",
            access_level=40, employee=employee,
        )
        ProjectMember.objects.create(
            repo=repo, gitlab_user_id=2002, username="stranger", name="Unknown Dev",
            access_level=30,
        )

        data = api_client.get(f"/api/projects/{project.pk}/members/").json()

        assert data["unlinked_count"] == 1
        by_username = {m["username"]: m for m in data["members"]}
        assert by_username["riya"]["employee"]["full_name"] == "Riya Sharma"
        assert by_username["stranger"]["employee"] is None
