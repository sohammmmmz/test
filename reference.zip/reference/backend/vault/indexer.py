"""Indexing a repository's codebase into structured records.

Walks the git tree, sends source files to Gemini in batches, and records the
classes, functions and imports it finds. That structure is what lets commit
scoring judge a change against the code it actually touches rather than against
the commit message alone.

Three constraints shape the design:

* **Cost.** A repository has far more files than a nightly diff. Files are
  skipped by extension and size before anything is sent, batched to amortise
  the per-request overhead, and — crucially — skipped entirely when their git
  blob id is unchanged since the last index.
* **Partial failure is normal.** One unparseable file must not abandon the
  index. Failures are recorded per file and the run continues.
* **The model is not a parser.** It is asked for structure it can read off the
  source, and anything it returns is treated as a best-effort summary rather
  than ground truth.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

from django.db import transaction
from django.utils import timezone

from gitlab_integration.client import GitLabClient
from gitlab_integration.exceptions import GitLabError
from projects.models import Project

from .code_models import CodeFile, CodeIndexRun, CodeSymbol, IndexStatus, SymbolKind

logger = logging.getLogger(__name__)

# Extension → language. Anything absent is not sent to the model: config,
# assets and lockfiles cost tokens and yield no structure.
LANGUAGE_BY_EXTENSION = {
    ".py": "python", ".pyi": "python",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".java": "java", ".kt": "kotlin", ".kts": "kotlin",
    ".go": "go", ".rs": "rust", ".rb": "ruby", ".php": "php",
    ".cs": "csharp", ".c": "c", ".h": "c", ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
    ".swift": "swift", ".scala": "scala", ".dart": "dart", ".ex": "elixir",
    ".exs": "elixir", ".vue": "vue", ".svelte": "svelte", ".sql": "sql",
}

SKIP_DIRECTORIES = {
    "node_modules", "vendor", "dist", "build", ".next", "__pycache__", ".git",
    "migrations", "venv", ".venv", "env", "target", "bin", "obj", "coverage",
    ".mypy_cache", ".pytest_cache", "site-packages", "bower_components",
}

MAX_FILE_BYTES = 120_000
MAX_FILES_PER_RUN = 400
FILES_PER_BATCH = 6
# Each file is truncated before batching so one huge file cannot crowd out the
# rest of its batch.
MAX_CHARS_PER_FILE = 12_000


EXTRACTION_INSTRUCTION = """\
You are indexing source files to build a map of a codebase.

For EACH file given, return its structure. Respond with ONLY a JSON object:

{"files": [{
  "path": "<the exact path given>",
  "summary": "<one or two sentences: what this file is responsible for>",
  "imports": ["<module or file this imports>", ...],
  "symbols": [{
     "name": "<identifier>",
     "kind": "class|function|method|interface|type|constant|component",
     "parent": "<enclosing class, or empty>",
     "signature": "<declaration line, trimmed>",
     "summary": "<one sentence: what it does>",
     "line": <line number or null>,
     "calls": ["<function or method this calls>", ...]
  }]
}]}

Rules:
- Report only what is actually declared in the file. Do not invent symbols.
- "calls" should name functions and methods defined elsewhere in this codebase
  where you can tell; ignore standard-library and framework noise.
- Omit trivial getters, setters and auto-generated code.
- If a file is truncated you will see a marker; index what is present and do
  not guess at the remainder.
- Return an entry for every file given, even if its symbol list is empty.
"""


@dataclass
class FileCandidate:
    path: str
    blob_id: str
    language: str
    module: str
    content: str = ""
    size_bytes: int = 0
    truncated: bool = False


@dataclass
class IndexOutcome:
    discovered: int = 0
    indexed: int = 0
    unchanged: int = 0
    skipped: int = 0
    symbols: int = 0
    errors: list = field(default_factory=list)


def language_for(path: str) -> str | None:
    lowered = path.lower()
    for extension, language in LANGUAGE_BY_EXTENSION.items():
        if lowered.endswith(extension):
            return language
    return None


def module_for(path: str, depth: int = 2) -> str:
    """The directory grouping a file belongs to.

    The filename is dropped before taking directories — including it would make
    every shallow path its own module ("src/auth.py" rather than "src"), which
    defeats the point of grouping.
    """
    parts = [p for p in path.split("/") if p]
    directories = parts[:-1]
    if not directories:
        return "(root)"
    return "/".join(directories[:depth])


def is_skippable(path: str) -> bool:
    parts = set(path.split("/")[:-1])
    if parts & SKIP_DIRECTORIES:
        return True
    name = path.rsplit("/", 1)[-1]
    return name.startswith(".") or ".min." in name


def discover_files(repo, client: GitLabClient, ref: str) -> list[FileCandidate]:
    """List indexable source files from the repository tree."""
    candidates: list[FileCandidate] = []

    for entry in client.list_tree(repo.gitlab_project_id, ref=ref, recursive=True):
        if entry.get("type") != "blob":
            continue
        path = entry.get("path", "")
        if is_skippable(path):
            continue
        language = language_for(path)
        if language is None:
            continue

        candidates.append(
            FileCandidate(
                path=path,
                blob_id=entry.get("id", "") or "",
                language=language,
                module=module_for(path),
            )
        )

    return candidates


def fetch_content(repo, client: GitLabClient, candidate: FileCandidate, ref: str) -> bool:
    """Load a file's text. Returns False when it should be skipped."""
    import base64

    try:
        payload = client.get_file(repo.gitlab_project_id, candidate.path, ref)
    except GitLabError as exc:
        logger.debug("Could not read %s: %s", candidate.path, exc)
        return False

    raw = base64.b64decode(payload.get("content", "") or "")
    candidate.size_bytes = len(raw)
    if candidate.size_bytes > MAX_FILE_BYTES:
        return False

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return False

    if len(text) > MAX_CHARS_PER_FILE:
        text = text[:MAX_CHARS_PER_FILE] + "\n... [file truncated for indexing] ..."
        candidate.truncated = True

    candidate.content = text
    return bool(text.strip())


def build_batch_prompt(batch: list[FileCandidate]) -> str:
    blocks = [
        f"### FILE: {c.path}\nLanguage: {c.language}\n```\n{c.content}\n```"
        for c in batch
    ]
    return "\n\n".join(blocks)


def parse_extraction(text: str) -> list[dict]:
    """Parse the model's response, tolerating fences and stray prose."""
    cleaned = (text or "").strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1] if "```" in cleaned[3:] else cleaned[3:]
        cleaned = cleaned.removeprefix("json").strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start == -1 or end <= start:
            raise ValueError("No JSON object in extraction response") from None
        data = json.loads(cleaned[start : end + 1])

    files = data.get("files") if isinstance(data, dict) else None
    return files if isinstance(files, list) else []


_VALID_KINDS = set(SymbolKind.values)


@transaction.atomic
def persist_file(
    project: Project, candidate: FileCandidate, extracted: dict, model_version: str
) -> int:
    """Store one file's structure. Returns the number of symbols recorded."""
    code_file, _ = CodeFile.objects.update_or_create(
        project=project,
        path=candidate.path,
        defaults={
            "module": candidate.module,
            "language": candidate.language,
            "size_bytes": candidate.size_bytes,
            "line_count": candidate.content.count("\n") + 1 if candidate.content else 0,
            "summary": (extracted.get("summary") or "").strip()[:4000],
            "imports": [str(i)[:512] for i in (extracted.get("imports") or [])][:100],
            "blob_id": candidate.blob_id,
            "indexed_at": timezone.now(),
            "model_version": model_version,
            "index_error": "",
            "is_present": True,
        },
    )

    # Replaced wholesale: a symbol removed from the file must disappear rather
    # than linger as a phantom.
    CodeSymbol.objects.filter(file=code_file).delete()

    symbols = []
    seen: set[tuple[str, str]] = set()
    for raw in extracted.get("symbols") or []:
        name = str(raw.get("name") or "").strip()[:512]
        if not name:
            continue
        parent = str(raw.get("parent") or "").strip()[:512]
        if (name, parent) in seen:
            continue
        seen.add((name, parent))

        kind = str(raw.get("kind") or "").lower()
        line = raw.get("line")
        symbols.append(
            CodeSymbol(
                file=code_file,
                project=project,
                name=name,
                kind=kind if kind in _VALID_KINDS else SymbolKind.FUNCTION,
                parent_name=parent,
                signature=str(raw.get("signature") or "")[:2000],
                summary=str(raw.get("summary") or "")[:2000],
                line_start=line if isinstance(line, int) and line >= 0 else None,
                calls=[str(c)[:255] for c in (raw.get("calls") or [])][:50],
            )
        )

    CodeSymbol.objects.bulk_create(symbols, batch_size=500)
    return len(symbols)


def index_project_code(
    project: Project,
    *,
    client: GitLabClient | None = None,
    scorer=None,
    force: bool = False,
    max_files: int = MAX_FILES_PER_RUN,
) -> CodeIndexRun:
    """Index a project's codebase, reusing anything whose content is unchanged."""
    from scoring.gemini import get_scorer

    repo = getattr(project, "repo", None)
    run = CodeIndexRun.objects.create(
        project=project, status=IndexStatus.RUNNING, started_at=timezone.now()
    )

    if repo is None:
        run.status = IndexStatus.FAILED
        run.errors = [{"stage": "setup", "message": "Project has no repository."}]
        run.finished_at = timezone.now()
        run.save()
        return run

    client = client or GitLabClient.for_service()
    scorer = scorer or get_scorer()
    model_version = getattr(scorer, "model", "")
    run.ref = repo.default_branch
    run.model_version = model_version

    outcome = IndexOutcome()

    try:
        candidates = discover_files(repo, client, repo.default_branch)
    except GitLabError as exc:
        run.status = IndexStatus.FAILED
        run.errors = [{"stage": "discover", "message": str(exc)}]
        run.finished_at = timezone.now()
        run.save()
        return run

    outcome.discovered = len(candidates)

    # Unchanged content is the common case on a re-index, and re-sending it is
    # the single biggest avoidable cost.
    known = {
        f.path: f.blob_id
        for f in CodeFile.objects.filter(project=project).only("path", "blob_id")
    }
    pending: list[FileCandidate] = []
    for candidate in candidates:
        if not force and candidate.blob_id and known.get(candidate.path) == candidate.blob_id:
            outcome.unchanged += 1
            continue
        pending.append(candidate)

    pending = pending[:max_files]

    loaded: list[FileCandidate] = []
    for candidate in pending:
        if fetch_content(repo, client, candidate, repo.default_branch):
            loaded.append(candidate)
        else:
            outcome.skipped += 1

    for start in range(0, len(loaded), FILES_PER_BATCH):
        batch = loaded[start : start + FILES_PER_BATCH]
        prompt = f"{EXTRACTION_INSTRUCTION}\n\n{build_batch_prompt(batch)}"

        response = scorer.generate_json(prompt)
        if not response.ok:
            outcome.errors.append(
                {"stage": "extract", "paths": [c.path for c in batch], "message": response.error}
            )
            outcome.skipped += len(batch)
            continue

        run.input_tokens += response.input_tokens or 0
        run.output_tokens += response.output_tokens or 0

        # Without an API key there is no structure to record. The files are
        # still stored so the map of the codebase exists, just without symbols.
        try:
            extracted = parse_extraction(response.text) if response.text else []
        except ValueError as exc:
            outcome.errors.append(
                {"stage": "parse", "paths": [c.path for c in batch], "message": str(exc)}
            )
            extracted = []

        by_path = {str(item.get("path", "")): item for item in extracted}
        for candidate in batch:
            payload = by_path.get(candidate.path, {})
            try:
                outcome.symbols += persist_file(project, candidate, payload, model_version)
                outcome.indexed += 1
            except Exception as exc:  # noqa: BLE001 - one file must not abort the run
                logger.exception("Persisting %s failed", candidate.path)
                outcome.errors.append(
                    {"stage": "persist", "paths": [candidate.path], "message": str(exc)}
                )

    # Files no longer in the tree are flagged rather than deleted, so history
    # that references them still resolves.
    live_paths = {c.path for c in candidates}
    CodeFile.objects.filter(project=project, is_present=True).exclude(
        path__in=live_paths
    ).update(is_present=False)

    run.files_discovered = outcome.discovered
    run.files_indexed = outcome.indexed
    run.files_unchanged = outcome.unchanged
    run.files_skipped = outcome.skipped
    run.symbols_extracted = outcome.symbols
    run.errors = outcome.errors[:50]
    run.status = IndexStatus.PARTIAL if outcome.errors else IndexStatus.COMPLETED
    run.finished_at = timezone.now()
    run.save()

    logger.info(
        "Indexed %s: %s files, %s symbols, %s unchanged, %s skipped",
        project.slug, outcome.indexed, outcome.symbols, outcome.unchanged, outcome.skipped,
    )
    return run
