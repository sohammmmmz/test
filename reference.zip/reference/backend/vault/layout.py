"""Detecting how a repository is laid out.

Whether a repo is a frontend, a backend, or a monorepo holding both changes how
its code should be grouped: a monorepo's ``frontend/`` and ``backend/`` are two
separate worlds that happen to share a git history, and flattening them into
one blob of modules loses the most useful boundary in the codebase.

Detection is by marker files rather than by asking the model. Marker files are
unambiguous, free, and cannot hallucinate — ``manage.py`` means Django whatever
else is in the tree.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Marker file (or suffix) → (stack, side). Order matters only for readability;
# every match contributes.
MARKERS: dict[str, tuple[str, str]] = {
    "package.json": ("node", "frontend"),
    "next.config.js": ("nextjs", "frontend"),
    "next.config.mjs": ("nextjs", "frontend"),
    "next.config.ts": ("nextjs", "frontend"),
    "vite.config.ts": ("vite", "frontend"),
    "vite.config.js": ("vite", "frontend"),
    "angular.json": ("angular", "frontend"),
    "svelte.config.js": ("svelte", "frontend"),
    "nuxt.config.ts": ("nuxt", "frontend"),
    "tailwind.config.ts": ("tailwind", "frontend"),
    "index.html": ("static", "frontend"),
    "manage.py": ("django", "backend"),
    "requirements.txt": ("python", "backend"),
    "pyproject.toml": ("python", "backend"),
    "Pipfile": ("python", "backend"),
    "go.mod": ("go", "backend"),
    "Cargo.toml": ("rust", "backend"),
    "pom.xml": ("java", "backend"),
    "build.gradle": ("java", "backend"),
    "composer.json": ("php", "backend"),
    "Gemfile": ("ruby", "backend"),
    "artisan": ("laravel", "backend"),
    "nest-cli.json": ("nestjs", "backend"),
    "Dockerfile": ("docker", "infra"),
    "docker-compose.yml": ("docker", "infra"),
    "pubspec.yaml": ("flutter", "mobile"),
    "build.gradle.kts": ("android", "mobile"),
}

# Directory names that conventionally announce a side of a monorepo.
DIRECTORY_HINTS = {
    "frontend": "frontend", "client": "frontend", "web": "frontend", "ui": "frontend",
    "app": "frontend", "www": "frontend",
    "backend": "backend", "server": "backend", "api": "backend", "service": "backend",
    "services": "backend", "core": "backend",
    "mobile": "mobile", "android": "mobile", "ios": "mobile",
    "infra": "infra", "deploy": "infra", "ops": "infra", "terraform": "infra",
}

LANGUAGE_SIDE = {
    "typescript": "frontend", "javascript": "frontend", "vue": "frontend",
    "svelte": "frontend",
    "python": "backend", "go": "backend", "java": "backend", "ruby": "backend",
    "php": "backend", "rust": "backend", "csharp": "backend", "kotlin": "backend",
    "scala": "backend", "elixir": "backend", "sql": "backend",
}


@dataclass
class Component:
    """One coherent part of a repository — a frontend, a backend, a service."""

    name: str
    root: str
    side: str
    stacks: list[str] = field(default_factory=list)
    file_count: int = 0

    def contains(self, path: str) -> bool:
        if self.root in ("", "."):
            return True
        return path == self.root or path.startswith(f"{self.root}/")


@dataclass
class RepoLayout:
    archetype: str
    components: list[Component]
    stacks: list[str]

    @property
    def is_monorepo(self) -> bool:
        return self.archetype == "monorepo"

    def component_for(self, path: str) -> Component | None:
        """The deepest component containing ``path``.

        Deepest wins so a file under ``backend/api`` is attributed to the api
        service rather than to the repository root.
        """
        best: Component | None = None
        for component in self.components:
            if component.contains(path) and (
                best is None or len(component.root) > len(best.root)
            ):
                best = component
        return best


def _directory_of(path: str) -> str:
    return path.rsplit("/", 1)[0] if "/" in path else ""


def detect_layout(paths: list[str], languages: dict[str, str] | None = None) -> RepoLayout:
    """Work out a repository's shape from its file paths.

    ``languages`` maps path → language for the indexable files, used to settle
    cases where marker files are absent or ambiguous.
    """
    languages = languages or {}
    by_directory: dict[str, Component] = {}
    stacks: set[str] = set()

    for path in paths:
        name = path.rsplit("/", 1)[-1]
        marker = MARKERS.get(name)
        if marker is None:
            continue
        stack, side = marker
        stacks.add(stack)

        directory = _directory_of(path)
        # Infrastructure markers appear everywhere and do not define a
        # component on their own.
        if side == "infra":
            continue

        component = by_directory.get(directory)
        if component is None:
            by_directory[directory] = Component(
                name=directory or "root", root=directory, side=side, stacks=[stack]
            )
        else:
            if stack not in component.stacks:
                component.stacks.append(stack)
            # A directory holding both kinds of marker is the root of a
            # combined project, not one side of it.
            if component.side != side:
                component.side = "fullstack"

    # Fall back to conventional directory names when markers are absent.
    if not by_directory:
        top_level = {p.split("/")[0] for p in paths if "/" in p}
        for directory in sorted(top_level):
            side = DIRECTORY_HINTS.get(directory.lower())
            if side:
                by_directory[directory] = Component(
                    name=directory, root=directory, side=side
                )

    # Still nothing: decide from the languages present.
    if not by_directory:
        present = set(languages.values())
        sides = {LANGUAGE_SIDE.get(lang) for lang in present} - {None}
        side = sides.pop() if len(sides) == 1 else "fullstack"
        by_directory[""] = Component(name="root", root="", side=side)

    components = list(by_directory.values())
    for path, _language in languages.items():
        best = None
        for component in components:
            if component.contains(path) and (
                best is None or len(component.root) > len(best.root)
            ):
                best = component
        if best is not None:
            best.file_count += 1

    # A component with no indexable files is a packaging artefact, not a part
    # of the codebase worth showing.
    components = [c for c in components if c.file_count > 0] or components
    components.sort(key=lambda c: (-c.file_count, c.root))

    sides = {c.side for c in components}
    if len(components) > 1 and len(sides - {"infra"}) > 1:
        archetype = "monorepo"
    elif len(components) > 1:
        archetype = "multi-package"
    elif components and components[0].side == "fullstack":
        archetype = "fullstack"
    elif components:
        archetype = components[0].side
    else:
        archetype = "unknown"

    return RepoLayout(
        archetype=archetype, components=components, stacks=sorted(stacks)
    )
