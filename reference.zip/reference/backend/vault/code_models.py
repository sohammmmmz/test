"""Persisted structure of a project's codebase.

Indexed at registration and refreshed as files change, this is what lets commit
scoring ask a sharper question than "does this diff look related to the task?" —
it can ask which module, class, or function the change lands in, and whether
that is where the assigned work actually lives.

Kept separate from the vault node tables because it has a different lifecycle:
code structure is re-derived from the repository, while vault nodes are a
rendering of it.
"""

from django.db import models

from common.models import TimeStampedModel


class IndexStatus(models.TextChoices):
    PENDING = "pending", "Queued"
    RUNNING = "running", "Indexing"
    COMPLETED = "completed", "Completed"
    PARTIAL = "partial", "Completed with errors"
    FAILED = "failed", "Failed"
    SKIPPED = "skipped", "Skipped"


class CodeFile(TimeStampedModel):
    """A source file, with the structure extracted from it."""

    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="code_files"
    )
    path = models.CharField(max_length=1024, db_index=True)
    module = models.CharField(
        max_length=512, blank=True, db_index=True,
        help_text="Leading directories; the unit the vault groups by.",
    )
    language = models.CharField(max_length=32, blank=True, db_index=True)
    size_bytes = models.PositiveIntegerField(default=0)
    line_count = models.PositiveIntegerField(default=0)

    # Model-written prose describing what the file is for.
    summary = models.TextField(blank=True)
    # Imports and module references, used to build edges between files.
    imports = models.JSONField(default=list, blank=True)

    # Blob SHA from the git tree: unchanged content is never re-indexed, which
    # is what keeps re-indexing a large repository affordable.
    blob_id = models.CharField(max_length=64, blank=True, db_index=True)
    indexed_at = models.DateTimeField(null=True, blank=True)
    model_version = models.CharField(max_length=64, blank=True)
    index_error = models.TextField(blank=True)

    # Cleared when a re-index no longer finds the file.
    is_present = models.BooleanField(default=True, db_index=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["project", "path"], name="uniq_code_file_path")
        ]
        indexes = [models.Index(fields=["project", "module"])]
        ordering = ["path"]

    def __str__(self):
        return self.path


class SymbolKind(models.TextChoices):
    CLASS = "class", "Class"
    FUNCTION = "function", "Function"
    METHOD = "method", "Method"
    INTERFACE = "interface", "Interface"
    TYPE = "type", "Type"
    CONSTANT = "constant", "Constant"
    COMPONENT = "component", "Component"


class CodeSymbol(TimeStampedModel):
    """A class, function, method or type declared in a file."""

    file = models.ForeignKey(CodeFile, on_delete=models.CASCADE, related_name="symbols")
    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="code_symbols"
    )
    name = models.CharField(max_length=512, db_index=True)
    kind = models.CharField(max_length=32, choices=SymbolKind.choices)
    # Set for methods, naming the class they belong to.
    parent_name = models.CharField(max_length=512, blank=True)
    signature = models.TextField(blank=True)
    summary = models.TextField(blank=True)
    line_start = models.PositiveIntegerField(null=True, blank=True)

    # Names this symbol calls or references. Stored as text rather than
    # foreign keys because a call can point at something outside the indexed
    # set — a library, or a file that failed to index — and dropping those
    # would silently understate how connected the code is.
    calls = models.JSONField(default=list, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["file", "name", "parent_name"], name="uniq_symbol_per_file"
            )
        ]
        indexes = [models.Index(fields=["project", "name"])]
        ordering = ["file", "line_start", "name"]

    def __str__(self):
        return f"{self.parent_name}.{self.name}" if self.parent_name else self.name

    @property
    def qualified_name(self) -> str:
        return f"{self.parent_name}.{self.name}" if self.parent_name else self.name


class CodeIndexRun(TimeStampedModel):
    """One pass of codebase indexing over a project."""

    project = models.ForeignKey(
        "projects.Project", on_delete=models.CASCADE, related_name="code_index_runs"
    )
    status = models.CharField(
        max_length=16, choices=IndexStatus.choices, default=IndexStatus.PENDING,
        db_index=True,
    )
    ref = models.CharField(max_length=255, blank=True)

    files_discovered = models.PositiveIntegerField(default=0)
    files_indexed = models.PositiveIntegerField(default=0)
    files_skipped = models.PositiveIntegerField(default=0)
    files_unchanged = models.PositiveIntegerField(default=0)
    symbols_extracted = models.PositiveIntegerField(default=0)

    model_version = models.CharField(max_length=64, blank=True)
    input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)

    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    errors = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"code index of {self.project.slug} [{self.status}]"

    @property
    def duration_seconds(self):
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None
