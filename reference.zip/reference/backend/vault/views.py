"""Vault graph API."""

from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response

from projects.models import Project

from .models import VaultEdge, VaultNode, VaultSnapshot


@api_view(["GET"])
def vault_graph(request, project_id: int):
    """Nodes and edges for the force-directed graph.

    Dangling links are returned as placeholder nodes rather than dropped: in
    Obsidian an unresolved link is how a gap announces itself — a task with no
    milestone, a module with no owner — and hiding them would hide the finding.
    """
    project = get_object_or_404(Project, pk=project_id)

    nodes = list(
        VaultNode.objects.filter(project=project, is_current=True).only(
            "id", "slug", "title", "node_type", "path", "source_model", "source_id"
        )
    )
    edges = list(
        VaultEdge.objects.filter(project=project).select_related("from_node")
    )

    known = {n.slug for n in nodes}
    payload_nodes = [
        {
            "id": n.slug,
            "title": n.title,
            "type": n.node_type,
            "path": n.path,
            "source_model": n.source_model,
            "source_id": n.source_id,
            "exists": True,
        }
        for n in nodes
    ]

    for slug in sorted({e.to_slug for e in edges} - known):
        payload_nodes.append(
            {"id": slug, "title": slug, "type": "missing", "path": "", "exists": False}
        )

    return Response(
        {
            "project": {"id": project.id, "name": project.name, "slug": project.slug},
            "nodes": payload_nodes,
            "edges": [
                {
                    "source": e.from_node.slug,
                    "target": e.to_slug,
                    "type": e.edge_type,
                    "label": e.label,
                    "dangling": e.to_node_id is None,
                }
                for e in edges
            ],
            "stats": {
                "node_count": len(nodes),
                "edge_count": len(edges),
                "dangling_count": sum(1 for e in edges if e.to_node_id is None),
            },
        }
    )


@api_view(["GET"])
def vault_node(request, project_id: int, slug: str):
    """A single note's rendered markdown, plus its backlinks."""
    project = get_object_or_404(Project, pk=project_id)
    node = get_object_or_404(VaultNode, project=project, slug=slug)

    return Response(
        {
            "slug": node.slug,
            "title": node.title,
            "type": node.node_type,
            "path": node.path,
            "frontmatter": node.frontmatter,
            "body": node.body,
            "markdown": node.to_markdown(),
            "outgoing": [
                {"target": e.to_slug, "type": e.edge_type, "exists": e.to_node_id is not None}
                for e in node.outgoing_edges.all()
            ],
            "backlinks": [
                {"source": e.from_node.slug, "title": e.from_node.title, "type": e.edge_type}
                for e in node.incoming_edges.select_related("from_node")
            ],
        }
    )


@api_view(["GET"])
def vault_snapshots(request, project_id: int):
    project = get_object_or_404(Project, pk=project_id)
    snapshots = VaultSnapshot.objects.filter(project=project)[:30]
    return Response(
        [
            {
                "id": s.id,
                "created_at": s.created_at,
                "node_count": s.node_count,
                "edge_count": s.edge_count,
                "dangling_edge_count": s.dangling_edge_count,
                "commit_sha": s.commit_sha,
                "committed_at": s.committed_at,
                "changed_paths": s.changed_paths,
            }
            for s in snapshots
        ]
    )


@api_view(["POST"])
def regenerate(request, project_id: int):
    """Rebuild the vault on demand, without waiting for a sync."""
    project = get_object_or_404(Project, pk=project_id)
    from .generator import regenerate_vault

    mirror = request.data.get("mirror", True)
    snapshot = regenerate_vault(project, mirror=bool(mirror))
    return Response(
        {
            "node_count": snapshot.node_count,
            "edge_count": snapshot.edge_count,
            "dangling_edge_count": snapshot.dangling_edge_count,
            "commit_sha": snapshot.commit_sha,
            "changed_paths": snapshot.changed_paths,
        }
    )


@api_view(["GET"])
def code_map(request, project_id: int):
    """The indexed structure of a project's codebase."""
    from .code_models import CodeFile, CodeIndexRun

    project = get_object_or_404(Project, pk=project_id)
    latest = CodeIndexRun.objects.filter(project=project).first()

    files = (
        CodeFile.objects.filter(project=project, is_present=True)
        .prefetch_related("symbols")
        .order_by("module", "path")
    )

    modules: dict[str, dict] = {}
    for code_file in files:
        entry = modules.setdefault(
            code_file.module or "(root)",
            {"module": code_file.module or "(root)", "files": [], "symbol_count": 0},
        )
        symbols = list(code_file.symbols.all())
        entry["symbol_count"] += len(symbols)
        entry["files"].append(
            {
                "path": code_file.path,
                "language": code_file.language,
                "summary": code_file.summary,
                "line_count": code_file.line_count,
                "imports": code_file.imports[:20],
                "symbols": [
                    {
                        "name": s.name,
                        "kind": s.kind,
                        "parent": s.parent_name,
                        "signature": s.signature,
                        "summary": s.summary,
                        "line": s.line_start,
                        "calls": s.calls[:15],
                    }
                    for s in symbols
                ],
            }
        )

    return Response(
        {
            "project": {"id": project.id, "name": project.name, "slug": project.slug},
            "indexed": bool(files),
            "latest_run": (
                {
                    "id": latest.id,
                    "status": latest.status,
                    "files_indexed": latest.files_indexed,
                    "files_unchanged": latest.files_unchanged,
                    "files_skipped": latest.files_skipped,
                    "symbols_extracted": latest.symbols_extracted,
                    "model_version": latest.model_version,
                    "finished_at": latest.finished_at,
                    "duration_seconds": latest.duration_seconds,
                    "errors": latest.errors[:10],
                }
                if latest
                else None
            ),
            "file_count": len(files),
            "modules": sorted(modules.values(), key=lambda m: -m["symbol_count"]),
        }
    )


@api_view(["POST"])
def reindex_code(request, project_id: int):
    """Re-index the codebase on demand.

    Unchanged files are reused by blob id, so a re-index after a few commits is
    far cheaper than the first pass. `force` bypasses that.
    """
    from sync.dispatch import dispatch_task
    from sync.tasks import index_project_code_task

    project = get_object_or_404(Project, pk=project_id)
    outcome = dispatch_task(
        index_project_code_task, project.pk, bool(request.data.get("force"))
    )

    if not outcome.ok:
        return Response(
            {"detail": outcome.detail, "code": "broker_unavailable"}, status=503
        )
    return Response(
        {
            "queued": outcome.queued,
            "ran_inline": outcome.ran_inline,
            "detail": outcome.detail,
            "result": outcome.result,
        },
        status=202,
    )


@api_view(["GET"])
def code_graph(request, project_id: int):
    """The code knowledge graph: components, modules, files and symbols.

    Returned as a graph rather than a tree because the interesting questions
    are reachability ones — what does this file pull in, what breaks if it
    changes — and a tree cannot answer those.
    """
    from .codegraph import build_code_graph

    project = get_object_or_404(Project, pk=project_id)
    include_symbols = request.query_params.get("symbols", "true") != "false"
    graph = build_code_graph(project, include_symbols=include_symbols)

    return Response(
        {
            "project": {"id": project.id, "name": project.name, "slug": project.slug},
            "archetype": graph.archetype,
            "stacks": graph.stacks,
            "components": graph.components,
            "nodes": [
                {
                    "id": n.id,
                    "label": n.label,
                    "kind": n.kind,
                    "component": n.component,
                    "module": n.module,
                    "language": n.language,
                    "summary": n.summary,
                    "symbol_count": n.symbol_count,
                    "parent": n.parent,
                }
                for n in graph.nodes
            ],
            "edges": [
                {"source": e.source, "target": e.target, "kind": e.kind}
                for e in graph.edges
            ],
            "stats": {
                "node_count": len(graph.nodes),
                "edge_count": len(graph.edges),
                "unresolved_imports": graph.unresolved_imports,
                "truncated": graph.truncated,
            },
        }
    )
