"""Shared pytest fixtures.

Tests never touch the network: the GitLab client is exercised against
``responses``-registered fixtures, and scoring runs through a stub Gemini
client.
"""

import pytest
from django.utils import timezone


@pytest.fixture(autouse=True)
def _cache_settings(settings):
    """Tests run against an in-process cache, with read-through switched off.

    Two separate reasons. A shared Redis would carry state between test runs
    and between developers, which is the classic source of a suite that passes
    alone and fails in CI. And read-through caching would mask exactly what
    most of these tests assert — that a view reflects what was just written —
    so it is off unless a test turns it on deliberately.
    """
    settings.CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
            "LOCATION": "test",
        }
    }
    settings.CACHE_ENABLED = False
    from django.core.cache import cache

    cache.clear()
    return settings


@pytest.fixture
def caching_on(settings):
    """Opt in to read-through caching for tests that are about the cache."""
    settings.CACHE_ENABLED = True
    return settings


@pytest.fixture(autouse=True)
def _gitlab_settings(settings):
    """Deterministic GitLab config for every test."""
    settings.GITLAB_URL = "https://gitlab.example.com"
    settings.GITLAB_API_URL = "https://gitlab.example.com/api/v4"
    settings.GITLAB_SERVICE_TOKEN = "test-service-token"
    settings.GITLAB_GROUP_ID = "42"
    settings.GITLAB_OAUTH_CLIENT_ID = "test-client-id"
    settings.GITLAB_OAUTH_CLIENT_SECRET = "test-client-secret"
    settings.GITLAB_WEBHOOK_SIGNING_TOKEN = "test-signing-token"
    settings.GITLAB_MAX_RETRIES = 1
    settings.CELERY_TASK_ALWAYS_EAGER = True
    return settings


@pytest.fixture
def mocked_responses():
    import responses

    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        yield rsps


@pytest.fixture
def admin_user(db):
    from accounts.models import User

    return User.objects.create_user(
        username="admin",
        email="admin@example.com",
        password="pw",
        is_staff=True,
        is_superuser=True,
    )


@pytest.fixture
def api_client(admin_user):
    from rest_framework.test import APIClient

    client = APIClient()
    client.force_authenticate(user=admin_user)
    return client


@pytest.fixture
def employee(db):
    from team.models import AuthorAlias, Employee

    emp = Employee.objects.create(
        official_email="riya@company.com",
        full_name="Riya Sharma",
        gitlab_user_id=1001,
        gitlab_username="riya",
    )
    AuthorAlias.objects.create(
        employee=emp, email="riya@company.com", source=AuthorAlias.Source.OFFICIAL
    )
    return emp


@pytest.fixture
def project(db):
    from projects.models import Project, ProjectStatus

    return Project.objects.create(
        name="Apollo", slug="apollo", status=ProjectStatus.ACTIVE
    )


@pytest.fixture
def repo(project):
    from projects.models import GitLabRepo

    return GitLabRepo.objects.create(
        project=project,
        gitlab_project_id=555,
        path_with_namespace="acme/apollo",
        name="apollo",
        web_url="https://gitlab.example.com/acme/apollo",
        default_branch="main",
        namespace_id=42,
    )


@pytest.fixture
def sync_run(project):
    from sync.models import RunStatus, SyncRun, TriggerSource

    return SyncRun.objects.create(
        project=project,
        trigger=TriggerSource.MANUAL,
        status=RunStatus.RUNNING,
        started_at=timezone.now(),
    )
