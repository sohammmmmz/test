# employee_util_tracker

GitLab project traceability, compliance and team utilization for a team that works
across many branches and commits daily.

- **Projects** — each mandatorily backed by a GitLab repository, validated if you
  supply one and created if you don't.
- **Compliance** — every project is checked for milestones with timelines, a BRD and
  technical document, and assigned members. Unmet requirements surface as warnings.
- **Sync** — nightly on a schedule, on demand via a button, and live via webhooks.
  All three run the same idempotent pipeline.
- **Vault** — an Obsidian-style markdown graph of each project's state, committed to
  the repository's `documentation` branch.
- **Scoring** — commits are assessed against the developer's assigned tasks using
  deterministic signals plus Gemini, and rolled up into daily scores and utilization.

Stack: **Next.js 15** (App Router) → **Django 5 + DRF** → **Postgres** (RDS), with
**Celery + Redis** for scheduling.

---

## Quick start

```bash
cp .env.example .env          # fill in DATABASE_URL, GitLab and Gemini values
docker compose up -d --build  # redis, backend, worker, beat, frontend
docker compose logs -f        # watch it come up
```

Then open http://localhost:3000. `docker compose down` stops it.

The database is **not** in this stack — it is RDS, reached over the network
through `DATABASE_URL`. That value comes from `.env` and is never set in
`docker-compose.yml`, because Compose's `environment:` silently overrides
`env_file:` and a value there would quietly point the app at the wrong
database.

One consequence is worth stating plainly: **a container's `localhost` is the
container itself**, so a `DATABASE_URL` pointing at `localhost:5432` cannot
work from inside one. Use the RDS endpoint; or `host.docker.internal:5432` if
Postgres runs natively on your machine; or start the throwaway database that
ships with this file:

```bash
docker compose --profile localdb up -d   # adds a postgres container
# and set DATABASE_URL=postgres://postgres:postgres@postgres:5432/util_tracker
```

Everyday commands:

```bash
docker compose restart backend                     # after changing .env
docker compose up -d --build backend worker beat   # after requirements.txt
docker compose exec backend python manage.py migrate
docker compose exec backend python manage.py seed_demo_data
docker compose down -v                             # also drops Redis + node_modules
```

Backend and frontend source are bind-mounted, so an edit reloads in place —
rebuild only when `requirements.txt` or `package.json` changes. The worker runs
Celery's normal prefork pool here; `--pool=solo` is a Windows workaround and a
container is Linux.

### Windows: one script

Only if you would rather not use Docker for the app processes.

```
start.bat          starts everything
start.bat /seed    also loads demo data
start.bat /nodocker  Redis already running
stop.bat           shuts it down
```

Creates `.env` and `.venv` if missing, installs dependencies, brings up Redis,
migrates, then opens four windows — Django, Celery worker, Celery beat, Next.js.
The database is RDS, reached over the network through `DATABASE_URL`; the script
starts no Postgres container. The worker is started with `--pool=solo`, which is required on
Windows; without it the worker accepts tasks and never finishes them, which is
what makes syncs appear to hang.

### Running without Docker

```bash
python -m venv .venv && .venv/bin/pip install -r backend/requirements-dev.txt
docker compose up -d redis

cd backend
../.venv/bin/python manage.py migrate
../.venv/bin/python manage.py seed_compliance_rules
../.venv/bin/python manage.py setup_periodic_tasks
../.venv/bin/python manage.py seed_demo_data      # optional sample data
../.venv/bin/python manage.py runserver

# in other terminals
../.venv/bin/celery -A config worker --loglevel=info
../.venv/bin/celery -A config beat --scheduler django_celery_beat.schedulers:DatabaseScheduler

cd ../frontend && npm install && npm run dev
```

### What actually needs to be running

| Process | Needed for |
|---|---|
| Postgres | everything |
| Django | everything |
| Next.js | the UI |
| **Redis** | queueing background work |
| **Celery worker** | running it — sync, scoring, code indexing |
| Celery beat | the *nightly* schedule only |

Without Redis and a worker, the manual sync button returns a 503 explaining
what to start. To work without them, set `CELERY_INLINE_FALLBACK=true` and jobs
run directly in the request instead — fine locally, and the reason a stopped
Redis no longer breaks the app.

**On Windows**, Celery's default prefork pool does not work (Windows spawns
rather than forks). Start the worker with the solo pool:

```
celery -A config worker --loglevel=info --pool=solo
```

Redis has no native Windows build either. Use Docker
(`docker run -d -p 6379:6379 redis:7-alpine`), [Memurai](https://www.memurai.com/),
or WSL.

---

## Configuration

Everything is environment-driven; see `.env.example`. Four values must come from you:

| Variable | What it is |
|---|---|
| `GITLAB_OAUTH_CLIENT_ID` / `_SECRET` | An OAuth application (scopes `read_user api`) from **gitlab.com → User settings → Applications**. Used for **login only**, plus the "can I see this repo?" check at registration. |
| `GITLAB_SERVICE_TOKEN` | A **Group Access Token** with `api` scope and the Maintainer role. Used for **all scheduled work**. |
| `GITLAB_GROUP_ID` | The group new repositories are created under, and where the webhook is registered. |
| `GEMINI_API_KEY` | Google AI Studio key for `gemini-3.6-flash`. |

**Why two GitLab credentials.** OAuth access tokens live two hours, and refreshing
rotates the refresh token. A 2am job cannot depend on any individual staying signed
in — or employed. So user OAuth handles login and per-user access checks, and a
service credential owns syncing, repo creation and webhooks. Without this split, an
intern offboarding silently kills their project's history.

Without a `GEMINI_API_KEY` the system still runs: scoring abstains and commits land
in a review queue rather than receiving invented numbers.

---

## How it works

### Signing in

Two ways in, one result. A **company password** (`ALLOWED_EMAIL_DOMAINS`, default
`solargroup.com`) or **GitLab OAuth**; both end by minting the same JWT access/refresh
pair into httpOnly cookies, so everything downstream has one notion of "signed in".

- The **access token** is short (30 minutes) and carries the identity, so authenticating
  a request needs no database read.
- The **refresh token** is long (30 days) and its only power is to mint a new pair. It is
  **rotated on every use**: each one is issued against a `RefreshSession` row holding
  only a hash of the currently valid token id. Presenting a superseded token — the
  signature is still valid, it simply is not the current one — means it was captured, so
  the whole session is revoked rather than the single request being rejected. A
  30-second grace window keeps two tabs refreshing at once from reading as a replay.

Refreshing happens in Next.js **middleware** (`frontend/src/middleware.ts`), which is the
only place that can do both halves: it rewrites the request cookies so the page being
rendered right now sees the new token, and sets them on the response so the browser
keeps them. Server components cannot set cookies, and a client-side refresh is
impossible because both cookies are httpOnly — which is the property that makes them
safe.

Registration is open **only while no account exists**; after that it needs a signed-in
administrator. An admin-only dashboard with a permanently open registration endpoint is
not an admin-only dashboard.

### Caching

Every dashboard is a wide join — commits, assignments, memberships and review notes
across the whole roster — and none of it changes between syncs. Results are cached in
Redis (`common/cache.py`) and keyed by a **version stamp per data family**; a sync bumps
the stamp rather than hunting down keys, which retires every derived answer at once
whatever parameters it was rendered with.

Redis being unavailable degrades to "compute it again", never to an error. Measured on a
seeded year of history: utilisation 97ms → 4ms, calendar 119ms → 11ms, workload 69ms →
5ms. The gap is wider in deployment, where the database is RDS across the network and a
cache hit makes no query at all.

### Sync

Four scopes on the sync screen — one project, all projects, one member, all members —
and one pipeline behind all of them, recorded in `SyncRun` every time.

Syncing a **member** needs a word, because GitLab has no endpoint for it: commits belong
to repositories, not to people. So it syncs every repository that person is attached to
(by GitLab membership *or* by a written assignment — people routinely have one without
the other) and then re-runs attribution over anything still credited to nobody, which is
usually the reason someone asked.

The buttons default to a **one-day commit window** (`SYNC_QUICK_WINDOW_DAYS`) rather than
resuming from where each repository left off. "Catch me up with today" and "reconcile
everything since the last run" are different questions, and the second is slow enough
that people stop pressing the button. `full` still forces the complete backfill.

The stages, in order:

1. Repo metadata, then milestones, commits, branches, issues, merge requests, members.
2. Commit authors resolved to employees; unmatched addresses queued for review.
3. Vault regenerated and mirrored to the `documentation` branch if content changed.
4. Compliance rules evaluated.
5. Unscored commits queued for Gemini.

Three details that are easy to get wrong and are handled deliberately:

- **Commits are fetched with `all=true`.** The endpoint otherwise returns only the
  default branch, so a team living on feature branches would appear to have committed
  nothing.
- **Webhooks alone lose data.** GitLab suppresses the push event entirely when one push
  touches more than three branches. The nightly sweep re-fetches an overlapping window
  to heal those gaps; upserts make the redundancy free.
- **Stages are isolated.** One failing marks the run `partial` and the rest continue —
  a single repo with a revoked token must not stop the others.

### Identity

Commits carry an email, not a GitLab user id. Attribution goes GitLab-resolved account
→ `AuthorAlias` → official email → **unmapped authors queue**. Claiming an address from
the queue backfills that person's history; without the backfill, only future commits
would be attributed.

### Compliance

Rules are rows, not hardcoded booleans. Each evaluation records pass/fail plus the
evidence behind it, so a verdict is arguable rather than opaque. Adding a rule means
writing a checker and inserting a row.

Built in: `HAS_MILESTONES`, `HAS_DOCUMENTS`, `HAS_MEMBERS` (enabled),
`NO_STALE_BRANCHES`, `HAS_ACTIVITY` (available, off by default).

### Documents and the vault

Uploads are committed to a `documentation` branch via a single atomic call —
`start_branch` creates the branch as part of the same commit, so there is no window
where an empty branch exists. Binaries go up base64-encoded, capped at 20 MB because
GitLab throttles larger requests.

The vault lives alongside them at `vault/`:

```
vault/
  Project.md
  milestones/M1-Launch.md
  tasks/ISSUE-123-Login-endpoint.md
  people/Riya-Sharma.md
  modules/src-api.md
  docs/BRD.md
  activity/2026-07-24.md
```

Clone the `documentation` branch and open it in Obsidian. `[[wikilinks]]` are parsed
into an edge table in Postgres — no graph database needed at this scale — and rendered
as an interactive graph in the UI. Unresolved links are kept and shown, because that is
how a gap announces itself.

### Commit cadence

The utilization page carries a per-person daily grid: one cell per day, aligned
across the whole team so a column where everyone went dark reads as a release or
an unrecorded holiday rather than as five people slacking.

A day is only marked **missed** when a commit was genuinely expected — a working
weekday, inside employment dates, with a live assignment. Weekends, configured
holidays, pre-hire days and unassigned stretches are drawn but never counted
against anyone; flagging them would bury the handful of real gaps under hundreds
of false ones. A day with review notes or a merged MR but no commits is its own
state, not an absence.

Configure with `WORKING_WEEKDAYS` and `NON_WORKING_DATES`. The data comes
straight from `Commit`, so cadence works after a plain sync, with no Gemini key
and no scoring run.

`GET /api/scoring/commit-calendar?days=90&project=<id>`

### Scoring

**Deterministic first.** Issue linkage, tests touched, MR merge state, CI status and
review activity need no model, cost nothing, and cannot be hallucinated. Gemini handles
only the two judgments that require reading code: whether a diff advances the assigned
task, and how substantial it is.

Controls that keep it cheap and honest:

- Scores cached by `diff_hash` — the same content is never scored twice.
- Diffs trimmed: generated and vendored paths dropped, per-file line caps, byte budget.
- `model_version` pinned per score, since a model upgrade shifts the distribution.
- Rationale stored with every score.
- Low confidence routes to a review queue instead of into someone's rollup.
- Human override with a required reason; overrides survive re-syncs.

Roughly **$7/month** at ten developers.

**A caveat worth stating.** Commit-derived scoring is blind to code review, mentoring,
debugging that ends in a one-line fix, and research that correctly concludes "don't
build this". It also penalises hard problems, since the hardest bug is often the
smallest diff. Review activity is tracked as a first-class signal and days without
commits are recorded as `had_no_commits` rather than zero, but the honest use of these
numbers is as trends and conversation-starters, not an automated ranking.

---

## Testing

```bash
cd backend && ../.venv/bin/python -m pytest      # 433 tests
../.venv/bin/ruff check .
cd ../frontend && npm run typecheck && npm run build
```

Tests never touch the network: GitLab is exercised against `responses` fixtures and
scoring runs through a stub client.

---

## Layout

```
backend/
  accounts/            admin users, password + GitLab sign-in, JWT rotation
  common/              cache backend, version stamps, invalidation signals
  gitlab_integration/  API client, OAuth, webhook verification
  team/                employees, aliases, assignments, identity resolution
  projects/            registration, repo validation/creation, documents
  activity/            commits, branches, MRs, issues, milestones, members
  compliance/          rules engine, checkers, dashboard
  vault/               markdown generation, wikilink parsing, repo mirror
  scoring/             diffs, deterministic signals, Gemini, rollups
  sync/                pipeline orchestration, Celery tasks, webhook receiver
frontend/src/
  middleware.ts        silent token refresh, signed-out redirects
  app/                 dashboard, projects, team, utilization, leaderboard, sync
  components/          graph, sync controls, registration form
  lib/                 server-side Django client, deterministic formatting
```

## Operations

```bash
python manage.py migrate                  # required after pulling; new auth + sync columns
python manage.py seed_compliance_rules    # idempotent; leaves admin retuning alone
python manage.py setup_periodic_tasks     # beat schedules; --reset restores defaults
python manage.py seed_demo_data --wipe    # local sample data, no network calls
python manage.py reattribute_commits      # re-decide authorship; --all includes manual fixes
```

**First sign-in.** With no accounts yet, the login screen offers to create one; that
first account becomes the superuser. After that, new accounts are created by an existing
administrator. `createsuperuser` still works and is the way back in if you are locked
out.

Schedules live in the database, so the nightly sync time is editable in Django Admin
without a deploy.

To register the group webhook once credentials are in place, `POST /api/sync/register-webhook`
or run the `sync.register_group_webhook` task. Use the **signing token** (HMAC-SHA256),
not the legacy plaintext secret token.
