import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        healthy: "#1a7f5a",
        warning: "#b4690e",
        critical: "#b3261e",
      },
    },
  },
  plugins: [],
};

export default config;
