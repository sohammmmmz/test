/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // Next normally 308-redirects "/path/" to "/path" before a route handler
  // runs. That silently rewrites the URL the API proxy is asked to forward,
  // and DRF's router registers every route *with* a trailing slash — so
  // Django would then APPEND_SLASH-redirect, which it cannot do for a POST
  // without discarding the body, and the write fails with a 500.
  //
  // Skipping the redirect lets the proxy forward the path exactly as sent.
  skipTrailingSlashRedirect: true,

  env: {
    BACKEND_INTERNAL_URL: process.env.BACKEND_INTERNAL_URL ?? "http://localhost:8000",
  },
};

export default nextConfig;
