/**
 * Keeps the sign-in alive, so the tool stops sending people back to GitLab.
 *
 * The access token is short-lived by design. Something has to notice it is
 * about to expire and trade the refresh token for a new pair, and the only
 * place that can happen is here: server components cannot set cookies (Next
 * only allows that in route handlers and server actions), and a client-side
 * refresh is impossible because both cookies are httpOnly and unreadable from
 * JavaScript — which is exactly the property that makes them safe.
 *
 * Middleware can do both halves. It rewrites the *request* cookies so the
 * server components rendering this very response already see the new token, and
 * sets them on the *response* so the browser keeps them.
 *
 * Refreshing is confined to navigations and API calls. Running it for every
 * image and script would mean a dozen concurrent refreshes per page load,
 * racing each other through a rotation that is meant to be sequential.
 */

import { type NextRequest, NextResponse } from "next/server";

const ACCESS_COOKIE = "eut_access";
const REFRESH_COOKIE = "eut_refresh";
const SESSION_COOKIE = "eut_session";

const BACKEND = process.env.BACKEND_INTERNAL_URL ?? "http://localhost:8000";

/** Refresh this long before the token actually dies, so it never expires
 *  mid-flight on a slow request. */
const EXPIRY_LEEWAY_SECONDS = 120;

/** Reachable without being signed in. */
const PROXY_PREFIX = "/api/proxy";
const PUBLIC_PREFIXES = ["/login", `${PROXY_PREFIX}/api/auth/`];

function isPublic(pathname: string): boolean {
  return PUBLIC_PREFIXES.some((prefix) => pathname.startsWith(prefix));
}

/**
 * Seconds until the token expires, from its unverified payload.
 *
 * Unverified is fine and is not a shortcut: this decides *when to ask the
 * backend*, nothing more. Django verifies the signature on every request that
 * matters, so the worst a forged `exp` achieves is an unnecessary refresh call
 * that then fails.
 */
function secondsLeft(token: string): number {
  try {
    const payload = token.split(".")[1];
    if (!payload) return 0;
    const json = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
    const exp = JSON.parse(json)?.exp;
    if (typeof exp !== "number") return 0;
    return exp - Math.floor(Date.now() / 1000);
  } catch {
    return 0;
  }
}

/** Pull `name=value` out of a Set-Cookie line. */
function cookieValue(setCookie: string, name: string): string | null {
  const first = setCookie.split(";")[0];
  const eq = first.indexOf("=");
  if (eq < 0) return null;
  return first.slice(0, eq).trim() === name ? first.slice(eq + 1) : null;
}

export async function middleware(request: NextRequest) {
  const { pathname, search } = request.nextUrl;

  const access = request.cookies.get(ACCESS_COOKIE)?.value;
  const refresh = request.cookies.get(REFRESH_COOKIE)?.value;
  const legacySession = request.cookies.get(SESSION_COOKIE)?.value;

  const accessIsUsable = Boolean(access) && secondsLeft(access!) > EXPIRY_LEEWAY_SECONDS;

  if (accessIsUsable) return NextResponse.next();

  if (refresh) {
    const refreshed = await tryRefresh(request, refresh);
    if (refreshed) return refreshed;
    // The refresh token was rejected — expired, revoked, or replayed. Fall
    // through to the signed-out path rather than serving a page that will
    // 401 on every request it makes.
  }

  if (isPublic(pathname)) return NextResponse.next();

  // A stale access token with no refresh is still worth passing through when a
  // Django session exists: someone signed in before this mechanism existed
  // should not be bounced to the login screen mid-task.
  if (legacySession) return NextResponse.next();

  if (pathname.startsWith("/api/")) {
    // API callers want a status code, not a login page they cannot render.
    return NextResponse.json({ detail: "Not signed in." }, { status: 401 });
  }

  const login = new URL("/login", request.url);
  login.searchParams.set("next", `${pathname}${search}`);
  return NextResponse.redirect(login);
}

async function tryRefresh(
  request: NextRequest,
  refresh: string,
): Promise<NextResponse | null> {
  let upstream: Response;
  try {
    upstream = await fetch(`${BACKEND}/api/auth/refresh`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Cookie: `${REFRESH_COOKIE}=${refresh}`,
      },
      cache: "no-store",
    });
  } catch {
    // Backend unreachable. Not a sign-out: let the request through and let the
    // page report the outage, which is far more useful than a login screen.
    return NextResponse.next();
  }

  if (!upstream.ok) return null;

  const setCookies = upstream.headers.getSetCookie();
  const newAccess = setCookies.map((c) => cookieValue(c, ACCESS_COOKIE)).find(Boolean);
  const newRefresh = setCookies.map((c) => cookieValue(c, REFRESH_COOKIE)).find(Boolean);
  if (!newAccess) return null;

  // Update the cookies the *downstream render* will read, so the page being
  // built right now uses the new token rather than the expired one.
  const headers = new Headers(request.headers);
  request.cookies.set(ACCESS_COOKIE, newAccess);
  if (newRefresh) request.cookies.set(REFRESH_COOKIE, newRefresh);
  headers.set("cookie", request.cookies.toString());

  const response = NextResponse.next({ request: { headers } });
  // Relay Django's own Set-Cookie lines verbatim rather than rebuilding them:
  // it owns the lifetimes, the Secure flag and the SameSite policy, and a
  // second opinion here would eventually disagree with it.
  for (const cookie of setCookies) response.headers.append("set-cookie", cookie);
  return response;
}

export const config = {
  matcher: [
    /*
     * Everything except Next's own static output and the favicon. Static assets
     * carry no session and refreshing on them would multiply every page load
     * into a burst of concurrent rotations.
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js|woff|woff2)$).*)",
  ],
};
