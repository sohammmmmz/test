import type { CSSProperties } from "react";

/**
 * Loading placeholders shaped like the content they stand in for.
 *
 * A skeleton beats a spinner here because every screen in this app is
 * structured — panels, rows, tiles — so a placeholder can set an accurate
 * expectation of what is arriving. A spinner can only say "wait".
 *
 * They cover structure only. Buttons, pills and icons are left out: at that
 * size a placeholder reads as noise rather than as a promise.
 *
 * The whole placeholder tree is `aria-hidden`, with one live region announcing
 * the wait, so a screen reader hears "Loading projects" instead of a hundred
 * empty boxes.
 */

export function Skeleton({
  width,
  height = 12,
  radius = 3,
  delay = 0,
  className = "",
  style,
}: {
  width?: number | string;
  height?: number | string;
  radius?: number;
  /** Offsets the sweep so a stack of bars ripples instead of pulsing as one. */
  delay?: number;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div
      className={`skeleton ${className}`}
      style={{
        width: width ?? "100%",
        height,
        borderRadius: radius,
        ["--sweep-delay" as string]: `${delay}ms`,
        ...style,
      }}
    />
  );
}

/** Wraps a placeholder tree: hidden from assistive tech, announced once. */
export function LoadingRegion({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <>
      <div role="status" aria-live="polite" className="sr-only">
        {label}
      </div>
      <div aria-hidden>{children}</div>
    </>
  );
}

/** The page header block, matched to the real one's metrics. */
export function SkeletonHeader() {
  return (
    <header
      className="px-8 py-7 border-b flex flex-col gap-3"
      style={{ borderColor: "var(--line)", background: "var(--surface)" }}
    >
      <Skeleton width={130} height={9} />
      <Skeleton width={280} height={20} delay={80} />
      <Skeleton width={420} height={11} delay={160} />
    </header>
  );
}

export function SkeletonTiles({ count = 4 }: { count?: number }) {
  return (
    <div
      className="grid gap-3"
      style={{ gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))" }}
    >
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="panel p-4 flex flex-col gap-2.5">
          <Skeleton width={70} height={9} delay={i * 90} />
          <Skeleton width={54} height={22} delay={i * 90 + 60} />
          <Skeleton width={100} height={9} delay={i * 90 + 120} />
        </div>
      ))}
    </div>
  );
}

/** A data table. Column widths vary so it reads as a table, not a grid. */
export function SkeletonTable({
  rows = 6,
  columns = [200, 90, 90, 90, 70],
}: {
  rows?: number;
  columns?: number[];
}) {
  return (
    <div className="panel overflow-hidden">
      <div
        className="flex gap-8 px-4 py-3 border-b"
        style={{ borderColor: "var(--line)" }}
      >
        {columns.map((w, i) => (
          <Skeleton key={i} width={Math.min(w, 80)} height={9} delay={i * 60} />
        ))}
      </div>
      {Array.from({ length: rows }, (_, r) => (
        <div
          key={r}
          className="flex gap-8 px-4 py-4 border-b last:border-b-0 items-center"
          style={{ borderColor: "var(--line)" }}
        >
          {columns.map((w, c) => (
            <Skeleton
              key={c}
              width={w}
              height={c === 0 ? 13 : 11}
              delay={r * 70 + c * 40}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

export function SkeletonPanel({
  lines = 3,
  title = true,
}: {
  lines?: number;
  title?: boolean;
}) {
  return (
    <div className="panel p-4 flex flex-col gap-3">
      {title && <Skeleton width={150} height={13} />}
      {Array.from({ length: lines }, (_, i) => (
        <Skeleton
          key={i}
          width={i === lines - 1 ? "60%" : "100%"}
          height={10}
          delay={i * 90 + 60}
        />
      ))}
    </div>
  );
}
