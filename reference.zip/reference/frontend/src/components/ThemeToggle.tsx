"use client";

import { useEffect, useState } from "react";

type Theme = "light" | "dark" | "system";

/**
 * Stamps `data-theme` on the root element, which the token layer treats as an
 * override of `prefers-color-scheme` in both directions.
 */
export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("system");

  useEffect(() => {
    const stored = (localStorage.getItem("theme") as Theme | null) ?? "system";
    setTheme(stored);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "system") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  const next: Record<Theme, Theme> = { system: "light", light: "dark", dark: "system" };
  const label: Record<Theme, string> = { system: "Auto", light: "Light", dark: "Dark" };

  return (
    <button
      onClick={() => setTheme(next[theme])}
      className="pill"
      style={{
        background: "transparent",
        border: "1px solid var(--line-strong)",
        color: "var(--ink-soft)",
        cursor: "pointer",
      }}
      title={`Theme: ${label[theme]} — click to change`}
    >
      {label[theme]}
    </button>
  );
}
