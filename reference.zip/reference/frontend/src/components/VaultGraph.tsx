"use client";

/**
 * Force-directed rendering of a project's vault.
 *
 * Dangling links are drawn as hollow nodes rather than hidden: in Obsidian an
 * unresolved link is how a gap announces itself — a task with no milestone, a
 * module with no owner — so suppressing them would hide the finding.
 */

import { drag as d3drag } from "d3-drag";
import {
  forceCenter,
  forceCollide,
  forceLink,
  forceManyBody,
  forceSimulation,
  type Simulation,
  type SimulationLinkDatum,
  type SimulationNodeDatum,
} from "d3-force";
import { select } from "d3-selection";
import { zoom as d3zoom, zoomIdentity } from "d3-zoom";
import { useEffect, useMemo, useRef, useState } from "react";
import type { VaultGraph as VaultGraphData } from "@/lib/types";

type SimNode = SimulationNodeDatum & {
  id: string;
  title: string;
  type: string;
  exists: boolean;
};
type SimLink = SimulationLinkDatum<SimNode> & { type: string; dangling: boolean };

// Hues sit around the cyan accent rather than competing with it, and stay
// clear of the semantic ok/warn/critical set used elsewhere.
const TYPE_COLOR: Record<string, string> = {
  project: "#35c9c0",
  milestone: "#7b8cf5",
  task: "#8fb4d9",
  person: "#e0a3c8",
  module: "#5aab9c",
  document: "#b9a6e8",
  activity: "#6b7590",
  missing: "#e2504f",
};

const TYPE_RADIUS: Record<string, number> = {
  project: 14,
  milestone: 10,
  person: 10,
  module: 9,
  document: 8,
  task: 7,
  activity: 5,
  missing: 6,
};

export function VaultGraph({ data }: { data: VaultGraphData }) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [selected, setSelected] = useState<SimNode | null>(null);
  const [hidden, setHidden] = useState<Set<string>>(new Set(["activity"]));

  const types = useMemo(
    () => Array.from(new Set(data.nodes.map((n) => n.type))).sort(),
    [data.nodes],
  );

  useEffect(() => {
    if (!svgRef.current) return;

    const visible = data.nodes.filter((n) => !hidden.has(n.type));
    const ids = new Set(visible.map((n) => n.id));
    const nodes: SimNode[] = visible.map((n) => ({ ...n }));
    const links: SimLink[] = data.edges
      .filter((e) => ids.has(e.source) && ids.has(e.target))
      .map((e) => ({ source: e.source, target: e.target, type: e.type, dangling: e.dangling }));

    const svg = select(svgRef.current);
    svg.selectAll("*").remove();

    const width = svgRef.current.clientWidth || 800;
    const height = 560;
    const root = svg.append("g");

    svg.call(
      d3zoom<SVGSVGElement, unknown>()
        .scaleExtent([0.2, 4])
        .on("zoom", (event) => root.attr("transform", event.transform)),
    );
    svg.call(
      d3zoom<SVGSVGElement, unknown>().transform,
      zoomIdentity,
    );

    const simulation: Simulation<SimNode, SimLink> = forceSimulation(nodes)
      .force(
        "link",
        forceLink<SimNode, SimLink>(links)
          .id((d) => d.id)
          .distance(70)
          .strength(0.4),
      )
      .force("charge", forceManyBody().strength(-220))
      .force("center", forceCenter(width / 2, height / 2))
      .force("collide", forceCollide<SimNode>().radius((d) => (TYPE_RADIUS[d.type] ?? 7) + 6));

    const link = root
      .append("g")
      .attr("stroke", "currentColor")
      .attr("stroke-opacity", 0.25)
      .selectAll<SVGLineElement, SimLink>("line")
      .data(links)
      .join("line")
      .attr("stroke-width", 1)
      .attr("stroke-dasharray", (d) => (d.dangling ? "3,3" : null));

    const node = root
      .append("g")
      .selectAll<SVGCircleElement, SimNode>("circle")
      .data(nodes)
      .join("circle")
      .attr("r", (d) => TYPE_RADIUS[d.type] ?? 7)
      .attr("fill", (d) => (d.exists ? (TYPE_COLOR[d.type] ?? "#888") : "transparent"))
      .attr("stroke", (d) => TYPE_COLOR[d.exists ? d.type : "missing"] ?? "#888")
      .attr("stroke-width", (d) => (d.exists ? 0 : 2))
      .attr("cursor", "pointer")
      .on("click", (_event, d) => setSelected(d));

    node.append("title").text((d) => `${d.title} (${d.type})`);

    const label = root
      .append("g")
      .selectAll<SVGTextElement, SimNode>("text")
      .data(nodes.filter((n) => (TYPE_RADIUS[n.type] ?? 0) >= 9))
      .join("text")
      .text((d) => (d.title.length > 24 ? `${d.title.slice(0, 22)}…` : d.title))
      .attr("font-size", 10)
      .attr("fill", "currentColor")
      .attr("opacity", 0.75)
      .attr("dx", 12)
      .attr("dy", 4)
      .attr("pointer-events", "none");

    node.call(
      d3drag<SVGCircleElement, SimNode>()
        .on("start", (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }),
    );

    simulation.on("tick", () => {
      link
        .attr("x1", (d) => (d.source as SimNode).x ?? 0)
        .attr("y1", (d) => (d.source as SimNode).y ?? 0)
        .attr("x2", (d) => (d.target as SimNode).x ?? 0)
        .attr("y2", (d) => (d.target as SimNode).y ?? 0);
      node.attr("cx", (d) => d.x ?? 0).attr("cy", (d) => d.y ?? 0);
      label.attr("x", (d) => d.x ?? 0).attr("y", (d) => d.y ?? 0);
    });

    return () => {
      simulation.stop();
    };
  }, [data, hidden]);

  function toggle(type: string) {
    setHidden((prev) => {
      const next = new Set(prev);
      if (next.has(type)) next.delete(type);
      else next.add(type);
      return next;
    });
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap gap-1.5 items-center">
        {types.map((type) => (
          <button
            key={type}
            onClick={() => toggle(type)}
            className="pill"
            style={{
              background: hidden.has(type) ? "transparent" : `${TYPE_COLOR[type] ?? "#888"}22`,
              color: hidden.has(type) ? "var(--ink-faint)" : (TYPE_COLOR[type] ?? "#888"),
              border: `1px solid ${TYPE_COLOR[type] ?? "#888"}55`,
              textDecoration: hidden.has(type) ? "line-through" : "none",
            }}
          >
            {type}
          </button>
        ))}
        <span className="mono text-[10.5px] ml-1" style={{ color: "var(--ink-faint)" }}>
          {data.stats.node_count} nodes · {data.stats.edge_count} links ·{" "}
          {data.stats.dangling_count} unresolved
        </span>
      </div>

      <div className="panel overflow-hidden">
        <svg ref={svgRef} width="100%" height={560} role="img" aria-label="Project vault graph" />
      </div>

      {selected && (
        <div className="panel p-4 text-[12.5px]">
          <div className="font-semibold">{selected.title}</div>
          <div className="eyebrow mt-1.5">
            {selected.type}
            {!selected.exists && " · unresolved link — this note does not exist yet"}
          </div>
        </div>
      )}
    </div>
  );
}
