"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { NavLink } from "./NavLink";
import { ThemeToggle } from "./ThemeToggle";

type Me = {
  username: string;
  gitlab_username: string;
  avatar_url: string;
  gitlab_connected: boolean;
};

const NAV = [
  { href: "/", label: "Overview", hint: "Compliance and drift" },
  { href: "/projects", label: "Projects", hint: "Repositories and health" },
  { href: "/team", label: "Team", hint: "People and identity" },
  { href: "/utilization", label: "Utilization", hint: "Planned vs actual" },
  { href: "/leaderboard", label: "Leaderboard", hint: "Rolling 30-day score" },
  { href: "/sync", label: "Sync", hint: "Runs and webhooks" },
];

export function SideRail() {
  const pathname = usePathname();
  const [me, setMe] = useState<Me | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    fetch("/api/proxy/api/auth/me")
      .then((r) => (r.ok ? r.json() : null))
      .then(setMe)
      .catch(() => setMe(null))
      .finally(() => setLoaded(true));
  }, [pathname]);

  async function signOut() {
    await fetch("/api/proxy/api/auth/logout", { method: "POST" });
    window.location.href = "/login";
  }

  return (
    <aside
      className="hidden md:flex flex-col shrink-0 border-r"
      style={{ width: "var(--rail)", background: "var(--ground-deep)" }}
    >
      <div className="px-5 py-5 border-b" style={{ borderColor: "var(--line)" }}>
        <Link href="/" className="flex items-center gap-2.5 group">
          <span
            className="live-dot inline-block shrink-0"
            style={{
              width: 7,
              height: 7,
              borderRadius: 999,
              background: "var(--accent)",
              color: "var(--accent)",
            }}
          />
          <span className="font-semibold tracking-tight text-[15px]">Util Tracker</span>
        </Link>
        <div className="eyebrow mt-2">GitLab traceability</div>
      </div>

      <nav className="flex-1 py-3 flex flex-col gap-0.5 px-2.5">
        {NAV.map((item) => {
          const active =
            item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          return (
            <NavLink key={item.href} href={item.href} active={active}>
              <div className="text-[13px] font-medium">{item.label}</div>
              <div className="text-[10.5px] mt-0.5" style={{ color: "var(--ink-faint)" }}>
                {item.hint}
              </div>
            </NavLink>
          );
        })}
      </nav>

      <div
        className="px-4 py-4 border-t flex flex-col gap-3"
        style={{ borderColor: "var(--line)" }}
      >
        <ThemeToggle />
        {!loaded ? (
          <div
            className="text-[11px] flex items-center gap-2"
            style={{ color: "var(--ink-faint)" }}
          >
            <span className="spinner" aria-hidden />
            Checking session
          </div>
        ) : me ? (
          <div className="flex flex-col gap-1.5">
            <div className="text-[12px] font-medium truncate">
              {me.gitlab_username || me.username}
            </div>
            <button
              onClick={signOut}
              className="text-[11px] text-left link-quiet"
              style={{ background: "none", border: "none", padding: 0, cursor: "pointer" }}
            >
              Sign out
            </button>
          </div>
        ) : (
          /* To the app's own login screen, which offers a password as well as
             GitLab — sending people straight to GitLab was the whole
             complaint. */
          <a
            href={`/login?next=${encodeURIComponent(pathname)}`}
            className="btn btn-primary w-full"
          >
            Sign in
          </a>
        )}
      </div>
    </aside>
  );
}
