"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { shortDate } from "@/lib/format";
import type { WorkloadProject, WorkloadRow } from "@/lib/types";

/**
 * One person's projects, planned allocation against observed share.
 *
 * The bar is the point. Planned allocation is drawn as an outline and the
 * observed share of commits as a fill inside it, so under- and over-running a
 * plan are visible without reading two numbers and subtracting. A project with
 * no plan at all gets a fill and no outline, which is exactly what it is:
 * work happening against nothing.
 */

function toneFor(project: WorkloadProject): string {
  if (project.is_unplanned) return "var(--warn)";
  if (project.drift === null) return "var(--ink-faint)";
  if (Math.abs(project.drift) <= 15) return "var(--ok)";
  return Math.abs(project.drift) <= 30 ? "var(--warn)" : "var(--crit)";
}

function ProjectRow({ project }: { project: WorkloadProject }) {
  const planned = project.allocation_percent;
  const observed = project.share_percent;
  const tone = toneFor(project);

  return (
    <li className="flex flex-col gap-1.5 py-2.5">
      <div className="flex items-baseline justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap min-w-0">
          <span className="text-[12.5px] font-medium truncate">{project.project}</span>
          {project.role && (
            <span className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
              {project.role}
            </span>
          )}
          {project.is_unplanned && (
            <span
              className="pill"
              style={{ background: "var(--warn-wash)", color: "var(--warn)" }}
              title="They have repository access and are committing, but no allocation is recorded"
            >
              unplanned
            </span>
          )}
          {project.is_historic && (
            <span
              className="pill"
              style={{ color: "var(--ink-faint)" }}
              title="Past commits only — no live assignment and no current repository access"
            >
              past work
            </span>
          )}
          {!project.has_access && !project.is_historic && (
            <span
              className="pill"
              style={{ background: "var(--crit-wash)", color: "var(--crit)" }}
              title="Assigned, but they are not a member of the repository"
            >
              no repo access
            </span>
          )}
        </div>
        <div className="mono text-[11px] flex items-baseline gap-2 shrink-0">
          <span style={{ color: "var(--ink-faint)" }}>
            {planned === null ? "no plan" : `plan ${planned}%`}
          </span>
          <span style={{ color: tone }}>
            {observed === null ? "no commits" : `actual ${observed}%`}
          </span>
        </div>
      </div>

      {/* Outline = the plan. Fill = what actually happened inside it. */}
      <div className="workload-bar">
        {planned !== null && (
          <span
            className="workload-plan"
            style={{ width: `${Math.min(planned, 100)}%` }}
            aria-hidden
          />
        )}
        <span
          className="workload-actual"
          style={{
            width: `${Math.min(observed ?? 0, 100)}%`,
            background: tone,
          }}
          aria-hidden
        />
      </div>

      <div className="text-[10.5px] flex gap-3 flex-wrap" style={{ color: "var(--ink-faint)" }}>
        <span className="mono">{project.commits} commits</span>
        <span className="mono">{project.active_days} active days</span>
        {/* Lifetime alongside the window: a project someone worked on for a
            year reads very differently from one they joined last week, and the
            window alone cannot tell them apart. */}
        {project.commits_all_time > project.commits && (
          <span
            className="mono"
            title={
              project.first_commit_at
                ? `First commit ${shortDate(project.first_commit_at)}`
                : undefined
            }
          >
            {project.commits_all_time} all time
          </span>
        )}
        {project.access_level && (
          <span>
            {project.access_level}
            {project.is_inherited && " (inherited)"}
          </span>
        )}
      </div>
    </li>
  );
}

export function Workload({ row }: { row: WorkloadRow }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState<string | null>(null);

  async function planFromRepos() {
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch(
        `/api/proxy/api/team/employees/${row.employee_id}/assign-from-repos/`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" },
      );
      const body = await res.json();
      setMessage(body.detail ?? "Done.");
      if (res.ok && body.created > 0) startTransition(() => router.refresh());
    } catch {
      setMessage("Could not reach the backend.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel overflow-hidden">
      <div
        className="px-4 py-3 border-b flex items-start justify-between gap-3 flex-wrap"
        style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
      >
        <div className="min-w-0">
          <div className="flex items-baseline gap-2 flex-wrap">
            <h3 className="text-[13.5px] font-semibold truncate">{row.full_name}</h3>
            {row.designation && (
              <span className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
                {row.designation}
                {row.department && ` · ${row.department}`}
              </span>
            )}
          </div>
          <div className="text-[11px] mt-1" style={{ color: "var(--ink-soft)" }}>
            <span
              className="mono"
              style={{ color: row.is_overallocated ? "var(--crit)" : "var(--ink-soft)" }}
            >
              {row.planned_allocation}% planned
            </span>
            {" across "}
            <span className="mono">{row.project_count}</span>
            {row.project_count === 1 ? " project" : " projects"}
            {row.unplanned_count > 0 && (
              <>
                {" · "}
                <span style={{ color: "var(--warn)" }}>
                  {row.unplanned_count} with no allocation
                </span>
              </>
            )}
          </div>
        </div>

        {row.unplanned_count > 0 && (
          <button
            onClick={planFromRepos}
            disabled={busy || pending}
            data-busy={busy || pending}
            className="btn btn-ghost text-[12px]"
            title="Create assignments for the repositories they already belong to"
          >
            {(busy || pending) && <span className="spinner" aria-hidden />}
            {busy ? "Planning" : "Plan from repos"}
          </button>
        )}
      </div>

      {message && (
        <div
          className="px-4 py-2 text-[11.5px] border-b"
          style={{ borderColor: "var(--line)", color: "var(--ink-soft)" }}
        >
          {message}
        </div>
      )}

      <ul className="px-4 py-1 divide-y" style={{ borderColor: "var(--line)" }}>
        {row.projects.map((project) => (
          <ProjectRow key={project.project_id} project={project} />
        ))}
        {row.projects.length === 0 && (
          <li className="py-5 text-[12px]" style={{ color: "var(--ink-faint)" }}>
            No projects. They are neither assigned to anything nor a member of any
            tracked repository.
          </li>
        )}
      </ul>
    </div>
  );
}
