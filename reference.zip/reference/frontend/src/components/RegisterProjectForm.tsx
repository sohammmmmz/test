"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { type AvailableRepo, RepoPicker } from "./RepoPicker";

type Validation = {
  valid: boolean;
  detail: string;
  path_with_namespace?: string;
  default_branch?: string;
  already_linked_to?: string | null;
};

const field = "field";

export function RegisterProjectForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [repo, setRepo] = useState("");
  // Browsing is the default: pasting a path means knowing it by heart.
  const [mode, setMode] = useState<"browse" | "paste">("browse");
  const [validation, setValidation] = useState<Validation | null>(null);
  const [checking, setChecking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function checkRepo() {
    if (!repo.trim()) return;
    setChecking(true);
    setValidation(null);
    try {
      const res = await fetch("/api/proxy/api/projects/validate-repo/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo_reference: repo.trim() }),
      });
      const data = await res.json();
      setValidation(res.ok ? data : { valid: false, detail: data.detail ?? "Check failed." });
    } catch {
      setValidation({ valid: false, detail: "Could not reach the backend." });
    } finally {
      setChecking(false);
    }
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/proxy/api/projects/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
          repo_reference: repo.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail ?? JSON.stringify(data));
        return;
      }
      router.push(`/projects/${data.id}`);
    } catch {
      setError("Could not reach the backend.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={submit} className="panel p-5 flex flex-col gap-4">
      <label className="flex flex-col gap-1.5">
        <span className="text-[12.5px] font-medium">Project name</span>
        <input
          className={field}
         
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          placeholder="Apollo"
        />
      </label>

      <label className="flex flex-col gap-1.5">
        <span className="text-[12.5px] font-medium">Description</span>
        <textarea
          className={field}
         
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="What this project is for. Used as context when scoring commits."
        />
      </label>

      <div className="flex flex-col gap-2">
        <div className="flex items-baseline justify-between gap-3 flex-wrap">
          <span className="text-[12.5px] font-medium">
            GitLab repository{" "}
            <span className="font-normal" style={{ color: "var(--ink-faint)" }}>
              — leave blank to create one
            </span>
          </span>
          <button
            type="button"
            onClick={() => setMode(mode === "browse" ? "paste" : "browse")}
            className="text-[11.5px] link-quiet"
            style={{ background: "none", border: "none", padding: 0, cursor: "pointer" }}
          >
            {mode === "browse" ? "Paste a URL instead" : "Browse my repositories"}
          </button>
        </div>

        {mode === "browse" ? (
          <RepoPicker
            value={repo}
            onSelect={(selected) => {
              setRepo(selected?.path_with_namespace ?? "");
              setValidation(null);
            }}
          />
        ) : (
          <div className="flex gap-2">
            <input
              className={field}
              value={repo}
              onChange={(e) => {
                setRepo(e.target.value);
                setValidation(null);
              }}
              placeholder="namespace/project or a full GitLab URL"
            />
            <button
              type="button"
              onClick={checkRepo}
              disabled={checking || !repo.trim()}
              data-busy={checking}
              className="btn btn-ghost whitespace-nowrap"
            >
              {checking && <span className="spinner" aria-hidden />}
              {checking ? "Checking" : "Check"}
            </button>
          </div>
        )}

        {mode === "browse" && repo && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="mono text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
              {repo}
            </span>
            <button
              type="button"
              onClick={checkRepo}
              disabled={checking}
              data-busy={checking}
              className="btn btn-ghost"
            >
              {checking && <span className="spinner" aria-hidden />}
              {checking ? "Checking" : "Check access"}
            </button>
          </div>
        )}
      </div>

      {validation && (
        <div
          className="panel p-3 text-[12.5px]"
          style={{
            background: validation.valid ? "var(--ok-wash)" : "var(--crit-wash)",
            borderColor: validation.valid ? "var(--ok)" : "var(--crit)",
            color: validation.valid ? "var(--ok)" : "var(--crit)",
          }}
        >
          {validation.detail}
          {validation.path_with_namespace && (
            <div className="mono text-[11px] mt-1 opacity-80">
              {validation.path_with_namespace} · default branch {validation.default_branch}
            </div>
          )}
        </div>
      )}

      {error && (
        <div
          className="panel p-3 text-[12.5px]"
          style={{ background: "var(--crit-wash)", borderColor: "var(--crit)", color: "var(--crit)" }}
        >
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={submitting || !name.trim()}
        data-busy={submitting}
        className="btn btn-primary self-start"
      >
        {submitting && <span className="spinner" aria-hidden />}
        {submitting ? "Registering" : "Register project"}
      </button>
    </form>
  );
}
