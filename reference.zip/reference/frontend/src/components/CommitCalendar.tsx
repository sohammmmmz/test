"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { dayLabel, monthShort, monthYear, weekdayIndex } from "@/lib/format";
import type { CalendarCell, CalendarRow, CalendarState, CommitCalendar } from "@/lib/types";

/**
 * Daily commit cadence, one strip per person.
 *
 * Read vertically as much as horizontally: the days are aligned across every
 * person, so a column where the whole team went dark is a release, an outage or
 * an unrecorded holiday — not five separate people slacking. That alignment is
 * the reason this is one grid rather than a chart per person.
 *
 * Encoding is deliberately redundant. Density uses a validated single-hue ramp;
 * a missed day adds a 45° hatch; a day of review-only contribution is hollow
 * with a centre dot. Nothing here is distinguishable by hue alone, and the
 * table view carries every value the grid shows.
 */

const RANGES = [30, 60, 90, 180] as const;

const WEEKDAY_LABELS = ["M", "T", "W", "T", "F", "S", "S"];

/**
 * Lay a person's days out as real calendar months.
 *
 * The strip view is dense and comparable across people; this one is how a
 * person actually thinks about their own month. Days sit under the right
 * weekday column, weeks read as rows, and a missed Tuesday is findable by date
 * rather than by counting cells.
 */
function toMonths(cells: CalendarCell[]) {
  const months = new Map<string, CalendarCell[]>();
  for (const cell of cells) {
    const key = cell.date.slice(0, 7);
    const bucket = months.get(key);
    if (bucket) bucket.push(cell);
    else months.set(key, [cell]);
  }

  return Array.from(months.entries()).map(([key, days]) => {
    // Monday-first, so the working week is contiguous and the weekend sits
    // together at the end where it reads as one block.
    const lead = (weekdayIndex(days[0].date) + 6) % 7;
    return {
      key,
      label: monthYear(days[0].date),
      lead,
      days,
    };
  });
}

const STATE_LABEL: Record<CalendarState, string> = {
  active: "Committed",
  indirect: "Reviewed, no commits",
  missed: "Missed",
  off: "Non-working day",
  outside: "Outside their time on any project",
};

/** Density bucket. Four classes, so adjacent steps stay distinguishable. */
function heatClass(commits: number): string {
  if (commits >= 7) return "cal-active-4";
  if (commits >= 4) return "cal-active-3";
  if (commits >= 2) return "cal-active-2";
  return "cal-active-1";
}

function cellClass(cell: CalendarCell): string {
  if (cell.state === "active") return heatClass(cell.commits);
  return `cal-${cell.state}`;
}

function tooltipFor(row: CalendarRow, cell: CalendarCell): string {
  const parts = [`${row.full_name} · ${dayLabel(cell.date)}`, STATE_LABEL[cell.state]];
  if (cell.commits) {
    parts.push(`${cell.commits} commit${cell.commits === 1 ? "" : "s"}`);
  }
  for (const project of cell.projects ?? []) {
    parts.push(`  ${project.name}: ${project.commits}`);
  }
  if (cell.reviews) parts.push(`${cell.reviews} review note${cell.reviews === 1 ? "" : "s"}`);
  if (cell.merges) parts.push(`${cell.merges} MR merged`);
  return parts.join("\n");
}

/** Month boundaries, for the ruler above the strips. */
function monthTicks(cells: CalendarCell[]) {
  const ticks: Array<{ index: number; label: string }> = [];
  let previous = "";
  cells.forEach((cell, index) => {
    const month = cell.date.slice(0, 7);
    if (month !== previous) {
      previous = month;
      ticks.push({ index, label: monthShort(cell.date) });
    }
  });
  return ticks;
}

/**
 * The person's projects as one line.
 *
 * These now come from repository membership as well as assignments, so
 * "no project" means genuinely on nothing rather than merely absent from a
 * planning table nobody fills in. A project backed only by membership is
 * starred: the work is real, the allocation is missing.
 */
function projectLine(row: CalendarRow): string {
  if (row.projects.length === 0) return "no project";
  const unplanned = new Set(row.unplanned_projects ?? []);
  return row.projects.map((p) => (unplanned.has(p) ? `${p}*` : p)).join(" · ");
}

function coverageTone(row: CalendarRow): string {
  if (row.coverage_percent === null) return "var(--ink-faint)";
  if (row.coverage_percent >= 80) return "var(--ok)";
  if (row.coverage_percent >= 50) return "var(--warn)";
  return "var(--crit)";
}

export function CommitCalendar({
  initial,
  projectId,
}: {
  initial: CommitCalendar;
  projectId?: number;
}) {
  const [data, setData] = useState(initial);
  const [days, setDays] = useState(initial.days);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<"strip" | "months" | "table">("strip");
  // Every fetch is ticketed so a slow earlier response cannot overwrite a
  // faster later one when the range is changed twice quickly.
  const ticket = useRef(0);

  const load = useCallback(
    async (nextDays: number) => {
      const mine = ++ticket.current;
      setLoading(true);
      setError(null);
      try {
        const query = new URLSearchParams({ days: String(nextDays) });
        if (projectId) query.set("project", String(projectId));
        const res = await fetch(`/api/proxy/api/scoring/commit-calendar?${query}`);
        if (!res.ok) throw new Error(String(res.status));
        const body = (await res.json()) as CommitCalendar;
        if (mine === ticket.current) setData(body);
      } catch {
        if (mine === ticket.current) setError("Could not load that range.");
      } finally {
        if (mine === ticket.current) setLoading(false);
      }
    },
    [projectId],
  );

  useEffect(() => {
    if (days !== data.days) void load(days);
    // `data.days` intentionally omitted: this reacts to the control, not the
    // response it produces.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [days, load]);

  const ticks = useMemo(
    () => monthTicks(data.rows[0]?.cells ?? []),
    [data.rows],
  );
  const span = data.rows[0]?.cells.length ?? 0;
  // Wide ranges get smaller cells so a quarter still fits without the strip
  // becoming unreadably long.
  const size = span > 120 ? 8 : span > 90 ? 9 : 11;
  const gap = span > 120 ? 2 : 3;
  const behind = data.rows.filter(
    (r) => r.coverage_percent !== null && r.coverage_percent < 60,
  );

  return (
    <section className="flex flex-col gap-4">
      {/* One filter row above everything it scopes. */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1" role="group" aria-label="Time range">
            {RANGES.map((option) => (
              <button
                key={option}
                onClick={() => setDays(option)}
                aria-pressed={days === option}
                className="pill"
                style={{
                  cursor: "pointer",
                  background: days === option ? "var(--accent-wash)" : "transparent",
                  color: days === option ? "var(--accent)" : "var(--ink-faint)",
                  border: `1px solid ${days === option ? "var(--accent)" : "var(--line)"}`,
                }}
              >
                {option}d
              </button>
            ))}
          </div>
          {loading && (
            <span
              className="eyebrow flex items-center gap-1.5"
              style={{ color: "var(--accent)" }}
              role="status"
            >
              <span className="spinner" aria-hidden />
              Updating
            </span>
          )}
          {error && (
            <span className="text-[11px]" style={{ color: "var(--crit)" }}>
              {error}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1" role="group" aria-label="View">
          {(
            [
              ["strip", "Timeline"],
              ["months", "Calendar"],
              ["table", "Table"],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setView(key)}
              aria-pressed={view === key}
              className="pill"
              style={{
                cursor: "pointer",
                background: view === key ? "var(--accent-wash)" : "transparent",
                color: view === key ? "var(--accent)" : "var(--ink-faint)",
                border: `1px solid ${view === key ? "var(--accent)" : "var(--line)"}`,
              }}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <Legend />

      {behind.length > 0 && view !== "table" && (
        <p className="text-[12px]" style={{ color: "var(--ink-soft)" }}>
          <span style={{ color: "var(--crit)" }}>{behind.length}</span> of{" "}
          {data.rows.length} committed on fewer than 60% of the days expected of them
          in this window.
        </p>
      )}

      {view === "table" && <TableView rows={data.rows} />}

      {view === "months" && (
        <div className={`flex flex-col gap-4 ${loading ? "settling" : ""}`}>
          {data.rows.map((row) => (
            <PersonCalendar key={row.employee_id} row={row} />
          ))}
          {data.rows.length === 0 && (
            <p className="text-[13px] py-8 text-center" style={{ color: "var(--ink-faint)" }}>
              No active team members to chart.
            </p>
          )}
        </div>
      )}

      {view === "strip" && (
        <div className="panel scroll-x">
          <div className="p-4 inline-block min-w-full">
            <div
              className={loading ? "settling" : undefined}
              style={{ ["--cal-size" as string]: `${size}px`, ["--cal-gap" as string]: `${gap}px` }}
            >
              <MonthRuler ticks={ticks} span={span} size={size} gap={gap} />
              {data.rows.map((row, rowIndex) => (
                <Strip key={row.employee_id} row={row} rowIndex={rowIndex} />
              ))}
              {data.rows.length === 0 && (
                <p className="text-[13px] py-8 text-center" style={{ color: "var(--ink-faint)" }}>
                  No active team members to chart.
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function MonthRuler({
  ticks,
  span,
  size,
  gap,
}: {
  ticks: Array<{ index: number; label: string }>;
  span: number;
  size: number;
  gap: number;
}) {
  if (span === 0) return null;
  return (
    <div className="flex items-end mb-1.5" style={{ paddingLeft: "var(--cal-label, 210px)" }}>
      <div style={{ position: "relative", width: span * (size + gap) - gap, height: 12 }}>
        {ticks.map((tick) => (
          <span
            key={tick.index}
            className="eyebrow"
            style={{
              position: "absolute",
              left: tick.index * (size + gap),
              fontSize: 9,
              whiteSpace: "nowrap",
            }}
          >
            {tick.label}
          </span>
        ))}
      </div>
    </div>
  );
}

function Strip({ row, rowIndex }: { row: CalendarRow; rowIndex: number }) {
  const summary =
    row.coverage_percent === null
      ? `${row.full_name}: no commits expected in this window.`
      : `${row.full_name}: committed or reviewed on ${row.active_days + row.indirect_days} of ` +
        `${row.expected_days} expected days, ${row.missed_days} missed.`;

  return (
    <div className="flex items-center gap-3 py-1.5">
      <div
        className="shrink-0 overflow-hidden"
        style={{ width: "var(--cal-label, 210px)" }}
      >
        <div className="flex items-baseline gap-2">
          <span className="text-[12.5px] font-medium truncate">{row.full_name}</span>
          <span
            className="mono text-[10.5px] shrink-0"
            style={{ color: coverageTone(row) }}
            title="Share of expected days with a commit or a review"
          >
            {row.coverage_percent === null ? "—" : `${row.coverage_percent}%`}
          </span>
        </div>
        <div className="text-[10.5px] truncate" style={{ color: "var(--ink-faint)" }}>
          {row.missed_days > 0 ? (
            <>
              <span style={{ color: "var(--crit)" }}>{row.missed_days} missed</span>
              {row.longest_gap > 1 && ` · ${row.longest_gap}d gap`}
            </>
          ) : row.expected_days > 0 ? (
            <span style={{ color: "var(--ok)" }}>no missed days</span>
          ) : (
            "nothing expected"
          )}
        </div>
      </div>

      {/* The grid is one image to assistive tech; the table view carries the
          detail, rather than emitting a focus stop per day. */}
      <div className="cal-grid" role="img" aria-label={summary}>
        {row.cells.map((cell, index) => (
          <div
            key={cell.date}
            className={`cal-cell ${cellClass(cell)}`}
            title={tooltipFor(row, cell)}
            style={{
              // Sweeps left to right, capped so a long range does not turn the
              // load into a wait.
              animationDelay: `${Math.min(index * 5 + rowIndex * 30, 700)}ms`,
            }}
          />
        ))}
      </div>
    </div>
  );
}

/**
 * One person, laid out as real months.
 *
 * Cells are large enough to carry the date and the commit count as text, so
 * the values are readable without hovering — the density encoding becomes
 * reinforcement rather than the only way to read the number.
 */
function PersonCalendar({ row }: { row: CalendarRow }) {
  const months = toMonths(row.cells);

  return (
    <div className="panel overflow-hidden">
      <div
        className="px-4 py-3 border-b flex items-baseline justify-between gap-3 flex-wrap"
        style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
      >
        <div className="flex items-baseline gap-2.5 flex-wrap">
          <h3 className="text-[13.5px] font-semibold">{row.full_name}</h3>
          <span className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
            {projectLine(row)}
          </span>
        </div>
        <div className="flex items-baseline gap-3 text-[11px]">
          <span className="mono" style={{ color: coverageTone(row) }}>
            {row.coverage_percent === null ? "—" : `${row.coverage_percent}% covered`}
          </span>
          <span
            className="mono"
            style={{ color: row.missed_days ? "var(--crit)" : "var(--ok)" }}
          >
            {row.missed_days} missed
          </span>
          <span className="mono" style={{ color: "var(--ink-soft)" }}>
            {row.commits} commits
          </span>
        </div>
      </div>

      <div className="p-4 flex gap-6 flex-wrap">
        {months.map((month) => (
          <div key={month.key} className="flex flex-col gap-2">
            <div className="eyebrow">{month.label}</div>
            <div
              className="grid gap-1"
              style={{ gridTemplateColumns: "repeat(7, 30px)" }}
            >
              {WEEKDAY_LABELS.map((label, i) => (
                <div
                  key={i}
                  className="text-center text-[9px] font-medium pb-0.5"
                  style={{ color: "var(--ink-faint)" }}
                  aria-hidden
                >
                  {label}
                </div>
              ))}
              {/* Blanks so the first day lands under its real weekday. */}
              {Array.from({ length: month.lead }, (_, i) => (
                <div key={`lead-${i}`} />
              ))}
              {month.days.map((cell) => (
                <DayBox key={cell.date} row={row} cell={cell} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DayBox({ row, cell }: { row: CalendarRow; cell: CalendarCell }) {
  const day = Number(cell.date.slice(8, 10));
  const isActive = cell.state === "active";

  return (
    <div
      className={`cal-day cal-day-${cell.state} ${isActive ? heatClass(cell.commits) : ""}`}
      title={tooltipFor(row, cell)}
    >
      <span className="cal-day-num">{day}</span>
      {cell.commits > 0 && <span className="cal-day-count">{cell.commits}</span>}
      {/* Form, not colour: a missed day carries a mark that survives greyscale
          and colour-vision deficiency. */}
      {cell.state === "missed" && (
        <span className="cal-day-flag" aria-hidden>
          ✕
        </span>
      )}
      {cell.state === "indirect" && (
        <span className="cal-day-flag" aria-hidden>
          ◇
        </span>
      )}
    </div>
  );
}

function Legend() {
  return (
    <div className="flex items-center gap-5 flex-wrap text-[11px]" style={{ color: "var(--ink-soft)" }}>
      <span className="flex items-center gap-1.5">
        <span style={{ color: "var(--ink-faint)" }}>Fewer</span>
        {["cal-active-1", "cal-active-2", "cal-active-3", "cal-active-4"].map((c) => (
          <span key={c} className={`cal-cell ${c}`} style={{ animation: "none" }} />
        ))}
        <span style={{ color: "var(--ink-faint)" }}>More commits</span>
      </span>
      {(
        [
          ["cal-missed", "Missed"],
          ["cal-indirect", "Review only"],
          ["cal-off", "Weekend / holiday"],
          ["cal-outside", "Not assigned"],
        ] as const
      ).map(([className, label]) => (
        <span key={className} className="flex items-center gap-1.5">
          <span className={`cal-cell ${className}`} style={{ animation: "none" }} />
          {label}
        </span>
      ))}
    </div>
  );
}

/**
 * The WCAG-clean twin of the grid. Every number the cells encode is here as
 * text, including the actual dates that were missed — which is also the form
 * you want when taking this into a conversation with someone.
 */
function TableView({ rows }: { rows: CalendarRow[] }) {
  return (
    <div className="panel scroll-x">
      <table className="data-table" style={{ minWidth: 900 }}>
        <thead>
          <tr>
            <th>Person</th>
            <th>Commits</th>
            <th>Committed</th>
            <th>Review only</th>
            <th>Missed</th>
            <th>Expected</th>
            <th>Coverage</th>
            <th>Longest gap</th>
            <th>Last commit</th>
            <th>Missed dates</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.employee_id}>
              <td
                className="track"
                style={{ ["--track-color" as string]: coverageTone(row) }}
              >
                <div className="font-medium">{row.full_name}</div>
                <div className="text-[11px] mt-0.5" style={{ color: "var(--ink-faint)" }}>
                  {projectLine(row)}
                </div>
              </td>
              <td className="mono text-[12px]">{row.commits}</td>
              <td className="mono text-[12px]">{row.active_days}</td>
              <td className="mono text-[12px]">{row.indirect_days}</td>
              <td
                className="mono text-[12px]"
                style={{ color: row.missed_days ? "var(--crit)" : "var(--ink-faint)" }}
              >
                {row.missed_days}
              </td>
              <td className="mono text-[12px]">{row.expected_days}</td>
              <td className="mono text-[12px]" style={{ color: coverageTone(row) }}>
                {row.coverage_percent === null ? "—" : `${row.coverage_percent}%`}
              </td>
              <td className="mono text-[12px]">{row.longest_gap || "—"}</td>
              <td className="mono text-[12px]" style={{ color: "var(--ink-soft)" }}>
                {row.last_commit_on ?? "never"}
              </td>
              <td className="text-[11px]" style={{ color: "var(--ink-soft)", maxWidth: 260 }}>
                {row.cells
                  .filter((c) => c.state === "missed")
                  .map((c) => c.date)
                  .join(", ") || "—"}
              </td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={10} className="text-center py-10" style={{ color: "var(--ink-faint)" }}>
                No active team members.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
