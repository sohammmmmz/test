/**
 * The first-arrival animation: an instrument powering on.
 *
 * The idiom is the one this app already speaks — a signal trace, a pulsing
 * carrier, a rule filling as the connection is acquired. It is not a generic
 * splash; it is a smaller version of what the dashboard itself draws.
 *
 * Shown once per browser session. That constraint is the whole reason it can
 * afford to be slower than everything else in the app: an animation you watch
 * forty times a day has to get out of the way, but one you watch on arrival can
 * take a beat. The gate is an attribute stamped on <html> before first paint
 * (see the head script in layout.tsx), so this markup renders identically on
 * the server and the client and CSS alone decides whether it is seen.
 *
 * Rendered as static markup rather than a client component on purpose: no
 * JavaScript needs to load before it can play.
 */
export function BootSequence() {
  return (
    <div className="boot" aria-hidden>
      <div className="boot-mark">
        <span className="boot-dot" />
        <span className="text-[17px] font-semibold tracking-tight">Util Tracker</span>
      </div>

      <svg className="boot-trace" viewBox="0 0 320 34" fill="none" aria-hidden>
        <path
          d="M0 24 L28 24 L40 12 L52 26 L68 20 L84 6 L100 22 L118 18 L134 27 L150 9 L168 21 L184 15 L202 25 L218 11 L236 23 L252 19 L270 8 L288 22 L304 17 L320 20"
          stroke="var(--accent)"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ ["--dash" as string]: "620" }}
        />
      </svg>

      <div className="boot-rule" />

      <div className="eyebrow boot-status">Acquiring signal</div>
    </div>
  );
}
