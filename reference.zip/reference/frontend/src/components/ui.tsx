import type { CSSProperties, ReactNode } from "react";
import type { HealthState } from "@/lib/types";

/**
 * Server-rendered presentation primitives.
 *
 * Motion here is pure CSS with a per-element delay, so the load sequence runs
 * without shipping any JavaScript — and `prefers-reduced-motion` collapses it
 * globally from `globals.css`.
 */

export function Reveal({
  children,
  delay = 0,
  index,
  className = "",
  style,
}: {
  children: ReactNode;
  /** Explicit delay in ms. */
  delay?: number;
  /** Position in a stagger; multiplied by the shared step so sibling groups
   *  across different screens arrive at the same cadence. */
  index?: number;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div
      className={`enter ${className}`}
      style={
        index === undefined
          ? { animationDelay: `${delay}ms`, ...style }
          : { ["--i" as string]: index, ...style }
      }
    >
      {children}
    </div>
  );
}

/**
 * Arrival for a group of siblings, in reading order.
 *
 * One orchestrated movement reads as the screen assembling; the same elements
 * fading in independently read as a queue. The `start` offset lets a block
 * begin after the header above it has landed rather than racing it.
 */
export function Stagger({
  children,
  start = 0,
  className = "",
  style,
}: {
  children: ReactNode[];
  start?: number;
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div className={className} style={style}>
      {children.map((child, i) => (
        <Reveal key={i} index={start + i}>
          {child}
        </Reveal>
      ))}
    </div>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <div className="eyebrow">{children}</div>;
}

const HEALTH: Record<HealthState, { label: string; color: string; wash: string }> = {
  healthy: { label: "Healthy", color: "var(--ok)", wash: "var(--ok-wash)" },
  warning: { label: "Warning", color: "var(--warn)", wash: "var(--warn-wash)" },
  critical: { label: "Critical", color: "var(--crit)", wash: "var(--crit-wash)" },
  unknown: { label: "Unevaluated", color: "var(--ink-faint)", wash: "transparent" },
};

export function healthColor(state: HealthState): string {
  return (HEALTH[state] ?? HEALTH.unknown).color;
}

export function HealthPill({ state, score }: { state: HealthState; score?: number }) {
  const tone = HEALTH[state] ?? HEALTH.unknown;
  return (
    <span
      className="pill"
      style={{
        background: tone.wash,
        color: tone.color,
        border: `1px solid ${tone.color}33`,
      }}
    >
      <span
        aria-hidden
        style={{
          width: 5,
          height: 5,
          borderRadius: 999,
          background: tone.color,
          display: "inline-block",
        }}
      />
      {tone.label}
      {typeof score === "number" && state !== "unknown" && (
        <span style={{ opacity: 0.7 }}>{score}</span>
      )}
    </span>
  );
}

export function StatTile({
  label,
  value,
  hint,
  tone,
  index = 0,
}: {
  label: string;
  value: number | string;
  hint?: string;
  tone?: string;
  /** Position in the tile row; drives the shared stagger. */
  index?: number;
}) {
  return (
    <Reveal index={index} className="panel p-4 flex flex-col gap-1">
      <Eyebrow>{label}</Eyebrow>
      <div
        className="mono text-[26px] leading-none font-medium mt-1"
        style={{ color: tone ?? "var(--ink)" }}
      >
        {value}
      </div>
      {hint && (
        <div className="text-[11px] mt-0.5" style={{ color: "var(--ink-faint)" }}>
          {hint}
        </div>
      )}
    </Reveal>
  );
}

/**
 * Commit-density sparkline.
 *
 * Encodes real activity rather than decorating the row: a flat trace with a
 * dim endpoint is a project nobody has touched, which is exactly the thing
 * this dashboard exists to surface.
 */
export function Sparkline({
  points,
  width = 96,
  height = 26,
  color = "var(--accent)",
  delay = 0,
}: {
  points: number[];
  width?: number;
  height?: number;
  color?: string;
  delay?: number;
}) {
  if (points.length === 0) {
    return (
      <svg width={width} height={height} aria-hidden>
        <line
          x1="0"
          y1={height - 2}
          x2={width}
          y2={height - 2}
          stroke="var(--line-strong)"
          strokeWidth="1"
          strokeDasharray="2,3"
        />
      </svg>
    );
  }

  const max = Math.max(...points, 1);
  const step = points.length > 1 ? width / (points.length - 1) : width;
  const y = (v: number) => height - 2 - (v / max) * (height - 5);
  const coords = points.map((v, i) => [i * step, y(v)] as const);
  const line = coords.map(([x, yy], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${yy.toFixed(1)}`).join(" ");
  const area = `${line} L${width},${height} L0,${height} Z`;
  const [lastX, lastY] = coords[coords.length - 1];
  const gradientId = `spark-${Math.round(points.reduce((a, b) => a + b, 0))}-${points.length}`;

  return (
    <svg width={width} height={height} aria-hidden style={{ display: "block" }}>
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gradientId})`} />
      <path
        className="spark-path"
        d={line}
        fill="none"
        stroke={color}
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{ ["--dash" as string]: "400", animationDelay: `${delay + 200}ms` }}
      />
      <circle cx={lastX} cy={lastY} r="2" fill={color} />
    </svg>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="panel p-10 text-center">
      <p className="font-medium">{title}</p>
      <p className="text-[13px] mt-2 max-w-md mx-auto" style={{ color: "var(--ink-faint)" }}>
        {body}
      </p>
    </div>
  );
}

export function relativeDays(iso: string | null): string {
  if (!iso) return "never";
  const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000);
  if (days <= 0) return "today";
  if (days === 1) return "yesterday";
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}
