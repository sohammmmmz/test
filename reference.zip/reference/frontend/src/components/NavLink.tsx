"use client";

import Link, { useLinkStatus } from "next/link";
import type { ReactNode } from "react";

/**
 * A rail item that shows when its own navigation is in flight.
 *
 * `useLinkStatus` only reports inside the Link it belongs to, which is exactly
 * right here: the feedback lands on the thing that was clicked rather than on a
 * detached bar at the top of the window. The destination's own skeleton takes
 * over the moment the route commits, so the two form one continuous response —
 * click, this item marks itself busy, the target screen draws its shape.
 */
function PendingMark() {
  const { pending } = useLinkStatus();
  if (!pending) return null;
  return (
    <span
      className="spinner absolute right-2.5 top-1/2 -translate-y-1/2"
      style={{ fontSize: 11, color: "var(--accent)" }}
      aria-hidden
    />
  );
}

export function NavLink({
  href,
  active,
  children,
}: {
  href: string;
  active: boolean;
  children: ReactNode;
}) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className="px-2.5 py-2 rounded-[3px] relative nav-item"
      style={{
        background: active ? "var(--surface)" : "transparent",
        color: active ? "var(--ink)" : "var(--ink-soft)",
      }}
    >
      {active && (
        <span
          aria-hidden
          className="absolute left-0 top-1.5 bottom-1.5 w-[2px] rounded rail-mark"
          style={{ background: "var(--accent)" }}
        />
      )}
      {children}
      <PendingMark />
    </Link>
  );
}
