"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState, useTransition } from "react";

type Member = {
  gitlab_user_id: number;
  username: string;
  name: string;
  email: string;
  access_level: number;
  access_level_display: string;
  employee: {
    id: number;
    full_name: string;
    department: string;
    designation: string;
    employment_type: string;
  } | null;
};

/**
 * Who has access to this repository, and whether the tool knows who they are.
 *
 * Adding someone happens here rather than on the Team tab because this is
 * where the question arises — you are looking at a repo, you see a name you
 * do not recognise, and the fix should be one step away.
 */
export function ProjectMembers({ projectId }: { projectId: number }) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState<Member | null>(null);
  const [message, setMessage] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/proxy/api/projects/${projectId}/members/`);
      const data = await res.json();
      setMembers(data.members ?? []);
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    load();
  }, [load]);

  async function addToTeam(member: Member, details: Record<string, string>) {
    const res = await fetch("/api/proxy/api/team/unlinked-members/create-employee/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gitlab_user_id: member.gitlab_user_id, ...details }),
    });
    const data = await res.json();
    if (!res.ok) {
      setMessage({ tone: "bad", text: Object.values(data).flat().join(" ") });
      return;
    }
    setMessage({
      tone: "ok",
      text: `${details.full_name} added to the team and linked to @${member.username}.`,
    });
    setAdding(null);
    await load();
    startTransition(() => router.refresh());
  }

  const unlinked = members.filter((m) => !m.employee);

  return (
    <div className="panel overflow-hidden">
      <div
        className="px-4 py-3 border-b flex items-center justify-between gap-3"
        style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
      >
        <div>
          <h3 className="text-[13px] font-semibold">Repository members</h3>
          <p
            className="text-[11.5px] mt-1 flex items-center gap-1.5"
            style={{ color: "var(--ink-soft)" }}
          >
            {loading
              ? [<span key="s" className="spinner" aria-hidden />, "Reading members"]
              : unlinked.length
                ? `${unlinked.length} of ${members.length} not on your team yet`
                : `${members.length} member(s), all recognised`}
          </p>
        </div>
      </div>

      {message && (
        <div
          className="px-4 py-2.5 text-[12px] border-b"
          style={{
            borderColor: "var(--line)",
            background: message.tone === "ok" ? "var(--ok-wash)" : "var(--crit-wash)",
            color: message.tone === "ok" ? "var(--ok)" : "var(--crit)",
          }}
        >
          {message.text}
        </div>
      )}

      {!loading && members.length === 0 && (
        <p className="p-5 text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
          No members synced yet — run a sync to pull them from GitLab.
        </p>
      )}

      {members.map((member) => (
        <div
          key={member.gitlab_user_id}
          className="track px-4 py-3 border-b last:border-b-0"
          style={{
            borderColor: "var(--line)",
            ["--track-color" as string]: member.employee ? "var(--ok)" : "var(--warn)",
          }}
        >
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="text-[12.5px] font-medium">
                {member.employee?.full_name || member.name || member.username}{" "}
                <span className="mono text-[11px]" style={{ color: "var(--ink-faint)" }}>
                  @{member.username}
                </span>
              </div>
              <div className="text-[11px] mt-0.5" style={{ color: "var(--ink-faint)" }}>
                {member.access_level_display}
                {member.employee
                  ? ` · ${member.employee.designation || "no designation"} · ${
                      member.employee.department || "no department"
                    }`
                  : " · not on your team"}
              </div>
            </div>

            {member.employee ? (
              <span className="pill" style={{ background: "var(--ok-wash)", color: "var(--ok)" }}>
                on team
              </span>
            ) : (
              <button
                className="btn btn-ghost"
                onClick={() =>
                  setAdding(
                    adding?.gitlab_user_id === member.gitlab_user_id ? null : member,
                  )
                }
              >
                {adding?.gitlab_user_id === member.gitlab_user_id ? "Cancel" : "Add to team"}
              </button>
            )}
          </div>

          {adding?.gitlab_user_id === member.gitlab_user_id && (
            <AddMemberForm member={member} onSubmit={(d) => addToTeam(member, d)} />
          )}
        </div>
      ))}
    </div>
  );
}

function AddMemberForm({
  member,
  onSubmit,
}: {
  member: Member;
  onSubmit: (details: Record<string, string>) => void;
}) {
  const [details, setDetails] = useState({
    full_name: member.name || member.username,
    official_email: member.email || "",
    department: "",
    designation: "",
    employment_type: "employee",
  });

  return (
    <div className="mt-3 pt-3 rise" style={{ borderTop: "1px solid var(--line)" }}>
      <div className="grid gap-2 md:grid-cols-2">
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Full name</span>
          <input
            className="field"
            value={details.full_name}
            onChange={(e) => setDetails({ ...details, full_name: e.target.value })}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Official email</span>
          <input
            className="field"
            type="email"
            value={details.official_email}
            onChange={(e) => setDetails({ ...details, official_email: e.target.value })}
            placeholder="name@company.com"
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Department</span>
          <input
            className="field"
            value={details.department}
            onChange={(e) => setDetails({ ...details, department: e.target.value })}
            placeholder="Engineering"
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Designation</span>
          <input
            className="field"
            value={details.designation}
            onChange={(e) => setDetails({ ...details, designation: e.target.value })}
            placeholder="Senior Engineer"
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Type</span>
          <select
            className="field"
            value={details.employment_type}
            onChange={(e) => setDetails({ ...details, employment_type: e.target.value })}
          >
            <option value="employee">Employee</option>
            <option value="intern">Intern</option>
            <option value="contractor">Contractor</option>
          </select>
        </label>
        <div className="flex items-end">
          <button
            className="btn btn-primary"
            disabled={!details.full_name || !details.official_email}
            onClick={() => onSubmit(details)}
          >
            Add to team
          </button>
        </div>
      </div>
      {!member.email && (
        <p className="text-[11px] mt-2" style={{ color: "var(--ink-faint)" }}>
          GitLab did not share this account&apos;s email, so it needs entering by hand.
          It becomes the key that attributes their commits.
        </p>
      )}
    </div>
  );
}
