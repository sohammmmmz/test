"use client";

import { useEffect, useState } from "react";
import { localTimestamp, utcTimestamp } from "@/lib/format";

/**
 * A timestamp shown in the reader's own timezone, without a hydration mismatch.
 *
 * The server has no way to know the reader's timezone, so it renders UTC — and
 * so does the first client render, which is what hydration compares. The swap
 * to local time happens in an effect, after React has matched the trees, where
 * a difference is an ordinary state update rather than a mismatch.
 *
 * `suppressHydrationWarning` is deliberately not used instead: it silences the
 * warning without making the two renders agree, so React still discards the
 * client value on the first pass.
 */
export function LocalTime({
  at,
  fallback = "—",
}: {
  at: string | null | undefined;
  fallback?: string;
}) {
  const [local, setLocal] = useState<string | null>(null);

  useEffect(() => {
    if (at) setLocal(localTimestamp(at));
  }, [at]);

  if (!at) return <>{fallback}</>;
  return <time dateTime={at}>{local ?? utcTimestamp(at)}</time>;
}
