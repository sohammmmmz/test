"use client";

/**
 * The code knowledge graph.
 *
 * Layered rather than flat: components anchor the sides of a monorepo, modules
 * hang off them, files off those, and symbols off files. That layering is what
 * makes a real codebase legible — a flat force graph of a thousand files is a
 * hairball regardless of how good the data is.
 *
 * Import and call edges cut *across* the hierarchy, and those are the ones
 * worth looking at: they answer what a change reaches.
 */

import { drag as d3drag } from "d3-drag";
import {
  forceCenter,
  forceCollide,
  forceLink,
  forceManyBody,
  forceSimulation,
  forceX,
  forceY,
  type Simulation,
  type SimulationLinkDatum,
  type SimulationNodeDatum,
} from "d3-force";
import { select } from "d3-selection";
import { zoom as d3zoom } from "d3-zoom";
import { useEffect, useMemo, useRef, useState } from "react";

type RawNode = {
  id: string;
  label: string;
  kind: "component" | "module" | "file" | "symbol";
  component: string;
  module: string;
  language: string;
  summary: string;
  symbol_count: number;
  parent: string;
};

type RawEdge = { source: string; target: string; kind: string };

export type CodeGraphData = {
  archetype: string;
  stacks: string[];
  components: Array<{
    name: string;
    root: string;
    side: string;
    stacks: string[];
    file_count: number;
  }>;
  nodes: RawNode[];
  edges: RawEdge[];
  stats: {
    node_count: number;
    edge_count: number;
    unresolved_imports: number;
    truncated: boolean;
  };
};

type SimNode = SimulationNodeDatum & RawNode;
type SimLink = SimulationLinkDatum<SimNode> & { kind: string };

// Sides of the repo get distinct hues so a monorepo reads as two clusters.
const SIDE_COLOR: Record<string, string> = {
  frontend: "#7b8cf5",
  backend: "#35c9c0",
  fullstack: "#b9a6e8",
  mobile: "#e0a3c8",
  infra: "#6b7590",
};

const KIND_RADIUS: Record<string, number> = {
  component: 16,
  module: 10,
  file: 6,
  symbol: 4,
};

const EDGE_STYLE: Record<string, { opacity: number; dash: string | null; width: number }> = {
  contains: { opacity: 0.14, dash: null, width: 1 },
  defines: { opacity: 0.12, dash: null, width: 0.8 },
  imports: { opacity: 0.45, dash: null, width: 1.2 },
  calls: { opacity: 0.4, dash: "3,2", width: 1 },
};

export function CodeGraph({ data }: { data: CodeGraphData }) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [selected, setSelected] = useState<SimNode | null>(null);
  const [showSymbols, setShowSymbols] = useState(false);
  const [onlyCrossLinks, setOnlyCrossLinks] = useState(false);

  const componentColor = useMemo(() => {
    const map: Record<string, string> = {};
    for (const c of data.components) map[c.name] = SIDE_COLOR[c.side] ?? "#8fb4d9";
    return map;
  }, [data.components]);

  useEffect(() => {
    if (!svgRef.current) return;

    const visible = data.nodes.filter((n) => showSymbols || n.kind !== "symbol");
    const ids = new Set(visible.map((n) => n.id));
    const nodes: SimNode[] = visible.map((n) => ({ ...n }));
    const links: SimLink[] = data.edges
      .filter((e) => ids.has(e.source) && ids.has(e.target))
      .filter((e) => !onlyCrossLinks || e.kind === "imports" || e.kind === "calls")
      .map((e) => ({ source: e.source, target: e.target, kind: e.kind }));

    const svg = select(svgRef.current);
    svg.selectAll("*").remove();

    const width = svgRef.current.clientWidth || 900;
    const height = 620;
    const root = svg.append("g");

    svg.call(
      d3zoom<SVGSVGElement, unknown>()
        .scaleExtent([0.15, 5])
        .on("zoom", (event) => root.attr("transform", event.transform)),
    );

    // Components are pinned across the canvas so each side of a monorepo owns
    // a region and its files settle nearby, rather than everything collapsing
    // into one centre of gravity.
    const componentNodes = nodes.filter((n) => n.kind === "component");
    const anchors = new Map<string, number>();
    componentNodes.forEach((node, index) => {
      const share = (index + 1) / (componentNodes.length + 1);
      anchors.set(node.component, share * width);
      node.fx = share * width;
      node.fy = height / 2;
    });

    const simulation: Simulation<SimNode, SimLink> = forceSimulation(nodes)
      .force(
        "link",
        forceLink<SimNode, SimLink>(links)
          .id((d) => d.id)
          .distance((d) => (d.kind === "contains" ? 34 : 90))
          .strength((d) => (d.kind === "contains" ? 0.9 : 0.15)),
      )
      .force("charge", forceManyBody().strength(-90))
      .force("center", forceCenter(width / 2, height / 2))
      .force(
        "x",
        forceX<SimNode>((d) => anchors.get(d.component) ?? width / 2).strength(0.08),
      )
      .force("y", forceY(height / 2).strength(0.04))
      .force(
        "collide",
        forceCollide<SimNode>().radius((d) => (KIND_RADIUS[d.kind] ?? 5) + 3),
      );

    const link = root
      .append("g")
      .selectAll<SVGLineElement, SimLink>("line")
      .data(links)
      .join("line")
      .attr("stroke", (d) =>
        d.kind === "imports" || d.kind === "calls" ? "var(--accent)" : "currentColor",
      )
      .attr("stroke-opacity", (d) => (EDGE_STYLE[d.kind] ?? EDGE_STYLE.contains).opacity)
      .attr("stroke-width", (d) => (EDGE_STYLE[d.kind] ?? EDGE_STYLE.contains).width)
      .attr("stroke-dasharray", (d) => (EDGE_STYLE[d.kind] ?? EDGE_STYLE.contains).dash);

    const node = root
      .append("g")
      .selectAll<SVGCircleElement, SimNode>("circle")
      .data(nodes)
      .join("circle")
      .attr("r", (d) => KIND_RADIUS[d.kind] ?? 5)
      .attr("fill", (d) => componentColor[d.component] ?? "#8fb4d9")
      .attr("fill-opacity", (d) => (d.kind === "file" ? 0.75 : d.kind === "symbol" ? 0.5 : 1))
      .attr("stroke", (d) => (d.kind === "component" ? "var(--ink)" : "none"))
      .attr("stroke-width", 1.5)
      .attr("cursor", "pointer")
      .on("click", (_event, d) => setSelected(d));

    node.append("title").text((d) => `${d.label}\n${d.kind}${d.module ? ` · ${d.module}` : ""}`);

    const label = root
      .append("g")
      .selectAll<SVGTextElement, SimNode>("text")
      .data(nodes.filter((n) => n.kind === "component" || n.kind === "module"))
      .join("text")
      .text((d) => d.label)
      .attr("font-size", (d) => (d.kind === "component" ? 12 : 9))
      .attr("font-weight", (d) => (d.kind === "component" ? 600 : 400))
      .attr("fill", "currentColor")
      .attr("opacity", (d) => (d.kind === "component" ? 0.95 : 0.6))
      .attr("dx", (d) => (KIND_RADIUS[d.kind] ?? 5) + 4)
      .attr("dy", 3)
      .attr("pointer-events", "none");

    node.call(
      d3drag<SVGCircleElement, SimNode>()
        .on("start", (event, d) => {
          if (!event.active) simulation.alphaTarget(0.25).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          if (d.kind !== "component") {
            d.fx = null;
            d.fy = null;
          }
        }),
    );

    simulation.on("tick", () => {
      link
        .attr("x1", (d) => (d.source as SimNode).x ?? 0)
        .attr("y1", (d) => (d.source as SimNode).y ?? 0)
        .attr("x2", (d) => (d.target as SimNode).x ?? 0)
        .attr("y2", (d) => (d.target as SimNode).y ?? 0);
      node.attr("cx", (d) => d.x ?? 0).attr("cy", (d) => d.y ?? 0);
      label.attr("x", (d) => d.x ?? 0).attr("y", (d) => d.y ?? 0);
    });

    return () => {
      simulation.stop();
    };
  }, [data, showSymbols, onlyCrossLinks, componentColor]);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className="pill"
          style={{ background: "var(--accent-wash)", color: "var(--accent)" }}
        >
          {data.archetype}
        </span>
        {data.components.map((c) => (
          <span
            key={c.root || c.name}
            className="pill"
            style={{
              background: `${SIDE_COLOR[c.side] ?? "#8fb4d9"}22`,
              color: SIDE_COLOR[c.side] ?? "#8fb4d9",
            }}
          >
            {c.name} · {c.file_count} files
          </span>
        ))}
        {data.stacks.map((s) => (
          <span key={s} className="pill" style={{ color: "var(--ink-faint)" }}>
            {s}
          </span>
        ))}

        <div className="flex gap-2 ml-auto">
          <button
            className="pill"
            onClick={() => setShowSymbols((v) => !v)}
            style={{
              cursor: "pointer",
              border: "1px solid var(--line-strong)",
              color: showSymbols ? "var(--accent)" : "var(--ink-faint)",
            }}
          >
            symbols
          </button>
          <button
            className="pill"
            onClick={() => setOnlyCrossLinks((v) => !v)}
            style={{
              cursor: "pointer",
              border: "1px solid var(--line-strong)",
              color: onlyCrossLinks ? "var(--accent)" : "var(--ink-faint)",
            }}
          >
            only imports &amp; calls
          </button>
        </div>
      </div>

      <div className="panel overflow-hidden">
        <svg
          ref={svgRef}
          width="100%"
          height={620}
          role="img"
          aria-label="Code knowledge graph"
        />
      </div>

      <div className="flex justify-between gap-3 flex-wrap">
        <span className="mono text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
          {data.stats.node_count} nodes · {data.stats.edge_count} edges ·{" "}
          {data.stats.unresolved_imports} external imports
          {data.stats.truncated && " · truncated to keep the graph readable"}
        </span>
        <span className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
          Solid teal = imports · dashed = calls · faint = containment
        </span>
      </div>

      {selected && (
        <div className="panel p-4 text-[12.5px] rise">
          <div className="font-semibold">{selected.label}</div>
          <div className="eyebrow mt-1.5">
            {selected.kind}
            {selected.module && ` · ${selected.module}`}
            {selected.language && ` · ${selected.language}`}
          </div>
          {selected.summary && (
            <p className="mt-2 leading-relaxed" style={{ color: "var(--ink-soft)" }}>
              {selected.summary}
            </p>
          )}
          {selected.parent && (
            <p className="mono text-[11px] mt-2" style={{ color: "var(--ink-faint)" }}>
              defined in {selected.parent}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
