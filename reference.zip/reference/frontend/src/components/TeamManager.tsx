"use client";

import { Fragment, useCallback, useEffect, useState } from "react";

type Employee = {
  id: number;
  full_name: string;
  official_email: string;
  employment_type: string;
  department: string;
  designation: string;
  gitlab_username: string;
  weekly_capacity_hours: string;
  joined_on: string | null;
  left_on: string | null;
  is_active: boolean;
  planned_allocation: number;
  active_project_count: number;
  is_overallocated: boolean;
};

/** The fields the edit form writes. Everything else on Employee is derived. */
type EditableFields = {
  full_name: string;
  official_email: string;
  department: string;
  designation: string;
  employment_type: string;
  gitlab_username: string;
  weekly_capacity_hours: string;
  joined_on: string;
  left_on: string;
  is_active: boolean;
};

function editableFrom(person: Employee): EditableFields {
  return {
    full_name: person.full_name,
    official_email: person.official_email,
    department: person.department ?? "",
    designation: person.designation ?? "",
    employment_type: person.employment_type,
    gitlab_username: person.gitlab_username ?? "",
    weekly_capacity_hours: String(person.weekly_capacity_hours ?? "40"),
    // <input type="date"> will not accept null, and an empty string is what
    // DRF needs to clear a nullable date.
    joined_on: person.joined_on ?? "",
    left_on: person.left_on ?? "",
    is_active: person.is_active ?? true,
  };
}

type UnlinkedMember = {
  gitlab_user_id: number;
  username: string;
  name: string;
  email: string;
  access_level_display: string;
  projects: Array<{ id: number; name: string; access_level: string }>;
};

const EMPTY = {
  full_name: "",
  official_email: "",
  department: "",
  designation: "",
  employment_type: "employee",
};

/**
 * Roster management plus the "Others" queue.
 *
 * The two are on one screen deliberately: an unrecognised GitLab account is
 * only actionable next to the roster you would add them to or link them
 * against.
 */
export function TeamManager() {
  const [people, setPeople] = useState<Employee[]>([]);
  const [others, setOthers] = useState<UnlinkedMember[]>([]);
  const [form, setForm] = useState({ ...EMPTY });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);
  const [claiming, setClaiming] = useState<UnlinkedMember | null>(null);
  const [editing, setEditing] = useState<number | null>(null);

  const load = useCallback(async () => {
    const [roster, unlinked] = await Promise.all([
      fetch("/api/proxy/api/team/employees/").then((r) => r.json()),
      fetch("/api/proxy/api/team/unlinked-members/").then((r) => r.json()),
    ]);
    setPeople(roster.results ?? roster ?? []);
    setOthers(Array.isArray(unlinked) ? unlinked : []);
  }, []);

  useEffect(() => {
    load().catch(() => setMessage({ tone: "bad", text: "Could not load the team." }));
  }, [load]);

  async function addPerson(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch("/api/proxy/api/team/employees/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ tone: "bad", text: Object.values(data).flat().join(" ") });
        return;
      }
      setForm({ ...EMPTY });
      setMessage({ tone: "ok", text: `${data.full_name} added to the team.` });
      await load();
    } finally {
      setBusy(false);
    }
  }

  /**
   * Save edits to one person.
   *
   * PATCH rather than PUT: the roster payload carries derived fields the write
   * serializer does not accept, and a partial update means an untouched field
   * is left exactly as it was rather than being resubmitted and revalidated.
   */
  async function saveEdits(id: number, fields: EditableFields) {
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch(`/api/proxy/api/team/employees/${id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...fields,
          // Nullable dates: the input yields "", the model wants null.
          joined_on: fields.joined_on || null,
          left_on: fields.left_on || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({
          tone: "bad",
          text: Object.entries(data)
            .map(([field, errors]) => `${field}: ${[errors].flat().join(" ")}`)
            .join(" · "),
        });
        return;
      }
      setEditing(null);
      setMessage({ tone: "ok", text: `${data.full_name} updated.` });
      await load();
    } catch {
      setMessage({ tone: "bad", text: "Could not reach the backend." });
    } finally {
      setBusy(false);
    }
  }

  /**
   * Re-decide attribution for commits already in the database.
   *
   * The repair path for the common case: somebody's commits arrived under an
   * email nobody recognised and were credited to no one. A sync will not fix
   * it — commits upsert on (repo, sha) and only a recent window is re-fetched,
   * so history keeps whatever attribution it first got. This re-runs the
   * matching locally, with no GitLab calls.
   */
  async function reattribute() {
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch("/api/proxy/api/team/reattribute/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ tone: "bad", text: data.detail ?? "Could not re-attribute." });
        return;
      }
      setMessage({
        tone: "ok",
        text:
          `${data.commits_attributed} commit(s) matched to a person` +
          (data.unmapped_authors_resolved
            ? `, ${data.unmapped_authors_resolved} address(es) cleared from the queue`
            : "") +
          (data.commits_still_unattributed
            ? `. ${data.commits_still_unattributed} still match nobody — check the queue below.`
            : ". Every commit is now attributed."),
      });
      await load();
    } catch {
      setMessage({ tone: "bad", text: "Could not reach the backend." });
    } finally {
      setBusy(false);
    }
  }

  async function linkToExisting(member: UnlinkedMember, employeeId: number) {
    const res = await fetch("/api/proxy/api/team/unlinked-members/link/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gitlab_user_id: member.gitlab_user_id, employee_id: employeeId }),
    });
    const data = await res.json();
    if (!res.ok) {
      setMessage({ tone: "bad", text: data.detail ?? "Could not link that account." });
      return;
    }
    setMessage({
      tone: "ok",
      text:
        `Linked @${member.username} to ${data.employee}. ` +
        (data.commits_backfilled
          ? `${data.commits_backfilled} past commit(s) reattributed.`
          : "Past commits stay unattributed until an email alias is known — GitLab does not expose member emails."),
    });
    setClaiming(null);
    await load();
  }

  async function addAsNewPerson(member: UnlinkedMember, details: typeof EMPTY) {
    const res = await fetch("/api/proxy/api/team/unlinked-members/create-employee/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gitlab_user_id: member.gitlab_user_id, ...details }),
    });
    const data = await res.json();
    if (!res.ok) {
      setMessage({ tone: "bad", text: Object.values(data).flat().join(" ") });
      return;
    }
    setMessage({ tone: "ok", text: `${details.full_name} added and linked to @${member.username}.` });
    setClaiming(null);
    await load();
  }

  return (
    <div className="flex flex-col gap-6">
      {message && (
        <div
          className="panel p-3 text-[12.5px] rise"
          style={{
            background: message.tone === "ok" ? "var(--ok-wash)" : "var(--crit-wash)",
            borderColor: message.tone === "ok" ? "var(--ok)" : "var(--crit)",
            color: message.tone === "ok" ? "var(--ok)" : "var(--crit)",
          }}
        >
          {message.text}
        </div>
      )}

      <section className="panel p-4 flex items-start justify-between gap-4 flex-wrap">
        <div className="min-w-0">
          <h2 className="text-[13px] font-semibold">Commit attribution</h2>
          <p className="text-[12px] mt-1 max-w-2xl" style={{ color: "var(--ink-soft)" }}>
            Commits are matched to a person through their GitLab account, reached by
            the account id, the username, a known address, the address&apos;s local part
            read as a handle, or the display name from their git config. Run this after
            correcting somebody&apos;s GitLab username or linking an account below —
            history is not re-matched by a sync.
          </p>
        </div>
        <button
          className="btn btn-ghost"
          onClick={reattribute}
          disabled={busy}
          data-busy={busy}
        >
          {busy && <span className="spinner" aria-hidden />}
          Re-match commits
        </button>
      </section>

      <section className="panel p-4">
        <h2 className="text-[13px] font-semibold mb-3">Add a team member</h2>
        <form onSubmit={addPerson} className="grid gap-3 md:grid-cols-2">
          <label className="flex flex-col gap-1">
            <span className="eyebrow">Full name</span>
            <input
              className="field"
              required
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
              placeholder="Riya Sharma"
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="eyebrow">Official email</span>
            <input
              className="field"
              type="email"
              required
              value={form.official_email}
              onChange={(e) => setForm({ ...form, official_email: e.target.value })}
              placeholder="riya@company.com"
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="eyebrow">Department</span>
            <input
              className="field"
              value={form.department}
              onChange={(e) => setForm({ ...form, department: e.target.value })}
              placeholder="Engineering"
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="eyebrow">Designation</span>
            <input
              className="field"
              value={form.designation}
              onChange={(e) => setForm({ ...form, designation: e.target.value })}
              placeholder="Senior Engineer"
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="eyebrow">Type</span>
            <select
              className="field"
              value={form.employment_type}
              onChange={(e) => setForm({ ...form, employment_type: e.target.value })}
            >
              <option value="employee">Employee</option>
              <option value="intern">Intern</option>
              <option value="contractor">Contractor</option>
            </select>
          </label>
          <div className="flex items-end">
            <button
              type="submit"
              disabled={busy}
              data-busy={busy}
              className="btn btn-primary"
            >
              {busy && <span className="spinner" aria-hidden />}
              {busy ? "Adding" : "Add to team"}
            </button>
          </div>
        </form>
      </section>

      {others.length > 0 && (
        <section className="panel overflow-hidden rise">
          <div
            className="px-4 py-3 border-b"
            style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
          >
            <h2 className="text-[13px] font-semibold">
              Others — {others.length} unrecognised GitLab account
              {others.length === 1 ? "" : "s"}
            </h2>
            <p className="text-[12px] mt-1" style={{ color: "var(--ink-soft)" }}>
              These accounts have access to tracked repositories but match nobody on the
              roster. Until they are designated, their work is not counted against anyone.
            </p>
          </div>

          {others.map((member) => (
            <div
              key={member.gitlab_user_id}
              className="track px-4 py-3 border-b last:border-b-0"
              style={{ borderColor: "var(--line)", ["--track-color" as string]: "var(--warn)" }}
            >
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0">
                  <div className="text-[13px] font-medium">
                    {member.name || member.username}{" "}
                    <span className="mono text-[11px]" style={{ color: "var(--ink-faint)" }}>
                      @{member.username}
                    </span>
                  </div>
                  <div className="text-[11.5px] mt-0.5" style={{ color: "var(--ink-faint)" }}>
                    {member.access_level_display} on{" "}
                    {member.projects.map((p) => p.name).join(", ")}
                    {member.email && ` · ${member.email}`}
                  </div>
                </div>
                <button
                  className="btn btn-ghost"
                  onClick={() =>
                    setClaiming(
                      claiming?.gitlab_user_id === member.gitlab_user_id ? null : member,
                    )
                  }
                >
                  {claiming?.gitlab_user_id === member.gitlab_user_id ? "Cancel" : "Designate"}
                </button>
              </div>

              {claiming?.gitlab_user_id === member.gitlab_user_id && (
                <DesignatePanel
                  member={member}
                  people={people}
                  onLink={(id) => linkToExisting(member, id)}
                  onCreate={(details) => addAsNewPerson(member, details)}
                />
              )}
            </div>
          ))}
        </section>
      )}

      <section className="panel scroll-x">
        <table className="data-table" style={{ minWidth: 860 }}>
          <thead>
            <tr>
              <th>Name</th>
              <th>Department</th>
              <th>Designation</th>
              <th>Type</th>
              <th>GitLab</th>
              <th>Projects</th>
              <th>Allocation</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {people.map((person) => (
              <Fragment key={person.id}>
                <tr>
                  <td
                    className="track"
                    style={{
                      ["--track-color" as string]: !person.is_active
                        ? "var(--ink-faint)"
                        : person.is_overallocated
                          ? "var(--crit)"
                          : "var(--accent)",
                    }}
                  >
                    <div className="font-medium">
                      {person.full_name}
                      {!person.is_active && (
                        <span className="pill ml-2" style={{ color: "var(--ink-faint)" }}>
                          inactive
                        </span>
                      )}
                    </div>
                    <div className="mono text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                      {person.official_email}
                    </div>
                  </td>
                  <td className="text-[12px]">{person.department || "—"}</td>
                  <td className="text-[12px]">{person.designation || "—"}</td>
                  <td className="text-[12px]" style={{ color: "var(--ink-soft)" }}>
                    {person.employment_type}
                  </td>
                  <td className="mono text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                    {person.gitlab_username || "not linked"}
                  </td>
                  <td className="mono text-[12px]">{person.active_project_count}</td>
                  <td
                    className="mono text-[12px]"
                    style={{ color: person.is_overallocated ? "var(--crit)" : undefined }}
                  >
                    {person.planned_allocation}%
                  </td>
                  <td>
                    <button
                      className="btn btn-ghost"
                      onClick={() => setEditing(editing === person.id ? null : person.id)}
                      aria-expanded={editing === person.id}
                    >
                      {editing === person.id ? "Cancel" : "Edit"}
                    </button>
                  </td>
                </tr>
                {editing === person.id && (
                  <tr>
                    <td colSpan={8} style={{ background: "var(--ground-deep)" }}>
                      <EditPanel
                        person={person}
                        busy={busy}
                        onSave={(fields) => saveEdits(person.id, fields)}
                        onCancel={() => setEditing(null)}
                      />
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
            {people.length === 0 && (
              <tr>
                <td colSpan={8} className="text-center py-10" style={{ color: "var(--ink-faint)" }}>
                  No team members yet — add the first one above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}

/**
 * Edit one person's details in place.
 *
 * Form state is seeded from the row and keyed on the person's id by the caller,
 * so opening a different row starts from that row's values rather than the
 * previous one's.
 *
 * `official_email` is editable but consequential: it is the canonical identity
 * and the address commits are attributed through, so changing it is called out
 * rather than presented as just another text field.
 */
function EditPanel({
  person,
  busy,
  onSave,
  onCancel,
}: {
  person: Employee;
  busy: boolean;
  onSave: (fields: EditableFields) => void;
  onCancel: () => void;
}) {
  const [fields, setFields] = useState<EditableFields>(() => editableFrom(person));

  function set<K extends keyof EditableFields>(key: K, value: EditableFields[K]) {
    setFields((current) => ({ ...current, [key]: value }));
  }

  return (
    <form
      className="p-4 flex flex-col gap-3 rise"
      onSubmit={(event) => {
        event.preventDefault();
        onSave(fields);
      }}
    >
      <div className="grid gap-3 md:grid-cols-3">
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Full name</span>
          <input
            className="field"
            required
            value={fields.full_name}
            onChange={(e) => set("full_name", e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Official email</span>
          <input
            className="field"
            type="email"
            required
            value={fields.official_email}
            onChange={(e) => set("official_email", e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Type</span>
          <select
            className="field"
            value={fields.employment_type}
            onChange={(e) => set("employment_type", e.target.value)}
          >
            <option value="employee">Employee</option>
            <option value="intern">Intern</option>
            <option value="contractor">Contractor</option>
          </select>
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Department</span>
          <input
            className="field"
            value={fields.department}
            onChange={(e) => set("department", e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Designation</span>
          <input
            className="field"
            value={fields.designation}
            onChange={(e) => set("designation", e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">GitLab username</span>
          <input
            className="field"
            value={fields.gitlab_username}
            onChange={(e) => set("gitlab_username", e.target.value)}
            placeholder="not linked"
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Weekly hours</span>
          <input
            className="field"
            type="number"
            min="0"
            max="168"
            step="0.5"
            value={fields.weekly_capacity_hours}
            onChange={(e) => set("weekly_capacity_hours", e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Joined on</span>
          <input
            className="field"
            type="date"
            value={fields.joined_on}
            onChange={(e) => set("joined_on", e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="eyebrow">Left on</span>
          <input
            className="field"
            type="date"
            value={fields.left_on}
            onChange={(e) => set("left_on", e.target.value)}
          />
        </label>
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <label className="flex items-center gap-2 text-[12px]">
          <input
            type="checkbox"
            checked={fields.is_active}
            onChange={(e) => set("is_active", e.target.checked)}
          />
          <span>
            Active
            <span className="ml-1.5" style={{ color: "var(--ink-faint)" }}>
              — unchecking removes them from the dashboards without deleting
              their history
            </span>
          </span>
        </label>
        <div className="flex gap-2">
          <button type="button" className="btn btn-ghost" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={busy} data-busy={busy}>
            {busy && <span className="spinner" aria-hidden />}
            {busy ? "Saving" : "Save changes"}
          </button>
        </div>
      </div>

      <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
        The official email is the identity commits are attributed through.
        Changing it does not move past commits — those follow the aliases
        already recorded for this person.
      </p>
    </form>
  );
}

function DesignatePanel({
  member,
  people,
  onLink,
  onCreate,
}: {
  member: UnlinkedMember;
  people: Employee[];
  onLink: (employeeId: number) => void;
  onCreate: (details: typeof EMPTY) => void;
}) {
  const [mode, setMode] = useState<"link" | "create">(people.length ? "link" : "create");
  const [employeeId, setEmployeeId] = useState<number | "">("");
  const [details, setDetails] = useState({
    ...EMPTY,
    full_name: member.name || member.username,
    official_email: member.email || "",
  });

  return (
    <div className="mt-3 pt-3 rise" style={{ borderTop: "1px solid var(--line)" }}>
      <div className="flex gap-2 mb-3">
        <button
          className="btn btn-ghost"
          onClick={() => setMode("link")}
          style={mode === "link" ? { borderColor: "var(--accent)", color: "var(--accent)" } : {}}
        >
          Existing person
        </button>
        <button
          className="btn btn-ghost"
          onClick={() => setMode("create")}
          style={mode === "create" ? { borderColor: "var(--accent)", color: "var(--accent)" } : {}}
        >
          New person
        </button>
      </div>

      {mode === "link" ? (
        <div className="flex gap-2 flex-wrap">
          <select
            className="field"
            style={{ maxWidth: 300 }}
            value={employeeId}
            onChange={(e) => setEmployeeId(Number(e.target.value))}
          >
            <option value="">Select a team member…</option>
            {people.map((p) => (
              <option key={p.id} value={p.id}>
                {p.full_name} — {p.official_email}
              </option>
            ))}
          </select>
          <button
            className="btn btn-primary"
            disabled={!employeeId}
            onClick={() => employeeId && onLink(Number(employeeId))}
          >
            Link account
          </button>
        </div>
      ) : (
        <div className="grid gap-2 md:grid-cols-2">
          <input
            className="field"
            value={details.full_name}
            onChange={(e) => setDetails({ ...details, full_name: e.target.value })}
            placeholder="Full name"
          />
          <input
            className="field"
            type="email"
            value={details.official_email}
            onChange={(e) => setDetails({ ...details, official_email: e.target.value })}
            placeholder="Official email"
          />
          <input
            className="field"
            value={details.department}
            onChange={(e) => setDetails({ ...details, department: e.target.value })}
            placeholder="Department"
          />
          <input
            className="field"
            value={details.designation}
            onChange={(e) => setDetails({ ...details, designation: e.target.value })}
            placeholder="Designation"
          />
          <select
            className="field"
            value={details.employment_type}
            onChange={(e) => setDetails({ ...details, employment_type: e.target.value })}
          >
            <option value="employee">Employee</option>
            <option value="intern">Intern</option>
            <option value="contractor">Contractor</option>
          </select>
          <button
            className="btn btn-primary"
            disabled={!details.full_name || !details.official_email}
            onClick={() => onCreate(details)}
          >
            Add and link
          </button>
        </div>
      )}
    </div>
  );
}
