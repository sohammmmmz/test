"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

/**
 * Deleting a tracked project.
 *
 * Requires typing the project name: this removes every commit, score and vault
 * note derived from the repository, and a misclick should not be able to do
 * that. The GitLab repository itself is never touched — the app tracks
 * repositories, it does not own them.
 */
export function DeleteProject({ projectId, projectName }: { projectId: number; projectName: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [confirmation, setConfirmation] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const matches = confirmation.trim() === projectName;

  async function remove() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/proxy/api/projects/${projectId}/`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.detail ?? "Could not delete this project.");
        return;
      }
      router.push("/projects");
      router.refresh();
    } catch {
      setError("Could not reach the backend.");
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button
        className="btn btn-ghost"
        onClick={() => setOpen(true)}
        style={{ borderColor: "var(--crit)", color: "var(--crit)" }}
      >
        Delete project
      </button>
    );
  }

  return (
    <div
      className="panel p-4 rise flex flex-col gap-3"
      style={{ borderColor: "var(--crit)" }}
    >
      <div>
        <h3 className="text-[13px] font-semibold" style={{ color: "var(--crit)" }}>
          Delete {projectName}?
        </h3>
        <p className="text-[12px] mt-1.5" style={{ color: "var(--ink-soft)" }}>
          This removes every synced commit, branch, merge request, issue, milestone,
          score, vault note and code index for this project. Assignments go with it;
          the people themselves stay on your team.
        </p>
        <p className="text-[12px] mt-1.5" style={{ color: "var(--ok)" }}>
          The GitLab repository is not touched.
        </p>
      </div>

      <label className="flex flex-col gap-1">
        <span className="eyebrow">Type the project name to confirm</span>
        <input
          className="field"
          value={confirmation}
          onChange={(e) => setConfirmation(e.target.value)}
          placeholder={projectName}
          autoComplete="off"
        />
      </label>

      {error && (
        <div className="text-[12px]" style={{ color: "var(--crit)" }}>
          {error}
        </div>
      )}

      <div className="flex gap-2">
        <button
          className="btn"
          disabled={!matches || busy}
          data-busy={busy}
          onClick={remove}
          style={{
            background: matches ? "var(--crit)" : "var(--line)",
            color: matches ? "#fff" : "var(--ink-faint)",
          }}
        >
          {busy && <span className="spinner" aria-hidden />}
          {busy ? "Deleting" : "Delete permanently"}
        </button>
        <button
          className="btn btn-ghost"
          onClick={() => {
            setOpen(false);
            setConfirmation("");
            setError(null);
          }}
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
