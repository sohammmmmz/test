"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

type Milestone = {
  id: number;
  title: string;
  state: string;
  start_date: string | null;
  due_date: string | null;
  web_url: string;
  issue_count: number;
  closed_issue_count: number;
};

/**
 * The two things a freshly registered project is always missing.
 *
 * Both write upstream rather than into this database: milestones are created
 * in GitLab, documents are committed to the documentation branch. That keeps
 * GitLab the source of truth, so the team's own boards and this tracker cannot
 * drift apart.
 */
export function ProjectSetup({
  projectId,
  milestones,
  hasBrd,
  hasTechnical,
  documentationBranch,
}: {
  projectId: number;
  milestones: Milestone[];
  hasBrd: boolean;
  hasTechnical: boolean;
  documentationBranch: string;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [message, setMessage] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);

  const [milestone, setMilestone] = useState({
    title: "",
    description: "",
    start_date: "",
    due_date: "",
  });
  const [savingMilestone, setSavingMilestone] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);

  function refresh() {
    startTransition(() => router.refresh());
  }

  async function addMilestone(event: React.FormEvent) {
    event.preventDefault();
    setSavingMilestone(true);
    setMessage(null);
    try {
      const res = await fetch("/api/proxy/api/activity/milestones/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project: projectId,
          title: milestone.title,
          description: milestone.description,
          start_date: milestone.start_date || null,
          due_date: milestone.due_date || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({
          tone: "bad",
          text: data.detail ?? Object.values(data).flat().join(" "),
        });
        return;
      }
      setMilestone({ title: "", description: "", start_date: "", due_date: "" });
      setMessage({ tone: "ok", text: `"${data.title}" created in GitLab.` });
      refresh();
    } catch {
      setMessage({ tone: "bad", text: "Could not reach the backend." });
    } finally {
      setSavingMilestone(false);
    }
  }

  async function uploadDocument(kind: "brd" | "technical", file: File) {
    setUploading(kind);
    setMessage(null);
    try {
      const body = new FormData();
      body.append("kind", kind);
      body.append("file", file);

      const res = await fetch(`/api/proxy/api/projects/${projectId}/documents/`, {
        method: "POST",
        body,
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ tone: "bad", text: data.detail ?? "Upload failed." });
        return;
      }
      setMessage({
        tone: "ok",
        text: `Committed to ${documentationBranch} as ${data.repo_path}.`,
      });
      refresh();
    } catch {
      setMessage({ tone: "bad", text: "Could not reach the backend." });
    } finally {
      setUploading(null);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      {message && (
        <div
          className="panel p-3 text-[12.5px] rise"
          style={{
            background: message.tone === "ok" ? "var(--ok-wash)" : "var(--crit-wash)",
            borderColor: message.tone === "ok" ? "var(--ok)" : "var(--crit)",
            color: message.tone === "ok" ? "var(--ok)" : "var(--crit)",
          }}
        >
          {message.text}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="panel overflow-hidden">
          <div
            className="px-4 py-3 border-b"
            style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
          >
            <h3 className="text-[13px] font-semibold">Timeline</h3>
            <p className="text-[11.5px] mt-1" style={{ color: "var(--ink-soft)" }}>
              Milestones are created in GitLab, so your boards stay the source of truth.
            </p>
          </div>

          {milestones.length > 0 && (
            <ul>
              {milestones.map((m) => (
                <li
                  key={m.id}
                  className="px-4 py-2.5 border-b flex items-center justify-between gap-3"
                  style={{ borderColor: "var(--line)" }}
                >
                  <div className="min-w-0">
                    <div className="text-[12.5px] font-medium truncate">{m.title}</div>
                    <div className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
                      {m.start_date ? `${m.start_date} → ` : ""}
                      {m.due_date ?? "no due date"} · {m.closed_issue_count}/{m.issue_count} tasks
                    </div>
                  </div>
                  <span className="pill" style={{ color: "var(--ink-faint)" }}>
                    {m.state}
                  </span>
                </li>
              ))}
            </ul>
          )}

          <form onSubmit={addMilestone} className="p-4 flex flex-col gap-2.5">
            <input
              className="field"
              required
              value={milestone.title}
              onChange={(e) => setMilestone({ ...milestone, title: e.target.value })}
              placeholder="Milestone title, e.g. M1 — Authentication"
            />
            <textarea
              className="field"
              rows={2}
              value={milestone.description}
              onChange={(e) => setMilestone({ ...milestone, description: e.target.value })}
              placeholder="What this milestone delivers"
            />
            <div className="grid gap-2 grid-cols-2">
              <label className="flex flex-col gap-1">
                <span className="eyebrow">Start</span>
                <input
                  className="field"
                  type="date"
                  value={milestone.start_date}
                  onChange={(e) => setMilestone({ ...milestone, start_date: e.target.value })}
                />
              </label>
              <label className="flex flex-col gap-1">
                <span className="eyebrow">Due — required</span>
                <input
                  className="field"
                  type="date"
                  required
                  value={milestone.due_date}
                  onChange={(e) => setMilestone({ ...milestone, due_date: e.target.value })}
                />
              </label>
            </div>
            <button
              type="submit"
              disabled={savingMilestone || !milestone.title || !milestone.due_date}
              data-busy={savingMilestone}
              className="btn btn-primary self-start"
            >
              {savingMilestone && <span className="spinner" aria-hidden />}
              {savingMilestone ? "Creating in GitLab" : "Create milestone"}
            </button>
            <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
              A due date is required — a milestone without one is a label, not a timeline,
              and the compliance rule would still report the project as unplanned.
            </p>
          </form>
        </section>

        <section className="panel overflow-hidden">
          <div
            className="px-4 py-3 border-b"
            style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
          >
            <h3 className="text-[13px] font-semibold">Documents</h3>
            <p className="text-[11.5px] mt-1" style={{ color: "var(--ink-soft)" }}>
              Committed to the <code className="mono">{documentationBranch}</code> branch,
              which is created automatically if it does not exist.
            </p>
          </div>

          <div className="p-4 flex flex-col gap-3">
            <DocumentSlot
              label="Business requirements document"
              kind="brd"
              present={hasBrd}
              uploading={uploading === "brd"}
              onPick={(file) => uploadDocument("brd", file)}
            />
            <DocumentSlot
              label="Technical document"
              kind="technical"
              present={hasTechnical}
              uploading={uploading === "technical"}
              onPick={(file) => uploadDocument("technical", file)}
            />
            <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
              PDF, DOCX or Markdown, up to 20 MB. The BRD is also read by the scorer, so it
              can judge whether changes serve what the project set out to do.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}

function DocumentSlot({
  label,
  kind,
  present,
  uploading,
  onPick,
}: {
  label: string;
  kind: string;
  present: boolean;
  uploading: boolean;
  onPick: (file: File) => void;
}) {
  return (
    <div
      className="track flex items-center justify-between gap-3 p-3 rounded"
      style={{
        border: "1px solid var(--line)",
        ["--track-color" as string]: present ? "var(--ok)" : "var(--crit)",
      }}
    >
      <div>
        <div className="text-[12.5px] font-medium">{label}</div>
        <div className="text-[11px] mt-0.5" style={{ color: present ? "var(--ok)" : "var(--crit)" }}>
          {present ? "Present" : "Missing"}
        </div>
      </div>
      <label
        className="btn btn-ghost"
        data-busy={uploading}
        style={{ cursor: uploading ? "progress" : "pointer" }}
      >
        {uploading && <span className="spinner" aria-hidden />}
        {uploading ? "Committing" : present ? "Replace" : "Upload"}
        <input
          type="file"
          hidden
          disabled={uploading}
          accept=".pdf,.docx,.doc,.md,.txt"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onPick(file);
            e.target.value = "";
          }}
          data-kind={kind}
        />
      </label>
    </div>
  );
}
