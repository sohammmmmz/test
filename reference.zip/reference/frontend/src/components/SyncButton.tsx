"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

export function SyncButton({
  projectId,
  label = "Sync now",
}: {
  projectId?: number;
  label?: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState<"incremental" | "full" | null>(null);

  /**
   * `full` re-fetches the whole backfill window instead of resuming from the
   * last synced timestamp. It is the answer to "the history is incomplete":
   * an incremental run only ever looks a few days back, so commits that
   * predate the first sync — or that were missed while a token was revoked —
   * never arrive on their own.
   */
  async function trigger(full: boolean) {
    setBusy(full ? "full" : "incremental");
    setMessage(null);
    try {
      const res = await fetch("/api/proxy/api/sync/trigger", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...(projectId ? { project: projectId } : {}), full }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage(data.detail ?? "Sync could not be queued.");
      } else {
        const scope =
          data.scope === "project" ? `for ${data.project}` : "of all projects";
        setMessage(
          full
            ? `Queued a full history backfill ${scope}. This takes considerably longer than a normal sync.`
            : `Queued a sync ${scope}.`,
        );
        // The run is asynchronous; refresh so the history picks it up.
        startTransition(() => router.refresh());
      }
    } catch {
      setMessage("Could not reach the backend.");
    } finally {
      setBusy(null);
    }
  }

  const working = busy !== null || pending;

  return (
    <div className="flex flex-col items-end gap-1">
      <div className="flex items-center gap-2">
        <button
          onClick={() => trigger(true)}
          disabled={working}
          className="btn btn-ghost"
          title="Re-fetch the full backfill window rather than resuming from the last sync. Use this when past commits are missing."
        >
          {busy === "full" ? "Queueing" : "Backfill history"}
        </button>
        <button
          onClick={() => trigger(false)}
          disabled={working}
          data-busy={working}
          className="btn btn-primary"
        >
          {working && <span className="spinner" aria-hidden />}
          {busy === "incremental" ? "Queueing" : pending ? "Refreshing" : label}
        </button>
      </div>
      {message && (
        <span className="text-[11px] text-right max-w-[280px]" style={{ color: "var(--ink-faint)" }}>
          {message}
        </span>
      )}
    </div>
  );
}
