"use client";

import { useEffect, useRef } from "react";

/**
 * Ambient commit-activity trace for the header.
 *
 * Plots the project's real daily commit counts as a slowly drifting
 * oscilloscope line — the instrument this tool actually is. Canvas rather than
 * hand-authored SVG paths, since the geometry is generated.
 *
 * Falls silent entirely under `prefers-reduced-motion`: the trace still draws,
 * it just stops moving.
 */
export function SignalTrace({
  data,
  height = 72,
}: {
  data: number[];
  height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const series = data.length > 1 ? data : [0, 0, 0, 0, 0, 0, 0, 0];
    const peak = Math.max(...series, 1);

    let frame = 0;
    let raf = 0;

    function resize() {
      if (!canvas) return;
      const ratio = window.devicePixelRatio || 1;
      const width = canvas.parentElement?.clientWidth ?? 800;
      canvas.width = width * ratio;
      canvas.height = height * ratio;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx?.setTransform(ratio, 0, 0, ratio, 0, 0);
    }

    function accent(): string {
      return (
        getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() ||
        "#35c9c0"
      );
    }

    function render() {
      if (!canvas || !ctx) return;
      const width = canvas.clientWidth;
      ctx.clearRect(0, 0, width, height);

      const stroke = accent();
      const step = width / (series.length - 1);
      // A slow horizontal drift plus a shallow vertical breath: enough to read
      // as live, not enough to distract from the numbers beside it.
      const drift = reduced ? 0 : Math.sin(frame / 240) * 3;

      const pointAt = (i: number) => {
        const value = series[i] / peak;
        const breath = reduced ? 0 : Math.sin(frame / 90 + i / 2.5) * 1.6;
        return [i * step + drift, height - 8 - value * (height - 22) + breath] as const;
      };

      ctx.beginPath();
      ctx.moveTo(...pointAt(0));
      for (let i = 1; i < series.length; i++) {
        const [x, y] = pointAt(i);
        const [px, py] = pointAt(i - 1);
        // Smooth the trace so dense day-by-day data reads as a signal.
        ctx.bezierCurveTo(px + step / 2, py, x - step / 2, y, x, y);
      }

      const fill = ctx.createLinearGradient(0, 0, 0, height);
      fill.addColorStop(0, `${stroke}26`);
      fill.addColorStop(1, `${stroke}00`);

      ctx.save();
      ctx.lineTo(width + 10, height);
      ctx.lineTo(-10, height);
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.restore();

      ctx.beginPath();
      ctx.moveTo(...pointAt(0));
      for (let i = 1; i < series.length; i++) {
        const [x, y] = pointAt(i);
        const [px, py] = pointAt(i - 1);
        ctx.bezierCurveTo(px + step / 2, py, x - step / 2, y, x, y);
      }
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.4;
      ctx.globalAlpha = 0.85;
      ctx.stroke();
      ctx.globalAlpha = 1;

      const [hx, hy] = pointAt(series.length - 1);
      ctx.beginPath();
      ctx.arc(hx, hy, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = stroke;
      ctx.fill();

      if (!reduced) {
        frame += 1;
        raf = requestAnimationFrame(render);
      }
    }

    resize();
    render();
    window.addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [data, height]);

  return <canvas ref={canvasRef} aria-hidden style={{ display: "block", width: "100%" }} />;
}
