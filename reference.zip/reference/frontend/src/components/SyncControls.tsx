"use client";

import { useMemo, useState } from "react";
import { shortDate } from "@/lib/format";
import type { SyncTargets } from "@/lib/types";

/**
 * The two things anyone comes to this page to do: sync a person, or sync a
 * project.
 *
 * Both lists behave identically on purpose — filter, pick a row, press sync, or
 * press the button at the top to do all of them. There is no third mode and no
 * hidden configuration; the only choice is the depth toggle, and it is stated
 * in plain terms rather than as a "full" flag whose meaning has to be guessed.
 *
 * Syncing a *person* is worth a word, because GitLab has no endpoint for it.
 * Commits belong to repositories, so this syncs every repository that person is
 * attached to — by GitLab membership or by a written assignment — and then
 * re-runs attribution over anything still credited to nobody. That last step is
 * why it exists: the usual reason to sync one person is that their commits are
 * not showing up.
 */

type Scope = "project" | "all_projects" | "employee" | "all_employees";

type Outcome = { kind: "ok" | "error"; text: string };

export function SyncControls({ targets }: { targets: SyncTargets }) {
  const [deep, setDeep] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [outcome, setOutcome] = useState<Outcome | null>(null);

  async function run(scope: Scope, id?: number, label?: string) {
    const key = `${scope}:${id ?? "all"}`;
    setBusy(key);
    setOutcome(null);
    try {
      const res = await fetch("/api/proxy/api/sync/trigger", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scope,
          ...(scope === "project" ? { project: id } : {}),
          ...(scope === "employee" ? { employee: id } : {}),
          full: deep,
        }),
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setOutcome({ kind: "error", text: data.detail ?? "Could not queue that sync." });
        return;
      }

      const what = label ?? data.target ?? "everything";
      setOutcome({
        kind: "ok",
        text: deep
          ? `Queued a full history backfill for ${what}. This reaches back a year and takes considerably longer.`
          : `Queued a sync for ${what}, covering the last ${targets.quick_window_days} day${
              targets.quick_window_days === 1 ? "" : "s"
            }. It will appear in the queue below.`,
      });
    } catch {
      setOutcome({ kind: "error", text: "Could not reach the backend." });
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <DepthToggle deep={deep} onChange={setDeep} days={targets.quick_window_days} />
        {outcome && (
          <span
            className="text-[11.5px] max-w-lg"
            style={{ color: outcome.kind === "error" ? "var(--crit)" : "var(--ink-faint)" }}
            role="status"
          >
            {outcome.text}
          </span>
        )}
      </div>

      <div
        className="grid gap-4"
        style={{ gridTemplateColumns: "repeat(auto-fit,minmax(340px,1fr))" }}
      >
        <TargetPanel
          eyebrow="Team"
          title="Sync by member"
          blurb="Syncs every repository that person is on, then re-matches commits nobody is credited for."
          allLabel="Sync all members"
          allBusy={busy === "all_employees:all"}
          onAll={() => run("all_employees", undefined, "every team member")}
          emptyText="No active team members."
          rows={targets.employees.map((person) => ({
            id: person.id,
            name: person.full_name,
            detail: [person.designation, person.department].filter(Boolean).join(" · "),
            meta:
              person.project_count === 0
                ? "on no repository"
                : `${person.project_count} repo${person.project_count === 1 ? "" : "s"}`,
            // Nothing to sync is worth saying up front rather than as a run
            // that completes having done nothing.
            disabled: person.project_count === 0,
            busy: busy === `employee:${person.id}`,
            onSync: () => run("employee", person.id, person.full_name),
          }))}
          anyBusy={busy !== null}
        />

        <TargetPanel
          eyebrow="Projects"
          title="Sync by project"
          blurb="Commits, branches, merge requests, members, then the vault and compliance passes."
          allLabel="Sync all projects"
          allBusy={busy === "all_projects:all"}
          onAll={() => run("all_projects", undefined, "every project")}
          emptyText="No projects registered."
          rows={targets.projects.map((project) => ({
            id: project.id,
            name: project.name,
            detail: project.slug,
            meta: project.last_synced_at
              ? `synced ${shortDate(project.last_synced_at)}`
              : "never synced",
            disabled: !project.has_repo,
            busy: busy === `project:${project.id}`,
            onSync: () => run("project", project.id, project.name),
          }))}
          anyBusy={busy !== null}
        />
      </div>
    </div>
  );
}

function DepthToggle({
  deep,
  onChange,
  days,
}: {
  deep: boolean;
  onChange: (value: boolean) => void;
  days: number;
}) {
  return (
    <div className="flex items-center gap-2 text-[12px]">
      <span style={{ color: "var(--ink-soft)" }}>Depth</span>
      <div className="flex" role="radiogroup" aria-label="Sync depth">
        <DepthOption
          selected={!deep}
          onSelect={() => onChange(false)}
          label={`Last ${days} day${days === 1 ? "" : "s"}`}
          title="The normal choice. Fetches recent commits and refreshes everything else."
          first
        />
        <DepthOption
          selected={deep}
          onSelect={() => onChange(true)}
          label="Full history"
          title="Re-fetches the whole backfill window. Use this when past commits are missing — it is much slower."
        />
      </div>
    </div>
  );
}

function DepthOption({
  selected,
  onSelect,
  label,
  title,
  first = false,
}: {
  selected: boolean;
  onSelect: () => void;
  label: string;
  title: string;
  first?: boolean;
}) {
  return (
    <button
      onClick={onSelect}
      role="radio"
      aria-checked={selected}
      title={title}
      className="text-[11.5px] px-2.5 py-1"
      style={{
        background: selected ? "var(--accent-wash)" : "transparent",
        color: selected ? "var(--accent)" : "var(--ink-faint)",
        border: "1px solid var(--line)",
        borderRightWidth: first ? 0 : 1,
        borderRadius: first ? "var(--radius) 0 0 var(--radius)" : "0 var(--radius) var(--radius) 0",
        cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}

type Row = {
  id: number;
  name: string;
  detail: string;
  meta: string;
  disabled: boolean;
  busy: boolean;
  onSync: () => void;
};

function TargetPanel({
  eyebrow,
  title,
  blurb,
  allLabel,
  allBusy,
  onAll,
  rows,
  emptyText,
  anyBusy,
}: {
  eyebrow: string;
  title: string;
  blurb: string;
  allLabel: string;
  allBusy: boolean;
  onAll: () => void;
  rows: Row[];
  emptyText: string;
  anyBusy: boolean;
}) {
  const [query, setQuery] = useState("");

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter(
      (row) =>
        row.name.toLowerCase().includes(needle) ||
        row.detail.toLowerCase().includes(needle),
    );
  }, [rows, query]);

  return (
    <section className="panel flex flex-col">
      <div className="p-4 border-b flex flex-col gap-3" style={{ borderColor: "var(--line)" }}>
        <div>
          <div className="eyebrow">{eyebrow}</div>
          <h2 className="text-[15px] font-semibold mt-1.5">{title}</h2>
          <p className="text-[11.5px] mt-1" style={{ color: "var(--ink-faint)" }}>
            {blurb}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onAll}
            disabled={anyBusy || rows.length === 0}
            data-busy={allBusy}
            className="btn btn-primary text-[12px]"
          >
            {allBusy && <span className="spinner" aria-hidden />}
            {allBusy ? "Queueing" : allLabel}
          </button>
          {rows.length > 6 && (
            <input
              className="field text-[12px]"
              style={{ flex: 1, minWidth: 0 }}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter"
              aria-label={`Filter ${eyebrow.toLowerCase()}`}
            />
          )}
        </div>
      </div>

      <div className="flex flex-col overflow-y-auto" style={{ maxHeight: 340 }}>
        {visible.length === 0 && (
          <p className="text-[12px] p-4 text-center" style={{ color: "var(--ink-faint)" }}>
            {query ? "Nothing matches that filter." : emptyText}
          </p>
        )}
        {visible.map((row) => (
          <div
            key={row.id}
            className="flex items-center justify-between gap-3 px-4 py-2.5 border-b"
            style={{ borderColor: "var(--line)" }}
          >
            <div className="min-w-0">
              <div className="text-[12.5px] font-medium truncate">{row.name}</div>
              <div className="text-[10.5px] truncate" style={{ color: "var(--ink-faint)" }}>
                {[row.detail, row.meta].filter(Boolean).join(" · ")}
              </div>
            </div>
            <button
              onClick={row.onSync}
              disabled={row.disabled || anyBusy}
              data-busy={row.busy}
              className="btn btn-ghost text-[11.5px] shrink-0"
              title={
                row.disabled
                  ? "Nothing to sync — no repository is attached."
                  : `Sync ${row.name}`
              }
            >
              {row.busy && <span className="spinner" aria-hidden />}
              {row.busy ? "Queueing" : "Sync"}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}
