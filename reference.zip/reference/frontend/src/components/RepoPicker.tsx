"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type AvailableRepo = {
  gitlab_project_id: number;
  name: string;
  path_with_namespace: string;
  namespace: string;
  web_url: string;
  default_branch: string | null;
  visibility: string;
  last_activity_at: string | null;
  linked_to: string | null;
};

type SearchResponse = {
  count: number;
  repos: AvailableRepo[];
  query?: string;
  matched_directly?: boolean;
  code?: string;
  detail?: string;
};

const MIN_QUERY = 3;
const DEBOUNCE_MS = 220;

/**
 * Search-as-you-type repository picker.
 *
 * GitLab does the searching — the previous version pulled the whole account on
 * open and filtered locally, which is what made it slow. Each keystroke
 * debounces, cancels the request still in flight, and asks for one page.
 *
 * Results are keyed by path so React reuses rows between queries; only genuinely
 * new rows animate in, which stops the list flickering on every keystroke.
 */
export function RepoPicker({
  value,
  onSelect,
}: {
  value: string;
  onSelect: (repo: AvailableRepo | null) => void;
}) {
  const [query, setQuery] = useState("");
  const [repos, setRepos] = useState<AvailableRepo[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [matchedDirectly, setMatchedDirectly] = useState(false);

  const inFlight = useRef<AbortController | null>(null);
  const seq = useRef(0);

  const runSearch = useCallback(async (q: string) => {
    // Cancel the previous request so a slow early keystroke cannot land after
    // a fast later one and overwrite it.
    inFlight.current?.abort();
    const controller = new AbortController();
    inFlight.current = controller;
    const ticket = ++seq.current;

    setLoading(true);
    try {
      const url = q
        ? `/api/proxy/api/projects/available-repos/?search=${encodeURIComponent(q)}`
        : "/api/proxy/api/projects/available-repos/";
      const res = await fetch(url, { signal: controller.signal });
      const data: SearchResponse = await res.json();

      if (ticket !== seq.current) return; // A newer search already won.

      setRepos(data.repos ?? []);
      setMatchedDirectly(Boolean(data.matched_directly));
      setNotice(data.repos?.length ? null : (data.detail ?? null));
    } catch (err) {
      if ((err as Error).name === "AbortError") return;
      setNotice("Could not reach the backend.");
      setRepos([]);
    } finally {
      if (ticket === seq.current) setLoading(false);
    }
  }, []);

  // Most recently active repositories on open — one request, so the panel is
  // useful immediately without enumerating the account.
  useEffect(() => {
    runSearch("");
  }, [runSearch]);

  useEffect(() => {
    const q = query.trim();
    if (q.length > 0 && q.length < MIN_QUERY) {
      setLoading(false);
      return;
    }
    const timer = setTimeout(() => runSearch(q), DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [query, runSearch]);

  const tooShort = query.trim().length > 0 && query.trim().length < MIN_QUERY;

  return (
    <div className="flex flex-col gap-2">
      <div className="relative">
        <input
          className="field"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search your repositories, or paste a GitLab URL…"
          autoComplete="off"
          spellCheck={false}
        />
        <span
          aria-hidden
          className="absolute right-2.5 top-1/2 -translate-y-1/2 transition-opacity duration-200"
          style={{ opacity: loading ? 1 : 0 }}
        >
          <span className="spinner" style={{ fontSize: 11, color: "var(--accent)" }} />
        </span>
      </div>

      <div
        className="text-[11px] transition-colors duration-200"
        style={{ color: tooShort ? "var(--warn)" : "var(--ink-faint)" }}
      >
        {tooShort
          ? `${MIN_QUERY - query.trim().length} more character${
              MIN_QUERY - query.trim().length === 1 ? "" : "s"
            } to search`
          : matchedDirectly
            ? "Exact match found — shown first"
            : query.trim()
              ? `${repos.length} match${repos.length === 1 ? "" : "es"}`
              : "Most recently active — start typing to search"}
      </div>

      {notice && !loading && (
        <div
          className="panel p-3 text-[12.5px] rise"
          style={{
            background: "var(--warn-wash)",
            borderColor: "var(--warn)",
            color: "var(--warn)",
          }}
        >
          {notice}
        </div>
      )}

      {repos.length > 0 && (
        <div
          className="panel overflow-y-auto transition-opacity duration-200"
          style={{ maxHeight: 300, opacity: loading ? 0.55 : 1 }}
        >
          {repos.map((repo, index) => {
            const selected = value === repo.path_with_namespace;
            const disabled = Boolean(repo.linked_to);
            const isDirect = matchedDirectly && index === 0;
            return (
              <button
                key={repo.path_with_namespace}
                type="button"
                disabled={disabled}
                onClick={() => onSelect(selected ? null : repo)}
                className="track rise w-full text-left px-3 py-2 border-b last:border-b-0 flex items-center justify-between gap-3"
                style={{
                  borderColor: "var(--line)",
                  background: selected ? "var(--accent-wash)" : "transparent",
                  opacity: disabled ? 0.45 : 1,
                  cursor: disabled ? "not-allowed" : "pointer",
                  // Cap the stagger so a full page never feels sluggish.
                  animationDelay: `${Math.min(index, 8) * 22}ms`,
                  ["--track-color" as string]: selected
                    ? "var(--accent)"
                    : isDirect
                      ? "var(--ok)"
                      : "transparent",
                }}
              >
                <span className="min-w-0">
                  <span className="mono text-[12px] block truncate">
                    {repo.path_with_namespace}
                  </span>
                  <span className="text-[10.5px]" style={{ color: "var(--ink-faint)" }}>
                    {repo.linked_to
                      ? `already linked to ${repo.linked_to}`
                      : repo.namespace}
                  </span>
                </span>
                <span className="flex items-center gap-1.5 shrink-0">
                  {isDirect && !selected && (
                    <span
                      className="pill"
                      style={{ background: "var(--ok-wash)", color: "var(--ok)" }}
                    >
                      exact
                    </span>
                  )}
                  <span className="pill" style={{ color: "var(--ink-faint)" }}>
                    {repo.visibility}
                  </span>
                  {selected && (
                    <span
                      className="pill"
                      style={{ background: "var(--accent-wash)", color: "var(--accent)" }}
                    >
                      selected
                    </span>
                  )}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
