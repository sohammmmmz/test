"use client";

import { useEffect, useState } from "react";
import { gitlabLoginUrl } from "@/lib/config";

type AuthConfig = {
  gitlab_url: string;
  oauth_configured: boolean;
  service_token_configured: boolean;
  group_configured: boolean;
  password_login_enabled: boolean;
  allowed_email_domains: string[];
  registration_open: boolean;
};

/**
 * Sign-in surface: a company password, or GitLab.
 *
 * The password form is the primary path now. GitLab OAuth remains, because the
 * per-user "can you see this repository?" check during project registration
 * needs a GitLab token that belongs to the person asking — but it is no longer
 * the only way to get through the front door.
 */
export function SignInPanel({ error, next }: { error: string | null; next: string }) {
  const [config, setConfig] = useState<AuthConfig | null>(null);
  const [checked, setChecked] = useState(false);

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [mode, setMode] = useState<"signin" | "register">("signin");
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/proxy/api/auth/config")
      .then((r) => (r.ok ? r.json() : null))
      .then((body: AuthConfig | null) => {
        setConfig(body);
        // With no accounts at all, the only useful thing this screen can offer
        // is creating the first one.
        if (body?.registration_open) setMode("register");
      })
      .catch(() => setConfig(null))
      .finally(() => setChecked(true));
  }, []);

  const domains = config?.allowed_email_domains ?? [];
  const domainHint = domains.length ? domains.map((d) => `@${d}`).join(" or ") : null;

  /**
   * Caught here as well as on the server.
   *
   * Not a substitute for the server rule — a client check protects nobody — but
   * a typo in a domain is worth saying immediately rather than after a round
   * trip that comes back looking like a rejected password.
   */
  function domainProblem(value: string): string | null {
    if (!domains.length || !value.includes("@")) return null;
    const domain = value.split("@").pop()?.toLowerCase() ?? "";
    if (domains.includes(domain)) return null;
    return `Use your company address — only ${domainHint} is accepted.`;
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setFormError(null);

    const localProblem = domainProblem(identifier);
    if (localProblem) {
      setFormError(localProblem);
      return;
    }
    if (mode === "register" && !identifier.includes("@")) {
      setFormError("Register with your full company email address.");
      return;
    }

    setBusy(true);
    try {
      // Spelled out rather than interpolated: these paths are checked against
      // Django's URLconf by a test that reads this file, and an interpolated
      // one cannot be resolved.
      const url =
        mode === "register" ? "/api/proxy/api/auth/register" : "/api/proxy/api/auth/login";
      const body =
        mode === "register"
          ? { email: identifier, password, full_name: fullName }
          : { identifier, password };

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        setFormError(await readError(res));
        return;
      }

      // A full navigation rather than a client-side push: the cookies were set
      // on this response, and every server component on the destination has to
      // be rendered with them.
      window.location.href = next || "/";
    } catch {
      setFormError("Could not reach the backend. Is Django running on port 8000?");
    } finally {
      setBusy(false);
    }
  }

  const readiness = [
    { label: "OAuth application", ok: config?.oauth_configured, need: "GITLAB_OAUTH_CLIENT_ID / _SECRET" },
    { label: "Sync service token", ok: config?.service_token_configured, need: "GITLAB_SERVICE_TOKEN" },
    { label: "Target group", ok: config?.group_configured, need: "GITLAB_GROUP_ID" },
  ];

  return (
    <div className="w-full max-w-md flex flex-col gap-5 rise">
      <div>
        <div className="flex items-center gap-2.5">
          <span
            className="live-dot inline-block"
            style={{ width: 7, height: 7, borderRadius: 999, background: "var(--accent)", color: "var(--accent)" }}
          />
          <span className="font-semibold tracking-tight text-[15px]">Util Tracker</span>
        </div>
        <h1 className="text-[26px] font-semibold mt-5 leading-tight">
          {mode === "register" ? "Create the first account" : "Sign in to continue"}
        </h1>
        <p className="text-[13px] mt-2" style={{ color: "var(--ink-soft)" }}>
          {mode === "register" ? (
            <>
              No accounts exist yet, so this one becomes the administrator.
              {domainHint ? ` It must be a ${domainHint} address.` : ""}
            </>
          ) : (
            <>
              This tool is administrator-only. Sign in with your company account
              {domainHint ? ` (${domainHint})` : ""}, or through GitLab.
            </>
          )}
        </p>
      </div>

      {(error || formError) && (
        <div
          className="panel p-3 text-[12.5px]"
          style={{ background: "var(--crit-wash)", borderColor: "var(--crit)", color: "var(--crit)" }}
          role="alert"
        >
          {formError ?? error}
        </div>
      )}

      <form onSubmit={submit} className="flex flex-col gap-3">
        {mode === "register" && (
          <Field
            label="Full name"
            value={fullName}
            onChange={setFullName}
            autoComplete="name"
            placeholder="Riya Sharma"
          />
        )}
        <Field
          label={mode === "register" ? "Company email" : "User id or company email"}
          value={identifier}
          onChange={setIdentifier}
          autoComplete={mode === "register" ? "email" : "username"}
          placeholder={domains[0] ? `you@${domains[0]}` : "you@company.com"}
          required
        />
        <Field
          label="Password"
          value={password}
          onChange={setPassword}
          type="password"
          autoComplete={mode === "register" ? "new-password" : "current-password"}
          required
        />

        <button
          type="submit"
          className="btn btn-primary w-full py-2.5"
          disabled={busy}
          data-busy={busy}
        >
          {busy ? (
            <span className="flex items-center gap-2 justify-center">
              <span className="spinner" aria-hidden />
              {mode === "register" ? "Creating account" : "Signing in"}
            </span>
          ) : mode === "register" ? (
            "Create account and sign in"
          ) : (
            "Sign in"
          )}
        </button>
      </form>

      {config?.oauth_configured && (
        <>
          <div className="flex items-center gap-3">
            <span className="flex-1 h-px" style={{ background: "var(--line)" }} />
            <span className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
              or
            </span>
            <span className="flex-1 h-px" style={{ background: "var(--line)" }} />
          </div>
          {/* A full page navigation to Django, not a fetch — Django redirects
              onward to GitLab, which an XHR cannot follow. */}
          <a href={gitlabLoginUrl(next)} className="btn btn-ghost w-full py-2.5 text-center">
            Continue with GitLab
          </a>
        </>
      )}

      <div className="panel p-4 flex flex-col gap-2.5">
        <div className="eyebrow">Configuration</div>
        {!checked ? (
          <div
            className="text-[12px] flex items-center gap-2"
            style={{ color: "var(--ink-faint)" }}
            role="status"
          >
            <span className="spinner" aria-hidden />
            Checking configuration
          </div>
        ) : !config ? (
          <div className="text-[12px]" style={{ color: "var(--crit)" }}>
            The backend is not reachable. Is Django running on port 8000?
          </div>
        ) : (
          <>
            {readiness.map((row) => (
              <div key={row.label} className="flex items-start justify-between gap-3 text-[12px]">
                <span style={{ color: "var(--ink-soft)" }}>{row.label}</span>
                {row.ok ? (
                  <span className="pill" style={{ background: "var(--ok-wash)", color: "var(--ok)" }}>
                    Set
                  </span>
                ) : (
                  <span className="mono text-[10.5px] text-right" style={{ color: "var(--warn)" }}>
                    {row.need}
                  </span>
                )}
              </div>
            ))}
            {!config.registration_open && mode === "register" && (
              <button
                onClick={() => setMode("signin")}
                className="text-[11.5px] link-quiet text-left"
                style={{ background: "none", border: "none", padding: 0, cursor: "pointer" }}
              >
                Back to sign in
              </button>
            )}
            {!config.registration_open && mode === "signin" && (
              <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                New accounts are created by an existing administrator on the Team
                screen — this page cannot make one.
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  ...rest
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  autoComplete?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[11.5px]" style={{ color: "var(--ink-soft)" }}>
        {label}
      </span>
      <input
        className="field"
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        {...rest}
      />
    </label>
  );
}

/** Unpack DRF's error shape, which is a dict of field → list of messages. */
async function readError(res: Response): Promise<string> {
  try {
    const body = await res.json();
    if (typeof body?.detail === "string") return body.detail;
    const first = Object.values(body ?? {})[0];
    if (Array.isArray(first) && typeof first[0] === "string") return first[0];
    if (typeof first === "string") return first;
  } catch {
    /* fall through to the status-based message */
  }
  if (res.status === 429) return "Too many attempts. Wait a minute and try again.";
  return `Sign-in failed (${res.status}).`;
}
