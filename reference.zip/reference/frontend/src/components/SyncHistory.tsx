"use client";

import { Fragment, useCallback, useEffect, useRef, useState } from "react";
import { LocalTime } from "@/components/LocalTime";
import type { SyncRunSummary, SyncStatus } from "@/lib/types";

/**
 * The queue: what is running now, and what ran recently.
 *
 * A client component for one reason: a sync is asynchronous, and a
 * server-rendered page can only ever show the state at the instant it was
 * requested. Pressing the button queued work and refreshed the page in the same
 * breath, so the run either had not been recorded yet or was still `running` —
 * and nothing ever updated it. That is what "the sync did not show up" was.
 *
 * Polling is adaptive: fast while something is running, slow when idle, and
 * stopped entirely while the tab is hidden. A background tab must not sit and
 * hammer the API for hours.
 *
 * Child runs are fetched only when a row is opened. They used to arrive with
 * every poll — twenty rows of unbounded stage JSON per fleet run, to render six
 * columns of summary — which was the single largest thing on this page.
 */

const POLL_ACTIVE_MS = 3_000;
const POLL_IDLE_MS = 30_000;

const STATUS: Record<string, { color: string; wash: string }> = {
  success: { color: "var(--ok)", wash: "var(--ok-wash)" },
  partial: { color: "var(--warn)", wash: "var(--warn-wash)" },
  failed: { color: "var(--crit)", wash: "var(--crit-wash)" },
  running: { color: "var(--accent)", wash: "var(--accent-wash)" },
  pending: { color: "var(--ink-faint)", wash: "transparent" },
};

function tone(status: string) {
  return STATUS[status] ?? STATUS.pending;
}

function changeSummary(run: SyncRunSummary): string {
  const entries = Object.entries(run.changes ?? {});
  if (entries.length === 0) return "no changes";
  return entries
    .sort(([, a], [, b]) => b - a)
    .slice(0, 4)
    .map(([stage, n]) => `${stage} +${n}`)
    .join("  ");
}

function RunRow({
  run,
  depth = 0,
  expanded,
  onToggle,
}: {
  run: SyncRunSummary;
  depth?: number;
  expanded?: boolean;
  onToggle?: () => void;
}) {
  const t = tone(run.status);
  const hasChildren = (run.child_count ?? 0) > 0;

  return (
    <tr>
      <td
        className="track mono text-[11.5px]"
        style={{
          ["--track-color" as string]: t.color,
          color: "var(--ink-soft)",
          paddingLeft: depth ? 12 + depth * 18 : undefined,
        }}
      >
        {hasChildren && (
          <button
            onClick={onToggle}
            aria-expanded={expanded}
            className="mr-1.5"
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "var(--ink-faint)",
              padding: 0,
            }}
            title={expanded ? "Hide per-project runs" : "Show per-project runs"}
          >
            {expanded ? "▾" : "▸"}
          </button>
        )}
        <LocalTime at={run.started_at} fallback="queued" />
      </td>
      <td className="text-[12.5px]">
        {run.scope_label ?? run.project_name ?? "All projects"}
        {hasChildren && (
          <span className="ml-1.5" style={{ color: "var(--ink-faint)" }}>
            ({run.child_count})
          </span>
        )}
        {run.scope === "employee" && (
          <span className="ml-1.5 pill" style={{ background: "var(--accent-wash)", color: "var(--accent)" }}>
            member
          </span>
        )}
      </td>
      <td className="text-[12px]" style={{ color: "var(--ink-soft)" }}>
        {run.trigger}
        {run.triggered_by_name && (
          <span style={{ color: "var(--ink-faint)" }}> · {run.triggered_by_name}</span>
        )}
      </td>
      <td>
        <span className="pill" style={{ background: t.wash, color: t.color }}>
          {run.status}
        </span>
      </td>
      <td className="mono text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
        {run.duration_seconds != null ? `${run.duration_seconds.toFixed(1)}s` : "—"}
      </td>
      <td className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
        {run.error_count > 0 ? (
          <span style={{ color: "var(--warn)" }}>
            {run.error_count} stage error(s): {run.error_stages.join(", ")}
          </span>
        ) : (
          <span className="mono">{changeSummary(run)}</span>
        )}
      </td>
    </tr>
  );
}

export function SyncHistory({ initial }: { initial: SyncStatus }) {
  const [status, setStatus] = useState(initial);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const [children, setChildren] = useState<Record<number, SyncRunSummary[] | "loading">>(
    {},
  );
  const [stale, setStale] = useState(false);
  // Every fetch is ticketed so a slow earlier response cannot overwrite a
  // faster later one.
  const ticket = useRef(0);

  const load = useCallback(async () => {
    const mine = ++ticket.current;
    try {
      const res = await fetch("/api/proxy/api/sync/status", { cache: "no-store" });
      if (!res.ok) throw new Error(String(res.status));
      const body = (await res.json()) as SyncStatus;
      if (mine === ticket.current) {
        setStatus(body);
        setStale(false);
      }
    } catch {
      if (mine === ticket.current) setStale(true);
    }
  }, []);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;

    const tick = () => {
      // A hidden tab polls nothing; it catches up on the visibility change.
      if (document.visibilityState === "visible") void load();
      timer = setTimeout(tick, status.is_running ? POLL_ACTIVE_MS : POLL_IDLE_MS);
    };

    timer = setTimeout(tick, status.is_running ? POLL_ACTIVE_MS : POLL_IDLE_MS);

    const onVisible = () => {
      if (document.visibilityState === "visible") void load();
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [load, status.is_running]);

  // An open row showing a run that is still going has to keep up: its children
  // appear one at a time as each repository finishes. Only while something is
  // actually running — a finished run will not grow more children.
  const openIds = [...expanded].join(",");
  useEffect(() => {
    if (!status.is_running || !openIds) return;
    for (const id of openIds.split(",")) void loadChildren(Number(id));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status.running_count, status.recent.length, openIds]);

  function toggle(id: number) {
    setExpanded((current) => {
      const next = new Set(current);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        void loadChildren(id);
      }
      return next;
    });
  }

  async function loadChildren(id: number) {
    // Fetched once and kept. A run that has finished will not grow more
    // children, and a running one is covered by the poll below.
    setChildren((current) =>
      current[id] && current[id] !== "loading" ? current : { ...current, [id]: "loading" },
    );
    try {
      const res = await fetch(`/api/proxy/api/sync/runs/${id}/children`, {
        cache: "no-store",
      });
      const body = res.ok ? ((await res.json()) as SyncRunSummary[]) : [];
      setChildren((current) => ({ ...current, [id]: body }));
    } catch {
      setChildren((current) => ({ ...current, [id]: [] }));
    }
  }

  const queuedWithNoWorker =
    status.broker_available && status.workers_online === 0;

  return (
    <div className="flex flex-col gap-4">
      {/* A reachable queue with nothing consuming it is the one failure that
          looks exactly like success from the button's point of view. */}
      {queuedWithNoWorker && (
        <div
          className="panel p-3 text-[12.5px]"
          style={{
            background: "var(--warn-wash)",
            borderColor: "var(--warn)",
            color: "var(--warn)",
          }}
        >
          Redis is reachable but no Celery worker is answering, so queued syncs
          will never start and will not appear below. Start one with{" "}
          <span className="mono">celery -A config worker --pool=solo</span> (the
          solo pool is required on Windows).
        </div>
      )}

      {!status.broker_available && (
        <div
          className="panel p-3 text-[12.5px]"
          style={{
            background: "var(--crit-wash)",
            borderColor: "var(--crit)",
            color: "var(--crit)",
          }}
        >
          The broker is unreachable, so nothing can be queued. Start Redis, then
          the Celery worker.
        </div>
      )}

      <div className="flex items-center gap-2 text-[11px]" style={{ color: "var(--ink-faint)" }}>
        {status.is_running ? (
          <>
            <span className="spinner" aria-hidden />
            Updating every {POLL_ACTIVE_MS / 1000}s while a sync is running
          </>
        ) : stale ? (
          <span style={{ color: "var(--warn)" }}>
            Could not reach the backend — showing the last state received
          </span>
        ) : (
          <>Live · rechecks every {POLL_IDLE_MS / 1000}s</>
        )}
      </div>

      <div className="panel scroll-x">
        <table className="data-table" style={{ minWidth: 940 }}>
          <thead>
            <tr>
              <th>Started</th>
              <th>Scope</th>
              <th>Trigger</th>
              <th>Result</th>
              <th>Duration</th>
              <th>Detail</th>
            </tr>
          </thead>
          <tbody>
            {status.recent.map((run) => (
              <Fragment key={run.id}>
                <RunRow
                  run={run}
                  expanded={expanded.has(run.id)}
                  onToggle={() => toggle(run.id)}
                />
                {expanded.has(run.id) &&
                  (() => {
                    const kids = children[run.id];
                    return kids === "loading" ? (
                    <tr>
                      <td colSpan={6} className="text-[11.5px] py-2" style={{ paddingLeft: 30 }}>
                        <span className="spinner" aria-hidden /> Loading the runs inside
                        this one
                      </td>
                    </tr>
                    ) : (
                      (kids ?? []).map((child) => (
                        <RunRow key={child.id} run={child} depth={1} />
                      ))
                    );
                  })()}
              </Fragment>
            ))}
            {status.recent.length === 0 && (
              <tr>
                <td
                  colSpan={6}
                  className="text-center py-10"
                  style={{ color: "var(--ink-faint)" }}
                >
                  No syncs have run yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
