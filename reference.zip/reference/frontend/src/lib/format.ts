/**
 * Deterministic formatting.
 *
 * Every function here produces byte-identical output on the Next.js server and
 * in the browser. That is not a stylistic preference — `toLocaleDateString()`
 * and `toLocaleString()` read the *host's* locale and ICU data, and Node and
 * the browser disagree. The observed break was a calendar tooltip rendered as
 * "Tue 28 Jul" on the server and "Tue, 28 Jul" on the client, which React
 * reports as a hydration mismatch and then refuses to patch up.
 *
 * So: no `Intl`, no `toLocale*`, no implicit locale anywhere in rendered output.
 *
 * Dates arrive from Django as plain ISO calendar dates ("2026-07-28"). They are
 * read as UTC on purpose. `new Date("2026-07-28")` is UTC midnight, so a viewer
 * west of Greenwich would otherwise see the previous day — the date GitLab
 * recorded a commit on must not shift because of where someone is sitting.
 */

const MONTHS_SHORT = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

const MONTHS_LONG = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

type Parts = { year: number; month: number; day: number; weekday: number };

/** Split "YYYY-MM-DD" (or the date half of a timestamp) into calendar parts. */
function parts(iso: string): Parts | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  // Date.UTC is pure arithmetic: no locale, no host timezone, no ICU.
  const weekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  return { year, month, day, weekday };
}

/** "Tue 28 Jul" — the calendar cell tooltip. */
export function dayLabel(iso: string): string {
  const p = parts(iso);
  if (!p) return iso;
  return `${WEEKDAYS_SHORT[p.weekday]} ${p.day} ${MONTHS_SHORT[p.month - 1]}`;
}

/** "Jul" — the month ruler above the strips. */
export function monthShort(iso: string): string {
  const p = parts(iso);
  return p ? MONTHS_SHORT[p.month - 1] : iso;
}

/** "July 2026" — the month-grid heading. */
export function monthYear(iso: string): string {
  const p = parts(iso);
  return p ? `${MONTHS_LONG[p.month - 1]} ${p.year}` : iso;
}

/**
 * "28 Jul 2026".
 *
 * Replaces a bare `toLocaleDateString()`, which rendered "7/28/2026" or
 * "28/07/2026" depending on the host — two readings of the same string that
 * differ by five months. A named month cannot be misread.
 */
export function shortDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const p = parts(iso);
  if (!p) return "—";
  return `${p.day} ${MONTHS_SHORT[p.month - 1]} ${p.year}`;
}

/** Days between an ISO date and today, or 0 for weekday offsets. */
export function weekdayIndex(iso: string): number {
  return parts(iso)?.weekday ?? 0;
}

/** Thousands separators, fixed to a comma rather than the host's convention. */
export function count(value: number): string {
  return value.toLocaleString("en-US");
}

/**
 * A timestamp in UTC: "28 Jul 2026 14:03 UTC".
 *
 * Timestamps are the one case where the honest answer differs per viewer, so
 * the server-rendered value is stated in UTC and labelled as such. `LocalTime`
 * upgrades it to the reader's own clock after hydration, where a mismatch is no
 * longer possible.
 */
export function utcTimestamp(iso: string | null | undefined): string {
  if (!iso) return "—";
  const at = new Date(iso);
  if (Number.isNaN(at.getTime())) return "—";
  const day = at.getUTCDate();
  const month = MONTHS_SHORT[at.getUTCMonth()];
  const hours = String(at.getUTCHours()).padStart(2, "0");
  const minutes = String(at.getUTCMinutes()).padStart(2, "0");
  return `${day} ${month} ${at.getUTCFullYear()} ${hours}:${minutes} UTC`;
}

/** The same instant in the reader's timezone. Client-side only — see LocalTime. */
export function localTimestamp(iso: string): string {
  const at = new Date(iso);
  if (Number.isNaN(at.getTime())) return "—";
  const day = at.getDate();
  const month = MONTHS_SHORT[at.getMonth()];
  const hours = String(at.getHours()).padStart(2, "0");
  const minutes = String(at.getMinutes()).padStart(2, "0");
  return `${day} ${month} ${at.getFullYear()} ${hours}:${minutes}`;
}
