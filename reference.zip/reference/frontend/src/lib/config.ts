/**
 * Two different backend URLs, and the distinction matters.
 *
 * `BACKEND_INTERNAL_URL` is server-to-server — inside docker-compose that is
 * `http://backend:8000`, a hostname the browser cannot resolve.
 *
 * `NEXT_PUBLIC_BACKEND_URL` is what the *browser* navigates to. The OAuth
 * handshake has to be a full page navigation to Django (it redirects onward to
 * GitLab), so it cannot go through a fetch or a Next.js route.
 */

export const BACKEND_INTERNAL_URL =
  process.env.BACKEND_INTERNAL_URL ?? "http://localhost:8000";

export const BACKEND_PUBLIC_URL =
  process.env.NEXT_PUBLIC_BACKEND_URL ?? "http://localhost:8000";

/** Full-page destination that starts the GitLab OAuth flow. */
export function gitlabLoginUrl(next = "/"): string {
  return `${BACKEND_PUBLIC_URL}/api/auth/gitlab/login?next=${encodeURIComponent(next)}`;
}
