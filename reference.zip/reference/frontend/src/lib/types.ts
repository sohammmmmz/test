export type HealthState = "healthy" | "warning" | "critical" | "unknown";

export type ProjectListItem = {
  id: number;
  name: string;
  slug: string;
  status: string;
  health_state: HealthState;
  health_score: number;
  last_activity_at: string | null;
  last_synced_at: string | null;
  is_stale: boolean;
  repo_path: string | null;
  repo_url: string | null;
};

export type Paginated<T> = {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
};

export type RuleEvaluation = {
  id: number;
  rule_code: string;
  rule_name: string;
  severity: "critical" | "warning" | "info";
  passed: boolean;
  message: string;
  evidence: Record<string, unknown>;
  remediation_hint: string;
  evaluated_at: string;
};

export type ProjectDetail = ProjectListItem & {
  description: string;
  owner_name: string | null;
  started_on: string | null;
  target_end_on: string | null;
  member_count: number;
  assignment_count: number;
  repo: {
    gitlab_project_id: number;
    path_with_namespace: string;
    web_url: string;
    default_branch: string;
    visibility: string;
    created_by_app: boolean;
    documentation_branch_ready: boolean;
  } | null;
  documents: Array<{
    id: number;
    kind: string;
    kind_display: string;
    filename: string;
    repo_path: string;
    committed_at: string | null;
    summary: string;
  }>;
};

/**
 * A project someone works on.
 *
 * `sources` says how it got here — `assigned` is a plan someone typed,
 * `member` is repository access GitLab reports, and both can be true.
 * `historic` is set only when neither is: they committed here, but the plan and
 * the access have since gone. A project with only `member` is real work that
 * nobody has allocated time for, which is what `is_unplanned` marks.
 */
export type WorkloadProject = {
  project_id: number;
  project: string;
  sources: Array<"assigned" | "member" | "historic">;
  is_unplanned: boolean;
  /** Listed only because of past commits — no live plan, no repo access now. */
  is_historic: boolean;
  has_access: boolean;
  access_level: string | null;
  is_inherited: boolean;
  assignment_id: number | null;
  role: string | null;
  allocation_percent: number | null;
  commits: number;
  active_days: number;
  /** Every commit ever synced here, not just the ones inside the window. */
  commits_all_time: number;
  active_days_all_time: number;
  first_commit_at: string | null;
  last_commit_at: string | null;
  /** Observed: this project's share of the person's commits in the window. */
  share_percent: number | null;
  /** share_percent − allocation_percent. The gap the plan did not predict. */
  drift: number | null;
};

export type RosterRow = {
  id: number;
  full_name: string;
  official_email: string;
  employment_type: string;
  department: string;
  designation: string;
  gitlab_username: string;
  active_project_count: number;
  project_count: number;
  unplanned_count: number;
  commits: number;
  commits_all_time: number;
  first_commit_at: string | null;
  last_commit_at: string | null;
  planned_allocation: number;
  is_overallocated: boolean;
  projects: WorkloadProject[];
};

export type WorkloadRow = {
  employee_id: number;
  full_name: string;
  official_email: string;
  department: string;
  designation: string;
  employment_type: string;
  gitlab_username: string;
  planned_allocation: number;
  is_overallocated: boolean;
  project_count: number;
  assigned_count: number;
  member_count: number;
  unplanned_count: number;
  commits: number;
  active_days: number;
  commits_all_time: number;
  active_days_all_time: number;
  first_commit_at: string | null;
  last_commit_at: string | null;
  projects: WorkloadProject[];
};

export type Workload = {
  days: number;
  start: string;
  end: string;
  rows: WorkloadRow[];
  totals: {
    people: number;
    unplanned: number;
    overallocated: number;
    commits: number;
    commits_all_time: number;
  };
};

export type UtilizationRow = {
  employee_id: number;
  full_name: string;
  employment_type: string;
  gitlab_username: string;
  planned_allocation: number;
  is_overallocated: boolean;
  assigned_projects: Array<{
    id: number;
    name: string;
    allocation: number | null;
    role: string | null;
    sources: Array<"assigned" | "member" | "historic">;
    commits: number;
    commits_all_time: number;
    first_commit_at: string | null;
    last_commit_at: string | null;
    share_percent: number | null;
    drift: number | null;
    is_unplanned: boolean;
    is_historic: boolean;
  }>;
  unplanned_count: number;
  commits: number;
  review_notes: number;
  merge_requests_merged: number;
  active_days: number;
  /** Lifetime, so a quiet fortnight does not read as "never committed". */
  commits_all_time: number;
  active_days_all_time: number;
  first_commit_at: string | null;
  last_commit_at: string | null;
  mean_score: number | null;
  dormant_assignments: Array<{
    project: string;
    project_id: number;
    allocation_percent: number;
    last_activity: string | null;
  }>;
};

/**
 * Commit cadence.
 *
 * `state` carries the whole judgment: `missed` is only ever set for a day a
 * commit was actually expected — a working weekday, inside employment, with an
 * active assignment. Weekends and pre-hire days are `off`/`outside` so the real
 * gaps are not buried.
 */
export type CalendarState = "active" | "indirect" | "missed" | "off" | "outside";

export type CalendarCell = {
  date: string;
  commits: number;
  state: CalendarState;
  reviews?: number;
  merges?: number;
  projects?: Array<{ name: string; commits: number }>;
};

export type CalendarRow = {
  employee_id: number;
  full_name: string;
  department: string;
  designation: string;
  employment_type: string;
  gitlab_username: string;
  planned_allocation: number;
  is_overallocated: boolean;
  /** Assignments and repository memberships together. */
  projects: string[];
  /** Of those, the ones with repo access but no allocation recorded. */
  unplanned_projects: string[];
  commits: number;
  active_days: number;
  indirect_days: number;
  missed_days: number;
  expected_days: number;
  /** Null when nothing was expected — no coverage figure, not a bad one. */
  coverage_percent: number | null;
  current_streak: number;
  longest_streak: number;
  longest_gap: number;
  last_commit_on: string | null;
  days_since_last_commit: number | null;
  cells: CalendarCell[];
};

export type CommitCalendar = {
  start: string;
  end: string;
  days: number;
  working_weekdays: number[];
  holidays: string[];
  totals: {
    people: number;
    commits: number;
    active_days: number;
    missed_days: number;
    expected_days: number;
    coverage_percent: number | null;
  };
  rows: CalendarRow[];
};

/**
 * The leaderboard.
 *
 * `components` is served by the backend rather than hard-coded here on purpose:
 * the scoring logic lives in one file (`scoring/leaderboard.py`) and the page
 * explains whatever that file currently computes, so a reweighting never leaves
 * the UI describing a formula that is no longer in use.
 */
export type LeaderboardComponent = {
  key: string;
  label: string;
  /** Share of the composite, before renormalisation over applicable parts. */
  weight: number;
  description: string;
};

export type LeaderboardRow = {
  rank: number;
  employee_id: number;
  full_name: string;
  official_email: string;
  department: string;
  designation: string;
  employment_type: string;
  gitlab_username: string;
  gitlab_avatar_url: string;
  /** 0–100. Saturating, so nobody ever reaches 100. */
  score: number;
  /** Per-component subscores. `null` means the component does not apply to
   *  this person — a new joiner has no coverage figure, not a zero. */
  components: Record<string, number | null>;
  commits: number;
  active_days: number;
  expected_days: number;
  longest_gap: number;
  current_streak: number;
  last_commit_on: string | null;
  commits_per_active_day: number;
};

export type Leaderboard = {
  window: { days: number; start: string; end: string };
  components: LeaderboardComponent[];
  totals: {
    people: number;
    commits: number;
    mean_score: number | null;
    median_score: number | null;
  };
  rows: LeaderboardRow[];
};

export type SyncRun = {
  id: number;
  project_name: string | null;
  trigger: string;
  status: "pending" | "running" | "success" | "partial" | "failed";
  started_at: string | null;
  finished_at: string | null;
  duration_seconds: number | null;
  stage_counts: Record<string, Record<string, number>>;
  errors: Array<{ stage: string; message: string; at: string }>;
  error_count: number;
};

/**
 * A run as the history list shows it.
 *
 * Deliberately not `SyncRun`: the unbounded `stage_counts` and `errors` JSON
 * stays on the server and arrives pre-reduced, because this endpoint is polled
 * while a sync is in flight.
 */
export type SyncScope = "project" | "all_projects" | "employee" | "all_employees";

export type SyncRunSummary = {
  id: number;
  project: number | null;
  project_name: string | null;
  project_slug: string | null;
  employee: number | null;
  employee_name: string | null;
  scope: SyncScope;
  /** What the run covered, in the words this page uses. Built server-side
   *  because it depends on which of project/employee is set. */
  scope_label: string;
  parent: number | null;
  trigger: string;
  triggered_by_name: string | null;
  status: "pending" | "running" | "success" | "partial" | "failed";
  started_at: string | null;
  finished_at: string | null;
  duration_seconds: number | null;
  error_count: number;
  error_stages: string[];
  /** {stage: rows written}, only for stages that wrote something. */
  changes: Record<string, number>;
  created_at: string;
  /** How many per-project runs sit under this one. The runs themselves are
   *  fetched from /api/sync/runs/{id}/children when a row is expanded — sending
   *  them with every poll was the largest cost on this page. */
  child_count?: number;
};

/** What can be synced. Cached server-side: it changes when someone joins or a
 *  project is registered, not three times a minute. */
export type SyncTargets = {
  projects: Array<{
    id: number;
    name: string;
    slug: string;
    status: string;
    last_synced_at: string | null;
    last_activity_at: string | null;
    has_repo: boolean;
  }>;
  employees: Array<{
    id: number;
    full_name: string;
    department: string;
    designation: string;
    gitlab_username: string;
    /** Repositories their work could be in. Zero means nothing to sync. */
    project_count: number;
  }>;
  quick_window_days: number;
};

export type SyncStatus = {
  running_count: number;
  is_running: boolean;
  unprocessed_webhooks: number;
  broker_available: boolean;
  /** Zero with a reachable broker means queued work will never start. */
  workers_online: number;
  latest: SyncRunSummary | null;
  recent: SyncRunSummary[];
};

export type GraphNode = {
  id: string;
  title: string;
  type: string;
  path: string;
  exists: boolean;
  source_model?: string;
  source_id?: number | null;
};

export type GraphEdge = {
  source: string;
  target: string;
  type: string;
  label: string;
  dangling: boolean;
};

export type VaultGraph = {
  project: { id: number; name: string; slug: string };
  nodes: GraphNode[];
  edges: GraphEdge[];
  stats: { node_count: number; edge_count: number; dangling_count: number };
};

export type Milestone = {
  id: number;
  title: string;
  state: string;
  start_date: string | null;
  due_date: string | null;
  web_url: string;
  issue_count: number;
  closed_issue_count: number;
};
