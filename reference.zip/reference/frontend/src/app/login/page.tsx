import { SignInPanel } from "@/components/SignInPanel";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  oauth_failed:
    "GitLab rejected the sign-in. Check that the application's redirect URI exactly matches GITLAB_OAUTH_REDIRECT_URI, including the port.",
  missing_code_or_state:
    "GitLab returned without an authorization code. Start the sign-in again.",
  access_denied: "You declined the authorization request.",
  wrong_domain:
    "That GitLab account's email address is outside the company domain, so it cannot be used to sign in here.",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; next?: string }>;
}) {
  const { error, next } = await searchParams;
  const message = error ? (ERRORS[error] ?? error) : null;

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <SignInPanel error={message} next={next ?? "/"} />
    </div>
  );
}
