import {
  LoadingRegion,
  Skeleton,
  SkeletonPanel,
  SkeletonTiles,
} from "@/components/Skeleton";

/**
 * Overview placeholder.
 *
 * Mirrors the real screen's proportions — the tall instrument header with its
 * trace, the tile row, then the two-column body — so the layout does not shift
 * when the data lands. A placeholder that resolves into a different shape is
 * worse than none, because it teaches the reader to distrust the preview.
 */
export default function Loading() {
  return (
    <LoadingRegion label="Loading overview">
      <div className="flex flex-col">
        <header
          className="relative border-b overflow-hidden px-8 pt-8 pb-16 flex flex-col gap-3"
          style={{ borderColor: "var(--line)", background: "var(--surface)" }}
        >
          <Skeleton width={90} height={9} />
          <Skeleton width={330} height={28} delay={80} />
          <Skeleton width={430} height={11} delay={160} />
          {/* Stands in for the commit trace that anchors the real header. */}
          <div className="absolute inset-x-0 bottom-0 h-[84px] opacity-40">
            <Skeleton height="100%" radius={0} delay={220} />
          </div>
        </header>

        <div className="px-8 py-7 flex flex-col gap-7">
          <SkeletonTiles count={4} />
          <div className="grid gap-7 lg:grid-cols-[1.4fr_1fr]">
            <SkeletonPanel lines={6} />
            <SkeletonPanel lines={4} />
          </div>
        </div>
      </div>
    </LoadingRegion>
  );
}
