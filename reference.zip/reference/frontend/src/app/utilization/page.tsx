import Link from "next/link";
import { redirect } from "next/navigation";
import { CommitCalendar } from "@/components/CommitCalendar";
import { EmptyState, Eyebrow, Reveal, StatTile } from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import { shortDate } from "@/lib/format";
import type { CommitCalendar as CommitCalendarData, UtilizationRow } from "@/lib/types";

export const dynamic = "force-dynamic";

/**
 * Windows the table and calendar can be read over.
 *
 * Fourteen days answers "is this person working now"; a year answers "what have
 * they done here". Both questions are asked of this screen and neither window
 * answers the other, so the choice is the reader's.
 */
const WINDOWS = [
  { days: 14, label: "14 days" },
  { days: 30, label: "30 days" },
  { days: 90, label: "90 days" },
  { days: 365, label: "1 year" },
] as const;

type DashboardResponse = {
  period_days: number;
  rows: UtilizationRow[];
  totals?: { commits: number; commits_all_time: number; people: number };
};

const dateOnly = shortDate;

export default async function UtilizationPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const params = await searchParams;
  const requested = Number(params.days);
  const periodDays = WINDOWS.some((w) => w.days === requested) ? requested : 14;
  // The calendar is one cell per person per day, so it is capped independently
  // of the table — a year of cells is unreadable long before it is slow.
  const calendarDays = Math.min(periodDays, 365);

  let rows: UtilizationRow[];
  let totals: DashboardResponse["totals"];
  let calendar: CommitCalendarData | null = null;

  try {
    const [data, cadence] = await Promise.all([
      api.get<DashboardResponse>(`/api/scoring/dashboard?days=${periodDays}`),
      // Cadence is the headline of this page, so a failure here should not
      // take the rest of it down with it.
      api
        .get<CommitCalendarData>(`/api/scoring/commit-calendar?days=${calendarDays}`)
        .catch(() => null),
    ]);
    rows = data.rows;
    totals = data.totals;
    calendar = cadence;
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect("/login?next=/utilization");
    }
    return (
      <div className="p-8">
        <EmptyState title="Could not load utilization" body="The backend did not respond." />
      </div>
    );
  }

  const dormant = rows.filter((r) => r.dormant_assignments.length > 0);

  return (
    <div className="flex flex-col">
      <header
        className="px-8 py-7 border-b"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <Eyebrow>Utilization · last {periodDays} days</Eyebrow>
        <h1 className="text-[26px] font-semibold mt-2 leading-none">Planned against actual</h1>
        <p className="text-[13px] mt-2 max-w-2xl" style={{ color: "var(--ink-soft)" }}>
          The distance between the two is the finding. A high allocation with no activity
          behind it means someone is blocked, quietly reassigned, or working somewhere this
          tool cannot see.
        </p>

        <nav className="flex items-center gap-2 mt-4 flex-wrap">
          <span className="eyebrow">Window</span>
          {WINDOWS.map((w) => (
            <Link
              key={w.days}
              href={`/utilization?days=${w.days}`}
              className="btn btn-ghost"
              style={
                w.days === periodDays
                  ? { borderColor: "var(--accent)", color: "var(--accent)" }
                  : undefined
              }
            >
              {w.label}
            </Link>
          ))}
          {totals && (
            <span className="text-[11.5px] ml-1" style={{ color: "var(--ink-faint)" }}>
              <span className="mono">{totals.commits}</span> commits in window ·{" "}
              <span className="mono">{totals.commits_all_time}</span> ever synced
            </span>
          )}
        </nav>
      </header>

      <div className="px-8 py-7 flex flex-col gap-7">
        {calendar && (
          <>
            <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))" }}>
              <StatTile
                label="Team coverage"
                value={
                  calendar.totals.coverage_percent === null
                    ? "—"
                    : `${calendar.totals.coverage_percent}%`
                }
                hint="of expected days with activity"
                tone={
                  (calendar.totals.coverage_percent ?? 100) >= 80
                    ? "var(--ok)"
                    : (calendar.totals.coverage_percent ?? 100) >= 50
                      ? "var(--warn)"
                      : "var(--crit)"
                }
              />
              <StatTile
                label="Missed days"
                value={calendar.totals.missed_days}
                hint={`across ${calendar.totals.people} people`}
                tone={calendar.totals.missed_days > 0 ? "var(--crit)" : "var(--ok)"}
                index={1}
              />
              <StatTile
                label="Days committed"
                value={calendar.totals.active_days}
                hint={`of ${calendar.totals.expected_days} expected`}
                index={2}
              />
              <StatTile
                label="Commits"
                value={calendar.totals.commits}
                hint={`since ${calendar.start}`}
                index={3}
              />
            </div>

            <Reveal index={4} className="flex flex-col gap-4">
              <div>
                <Eyebrow>Commit cadence</Eyebrow>
                <h2 className="text-[17px] font-semibold mt-1.5">
                  Who committed, and on which days they did not
                </h2>
                <p className="text-[12.5px] mt-1.5 max-w-3xl" style={{ color: "var(--ink-soft)" }}>
                  A day counts as missed only when a commit was genuinely expected — a
                  working weekday, inside employment, with a live assignment. Weekends,
                  holidays and unassigned stretches are marked but never held against
                  anyone. Days spent reviewing rather than committing are shown as their
                  own state, not as absence.
                </p>
              </div>
              <CommitCalendar initial={calendar} />
            </Reveal>
          </>
        )}

        {dormant.length > 0 && (
          <Reveal className="panel overflow-hidden">
            <div
              className="px-4 py-3 border-b"
              style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
            >
              <h2 className="text-[13px] font-semibold">Assigned but silent</h2>
            </div>
            <ul>
              {dormant.flatMap((r) =>
                r.dormant_assignments.map((d) => (
                  <li
                    key={`${r.employee_id}-${d.project_id}`}
                    className="track px-4 py-3 border-b last:border-b-0 flex items-baseline gap-2 flex-wrap text-[12.5px]"
                    style={{
                      borderColor: "var(--line)",
                      ["--track-color" as string]: "var(--warn)",
                    }}
                  >
                    <span className="font-medium">{r.full_name}</span>
                    <span style={{ color: "var(--ink-soft)" }}>
                      allocated <span className="mono">{d.allocation_percent}%</span> to{" "}
                      {d.project}, last active{" "}
                      {d.last_activity
                        ? new Date(d.last_activity).toLocaleDateString()
                        : "never"}
                    </span>
                  </li>
                )),
              )}
            </ul>
          </Reveal>
        )}

        <Reveal index={6} className="panel scroll-x">
          <table className="data-table" style={{ minWidth: 1180 }}>
            <thead>
              <tr>
                <th>Person</th>
                <th>Planned</th>
                <th>Projects</th>
                <th>Commits</th>
                <th>Reviews</th>
                <th>MRs merged</th>
                <th>Active days</th>
                <th title="Every commit ever synced for this person">All time</th>
                <th title="First and last commit on record">History</th>
                <th>Mean score</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const silent = r.commits === 0 && r.review_notes === 0 && r.planned_allocation > 0;
                // Quiet this window but active before it is a different state
                // from never having committed, and the two must not look alike.
                const dormant = silent && r.commits_all_time > 0;
                return (
                  <tr key={r.employee_id}>
                    <td
                      className="track"
                      style={{
                        ["--track-color" as string]: r.is_overallocated
                          ? "var(--crit)"
                          : silent
                            ? "var(--warn)"
                            : "var(--ok)",
                      }}
                    >
                      <div className="font-medium">{r.full_name}</div>
                      {/* Projects now come from repository membership as well as
                          assignments. One with no allocation behind it is marked
                          rather than hidden — that is the gap worth closing. */}
                      <div className="text-[11px] mt-0.5 flex flex-wrap gap-x-1.5 gap-y-0.5">
                        {r.assigned_projects.length === 0 && (
                          <span style={{ color: "var(--ink-faint)" }}>
                            no projects
                          </span>
                        )}
                        {r.assigned_projects.map((p) => (
                          <span
                            key={p.id}
                            style={{
                              color: p.is_unplanned
                                ? "var(--warn)"
                                : "var(--ink-faint)",
                              opacity: p.is_historic ? 0.6 : 1,
                            }}
                            title={
                              p.is_historic
                                ? `${p.name}: ${p.commits_all_time} past commit(s), no live plan or repository access`
                                : p.is_unplanned
                                  ? `${p.name}: repository member with no allocation recorded — ${p.commits_all_time} commit(s) all time`
                                  : `${p.name}: ${p.allocation}% planned, ${p.share_percent ?? 0}% of commits, ${p.commits_all_time} all time`
                            }
                          >
                            {p.name}
                            {p.is_unplanned && "*"}
                            {p.is_historic && "†"}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td>
                      <span
                        className="mono text-[12px]"
                        style={{ color: r.is_overallocated ? "var(--crit)" : "var(--ink)" }}
                      >
                        {r.planned_allocation}%
                      </span>
                    </td>
                    <td className="mono text-[12px]">{r.assigned_projects.length}</td>
                    <td className="mono text-[12px]">{r.commits}</td>
                    <td className="mono text-[12px]">{r.review_notes}</td>
                    <td className="mono text-[12px]">{r.merge_requests_merged}</td>
                    <td className="mono text-[12px]">{r.active_days}</td>
                    <td
                      className="mono text-[12px]"
                      style={{ color: dormant ? "var(--warn)" : "var(--ink-soft)" }}
                      title={`${r.active_days_all_time} day(s) with a commit, all time`}
                    >
                      {r.commits_all_time}
                    </td>
                    <td className="text-[11px]" style={{ color: "var(--ink-faint)" }}>
                      {r.commits_all_time === 0 ? (
                        "no commits on record"
                      ) : (
                        <>
                          {dateOnly(r.first_commit_at)} → {dateOnly(r.last_commit_at)}
                        </>
                      )}
                    </td>
                    <td className="mono text-[12px]" style={{ color: "var(--ink-soft)" }}>
                      {r.mean_score ?? "—"}
                    </td>
                  </tr>
                );
              })}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={10} className="text-center py-10" style={{ color: "var(--ink-faint)" }}>
                    No active team members.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </Reveal>

        <Reveal index={7} className="flex flex-col gap-3">
          <p className="text-[12px] max-w-3xl leading-relaxed" style={{ color: "var(--ink-faint)" }}>
            <span style={{ color: "var(--ink-soft)" }}>Reading the project list.</span>{" "}
            A project is listed if it was planned, if GitLab reports repository membership,
            or if the person has committed to it at any point.{" "}
            <span className="mono" style={{ color: "var(--warn)" }}>*</span> marks one they
            have access to with no allocation recorded — real work nobody has planned.{" "}
            <span className="mono">†</span> marks one they have left: past commits, no live
            plan and no current access. <span style={{ color: "var(--ink-soft)" }}>Commits</span>{" "}
            counts the chosen window, <span style={{ color: "var(--ink-soft)" }}>All time</span>{" "}
            counts everything ever synced, so somebody quiet this fortnight is visibly
            different from somebody who has never committed at all.
          </p>
          <p className="text-[12px] max-w-3xl leading-relaxed" style={{ color: "var(--ink-faint)" }}>
            <span style={{ color: "var(--ink-soft)" }}>On reading these numbers.</span>{" "}
            Commit-derived scores are blind to work that leaves no commits — code review,
            mentoring, debugging that ends in a one-line fix, research that correctly concludes
            not to build something. They also under-rate hard problems, since the hardest bug is
            often the smallest diff. Review counts sit in this table for that reason, days
            without commits are recorded as such rather than as zero, and any score can be
            overridden with a stated reason.
          </p>
        </Reveal>
      </div>
    </div>
  );
}
