import {
  LoadingRegion,
  Skeleton,
  SkeletonHeader,
  SkeletonTable,
  SkeletonTiles,
} from "@/components/Skeleton";

/**
 * The cadence grid gets a real placeholder rather than a grey block: the strips
 * are the point of this screen, and a rectangle where a hundred cells are about
 * to appear would understate what is loading.
 */
export default function Loading() {
  return (
    <LoadingRegion label="Loading utilization">
      <div className="flex flex-col">
        <SkeletonHeader />
        <div className="px-8 py-7 flex flex-col gap-7">
          <SkeletonTiles count={4} />

          <div className="flex flex-col gap-4">
            <Skeleton width={120} height={9} />
            <Skeleton width={340} height={17} delay={60} />
            <div className="panel p-4 flex flex-col gap-2.5">
              {Array.from({ length: 5 }, (_, row) => (
                <div key={row} className="flex items-center gap-3">
                  <div className="shrink-0 flex flex-col gap-1.5" style={{ width: 210 }}>
                    <Skeleton width={130} height={11} delay={row * 80} />
                    <Skeleton width={80} height={8} delay={row * 80 + 40} />
                  </div>
                  <div className="flex gap-[3px] overflow-hidden">
                    {Array.from({ length: 60 }, (_, cell) => (
                      <Skeleton
                        key={cell}
                        width={11}
                        height={11}
                        radius={2}
                        delay={row * 80 + cell * 12}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <SkeletonTable rows={5} columns={[200, 70, 70, 70, 70, 70, 70, 70]} />
        </div>
      </div>
    </LoadingRegion>
  );
}
