/**
 * Server-side pass-through to Django for client components.
 *
 * Client components cannot call Django directly — the session cookie is
 * httpOnly and the backend is not necessarily reachable from the browser. They
 * post here instead, and this handler forwards with the cookie attached.
 *
 * The upstream path is taken from `nextUrl.pathname`, NOT by rejoining the
 * catch-all segments. Next.js splits the path on "/" and drops the trailing
 * slash, but DRF's router registers every route *with* one. Django then tries
 * to APPEND_SLASH-redirect, which it cannot do for a POST without discarding
 * the body — so a rejoined path turns every write through this proxy into a
 * 500.
 */

import { cookies } from "next/headers";
import { type NextRequest, NextResponse } from "next/server";

const BACKEND = process.env.BACKEND_INTERNAL_URL ?? "http://localhost:8000";
const PREFIX = "/api/proxy";

// Hop-by-hop and body-framing headers must not be relayed; Node sets its own.
const STRIPPED = new Set([
  "host",
  "connection",
  "content-length",
  "transfer-encoding",
  "keep-alive",
  "upgrade",
  "accept-encoding",
]);

async function forward(request: NextRequest) {
  const cookieStore = await cookies();
  const cookieHeader = cookieStore
    .getAll()
    .map((c) => `${c.name}=${c.value}`)
    .join("; ");

  const upstreamPath = request.nextUrl.pathname.slice(PREFIX.length) || "/";
  const target = `${BACKEND}${upstreamPath}${request.nextUrl.search}`;

  const headers = new Headers();
  request.headers.forEach((value, key) => {
    if (!STRIPPED.has(key.toLowerCase())) headers.set(key, value);
  });
  if (cookieHeader) headers.set("Cookie", cookieHeader);
  // Django's CSRF check compares Origin against CSRF_TRUSTED_ORIGINS; the
  // browser's own Origin is the right one to present.
  headers.set("Referer", request.nextUrl.origin);

  const hasBody = request.method !== "GET" && request.method !== "HEAD";

  // DRF's SessionAuthentication enforces CSRF on every unsafe method. The
  // token lives in a readable cookie that Django mints on /api/auth/config
  // and /api/auth/me; pairing it into the header here keeps that protection
  // switched on without every caller having to plumb it through by hand.
  if (hasBody) {
    const csrf = cookieStore.get("csrftoken")?.value;
    if (csrf) headers.set("X-CSRFToken", csrf);
  }

  const response = await fetch(target, {
    method: request.method,
    headers,
    body: hasBody ? await request.arrayBuffer() : undefined,
    // Django's own redirects (e.g. APPEND_SLASH on a GET) should reach the
    // caller rather than being silently followed to a different resource.
    redirect: "manual",
    cache: "no-store",
  });

  const outHeaders = new Headers();
  const contentType = response.headers.get("content-type");
  if (contentType) outHeaders.set("content-type", contentType);

  // Django's redirect targets are paths rooted at *its* origin. Relayed
  // verbatim, the browser resolves them against the Next.js origin instead and
  // lands on a 404, so they are rewritten back inside the proxy prefix.
  const location = response.headers.get("location");
  if (location) {
    outHeaders.set(
      "location",
      location.startsWith("/") && !location.startsWith(PREFIX)
        ? `${PREFIX}${location}`
        : location,
    );
  }
  // Relay Set-Cookie so login/logout round-trips work through the proxy.
  for (const [key, value] of response.headers.entries()) {
    if (key.toLowerCase() === "set-cookie") outHeaders.append("set-cookie", value);
  }

  return new NextResponse(response.body, {
    status: response.status,
    headers: outHeaders,
  });
}

export async function GET(request: NextRequest) {
  return forward(request);
}

export async function POST(request: NextRequest) {
  return forward(request);
}

export async function PUT(request: NextRequest) {
  return forward(request);
}

export async function PATCH(request: NextRequest) {
  return forward(request);
}

export async function DELETE(request: NextRequest) {
  return forward(request);
}
