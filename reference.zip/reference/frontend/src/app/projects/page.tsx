import Link from "next/link";
import { redirect } from "next/navigation";
import {
  EmptyState,
  Eyebrow,
  HealthPill,
  Reveal,
  Sparkline,
  healthColor,
  relativeDays,
} from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import type { Paginated, ProjectListItem } from "@/lib/types";

export const dynamic = "force-dynamic";

type ActivityPoint = { date: string; count: number };

export default async function ProjectsPage() {
  let data: Paginated<ProjectListItem>;
  try {
    data = await api.get<Paginated<ProjectListItem>>("/api/projects/");
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect("/login?next=/projects");
    }
    return (
      <div className="p-8">
        <EmptyState title="Could not load projects" body="The backend did not respond." />
      </div>
    );
  }

  // One activity series per project, so each row carries real commit density
  // rather than a decorative squiggle.
  const series = await Promise.all(
    data.results.map((p) =>
      api
        .get<ActivityPoint[]>(`/api/activity/commits/activity/?project=${p.id}&days=30`)
        .catch(() => [] as ActivityPoint[]),
    ),
  );

  return (
    <div className="flex flex-col">
      <header
        className="px-8 py-7 border-b flex items-end justify-between gap-4 flex-wrap"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <div>
          <Eyebrow>Projects</Eyebrow>
          <h1 className="text-[26px] font-semibold mt-2 leading-none">
            {data.count} tracked
          </h1>
          <p className="text-[13px] mt-2" style={{ color: "var(--ink-soft)" }}>
            Every project is backed by exactly one GitLab repository.
          </p>
        </div>
        <Link href="/projects/new" className="btn btn-primary">
          Register project
        </Link>
      </header>

      <div className="px-8 py-7">
        {data.results.length === 0 ? (
          <EmptyState
            title="No projects yet"
            body="Register one and either link an existing GitLab repository or let the app create it for you."
          />
        ) : (
          <Reveal className="panel scroll-x">
            <table className="data-table" style={{ minWidth: 940 }}>
              <thead>
                <tr>
                  <th>Project</th>
                  <th>Repository</th>
                  <th>Status</th>
                  <th>Compliance</th>
                  <th>Activity · 30d</th>
                  <th>Last commit</th>
                  <th>Synced</th>
                </tr>
              </thead>
              <tbody>
                {data.results.map((p, index) => {
                  const points = series[index]?.map((a) => a.count) ?? [];
                  const tone = healthColor(p.health_state);
                  return (
                    <tr key={p.id}>
                      <td
                        className="track"
                        style={{ ["--track-color" as string]: tone }}
                      >
                        <Link href={`/projects/${p.id}`} className="font-medium hover:underline">
                          {p.name}
                        </Link>
                      </td>
                      <td>
                        {p.repo_url ? (
                          <a
                            href={p.repo_url}
                            target="_blank"
                            rel="noreferrer"
                            className="mono text-[11.5px] link-quiet"
                          >
                            {p.repo_path}
                          </a>
                        ) : (
                          <span className="pill" style={{ background: "var(--crit-wash)", color: "var(--crit)" }}>
                            missing
                          </span>
                        )}
                      </td>
                      <td className="text-[12px]" style={{ color: "var(--ink-soft)" }}>
                        {p.status}
                      </td>
                      <td>
                        <HealthPill state={p.health_state} score={p.health_score} />
                      </td>
                      <td>
                        <Sparkline
                          points={points}
                          color={points.some((n) => n > 0) ? "var(--accent)" : "var(--ink-faint)"}
                          delay={index * 50}
                        />
                      </td>
                      <td
                        className="mono text-[11.5px]"
                        style={{ color: p.is_stale ? "var(--warn)" : "var(--ink-soft)" }}
                      >
                        {relativeDays(p.last_activity_at)}
                      </td>
                      <td className="mono text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
                        {relativeDays(p.last_synced_at)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Reveal>
        )}
      </div>
    </div>
  );
}
