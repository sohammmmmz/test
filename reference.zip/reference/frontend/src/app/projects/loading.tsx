import {
  LoadingRegion,
  SkeletonHeader,
  SkeletonTable,
} from "@/components/Skeleton";

export default function Loading() {
  return (
    <LoadingRegion label="Loading projects">
      <div className="flex flex-col">
        <SkeletonHeader />
        <div className="px-8 py-7">
          {/* Columns match the real table: project, health, activity, commits,
              members, synced. */}
          <SkeletonTable rows={7} columns={[210, 80, 96, 60, 60, 80]} />
        </div>
      </div>
    </LoadingRegion>
  );
}
