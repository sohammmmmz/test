import Link from "next/link";
import { RegisterProjectForm } from "@/components/RegisterProjectForm";
import { Eyebrow } from "@/components/ui";

export const dynamic = "force-dynamic";

export default function NewProjectPage() {
  return (
    <div className="flex flex-col">
      <header
        className="px-8 py-7 border-b"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <Eyebrow>New project</Eyebrow>
        <h1 className="text-[26px] font-semibold mt-2 leading-none">Register a project</h1>
        <p className="text-[13px] mt-2.5 max-w-2xl" style={{ color: "var(--ink-soft)" }}>
          Every project needs a GitLab repository. Paste one to link it, or leave the field
          blank and it will be created under the configured group. A linked repository is
          checked twice — that you can see it, and that the sync service account can too.
          Without the second check a project would register and then quietly never sync.
        </p>
      </header>

      <div className="px-8 py-7 max-w-2xl flex flex-col gap-4 rise">
        <RegisterProjectForm />
        <Link href="/projects" className="text-[12px] link-quiet">
          ← All projects
        </Link>
      </div>
    </div>
  );
}
