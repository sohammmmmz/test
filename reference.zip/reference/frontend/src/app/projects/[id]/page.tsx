import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { SignalTrace } from "@/components/SignalTrace";
import { CodeGraph, type CodeGraphData } from "@/components/CodeGraph";
import { DeleteProject } from "@/components/DeleteProject";
import { ProjectMembers } from "@/components/ProjectMembers";
import { ProjectSetup } from "@/components/ProjectSetup";
import { SyncButton } from "@/components/SyncButton";
import { VaultGraph } from "@/components/VaultGraph";
import { EmptyState, Eyebrow, HealthPill, Reveal, relativeDays } from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import type {
  Milestone,
  ProjectDetail,
  RuleEvaluation,
  VaultGraph as VaultGraphData,
} from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  let project: ProjectDetail;
  try {
    project = await api.get<ProjectDetail>(`/api/projects/${id}/`);
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) notFound();
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect(`/login?next=/projects/${id}`);
    }
    return (
      <div className="p-8">
        <EmptyState title="Could not load this project" body="The backend did not respond." />
      </div>
    );
  }

  const [compliance, graph, activity, milestones, codeGraph] = await Promise.all([
    api
      .get<{ rules: RuleEvaluation[] }>(`/api/compliance/project/${id}`)
      .catch(() => ({ rules: [] as RuleEvaluation[] })),
    api.get<VaultGraphData>(`/api/vault/${id}/graph`).catch(() => null),
    api
      .get<Array<{ date: string; count: number }>>(
        `/api/activity/commits/activity/?project=${id}&days=45`,
      )
      .catch(() => []),
    api
      .get<{ results: Milestone[] } | Milestone[]>(`/api/activity/milestones/?project=${id}`)
      .catch(() => ({ results: [] as Milestone[] })),
    api.get<CodeGraphData>(`/api/vault/${id}/code-graph`).catch(() => null),
  ]);

  const milestoneList = Array.isArray(milestones)
    ? milestones
    : (milestones.results ?? []);
  const hasBrd = project.documents.some((d) => d.kind === "brd");
  const hasTechnical = project.documents.some((d) => d.kind === "technical");

  const failing = compliance.rules.filter((r) => !r.passed);

  return (
    <div className="flex flex-col">
      <header
        className="relative border-b overflow-hidden"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <div className="absolute inset-x-0 bottom-0 opacity-80 pointer-events-none">
          <SignalTrace data={activity.map((a) => a.count)} height={72} />
        </div>
        <div className="relative px-8 pt-7 pb-14 flex items-start justify-between gap-4 flex-wrap">
          <div className="min-w-0">
            <Eyebrow>Project</Eyebrow>
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              <h1 className="text-[26px] font-semibold leading-none">{project.name}</h1>
              <HealthPill state={project.health_state} score={project.health_score} />
            </div>
            {project.description && (
              <p className="text-[13px] mt-2.5 max-w-2xl" style={{ color: "var(--ink-soft)" }}>
                {project.description}
              </p>
            )}
            {project.repo && (
              <div className="flex gap-4 mt-3 flex-wrap text-[11.5px]">
                <a
                  href={project.repo.web_url}
                  target="_blank"
                  rel="noreferrer"
                  className="mono link-quiet"
                >
                  {project.repo.path_with_namespace}
                </a>
                <span className="mono" style={{ color: "var(--ink-faint)" }}>
                  default: {project.repo.default_branch}
                </span>
                <span className="mono" style={{ color: "var(--ink-faint)" }}>
                  last commit {relativeDays(project.last_activity_at)}
                </span>
                {project.repo.created_by_app && (
                  <span className="pill" style={{ background: "var(--accent-wash)", color: "var(--accent)" }}>
                    created by this app
                  </span>
                )}
              </div>
            )}
          </div>
          <SyncButton projectId={project.id} label="Sync project" />
        </div>
      </header>

      <div className="px-8 py-7 flex flex-col gap-7">
        <div className="grid gap-5 lg:grid-cols-2">
          <Reveal className="panel overflow-hidden">
            <div
              className="px-4 py-3 border-b flex items-center justify-between"
              style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
            >
              <h2 className="text-[13px] font-semibold">Requirements</h2>
              <span className="eyebrow">
                {compliance.rules.length - failing.length}/{compliance.rules.length} met
              </span>
            </div>
            {compliance.rules.length === 0 ? (
              <p className="p-5 text-[12.5px]" style={{ color: "var(--ink-faint)" }}>
                Not evaluated yet — run a sync.
              </p>
            ) : (
              <ul>
                {compliance.rules.map((rule) => (
                  <li
                    key={rule.id}
                    className="track px-4 py-3 border-b last:border-b-0 flex gap-3 items-start"
                    style={{
                      borderColor: "var(--line)",
                      ["--track-color" as string]: rule.passed ? "var(--ok)" : "var(--crit)",
                    }}
                  >
                    <span
                      className="pill mt-0.5 shrink-0"
                      style={{
                        background: rule.passed ? "var(--ok-wash)" : "var(--crit-wash)",
                        color: rule.passed ? "var(--ok)" : "var(--crit)",
                      }}
                    >
                      {rule.passed ? "met" : "unmet"}
                    </span>
                    <div className="min-w-0">
                      <div className="text-[12.5px] font-medium">{rule.rule_name}</div>
                      <div className="text-[12px] mt-0.5" style={{ color: "var(--ink-soft)" }}>
                        {rule.message}
                      </div>
                      {!rule.passed && rule.remediation_hint && (
                        <div className="text-[11.5px] mt-1.5" style={{ color: "var(--ink-faint)" }}>
                          {rule.remediation_hint}
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Reveal>

          <Reveal index={0} className="panel overflow-hidden">
            <div
              className="px-4 py-3 border-b"
              style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
            >
              <h2 className="text-[13px] font-semibold">Repository</h2>
            </div>
            <dl className="p-4 grid grid-cols-2 gap-y-2.5 text-[12.5px]">
              <dt style={{ color: "var(--ink-faint)" }}>Members</dt>
              <dd className="mono">{project.member_count}</dd>
              <dt style={{ color: "var(--ink-faint)" }}>Assigned here</dt>
              <dd className="mono">{project.assignment_count}</dd>
              <dt style={{ color: "var(--ink-faint)" }}>Milestones</dt>
              <dd className="mono">{milestoneList.length}</dd>
              <dt style={{ color: "var(--ink-faint)" }}>Documentation branch</dt>
              <dd className="mono">
                {project.repo?.documentation_branch_ready ? "ready" : "not created yet"}
              </dd>
            </dl>
          </Reveal>
        </div>

        <Reveal index={1}>
          <ProjectMembers projectId={project.id} />
        </Reveal>

        <Reveal index={2}>
          <h2 className="text-[15px] font-semibold mb-3">Set up this project</h2>
          <ProjectSetup
            projectId={project.id}
            milestones={milestoneList}
            hasBrd={hasBrd}
            hasTechnical={hasTechnical}
            documentationBranch="documentation"
          />
        </Reveal>

        <Reveal index={3}>
          <div className="flex items-baseline justify-between mb-3 flex-wrap gap-2">
            <h2 className="text-[15px] font-semibold">Code knowledge graph</h2>
            <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
              Built from the indexed codebase — components, modules, files and the
              imports and calls between them.
            </p>
          </div>
          {codeGraph && codeGraph.nodes.length > 0 ? (
            <CodeGraph data={codeGraph} />
          ) : (
            <EmptyState
              title="The codebase has not been indexed yet"
              body="Indexing runs when a project is registered. If it has not completed, check that GEMINI_API_KEY is set and re-run it from the sync page."
            />
          )}
        </Reveal>

        <Reveal index={4}>
          <div className="flex items-baseline justify-between mb-3 flex-wrap gap-2">
            <h2 className="text-[15px] font-semibold">Project vault</h2>
            <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
              Generated at <code className="mono">vault/</code> on the{" "}
              <code className="mono">documentation</code> branch — clone it and open in Obsidian.
            </p>
          </div>
          {graph && graph.nodes.length > 0 ? (
            <VaultGraph data={graph} />
          ) : (
            <EmptyState
              title="No vault yet"
              body="The vault is built during sync from milestones, tasks, people, modules and documents. Run a sync to generate it."
            />
          )}
        </Reveal>

        <div
          className="flex items-center justify-between gap-4 flex-wrap pt-4"
          style={{ borderTop: "1px solid var(--line)" }}
        >
          <Link href="/projects" className="text-[12px] link-quiet">
            ← All projects
          </Link>
          <DeleteProject projectId={project.id} projectName={project.name} />
        </div>
      </div>
    </div>
  );
}
