import { LoadingRegion, Skeleton, SkeletonPanel } from "@/components/Skeleton";

/**
 * Project detail placeholder.
 *
 * This screen fetches six endpoints in parallel — project, compliance, vault,
 * commits, milestones, code graph — so it is the one most likely to be looked
 * at while it loads, and the one where a shape-accurate placeholder earns the
 * most.
 */
export default function Loading() {
  return (
    <LoadingRegion label="Loading project">
      <div className="flex flex-col">
        <header
          className="relative border-b overflow-hidden px-8 pt-7 pb-14 flex flex-col gap-3"
          style={{ borderColor: "var(--line)", background: "var(--surface)" }}
        >
          <Skeleton width={70} height={9} />
          <Skeleton width={260} height={24} delay={80} />
          <Skeleton width={400} height={11} delay={160} />
          <div className="flex gap-4 mt-1">
            <Skeleton width={180} height={10} delay={220} />
            <Skeleton width={90} height={10} delay={260} />
            <Skeleton width={110} height={10} delay={300} />
          </div>
          <div className="absolute inset-x-0 bottom-0 h-[72px] opacity-35">
            <Skeleton height="100%" radius={0} delay={340} />
          </div>
        </header>

        <div className="px-8 py-7 flex flex-col gap-7">
          <div className="grid gap-7 lg:grid-cols-[1fr_1fr]">
            <SkeletonPanel lines={5} />
            <SkeletonPanel lines={5} />
          </div>
          {/* The vault and code graphs: large square canvases, so a large
              square is the honest placeholder. */}
          <div className="panel p-4 flex flex-col gap-3">
            <Skeleton width={160} height={13} />
            <Skeleton height={320} radius={4} delay={120} />
          </div>
          <SkeletonPanel lines={4} />
        </div>
      </div>
    </LoadingRegion>
  );
}
