import Link from "next/link";
import { redirect } from "next/navigation";
import { SignalTrace } from "@/components/SignalTrace";
import { EmptyState, Eyebrow, Reveal, StatTile, relativeDays } from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import { count } from "@/lib/format";

export const dynamic = "force-dynamic";

type DashboardSummary = {
  project_count: number;
  active_project_count: number;
  compliant_project_count: number;
  critical_project_count: number;
  warning_count: number;
  unmapped_author_count: number;
  stale_project_count: number;
  commit_count: number;
  last_sync: {
    finished_at: string | null;
    status: string;
    trigger: string;
    duration_seconds: number | null;
  } | null;
  warnings: Array<{
    project_id: number;
    project_name: string;
    rule_code: string;
    rule_name: string;
    severity: string;
    message: string;
    remediation_hint: string;
  }>;
};

const SEVERITY: Record<string, { color: string; wash: string }> = {
  critical: { color: "var(--crit)", wash: "var(--crit-wash)" },
  warning: { color: "var(--warn)", wash: "var(--warn-wash)" },
  info: { color: "var(--ink-faint)", wash: "transparent" },
};

export default async function OverviewPage() {
  let data: DashboardSummary;
  let activity: Array<{ date: string; count: number }> = [];

  try {
    data = await api.get<DashboardSummary>("/api/compliance/dashboard");
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect("/login?next=/");
    }
    return (
      <div className="p-8">
        <EmptyState
          title="The backend is not responding"
          body="Django should be running on port 8000. Check the server logs, then reload."
        />
      </div>
    );
  }

  try {
    activity = await api.get("/api/activity/commits/activity/?days=45");
  } catch {
    activity = [];
  }

  // Group failing rules by project so the panel reads as "what is wrong with
  // this project", not a flat list of unrelated violations.
  const byProject = new Map<number, { name: string; rows: DashboardSummary["warnings"] }>();
  for (const w of data.warnings) {
    const entry = byProject.get(w.project_id) ?? { name: w.project_name, rows: [] };
    entry.rows.push(w);
    byProject.set(w.project_id, entry);
  }

  const trace = activity.map((a) => a.count);
  const syncTone =
    data.last_sync?.status === "success"
      ? "var(--ok)"
      : data.last_sync?.status === "partial"
        ? "var(--warn)"
        : data.last_sync
          ? "var(--crit)"
          : "var(--ink-faint)";

  return (
    <div className="flex flex-col">
      {/* Instrument header — the live trace is the project's real commit
          activity, so the most characteristic thing in this tool's world is
          the first thing on the page. */}
      <header
        className="relative border-b overflow-hidden"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <div className="absolute inset-x-0 bottom-0 opacity-90 pointer-events-none">
          <SignalTrace data={trace} height={84} />
        </div>
        <div className="relative px-8 pt-8 pb-16">
          <Eyebrow>Overview</Eyebrow>
          <h1 className="text-[30px] font-semibold mt-2 leading-none">
            {data.project_count === 0
              ? "Nothing tracked yet"
              : `${data.warning_count} open ${data.warning_count === 1 ? "warning" : "warnings"}`}
          </h1>
          <p className="text-[13px] mt-2.5 max-w-xl" style={{ color: "var(--ink-soft)" }}>
            {data.last_sync?.finished_at ? (
              <>
                Last sync {relativeDays(data.last_sync.finished_at)} via{" "}
                {data.last_sync.trigger} —{" "}
                <span style={{ color: syncTone }}>{data.last_sync.status}</span>
                {data.last_sync.duration_seconds != null &&
                  ` in ${data.last_sync.duration_seconds.toFixed(1)}s`}
                .
              </>
            ) : (
              "No sync has completed yet. Run one from the Sync page to pull GitLab history."
            )}
          </p>
        </div>
      </header>

      <div className="px-8 py-7 flex flex-col gap-7">
        <section className="grid gap-3 grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
          <StatTile label="Projects" value={data.project_count} hint={`${data.active_project_count} active`} index={0} />
          <StatTile
            label="Compliant"
            value={data.compliant_project_count}
            hint="all rules passing"
            tone={data.compliant_project_count > 0 ? "var(--ok)" : undefined}
            index={1}
          />
          <StatTile
            label="Critical"
            value={data.critical_project_count}
            hint="mandatory rule failing"
            tone={data.critical_project_count > 0 ? "var(--crit)" : undefined}
            index={2}
          />
          <StatTile
            label="Stale"
            value={data.stale_project_count}
            hint="no commits in 14d"
            tone={data.stale_project_count > 0 ? "var(--warn)" : undefined}
            index={3}
          />
          <StatTile label="Commits" value={count(data.commit_count)} hint="all branches" index={4} />
          <StatTile
            label="Unattributed"
            value={data.unmapped_author_count}
            hint="authors to claim"
            tone={data.unmapped_author_count > 0 ? "var(--warn)" : undefined}
            index={5}
          />
        </section>

        <Reveal index={6}>
          <div className="flex items-baseline justify-between mb-3">
            <h2 className="text-[15px] font-semibold">Requirements not met</h2>
            <Link href="/projects" className="text-[12px] link-quiet">
              All projects →
            </Link>
          </div>

          {byProject.size === 0 ? (
            <EmptyState
              title={data.project_count === 0 ? "No projects registered" : "Everything checks out"}
              body={
                data.project_count === 0
                  ? "Register a project to start tracking. Each one needs a GitLab repository — link an existing one or let the app create it."
                  : "Every tracked project has milestones with timelines, both documents, and assigned members."
              }
            />
          ) : (
            <div className="flex flex-col gap-3">
              {[...byProject.entries()].map(([projectId, entry], index) => (
                <Reveal
                  key={projectId}
                  index={7 + index}
                  className="panel overflow-hidden"
                >
                  <div
                    className="px-4 py-2.5 flex items-center justify-between border-b"
                    style={{ borderColor: "var(--line)", background: "var(--ground-deep)" }}
                  >
                    <Link href={`/projects/${projectId}`} className="text-[13px] font-semibold hover:underline">
                      {entry.name}
                    </Link>
                    <span className="eyebrow">
                      {entry.rows.length} unmet
                    </span>
                  </div>
                  <ul>
                    {entry.rows.map((row) => {
                      const tone = SEVERITY[row.severity] ?? SEVERITY.info;
                      return (
                        <li
                          key={row.rule_code}
                          className="track px-4 py-3 border-b last:border-b-0 flex gap-3 items-start"
                          style={{
                            borderColor: "var(--line)",
                            ["--track-color" as string]: tone.color,
                          }}
                        >
                          <span
                            className="pill mt-0.5 shrink-0"
                            style={{ background: tone.wash, color: tone.color }}
                          >
                            {row.severity}
                          </span>
                          <div className="min-w-0">
                            <div className="text-[13px] font-medium">{row.rule_name}</div>
                            <div className="text-[12.5px] mt-0.5" style={{ color: "var(--ink-soft)" }}>
                              {row.message}
                            </div>
                            {row.remediation_hint && (
                              <div className="text-[11.5px] mt-1.5" style={{ color: "var(--ink-faint)" }}>
                                {row.remediation_hint}
                              </div>
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </Reveal>
              ))}
            </div>
          )}
        </Reveal>
      </div>
    </div>
  );
}
