import {
  LoadingRegion,
  SkeletonHeader,
  SkeletonTable,
  SkeletonTiles,
} from "@/components/Skeleton";

export default function Loading() {
  return (
    <LoadingRegion label="Loading sync history">
      <div className="flex flex-col">
        <SkeletonHeader />
        <div className="px-8 py-7 flex flex-col gap-7">
          <SkeletonTiles count={3} />
          <SkeletonTable rows={8} columns={[150, 90, 90, 70, 70, 90]} />
        </div>
      </div>
    </LoadingRegion>
  );
}
