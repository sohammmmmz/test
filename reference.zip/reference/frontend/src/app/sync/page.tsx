import { Suspense } from "react";
import { redirect } from "next/navigation";
import { LoadingRegion, SkeletonTable, SkeletonTiles } from "@/components/Skeleton";
import { SyncControls } from "@/components/SyncControls";
import { SyncHistory } from "@/components/SyncHistory";
import { EmptyState, Eyebrow, Reveal, StatTile } from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import type { SyncStatus, SyncTargets } from "@/lib/types";

export const dynamic = "force-dynamic";

/**
 * Sync.
 *
 * Three parts, in the order they are used: pick a person, pick a project, watch
 * the queue.
 *
 * The header renders without waiting for anything. Everything below it sits
 * behind one Suspense boundary that fetches the targets and the queue *in
 * parallel* — this page was the slowest in the app, and a large part of that
 * was work done serially that had no reason to be. The rest was the queue
 * response carrying every child run of every fleet sync on every poll; those
 * now load only when a row is opened.
 */
async function Panels() {
  let targets: SyncTargets;
  let status: SyncStatus;

  try {
    // Together, not one after the other. The targets list is cached server-side
    // and the queue is not, so awaiting them in sequence would have added the
    // cheap one's latency to the expensive one's for no reason.
    [targets, status] = await Promise.all([
      api.get<SyncTargets>("/api/sync/targets"),
      api.get<SyncStatus>("/api/sync/status"),
    ]);
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect("/login?next=/sync");
    }
    return (
      <EmptyState
        title="Could not load the sync page"
        body="The backend did not respond."
      />
    );
  }

  return (
    <>
      <Reveal index={0}>
        <SyncControls targets={targets} />
      </Reveal>

      <section
        className="grid gap-3"
        style={{ gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))" }}
      >
        <StatTile
          label="In progress"
          value={status.running_count}
          hint="active runs"
          tone={status.running_count > 0 ? "var(--accent)" : undefined}
          index={0}
        />
        <StatTile
          label="Workers"
          value={status.workers_online}
          hint={status.broker_available ? "answering ping" : "broker unreachable"}
          tone={status.workers_online === 0 ? "var(--crit)" : "var(--ok)"}
          index={1}
        />
        <StatTile
          label="Queued webhooks"
          value={status.unprocessed_webhooks}
          hint="awaiting processing"
          tone={status.unprocessed_webhooks > 0 ? "var(--warn)" : undefined}
          index={2}
        />
        <StatTile
          label="Recent runs"
          value={status.recent.length}
          hint="most recent first"
          index={3}
        />
      </section>

      <Reveal index={4}>
        <SyncHistory initial={status} />
      </Reveal>
    </>
  );
}

export default function SyncPage() {
  return (
    <div className="flex flex-col">
      <header
        className="px-8 py-7 border-b"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <Eyebrow>Sync</Eyebrow>
        <h1 className="text-[26px] font-semibold mt-2 leading-none">
          Fetch from GitLab
        </h1>
        <p className="text-[13px] mt-2 max-w-3xl" style={{ color: "var(--ink-soft)" }}>
          Sync one team member or all of them, one project or all of them. Every
          button here enters the same pipeline the nightly schedule and incoming
          webhooks use, so a manual run cannot produce different data — it only
          changes what gets visited and how far back the commit window reaches.
          The nightly pass deliberately re-fetches an overlapping window: GitLab
          drops the push event entirely when one push touches more than three
          branches, and the overlap is what heals those gaps.
        </p>
      </header>

      <div className="px-8 py-7 flex flex-col gap-7">
        <Suspense
          fallback={
            <LoadingRegion label="Loading sync">
              <div className="flex flex-col gap-7">
                <SkeletonTiles count={2} />
                <SkeletonTiles count={4} />
                <SkeletonTable rows={6} columns={[170, 130, 90, 80, 70, 160]} />
              </div>
            </LoadingRegion>
          }
        >
          <Panels />
        </Suspense>
      </div>
    </div>
  );
}
