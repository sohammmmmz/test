import {
  LoadingRegion,
  SkeletonHeader,
  SkeletonTable,
  SkeletonTiles,
} from "@/components/Skeleton";

export default function Loading() {
  return (
    <LoadingRegion label="Loading team">
      <div className="flex flex-col">
        <SkeletonHeader />
        <div className="px-8 py-7 flex flex-col gap-7">
          <SkeletonTiles count={4} />
          <SkeletonTable rows={6} columns={[200, 120, 110, 70, 70]} />
        </div>
      </div>
    </LoadingRegion>
  );
}
