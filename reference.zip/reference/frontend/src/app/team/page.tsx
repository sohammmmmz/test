import { redirect } from "next/navigation";
import { TeamManager } from "@/components/TeamManager";
import { Workload } from "@/components/Workload";
import { EmptyState, Eyebrow, Reveal, StatTile } from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import type { Workload as WorkloadData } from "@/lib/types";

export const dynamic = "force-dynamic";

type Summary = {
  total_active: number;
  employees: number;
  interns: number;
  contractors: number;
  unassigned: number;
  unplanned: number;
  unmapped_authors: number;
  unlinked_members: number;
  overallocated: number;
};

export default async function TeamPage() {
  let summary: Summary;
  let workload: WorkloadData | null = null;
  try {
    const [s, w] = await Promise.all([
      api.get<Summary[] | Summary>("/api/team/summary/"),
      // The workload panel is additive; a failure there should not take the
      // roster and counts down with it.
      api.get<WorkloadData>("/api/team/workload/?days=30").catch(() => null),
    ]);
    summary = Array.isArray(s) ? s[0] : s;
    workload = w;
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect("/login?next=/team");
    }
    return (
      <div className="p-8">
        <EmptyState title="Could not load the team" body="The backend did not respond." />
      </div>
    );
  }

  return (
    <div className="flex flex-col">
      <header
        className="px-8 py-7 border-b"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <Eyebrow>Team</Eyebrow>
        <h1 className="text-[26px] font-semibold mt-2 leading-none">
          {summary?.total_active ?? 0} active
        </h1>
        <p className="text-[13px] mt-2" style={{ color: "var(--ink-soft)" }}>
          {summary?.employees ?? 0} employees · {summary?.interns ?? 0} interns ·{" "}
          {summary?.contractors ?? 0} contractors
        </p>
      </header>

      <div className="px-8 py-7 flex flex-col gap-7">
        {/* "Unassigned" counts people on no project at all — neither an
            assignment nor a repository membership. Somebody who belongs to a
            repo with no allocation written down is a planning gap, not an idle
            person, and is counted separately as "no allocation". */}
        <section className="grid gap-3 grid-cols-2 md:grid-cols-5">
          <StatTile
            label="Unassigned"
            value={summary?.unassigned ?? 0}
            hint="on no project at all"
            index={0}
          />
          <StatTile
            label="No allocation"
            value={summary?.unplanned ?? 0}
            hint="on a repo, nothing planned"
            tone={(summary?.unplanned ?? 0) > 0 ? "var(--warn)" : undefined}
            index={1}
          />
          <StatTile
            label="Over 100%"
            value={summary?.overallocated ?? 0}
            hint="committed beyond capacity"
            tone={(summary?.overallocated ?? 0) > 0 ? "var(--crit)" : undefined}
            index={2}
          />
          <StatTile
            label="Unattributed authors"
            value={summary?.unmapped_authors ?? 0}
            hint="git identities to claim"
            tone={(summary?.unmapped_authors ?? 0) > 0 ? "var(--warn)" : undefined}
            index={3}
          />
          <StatTile
            label="Others"
            value={summary?.unlinked_members ?? 0}
            hint="GitLab accounts to designate"
            tone={(summary?.unlinked_members ?? 0) > 0 ? "var(--warn)" : undefined}
            index={4}
          />
        </section>

        {workload && workload.rows.length > 0 && (
          <Reveal index={4} className="flex flex-col gap-4">
            <div>
              <Eyebrow>Workload · last {workload.days} days</Eyebrow>
              <h2 className="text-[17px] font-semibold mt-1.5">
                What each person is actually working on
              </h2>
              <p
                className="text-[12.5px] mt-1.5 max-w-3xl"
                style={{ color: "var(--ink-soft)" }}
              >
                Projects come from repository membership as well as assignments, so
                somebody who is a member of four repos no longer reads as working on
                nothing. The outline on each bar is the plan and the fill is the share
                of their commits that actually landed there —{" "}
                <span style={{ color: "var(--warn)" }}>unplanned</span> means real work
                with no allocation recorded against it.
              </p>
            </div>
            <div className="flex flex-col gap-3">
              {workload.rows.map((row) => (
                <Workload key={row.employee_id} row={row} />
              ))}
            </div>
          </Reveal>
        )}

        <TeamManager />
      </div>
    </div>
  );
}
