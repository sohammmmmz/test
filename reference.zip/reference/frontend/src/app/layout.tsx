import type { Metadata } from "next";
import { Archivo, IBM_Plex_Mono } from "next/font/google";
import { BootSequence } from "@/components/BootSequence";
import { SideRail } from "@/components/SideRail";
import "./globals.css";

// Archivo is an industrial grotesque with a real weight range — deliberately
// not Inter. IBM Plex Mono carries SHAs, counts and micro-labels.
const archivo = Archivo({
  subsets: ["latin"],
  variable: "--font-archivo",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  variable: "--font-plex-mono",
  weight: ["400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Util Tracker",
  description: "GitLab project traceability, compliance and team utilization",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Applied before paint so a stored theme choice never flashes the
            wrong ground colour. */}
        {/* Two decisions that must be made before the first paint. The theme,
            so a stored choice never flashes the wrong ground colour; and
            whether this is the session's first page, so the boot sequence can
            be gated by CSS instead of by a client component that would have to
            render the app first and animate over it. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              `(function(){try{var t=localStorage.getItem('theme');` +
              `if(t&&t!=='system')document.documentElement.setAttribute('data-theme',t);` +
              `if(!sessionStorage.getItem('booted')){` +
              `document.documentElement.setAttribute('data-boot','1');` +
              `sessionStorage.setItem('booted','1')}}catch(e){}})()`,
          }}
        />
      </head>
      <body className={`${archivo.variable} ${plexMono.variable}`}>
        <BootSequence />
        <div className="flex min-h-screen boot-behind">
          <SideRail />
          <div className="flex-1 min-w-0">{children}</div>
        </div>
      </body>
    </html>
  );
}
