import Link from "next/link";
import { redirect } from "next/navigation";
import { EmptyState, Eyebrow, Reveal, StatTile } from "@/components/ui";
import { api, ApiError } from "@/lib/api";
import type { Leaderboard, LeaderboardRow } from "@/lib/types";

export const dynamic = "force-dynamic";

/**
 * Windows the ranking can be read over.
 *
 * Thirty days is the default and the one the score was tuned for. The others
 * exist because "who has been steady this quarter" and "who is working this
 * week" are different questions, and a single fixed window silently answers
 * only one of them.
 */
const WINDOWS = [
  { days: 7, label: "7 days" },
  { days: 30, label: "30 days" },
  { days: 90, label: "90 days" },
] as const;

/** Podium tones for the top three. Everyone else is neutral by design. */
const PODIUM = ["var(--accent)", "var(--ok)", "var(--warn)"];

function scoreTone(score: number): string {
  if (score >= 60) return "var(--ok)";
  if (score >= 30) return "var(--warn)";
  if (score > 0) return "var(--crit)";
  return "var(--ink-faint)";
}

function ScoreBar({ score }: { score: number }) {
  return (
    <div
      className="workload-bar"
      role="img"
      aria-label={`Score ${score} out of 100`}
      title={`${score} / 100`}
    >
      <span
        className="workload-actual"
        style={{ width: `${Math.max(score, 1)}%`, background: scoreTone(score) }}
        aria-hidden
      />
    </div>
  );
}

function Row({
  row,
  componentKeys,
}: {
  row: LeaderboardRow;
  componentKeys: string[];
}) {
  const podium = row.rank <= 3 ? PODIUM[row.rank - 1] : undefined;

  return (
    <tr>
      <td
        className="track"
        style={{ ["--track-color" as string]: podium ?? "var(--line-strong)" }}
      >
        <span
          className="mono text-[15px] font-medium"
          style={{ color: podium ?? "var(--ink-faint)" }}
        >
          {row.rank}
        </span>
      </td>
      <td>
        <div className="font-medium text-[13px]">{row.full_name}</div>
        <div className="text-[10.5px] mt-0.5" style={{ color: "var(--ink-faint)" }}>
          {row.designation || row.employment_type}
          {row.department && ` · ${row.department}`}
        </div>
      </td>
      <td style={{ minWidth: 190 }}>
        <div className="flex items-center gap-2">
          <span
            className="mono text-[14px] font-medium"
            style={{ color: scoreTone(row.score), minWidth: 42 }}
          >
            {row.score}
          </span>
          <div className="flex-1">
            <ScoreBar score={row.score} />
          </div>
        </div>
      </td>
      {componentKeys.map((key) => {
        const value = row.components[key];
        return (
          <td key={key} className="mono text-[12px]">
            {value === null || value === undefined ? (
              <span
                style={{ color: "var(--ink-faint)" }}
                title="Does not apply to this person over this window"
              >
                n/a
              </span>
            ) : (
              <span style={{ color: scoreTone(value) }}>{value}</span>
            )}
          </td>
        );
      })}
      <td className="mono text-[12px]">{row.commits}</td>
      <td className="mono text-[12px]">
        {row.active_days}
        <span style={{ color: "var(--ink-faint)" }}>/{row.expected_days}</span>
      </td>
      <td
        className="mono text-[12px]"
        style={{ color: row.longest_gap > 4 ? "var(--crit)" : "var(--ink-soft)" }}
      >
        {row.longest_gap}
      </td>
      <td className="mono text-[12px]" style={{ color: "var(--ink-soft)" }}>
        {row.current_streak}
      </td>
    </tr>
  );
}

export default async function LeaderboardPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const params = await searchParams;
  const requested = Number(params.days);
  const days = WINDOWS.some((w) => w.days === requested) ? requested : 30;

  let data: Leaderboard;
  try {
    data = await api.get<Leaderboard>(`/api/scoring/leaderboard?days=${days}`);
  } catch (err) {
    if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
      redirect("/login?next=/leaderboard");
    }
    return (
      <div className="p-8">
        <EmptyState
          title="Could not load the leaderboard"
          body="The backend did not respond."
        />
      </div>
    );
  }

  const componentKeys = data.components.map((c) => c.key);
  const leader = data.rows[0];

  return (
    <div className="flex flex-col">
      <header
        className="px-8 py-7 border-b"
        style={{ borderColor: "var(--line)", background: "var(--surface)" }}
      >
        <Eyebrow>
          Leaderboard · {data.window.start} → {data.window.end}
        </Eyebrow>
        <h1 className="text-[26px] font-semibold mt-2 leading-none">
          Commit cadence, ranked
        </h1>
        <p className="text-[13px] mt-2 max-w-2xl" style={{ color: "var(--ink-soft)" }}>
          A rolling {data.window.days}-day window ending today, recomputed on every
          load — nothing here is a stored snapshot, so this and the commit calendar
          can never drift apart. The score rewards steady work over bursts.
        </p>

        <nav className="flex items-center gap-2 mt-4 flex-wrap">
          <span className="eyebrow">Window</span>
          {WINDOWS.map((w) => (
            <Link
              key={w.days}
              href={`/leaderboard?days=${w.days}`}
              className="btn btn-ghost"
              style={
                w.days === days
                  ? { borderColor: "var(--accent)", color: "var(--accent)" }
                  : undefined
              }
            >
              {w.label}
            </Link>
          ))}
        </nav>
      </header>

      <div className="px-8 py-7 flex flex-col gap-7">
        <div
          className="grid gap-3"
          style={{ gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))" }}
        >
          <StatTile
            label="Leading"
            value={leader ? leader.full_name : "—"}
            hint={leader ? `${leader.score} points` : "nobody on the roster"}
            tone="var(--accent)"
            index={0}
          />
          <StatTile
            label="Ranked"
            value={data.totals.people}
            hint="everyone active, including zeros"
            index={1}
          />
          <StatTile
            label="Median score"
            value={data.totals.median_score ?? "—"}
            hint={`mean ${data.totals.mean_score ?? "—"}`}
            index={2}
          />
          <StatTile
            label="Commits"
            value={data.totals.commits}
            hint={`across ${data.window.days} days`}
            index={3}
          />
        </div>

        <Reveal index={4} className="panel scroll-x">
          <table className="data-table" style={{ minWidth: 1020 }}>
            <thead>
              <tr>
                <th style={{ width: 52 }}>#</th>
                <th>Person</th>
                <th>Score</th>
                {data.components.map((c) => (
                  <th
                    key={c.key}
                    title={`${c.description} Weight ${Math.round(c.weight * 100)}%.`}
                  >
                    {c.label}
                    <span className="ml-1" style={{ color: "var(--ink-faint)" }}>
                      {Math.round(c.weight * 100)}%
                    </span>
                  </th>
                ))}
                <th>Commits</th>
                <th title="Days with a commit, against working days in the window">
                  Active
                </th>
                <th title="Longest run of working days with no commit">Gap</th>
                <th title="Working days back from today with a commit each">Streak</th>
              </tr>
            </thead>
            <tbody>
              {data.rows.map((row) => (
                <Row key={row.employee_id} row={row} componentKeys={componentKeys} />
              ))}
              {data.rows.length === 0 && (
                <tr>
                  <td
                    colSpan={7 + data.components.length}
                    className="text-center py-10"
                    style={{ color: "var(--ink-faint)" }}
                  >
                    No active team members to rank.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </Reveal>

        <Reveal index={5} className="panel p-4 flex flex-col gap-3">
          <h2 className="text-[13px] font-semibold">How the score is built</h2>
          {/* Rendered from the API rather than restated here, so the page can
              never describe a formula the backend has stopped using. */}
          <ul className="flex flex-col gap-2.5">
            {data.components.map((c) => (
              <li key={c.key} className="flex gap-3 text-[12.5px]">
                <span
                  className="mono shrink-0"
                  style={{ color: "var(--accent)", width: 40 }}
                >
                  {Math.round(c.weight * 100)}%
                </span>
                <span>
                  <span className="font-medium">{c.label}</span>
                  <span style={{ color: "var(--ink-soft)" }}> — {c.description}</span>
                </span>
              </li>
            ))}
          </ul>
          <p className="text-[11.5px]" style={{ color: "var(--ink-faint)" }}>
            A component that cannot be computed for someone shows as{" "}
            <span className="mono">n/a</span> and its weight is redistributed across
            the rest, so a person in their first week is ranked on what they have
            actually had the chance to do.
          </p>
        </Reveal>

        <Reveal index={6}>
          <p
            className="text-[12px] max-w-3xl leading-relaxed"
            style={{ color: "var(--ink-faint)" }}
          >
            <span style={{ color: "var(--ink-soft)" }}>What this does not measure.</span>{" "}
            Difficulty, correctness, review work, mentoring, debugging that ends in a
            one-line fix, or the research that correctly concludes not to build
            something. The hardest problem of someone&apos;s month is often the smallest
            diff, and it will rank below a day of renaming variables. This is a ranking
            of commit cadence, which is all a commit log can honestly report — read it
            as a description of a working pattern, not of a person, and never as the
            input to a decision about one.
          </p>
        </Reveal>
      </div>
    </div>
  );
}
